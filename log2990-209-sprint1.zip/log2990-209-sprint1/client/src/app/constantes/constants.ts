export const DEFAULT_WIDTH = 1000;
export const DEFAULT_HEIGHT = 800;
export const COLOR_PICKER_WIDTH = 50;
export const COLOR_SLIDER_HEIGHT = 250;
export const CURSOR_SIZE = 10;
export const MAXIMUM_COLOR = 10;

export const ZERO_DEGREE = 0;
export const PI_ON_4_DEGREE = 45;
export const PI_ON_2_DEGREE = 90;
export const THREE_PI_ON_4_DEGREE = 135;
export const PI_DEGREE = 180;
export const FIVE_PI_ON_4_DEGREE = 225;
export const THREE_PI_ON_2_DEGREE = 270;
export const SEVEN_PI_ON_4_DEGREE = 315;
export const TWO_PI_DEGREE = 360;

export const MIN_ZERO_DEGREE = 337.5;
export const MIN_PI_ON_4_DEGREE = 22.5;
export const MIN_PI_ON_2_DEGREE = 67.5;
export const MIN_THREE_PI_ON_4_DEGREE = 112.5;
export const MIN_PI_DEGREE = 157.5;
export const MIN_FIVE_PI_ON_4_DEGREE = 202.5;
export const MIN_THREE_PI_ON_2_DEGREE = 247.5;
export const MIN_SEVEN_PI_ON_4_DEGREE = 292.5;

export const CLOSED_LINE = 20;
export const JOIN_MIN_RADIUS = 2;
export const NB_TOOLS = 6;

export const ANGLE_BRUSH = 25;
export const IMAGES_BY_POINT = 5;
export const ERASE_INDEX = 4;
export const WIDTH_RATE = 4;
