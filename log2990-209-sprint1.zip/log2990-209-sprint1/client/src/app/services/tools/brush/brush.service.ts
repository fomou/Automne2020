import { Injectable } from '@angular/core';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import * as cte from '@app/constantes/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { Texture } from '@app/enums/texture-number';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { SidebarService } from '@app/services/tools/slide-bar/sidebar.service';

@Injectable({
    providedIn: 'root',
})
export class BrushService extends Tool {
    private pathData: Vec2[];
    private img: HTMLImageElement = new Image();
    private color: string;
    constructor(drawingService: DrawingService, private sidebarService: SidebarService, private colorSelectorService: ColorSelectorService) {
        super(drawingService);
        this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });
        this.img.src = '../../../assets/snow.svg';
        this.clearPath();
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.clearPath();
            this.mouseDownCoord = this.getPositionFromMouse(event);
            this.pathData.push(this.mouseDownCoord);
            this.drawPoint(this.drawingService.baseCtx, this.mouseDownCoord.x, this.mouseDownCoord.y);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown) {
            const mousePosition = this.getPositionFromMouse(event);
            this.pathData.push(mousePosition);
            this.drawImage(this.drawingService.baseCtx, this.pathData);
        }
        this.mouseDown = false;
        this.clearPath();
    }

    onMouseMove(event: MouseEvent): void {
        this.initialiserTexture(this.drawingService.previewCtx);
        if (this.mouseDown) {
            this.changeTexture(this.drawingService.previewCtx, event);
        }
    }
    onMouseLeave(event: MouseEvent): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.drawImage(this.drawingService.baseCtx, this.pathData);
        this.clearPath();
        this.mouseDown = false;
    }

    onMouseEnter(event: MouseEvent): void {
        if (event.buttons === 1) {
            this.mouseDown = true;
        }
    }

    private changeTexture(ctx: CanvasRenderingContext2D, event: MouseEvent): void {
        const mousePosition = this.getPositionFromMouse(event);
        this.pathData.push(mousePosition);
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.drawImage(this.drawingService.previewCtx, this.pathData);
    }

    private initialiserTexture(ctx: CanvasRenderingContext2D): void {
        ctx.lineJoin = ctx.lineCap = 'round';
        switch (this.sidebarService.textureNum) {
            case Texture.texture1:
                this.img.src = '../../../assets/snow.svg';
                break;
            case Texture.texture2:
                this.img.src = '../../../assets/star.svg';
                break;
            case Texture.texture3:
                this.img.src = '../../../assets/boxes.svg';
                break;
            case Texture.texture4:
                this.img.src = '../../../assets/arrow-left.svg';
                break;
            case Texture.texture5:
                this.img.src = '../../../assets/circle.svg';
                break;
        }
    }

    private getImage(): HTMLCanvasElement {
        const canvas: HTMLCanvasElement = document.createElement('canvas');
        canvas.width = this.img.width;
        canvas.height = this.img.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.fillStyle = this.color;
        copyCanvas.fillRect(0, 0, this.img.width, this.img.height);
        copyCanvas.globalCompositeOperation = 'destination-in';
        copyCanvas.drawImage(this.img, 0, 0, this.img.width / this.sidebarService.brushWidth, this.img.height / this.sidebarService.brushWidth);
        return canvas;
    }

    private drawImage(ctx: CanvasRenderingContext2D, path: Vec2[]): void {
        ctx.beginPath();
        const size: number = path.length;
        const canvasImage: HTMLCanvasElement = this.getImage();
        for (let i = 0; i < size - 1; i++) {
            const dist: number = this.distanceBetween(path[i], path[i + 1]);
            const angle: number = this.angleBetween(path[i], path[i + 1]);
            for (let j = 0; j < dist; j = j + cte.IMAGES_BY_POINT) {
                const x: number = path[i].x + Math.sin(angle) * j - cte.ANGLE_BRUSH;
                const y: number = path[i].y + Math.cos(angle) * j - cte.ANGLE_BRUSH;
                ctx.drawImage(canvasImage, x, y);
            }
        }
        ctx.stroke();
    }

    private drawPoint(ctx: CanvasRenderingContext2D, pointX: number, pointY: number): void {
        ctx.beginPath();
        const canvasImage: HTMLCanvasElement = this.getImage();
        ctx.drawImage(canvasImage, pointX - canvasImage.width / 2, pointY - canvasImage.height / 2); // centrer l image au niveau du curseur
        ctx.stroke();
    }

    private distanceBetween(point1: Vec2, point2: Vec2): number {
        return Math.sqrt(Math.pow(point2.x - point1.x, 2) + Math.pow(point2.y - point1.y, 2));
    }

    private angleBetween(point1: Vec2, point2: Vec2): number {
        return Math.atan2(point2.x - point1.x, point2.y - point1.y);
    }

    private clearPath(): void {
        this.pathData = [];
    }
}
