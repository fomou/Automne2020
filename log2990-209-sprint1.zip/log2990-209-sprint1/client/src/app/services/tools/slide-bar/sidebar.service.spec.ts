import { TestBed } from '@angular/core/testing';

import { SidebarService } from './sidebar.service';

describe('SidebarService', () => {
    let service: SidebarService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(SidebarService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('changeWidth should set width', () => {
        const widthExpect = 5;
        service.changeWidth(widthExpect);
        expect(service.width).toEqual(widthExpect);
    });

    it('changeBrushWidth should set brushWidth', () => {
        const brushWidthExpect = 50;
        service.changeBrushWidth(brushWidthExpect);
        expect(service.brushWidth).toEqual(brushWidthExpect);
    });

    it('selectTexture should set textureNumber', () => {
        const textureNumExpect = 2;
        service.selectTexture(textureNumExpect);
        expect(service.textureNum).toEqual(textureNumExpect);
    });

    it('changeBrushWidth should set brushWidth', () => {
        const eraserSizeExpect = 20;
        service.changeEraserSize(eraserSizeExpect);
        expect(service.eraserSize).toEqual(eraserSizeExpect);
    });
});
