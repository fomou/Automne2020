import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingType } from '@app/enums/draw-type';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { EllipseService } from './ellipse.service';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable:no-magic-numbers :

describe('EllipseService', () => {
    let service: EllipseService;
    let mouseEvent: MouseEvent;
    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let drawEllipseSpy: jasmine.Spy<any>;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(EllipseService);
        drawEllipseSpy = spyOn<any>(service, 'drawEllipse').and.callThrough();
        service.drawingService.baseCtx = baseCtxStub; // Jasmine doesnt copy properties with underlying data
        service.drawingService.previewCtx = previewCtxStub;
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('onKeyDown should set shiftPressed to true if shift is hited', () => {
        service.shiftPressed = false;
        const event = { code: 'ShiftLeft' } as KeyboardEvent;
        service.onKeyDown(event);
        expect(service.shiftPressed).toEqual(true);
    });

    it('onKeyUp should set shiftPressed to false if shift is released', () => {
        service.shiftPressed = true;
        const event = { code: 'ShiftLeft' } as KeyboardEvent;
        service.onKeyUp(event);
        expect(service.shiftPressed).toEqual(false);
    });

    it(' mouseDown should set firstPoint to correct position', () => {
        const expectedResult: Vec2 = { x: 25, y: 25 };
        service.onMouseDown(mouseEvent);
        expect(service.firstPoint).toEqual(expectedResult);
    });

    it(' mouseDown should set mouseDown property to true on left click', () => {
        service.onMouseDown(mouseEvent);
        expect(service.mouseDown).toEqual(true);
    });

    it(' mouseDown should set mouseDown property to false on right click', () => {
        const mouseEventRClick = {
            offsetX: 25,
            offsetY: 25,
            button: 1, // TODO: Avoir ceci dans un enum accessible
        } as MouseEvent;
        service.onMouseDown(mouseEventRClick);
        expect(service.mouseDown).toEqual(false);
    });

    it(' onMouseUp should call drawEllipse if mouse was already down', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.mouseDown = true;
        service.lastPoint = service.getPositionFromMouse(mouseEvent);
        service.onMouseUp(mouseEvent);
        expect(drawEllipseSpy).toHaveBeenCalled();
    });

    it(' onMouseUp should not call drawEllipse if mouse was not already down', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.mouseDown = false;
        service.lastPoint = service.getPositionFromMouse(mouseEvent);
        service.onMouseUp(mouseEvent);
        expect(drawEllipseSpy).not.toHaveBeenCalled();
        expect(service.mouseDown).toEqual(false);
    });

    it(' onMouseUp should  call drawEllipse if mouse was and shift is pressed down', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.mouseDown = true;
        service.shiftPressed = true;
        service.lastPoint = service.getPositionFromMouse(mouseEvent);
        service['circleCenter'] = { x: 10, y: 10 };
        service.onMouseUp(mouseEvent);
        expect(drawEllipseSpy).toHaveBeenCalled();
        expect(service.mouseDown).toEqual(false);
    });

    it(' onMouseMove should not call drawLine if mouse was not already down', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.mouseDown = false;
        service.lastPoint = service.getPositionFromMouse(mouseEvent);
        service.onMouseMove(mouseEvent);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
        expect(drawEllipseSpy).not.toHaveBeenCalled();
    });

    it(' onMouseMove should not call getCenter if shift is pressed ', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.mouseDown = true;
        service.lastPoint = service.getPositionFromMouse(mouseEvent);
        service.shiftPressed = true;
        service['circleCenter'] = { x: 4, y: 2 };
        service.onMouseMove(mouseEvent);
        const getCenterSpy = spyOn<any>(service, 'getCenter').and.callThrough();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawEllipseSpy).toHaveBeenCalled();
        expect(getCenterSpy).not.toHaveBeenCalled();
    });

    it(' onMouseMove should call getCenter if shift is not  down', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.mouseDown = true;
        service.shiftPressed = false;
        const getCenterSpy = spyOn<any>(service, 'getCenter').and.callThrough();
        service.onMouseMove(mouseEvent);
        expect(getCenterSpy).toHaveBeenCalled();
        expect(drawEllipseSpy).toHaveBeenCalled();
    });

    it(' onKeyDown should call drawEllipse and getCenter if shift is  down', () => {
        service.firstPoint = { x: 0, y: 0 } as Vec2;
        service.lastPoint = { x: 25, y: 25 } as Vec2;
        service.shiftPressed = true;
        service.mouseDown = true;
        service.drawingType = DrawingType.fill;
        const keyboardEvent = { code: 'ShiftLeft' } as KeyboardEvent;
        const getCenterSpy = spyOn<any>(service, 'getCenter').and.callThrough();
        service.onKeyDown(keyboardEvent);
        expect(getCenterSpy).toHaveBeenCalled();
        expect(drawEllipseSpy).toHaveBeenCalled();
    });

    it(' onKeyDown should not call  if shift is down and mouse is up', () => {
        service.firstPoint = { x: 0, y: 0 };
        const keyboardEvent = { code: 'ShiftLeft' } as KeyboardEvent;
        service.mouseDown = false;
        service.lastPoint = { x: 25, y: 25 };
        service.onKeyDown(keyboardEvent);
        expect(drawEllipseSpy).not.toHaveBeenCalled();
    });

    it(' onKeyUp should  call drawEllipse if shift is up and mouse is down', () => {
        service.firstPoint = { x: 0, y: 0 };
        const keyboardEvent = { code: 'ShiftLeft' } as KeyboardEvent;
        service.mouseDown = true;
        service.shiftPressed = true;
        service.lastPoint = { x: 25, y: 25 };
        service.onKeyUp(keyboardEvent);
        expect(drawEllipseSpy).toHaveBeenCalled();
        expect(service.shiftPressed).toEqual(false);
    });

    it(' onKeyUp should  not set shiftpressed to false is another key is up', () => {
        service.firstPoint = { x: 0, y: 0 };
        const keyboardEvent = { code: '' } as KeyboardEvent;
        service.mouseDown = true;
        service.shiftPressed = true;
        service.lastPoint = { x: 25, y: 25 };
        service.onKeyUp(keyboardEvent);
        expect(drawEllipseSpy).toHaveBeenCalled();
        expect(service.shiftPressed).toEqual(true);
    });

    it('should give right radiusX and radiusY', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.lastPoint = { x: 10, y: 6 };

        expect(service.radiusX).toEqual(5);
    });

    it('should unsubscribe on destroy', () => {
        service.ngOnDestroy();
        expect(service.subscription.closed).toEqual(true);
    });

    it('should give the center', () => {
        let startPoint = { x: 0, y: 0 } as Vec2;
        let endPoint = { x: 10, y: 6 } as Vec2;

        expect(service['getCenter'](startPoint, endPoint)).toEqual({ x: 5, y: 3 });

        startPoint = { x: 10, y: 0 } as Vec2;
        endPoint = { x: 0, y: 6 } as Vec2;

        expect(service['getCenter'](startPoint, endPoint)).toEqual({ x: 5, y: 3 });

        startPoint = { x: 10, y: 6 } as Vec2;
        endPoint = { x: 0, y: 0 } as Vec2;

        expect(service['getCenter'](startPoint, endPoint)).toEqual({ x: 5, y: 3 });
    });

    // Test  drawEllipse Fill
    it(' should call  fill and stroke at the same time in outline style ', () => {
        service.shiftPressed = false;
        service.lastPoint = { x: 10, y: 10 };
        service.firstPoint = { x: 11, y: 30 };
        service.drawingType = DrawingType.stroke;
        const strokeSpy = spyOn<any>(baseCtxStub, 'stroke').and.callThrough();
        const center = { x: 10, y: 10 } as Vec2;
        service['drawEllipse'](baseCtxStub, center);
        expect(strokeSpy).toHaveBeenCalled();
    });

    it(' should call  fill and stroke at the same time in outline style ', () => {
        service.drawingService.baseCtx = baseCtxStub;

        const spy = spyOn<any>(baseCtxStub, 'fill');
        const strokeSpy = spyOn<any>(baseCtxStub, 'stroke').and.callThrough();
        service.drawingType = 'outline';
        service.lastPoint = { x: 10, y: 10 };
        service.firstPoint = { x: 11, y: 30 };
        const center = { x: 10, y: 10 } as Vec2;
        service['drawEllipse'](baseCtxStub, center);

        expect(spy).toHaveBeenCalled();
        expect(strokeSpy).toHaveBeenCalled();
    });
});
