import { Injectable, OnDestroy } from '@angular/core';
import { ShapeTool } from '@app/classes/shape-tool';
import { Vec2 } from '@app/classes/vec2';
import { DrawingType } from '@app/enums/draw-type';
import { Keyboard } from '@app/enums/key-board';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { DrawingTypeSelectorService } from '@app/services/tools/drawing-type/drawing-type-selector.service';
import { SidebarService } from '@app/services/tools/slide-bar/sidebar.service';
import { Subscription } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class EllipseService extends ShapeTool implements OnDestroy {
    subscription: Subscription;
    private circleCenter: Vec2;

    constructor(
        private colorSelectorService: ColorSelectorService,
        drawingService: DrawingService,
        private sidebarService: SidebarService,
        drawingTypeSelectorService: DrawingTypeSelectorService,
    ) {
        super(drawingService);
        this.shiftPressed = false;
        this.subscription = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.primaryColor = color;
        });

        this.colorSelectorService.secondaryColor$.subscribe((color) => {
            this.secondaryColor = color;
        });
        drawingTypeSelectorService.drawingType$.subscribe((type) => {
            this.drawingType = type;
        });
    }

    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }

    private getCenter(startPoint: Vec2, endPoint: Vec2): Vec2 {
        let y = Math.abs(endPoint.y - startPoint.y) / 2;
        let x = Math.abs(startPoint.x - endPoint.x) / 2;

        x = endPoint.x > startPoint.x ? startPoint.x + x : startPoint.x - x;
        y = endPoint.y > startPoint.y ? startPoint.y + y : startPoint.y - y;

        return { x, y };
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.firstPoint = this.getPositionFromMouse(event);
            this.circleCenter = this.firstPoint;
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown && this.shiftPressed) {
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawEllipse(this.drawingService.baseCtx, this.circleCenter);
        } else if (this.mouseDown) {
            this.lastPoint = this.getPositionFromMouse(event);
            const center = this.getCenter(this.firstPoint, this.lastPoint);
            this.drawEllipse(this.drawingService.baseCtx, center);
        }
        this.mouseDown = false;
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown && this.shiftPressed) {
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawEllipse(this.drawingService.previewCtx, this.circleCenter);
        } else if (this.mouseDown) {
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            const center = this.getCenter(this.firstPoint, this.lastPoint);
            this.drawEllipse(this.drawingService.previewCtx, center);
        }
    }

    onKeyDown(event: KeyboardEvent): void {
        this.shiftPressed = event.code === Keyboard.shift;
        if (this.shiftPressed && this.mouseDown) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.circleCenter = this.getCenter(this.firstPoint, this.lastPoint);
            this.drawEllipse(this.drawingService.previewCtx, this.circleCenter);
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        if (event.code === Keyboard.shift) {
            this.shiftPressed = false;
        }
        if (this.mouseDown) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            const center = this.getCenter(this.firstPoint, this.lastPoint);
            this.drawEllipse(this.drawingService.previewCtx, center);
        }
    }

    private drawEllipse(ctx: CanvasRenderingContext2D, center: Vec2): void {
        const radiusX = this.radiusX;
        let radiusY = this.radiusY;

        if (this.shiftPressed) {
            radiusY = radiusX;
        }

        switch (this.drawingType) {
            case DrawingType.stroke:
                ctx.beginPath();
                ctx.lineWidth = this.sidebarService.widthShape;
                ctx.strokeStyle = this.primaryColor;
                ctx.ellipse(center.x, center.y, radiusX, radiusY, 0, 0, Math.PI * 2);
                ctx.stroke();
                ctx.closePath();
                break;

            case DrawingType.fill:
                ctx.beginPath();
                ctx.fillStyle = this.primaryColor;
                ctx.ellipse(center.x, center.y, radiusX, radiusY, 0, 0, Math.PI * 2);
                ctx.fill();
                ctx.closePath();

                break;

            case DrawingType.outline:
                ctx.lineWidth = this.sidebarService.widthShape;
                ctx.beginPath();
                ctx.strokeStyle = this.secondaryColor;
                ctx.ellipse(center.x, center.y, radiusX, radiusY, 0, 0, Math.PI * 2);
                ctx.stroke();
                ctx.closePath();
                ctx.beginPath();
                ctx.fillStyle = this.primaryColor;
                ctx.ellipse(center.x, center.y, radiusX, radiusY, 0, 0, Math.PI * 2);
                ctx.fill();
                ctx.closePath();

            default:
                break;
        }
    }

    get radiusY(): number {
        return Math.abs(this.firstPoint.y - this.lastPoint.y) / 2;
    }

    get radiusX(): number {
        return Math.abs(this.lastPoint.x - this.firstPoint.x) / 2;
    }
}
