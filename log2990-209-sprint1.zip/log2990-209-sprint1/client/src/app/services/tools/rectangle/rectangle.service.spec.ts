import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingType } from '@app/enums/draw-type';
import { DrawingService } from '@app/services//drawing/drawing.service';
import { RectangleService } from './rectangle.service';

// tslint:disable: no-string-literal
describe('RectangleService', () => {
    let service: RectangleService;
    let mouseEvent: MouseEvent;
    let drawServiceSpy: jasmine.SpyObj<DrawingService>;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;
    // tslint:disable: no-any
    let drawRectangleSpy: jasmine.Spy<any>;
    let fakeMousePositionSpy: jasmine.Spy<any>;
    let getPositionSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(RectangleService);
        drawRectangleSpy = spyOn<any>(service, 'drawRectangle').and.callThrough();
        fakeMousePositionSpy = spyOn<any>(service, 'fakeMousePosition').and.callThrough();
        getPositionSpy = spyOn<any>(service, 'getPositionFromMouse').and.callThrough();
        service.drawingService.baseCtx = baseCtxStub; // Jasmine doesnt copy properties with underlying data
        service.drawingService.previewCtx = previewCtxStub;

        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            button: 0,
        } as MouseEvent;
    });
    // tslint:disable: no-magic-numbers
    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it(' mouseDown should set first point  to correct position', () => {
        const expectedResult: Vec2 = { x: 25, y: 25 };
        service.onMouseDown(mouseEvent);
        expect(service.firstPoint).toEqual(expectedResult);
    });

    it(' mouseDown should not  first point  if the mouse ', () => {
        const event = { button: 2 } as MouseEvent;
        service.onMouseDown(event);
        expect(getPositionSpy).not.toHaveBeenCalled();
    });

    it(' onMouseMove should call rectangle if mouse was already down', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        service.mouseDown = true;

        service.onMouseMove(mouseEvent);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawRectangleSpy).toHaveBeenCalled();
    });

    it(' onMouseUp should call drawRectangle if mouse was already down and set mouseDown to false', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        service.mouseDown = true;

        service.onMouseUp(mouseEvent);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawRectangleSpy).toHaveBeenCalled();
        expect(service.mouseDown).toEqual(false);
    });

    it(' onMouseUp should call drawRectangle if mouse was already down and set mouseDown to false', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        service.mouseDown = false;

        service.onMouseUp(mouseEvent);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
        expect(drawRectangleSpy).not.toHaveBeenCalled();
        expect(getPositionSpy).not.toHaveBeenCalled();
    });

    it(' onMouseUp should call drawRectangle and fakeMousePosition if mouse was already down and shift is pressed', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        service.mouseDown = true;
        service.shiftPressed = true;

        service.onMouseUp(mouseEvent);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawRectangleSpy).toHaveBeenCalled();
        expect(getPositionSpy).toHaveBeenCalled();
        expect(fakeMousePositionSpy).toHaveBeenCalled();
    });

    it(' #fakeMousePosition  should fake current mouse position', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.lastPoint = { x: 10, y: 6 };
        const expectFakepoint = { x: 10, y: 10 };
        service.mouseDown = true;
        service.shiftPressed = true;

        // tslint:disable-next-line:no-string-literal
        const fakePoint = service['fakeMousePosition'](service.lastPoint, service.firstPoint);

        expect(fakePoint).toEqual(expectFakepoint);
    });

    it(' onMouseMove should call fakeMouse if mouse was already down and shift is pressed', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        service.mouseDown = true;
        service.shiftPressed = true;

        service.onMouseMove(mouseEvent);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawRectangleSpy).toHaveBeenCalled();
        // tslint:disable-next-line:no-string-literal
        expect(fakeMousePositionSpy).toHaveBeenCalled();
    });

    it('onMouseMove should not call fakeMousePosition if mouse was already down and sift is not pressed', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        service.mouseDown = true;
        service.shiftPressed = false;

        service.onMouseMove(mouseEvent);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawRectangleSpy).toHaveBeenCalled();
        expect(fakeMousePositionSpy).not.toHaveBeenCalledWith(service.lastPoint, service.firstPoint);
    });

    it('onMouseMove should not call fakeMousePosition if mouse was already down and sift is not pressed', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        service.mouseDown = false;
        service.shiftPressed = true;

        service.onMouseMove(mouseEvent);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
        expect(drawRectangleSpy).not.toHaveBeenCalled();
        expect(fakeMousePositionSpy).not.toHaveBeenCalledWith(service.lastPoint, service.firstPoint);
    });

    it('onKeyDwn should set shiftPressed to true and call drawRectangle and fakeMousePosition', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        const keyboardEvent = { code: 'ShiftLeft' } as KeyboardEvent;
        service.mouseDown = true;
        service.shiftPressed = false;

        service.onKeyDown(keyboardEvent);
        expect(service.shiftPressed).toEqual(true);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawRectangleSpy).toHaveBeenCalled();
        expect(fakeMousePositionSpy).toHaveBeenCalledWith(service.lastPoint, service.firstPoint);
    });

    it('onKeyDwn should not call drawRectangle and fakeMousePosition if shift is not pressed', () => {
        service.lastPoint = { x: 0, y: 0 };
        service.firstPoint = { x: 25, y: 25 };
        const keyboardEvent = { code: 'ShiftLeft' } as KeyboardEvent;
        service.mouseDown = false;
        service.shiftPressed = false;

        service.onKeyDown(keyboardEvent);
        expect(service.shiftPressed).toEqual(true);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
        expect(drawRectangleSpy).not.toHaveBeenCalled();
        expect(fakeMousePositionSpy).not.toHaveBeenCalledWith(service.lastPoint, service.firstPoint);
    });

    it('onKeyUp should set shiftpressed to false and call clearCanvas an drawrectangle if mouse is already down', () => {
        const event = {} as KeyboardEvent;
        service.firstPoint = { x: 0, y: 0 };
        service.lastPoint = { x: 1, y: 3 };
        service.shiftPressed = true;
        service.mouseDown = true;
        service.onKeyUp(event);
        expect(service.shiftPressed).toEqual(false);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawRectangleSpy).toHaveBeenCalled();
    });

    it('onKeyUp should not call clearCanvas, drawrectangle if mouse is not down', () => {
        const event = {} as KeyboardEvent;
        service.mouseDown = false;
        service.onKeyUp(event);
        expect(service.shiftPressed).toEqual(false);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
        expect(drawRectangleSpy).not.toHaveBeenCalled();
    });

    it('should return right top left point ', () => {
        let startPoint = { x: 0, y: 0 };
        let endpoint = { x: 10, y: 10 };
        // tslint: no-string-literal
        expect(service['findTopLeftPoint'](startPoint, endpoint)).toEqual(startPoint);

        startPoint = { x: 10, y: 10 };
        endpoint = { x: 0, y: 0 };
        expect(service['findTopLeftPoint'](startPoint, endpoint)).toEqual(endpoint);

        startPoint = { x: 0, y: 10 };
        endpoint = { x: 10, y: 0 };
        expect(service['findTopLeftPoint'](startPoint, endpoint)).toEqual({ x: 0, y: 0 });

        startPoint = { x: 10, y: 0 };
        endpoint = { x: 0, y: 10 };
        expect(service['findTopLeftPoint'](startPoint, endpoint)).toEqual({ x: 0, y: 0 });
    });

    it('should give correct width and heigth', () => {
        service.firstPoint = { x: 0, y: 0 };
        service.lastPoint = { x: 1, y: 3 };

        expect(service['width']).toEqual(1);
        expect(service['height']).toEqual(3);
        expect(service['squareWidth']).toEqual(3);

        service.firstPoint = { x: 0, y: 0 };
        service.lastPoint = { x: 3, y: 2 };
        expect(service['squareWidth']).toEqual(3);
    });

    it('should change pixel on the canvas on fill style', () => {
        service.drawingType = DrawingType.fill;
        mouseEvent = { offsetX: 0, offsetY: 0, button: 0 } as MouseEvent;
        service.onMouseDown(mouseEvent);
        mouseEvent = { offsetX: 10, offsetY: 10, button: 0 } as MouseEvent;
        service.onMouseUp(mouseEvent);
        service.primaryColor = '#0000FF';

        const imageData = baseCtxStub.getImageData(5, 5, 2, 2).data;

        expect(imageData[0]).toEqual(0);
        expect(imageData[1]).toEqual(0);
        // tslint:disable-next-line: no-magic-numbers
        expect(imageData[3]).toEqual(255);
    });

    it('should change pixel on the canvas on stroke still', () => {
        service.drawingType = DrawingType.stroke;
        mouseEvent = { offsetX: 0, offsetY: 0, button: 0 } as MouseEvent;
        service.onMouseDown(mouseEvent);
        mouseEvent = { offsetX: 10, offsetY: 10, button: 0 } as MouseEvent;
        service.onMouseUp(mouseEvent);
        service.primaryColor = '#0000FF';

        const imageData = baseCtxStub.getImageData(5, 5, 1, 1).data;

        expect(imageData[0]).toEqual(0);
        expect(imageData[1]).toEqual(0);
        expect(imageData[3]).toEqual(255);
    });

    // Test setters
    it('setLineWidth should set lineWitdh property to a new value', () => {
        service.setLineWidth(1);
        expect(service['lineWidth']).toEqual(1);
    });

    // Test fakeMousPosition
    it('fakeMousePosition should returne the correct point', () => {
        const currentPoint = { x: 10, y: 10 };
        const previewPoint = { x: 20, y: 15 };
        const expectedResult: Vec2 = { x: 10, y: 5 };
        const result = service['fakeMousePosition'](currentPoint, previewPoint);
        expect(result).toEqual(expectedResult);
    });

    it('fakeMousePosition should returne the correct point v2', () => {
        const currentPoint = { x: 10, y: 20 };
        const previewPoint = { x: 20, y: 10 };
        const expectedResult: Vec2 = { x: 10, y: 20 };
        const result = service['fakeMousePosition'](currentPoint, previewPoint);
        expect(result).toEqual(expectedResult);
    });

    // it('should change pixel on the canvas on stroke style', () => {
    //     service.drawingType = '';
    //     mouseEvent = { offsetX: 0, offsetY: 0, button: 0 } as MouseEvent;
    //     service.onMouseDown(mouseEvent);
    //     mouseEvent = { offsetX: 10, offsetY: 10, button: 0 } as MouseEvent;
    //     service.primaryColor = '#0000FF';
    //     service.secondaryColor = '#FF0000';
    //     service.onMouseUp(mouseEvent);
    //     const imageData = baseCtxStub.getImageData(5, 5, 1, 1).data;

    //     expect(imageData[0]).toEqual(0);
    //     expect(imageData[1]).toEqual(0);
    //     expect(imageData[3]).toEqual(0);
    // });

    // it('should change pixel on the canvas on stroke still', () => {
    //     service.drawingType = DrawingType.outline;
    //     mouseEvent = { offsetX: 0, offsetY: 0, button: 0 } as MouseEvent;
    //     service.onMouseDown(mouseEvent);
    //     mouseEvent = { offsetX: 10, offsetY: 10, button: 0 } as MouseEvent;
    //     service.primaryColor = '#0000FF';
    //     service.secondaryColor = '#FF0000';
    //     service.onMouseUp(mouseEvent);
    //     const imageData = baseCtxStub.getImageData(5, 5, 1, 1).data;
    //     expect(imageData[0]).toEqual(0);
    //     expect(imageData[1]).toEqual(0);
    //     expect(imageData[3]).toEqual(255);
    // });
});
