import { Injectable } from '@angular/core';
import { ShapeTool } from '@app/classes/shape-tool';
import { Vec2 } from '@app/classes/vec2';
import { DrawingType } from '@app/enums/draw-type';
import { Keyboard } from '@app/enums/key-board';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { DrawingTypeSelectorService } from '@app/services/tools/drawing-type/drawing-type-selector.service';
import { SidebarService } from '@app/services/tools/slide-bar/sidebar.service';

@Injectable({
    providedIn: 'root',
})
export class RectangleService extends ShapeTool {
    path: Vec2[];

    constructor(
        drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private sidebarService: SidebarService,
        drawingType: DrawingTypeSelectorService,
    ) {
        super(drawingService);
        this.shiftPressed = false;
        this.mouseDown = false;
        this.path = [];

        this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.primaryColor = color;
        });

        this.colorSelectorService.secondaryColor$.subscribe((color) => {
            this.secondaryColor = color;
        });

        drawingType.drawingType$.subscribe((type) => {
            this.drawingType = type;
        });
    }

    setLineWidth(width: number): void {
        this.lineWidth = width;
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.firstPoint = this.getPositionFromMouse(event);
            this.path.push(this.getPositionFromMouse(event));
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown && this.shiftPressed) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.path.push(this.getPositionFromMouse(event));
            this.lastPoint = this.getPositionFromMouse(event);
            const lastPoint = this.fakeMousePosition(this.lastPoint, this.firstPoint);
            this.drawRectangle(this.drawingService.baseCtx, this.firstPoint, lastPoint);
        } else if (this.mouseDown) {
            this.lastPoint = this.getPositionFromMouse(event);
            this.path.push(this.getPositionFromMouse(event));
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            // const topLeftPoint = this.findTopLeftPoint(this.firstPoint, this.lastPoint);
            this.drawRectangle(this.drawingService.baseCtx, this.firstPoint, this.lastPoint);
        }
        this.mouseDown = false;
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown && this.shiftPressed) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.path.push(this.getPositionFromMouse(event));
            this.lastPoint = this.getPositionFromMouse(event);
            const lastPoint = this.fakeMousePosition(this.lastPoint, this.firstPoint);
            this.drawRectangle(this.drawingService.previewCtx, this.firstPoint, lastPoint);
        } else if (this.mouseDown) {
            this.lastPoint = this.getPositionFromMouse(event);
            this.path.push(this.getPositionFromMouse(event));
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawRectangle(this.drawingService.previewCtx, this.firstPoint, this.lastPoint);
        }
    }

    onKeyDown(event: KeyboardEvent): void {
        this.shiftPressed = event.code === Keyboard.shift;
        if (this.shiftPressed && this.mouseDown) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            const lastPoint = this.fakeMousePosition(this.lastPoint, this.firstPoint);
            // const topLeftPoint=this.findTopLeftPoint(this.firstPoint,this.lastPoint)
            this.drawRectangle(this.drawingService.previewCtx, this.firstPoint, lastPoint);
        }
    }

    onKeyUp(event?: KeyboardEvent): void {
        this.shiftPressed = false;
        if (this.mouseDown) {
            // const point = this.path[this.path.length - 1];
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            console.log(this.lastPoint);
            this.drawRectangle(this.drawingService.previewCtx, this.firstPoint, this.lastPoint);
        }
    }

    private drawRectangle(ctx: CanvasRenderingContext2D, startPoint: Vec2, endPoint: Vec2): void {
        const point = this.findTopLeftPoint(startPoint, endPoint);

        switch (this.drawingType) {
            case DrawingType.fill:
                console.log(endPoint);
                ctx.fillStyle = this.primaryColor;
                ctx.fillRect(point.x, point.y, this.width, this.height);
                break;

            case DrawingType.stroke:
                ctx.lineWidth = this.sidebarService.widthShape;
                ctx.strokeStyle = this.primaryColor;
                ctx.strokeRect(point.x, point.y, this.width, this.height);
                break;

            case DrawingType.outline:
                ctx.lineWidth = this.sidebarService.widthShape;
                ctx.fillStyle = this.secondaryColor;
                ctx.fillRect(point.x, point.y, this.width, this.height);
                const width = Math.max(this.width, 2 * ctx.lineWidth);
                const height = Math.max(this.height, 2 * ctx.lineWidth);
                ctx.clearRect(
                    point.x + this.sidebarService.widthShape,
                    point.y + this.sidebarService.widthShape,
                    Math.abs(width - 2 * ctx.lineWidth),
                    Math.abs(height - 2 * ctx.lineWidth),
                );
                ctx.fillStyle = this.primaryColor;
                ctx.fillRect(
                    point.x + this.sidebarService.widthShape,
                    point.y + this.sidebarService.widthShape,
                    Math.abs(width - 2 * ctx.lineWidth),
                    Math.abs(height - 2 * ctx.lineWidth),
                );
                break;
        }
    }

    // on trouve la position du coin supérieur gauche
    private findTopLeftPoint(startPoint: Vec2, endPoint: Vec2): Vec2 {
        let x = startPoint.x;
        let y = startPoint.y;

        if (startPoint.x > endPoint.x && startPoint.y > endPoint.y) {
            // dans le premier cadrant
            x = endPoint.x;
            y = endPoint.y;
        } else if (startPoint.x > endPoint.x && startPoint.y < endPoint.y) {
            x = endPoint.x;
            y = startPoint.y;
        } else if (startPoint.x < endPoint.x && startPoint.y > endPoint.y) {
            x = startPoint.x;
            y = endPoint.y;
        }

        return { x, y };
    }

    private fakeMousePosition(currentPoint: Vec2, previewPoint: Vec2): Vec2 {
        const width = Math.abs(currentPoint.x - previewPoint.x);
        const heigth = Math.abs(currentPoint.y - previewPoint.y);

        const point: Vec2 = currentPoint;

        if (width > heigth) {
            if (
                (currentPoint.x < previewPoint.x && currentPoint.y < previewPoint.y) ||
                (currentPoint.x > previewPoint.x && currentPoint.y < previewPoint.y)
            ) {
                point.y -= width - heigth;
            } else {
                point.y += width - heigth;
            }
        } else {
            if (
                (currentPoint.x < previewPoint.x && currentPoint.y < previewPoint.y) ||
                (currentPoint.x < previewPoint.x && currentPoint.y > previewPoint.y)
            ) {
                point.x -= heigth - width;
            } else {
                point.x += heigth - width;
            }
        }
        return point;
    }

    get width(): number {
        return Math.abs(this.firstPoint.x - this.lastPoint.x);
    }

    get height(): number {
        return Math.abs(this.firstPoint.y - this.lastPoint.y);
    }

    get squareWidth(): number {
        return this.width > this.height ? this.width : this.height;
    }
}
