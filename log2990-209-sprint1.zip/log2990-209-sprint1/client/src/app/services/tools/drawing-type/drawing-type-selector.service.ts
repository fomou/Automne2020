import { Injectable } from '@angular/core';
import { DrawingType } from '@app/enums/draw-type';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class DrawingTypeSelectorService {
    drawingTypeSource: BehaviorSubject<string>; // = new BehaviorSubject<string>(DrawingType.stroke);
    drawingType$: Observable<string>;
    constructor() {
        this.drawingTypeSource = new BehaviorSubject<string>(DrawingType.outline);
        this.drawingType$ = this.drawingTypeSource.asObservable();
    }

    changeDrawingType(type: string): void {
        this.drawingTypeSource.next(type);
    }
}
