import { Injectable } from '@angular/core';
import { Tool } from '@app/classes/tool';
import { Keyboard } from '@app/enums/key-board';
import { BrushService } from '@app/services/tools/brush/brush.service';
import { EllipseService } from '@app/services/tools/ellipse/ellipse.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PencilService } from '@app/services/tools/pencil/pencil-service';
import { RectangleService } from '@app/services/tools/rectangle/rectangle.service';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ToolsSelectorService {
    toolSource: BehaviorSubject<Tool>;
    toolsMap: Map<string, Tool> = new Map<string, Tool>();
    tool$: Observable<Tool>;

    constructor(
        pencilService: PencilService,
        rectangleService: RectangleService,
        ellipseService: EllipseService,
        lineService: LineService,
        eraseService: EraseService,
        brushervice: BrushService,
    ) {
        this.toolsMap.set(Keyboard.un, rectangleService);
        this.toolsMap.set(Keyboard.deux, ellipseService);
        this.toolsMap.set(Keyboard.l, lineService);
        this.toolsMap.set(Keyboard.c, pencilService);
        this.toolsMap.set(Keyboard.e, eraseService);
        this.toolsMap.set(Keyboard.w, brushervice);

        this.toolSource = new BehaviorSubject<Tool>(pencilService);
        this.tool$ = this.toolSource.asObservable();
    }
    changeTool(tool: Tool): void {
        this.toolSource.next(tool);
    }

    getToolBykey(event: KeyboardEvent): Tool {
        return this.toolsMap.get(event.code) as Tool;
    }
}
