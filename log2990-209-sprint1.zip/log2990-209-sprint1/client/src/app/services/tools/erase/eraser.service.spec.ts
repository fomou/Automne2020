import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';

// tslint:disable:no-any
// tslint:disable:no-string-literal
describe('EraseService', () => {
    let service: EraseService;
    let mouseEvent: MouseEvent;
    let drawServiceSpy: jasmine.SpyObj<DrawingService>;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;
    let eraseLineSpy: jasmine.Spy<any>;
    let clearPathSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(EraseService);

        eraseLineSpy = spyOn<any>(service, 'eraseLine').and.callThrough();
        clearPathSpy = spyOn<any>(service, 'clearPath').and.callThrough();

        service['drawingService'].baseCtx = baseCtxStub; // Jasmine doesnt copy properties with underlying data
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // Tests onMouseDown
    it(' mouseDown should set mouseDownCoord to correct position', () => {
        const expectedResult: Vec2 = { x: 25, y: 25 };
        service.onMouseDown(mouseEvent);
        expect(service.mouseDownCoord).toEqual(expectedResult);
    });
    it('onMouseDown with right click should do nothing ', () => {
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            button: 1, // click droit
        } as MouseEvent;
        service.onMouseDown(mouseEvent);
        expect(service.mouseDown).toEqual(false);
    });

    // Tests onMouseUp
    it('onMouseUp should set mouseDown to false', () => {
        service['mouseDown'] = true;
        service.onMouseUp(mouseEvent);
        expect(service['mouseDown']).toEqual(false);
        expect(clearPathSpy).toHaveBeenCalled();
    });
    it('onMouseUp should set mouseDown to false', () => {
        service.onMouseUp(mouseEvent);
        service['mouseDown'] = false;
        expect(clearPathSpy).toHaveBeenCalled();
    });

    // Tests onMouseMove
    it('onMouseMove should erase if mouseDown was true', () => {
        service['mouseDown'] = true;
        service.onMouseMove(mouseEvent);
        expect(eraseLineSpy).toHaveBeenCalled();
    });
    it('onMouseMove should not erase if mouseDown was false', () => {
        service['mouseDown'] = false;
        service.onMouseMove(mouseEvent);
        expect(eraseLineSpy).not.toHaveBeenCalled();
    });

    // Tests OnMouseLeave
    it('onMouseMove should call eraseLine()', () => {
        service['mouseDown'] = true;
        service.onMouseLeave(mouseEvent);
        expect(service.mouseDown).toEqual(false);
    });

    // Test onMouseEnter
    it(' onMouseEnter should put mouseDown to true if event event.buttons==1', () => {
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            buttons: 1,
        } as MouseEvent;
        service.mouseDown = false;
        service.onMouseEnter(mouseEvent);
        expect(service.mouseDown).toEqual(true);
    });
    it(' onMouseEnter should not put mouseDown to true if event event.buttons!=1', () => {
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            buttons: 0,
        } as MouseEvent;
        service.mouseDown = false;
        service.onMouseEnter(mouseEvent);
        expect(service.mouseDown).toEqual(false);
    });
});
