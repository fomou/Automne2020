import { DrawingService } from '@app/services/drawing/drawing.service';
import { Shape } from './shape';
import { Tool } from './tool';
import { Vec2 } from './vec2';

export abstract class ShapeTool extends Tool {
    shapeCaracteristics: Shape;
    shiftPressed: boolean;
    firstPoint: Vec2;
    lastPoint: Vec2;
    primaryColor: string;
    secondaryColor: string;
    drawingType: string;
    protected lineWidth: number;
    constructor(drawingService: DrawingService) {
        super(drawingService);
    }
}
