import { DrawingType } from '@app/enums/draw-type';
import { Vec2 } from './vec2';

export interface Shape {
    color: string;
    type: DrawingType;
    point: Vec2;
    height: number;
    width: number;
}
