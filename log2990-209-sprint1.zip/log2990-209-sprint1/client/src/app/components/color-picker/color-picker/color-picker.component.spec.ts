import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { ColorPickerComponent } from './color-picker.component';

describe('ColorPickerComponent', () => {
    let component: ColorPickerComponent;
    let fixture: ComponentFixture<ColorPickerComponent>;
    let colorFormsStub: FormBuilder;
    let colorSelectorServiceStub: ColorSelectorService;
    // let colorSelectorSpy: jasmine.SpyObj<ColorSelectorService>;

    beforeEach(async(() => {
        colorFormsStub = new FormBuilder();
        colorSelectorServiceStub = new ColorSelectorService();

        TestBed.configureTestingModule({
            declarations: [ColorPickerComponent],
            providers: [
                { provide: FormBuilder, useValue: colorFormsStub },
                { provide: ColorSelectorService, useValue: colorSelectorServiceStub },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ColorPickerComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // colorSelectorSpy = jasmine.createSpyObj('ColorSelectorService', ['getCurrentColor', 'addColorsToArray', 'annoceColor']);
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should give correct color entrerd in the form', () => {
        component.colorForms.setValue({
            red: 'ab',
            green: '1b',
            blue: 'ef',
        });
        component.getEnteredColor();
        expect(component.manuelColor).toBe('#AB1BEF');
    });

    it('should complete missing letters with 0 ', () => {
        component.colorForms.setValue({
            red: 'b',
            green: '1',
            blue: 'f',
        });
        component.getEnteredColor();
        expect(component.manuelColor).toBe('#0B010F');
    });

    it('should not give color if one field is left empty in the form', () => {
        component.colorForms.setValue({
            red: '',
            green: '1b',
            blue: 'ef',
        });
        component.getEnteredColor();
        expect(component.fieldEmpty).toEqual(true);
        expect(component.manuelColor).toEqual('');
    });

    it('should send color if it changed', () => {
        component.previewColor = 'green';
        component.color = 'red';
        colorSelectorServiceStub.colorType = 'primary';
        component.confirm();

        expect(colorSelectorServiceStub.primaryColorSource.getValue()).toBe('red');
    });

    it('should send manual color if it is in correct form', () => {
        component.previewColor = 'green';
        component.color = 'green';

        component.colorForms.setValue({
            red: 'ab',
            green: '1b',
            blue: 'ef',
        });
        component.getEnteredColor();
        colorSelectorServiceStub.colorType = 'primary';
        component.confirm();
        expect(colorSelectorServiceStub.primaryColorSource.getValue()).toEqual(component.manuelColor);
    });

    it('should send manual color if it is in correct form', () => {
        component.previewColor = 'green';
        component.color = 'green';

        component.colorForms.setValue({
            red: 'ab',
            green: '',
            blue: '',
        });
        component.hue = 'blue';
        component.getEnteredColor();
        colorSelectorServiceStub.colorType = 'primary';
        component.confirm();
        expect(colorSelectorServiceStub.primaryColorSource.getValue()).toEqual('blue');
    });

    // it('should call getCurrentColor of colorSelectorService ', () => {
    //     component.ngOnInit();
    //     expect(colorSelectorSpy.getCurentColor).toHaveBeenCalled();
    // });

    // it('confirm() should annonceColor and addColorToarray ', () => {
    //     component.previewColor = 'red';
    //     component.color = 'red';
    //     component.confirm();
    //     expect(colorSelectorSpy.annonceColor).toHaveBeenCalled();
    //     expect(colorSelectorSpy.addColorsToArray).toHaveBeenCalled();
    // });

    it('getEnteredColor should return false if color hexadecimal value is not valid', () => {
        component.colorForms.setValue({
            red: 'ab',
            green: '1g',
            blue: '22',
        });

        const colorIsValide = component.getEnteredColor();
        expect(colorIsValide).toEqual(false);
        expect(component.manuelColor).toEqual('');
    });
    it('should give right hexadecimal value for red, green and blue', () => {
        component.colorForms.setValue({
            red: 'ab',
            green: '1e',
            blue: '22',
        });

        expect(component.colorForms.get('red')?.value).toEqual('ab');
        expect(component.greenHexValue).toEqual('1E');
        expect(component.blueHexValue).toEqual('22');
    });

    // it('confirm() should addColorToarray ', () => {
    //     component.previewColor = 'blue';
    //     component.hue = 'red';
    //     component.previewHue = 'green';
    //     component.color = 'red';
    //     component.confirm();
    //     expect(colorSelectorSpy.addColorsToArray).toHaveBeenCalledWith(component.color);
    // });
});
