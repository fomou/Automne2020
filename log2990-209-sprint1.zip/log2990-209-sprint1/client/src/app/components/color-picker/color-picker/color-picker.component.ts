import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';

@Component({
    selector: 'app-color-picker',
    templateUrl: './color-picker.component.html',
    styleUrls: ['./color-picker.component.scss'],
})
export class ColorPickerComponent implements OnInit, OnDestroy {
    hue: string;
    color: string;
    previewColor: string;
    previewHue: string;
    colorForms: FormGroup;
    manuelColor: string;
    fieldEmpty: boolean = true;
    constructor(private colorSelectorService: ColorSelectorService, private formsBuilder: FormBuilder) {
        this.colorForms = this.formsBuilder.group({
            red: ['', [Validators.required, Validators.maxLength(2)]],
            green: ['', [Validators.required, Validators.maxLength(2)]],
            blue: ['', [Validators.required, Validators.maxLength(2)]],
        });
        this.manuelColor = '';
        // this.hue = this.colorSelectorService.getCurentColor();
    }

    ngOnInit(): void {
        this.color = this.colorSelectorService.getCurentColor();
        this.previewColor = this.color;
        this.hue = this.colorSelectorService.getCurentColor();
        this.previewHue = this.hue;
    }
    ngOnDestroy(): void {
        this.colorSelectorService.keepHue(this.hue);
    }

    confirm(): void {
        if (this.previewColor !== this.color) {
            this.colorSelectorService.annonceColor(this.color);
            if (this.previewHue !== this.hue) {
                this.colorSelectorService.addColorsToArray(this.color);
            }
        } else if (this.getEnteredColor()) {
            this.colorSelectorService.annonceColor(this.manuelColor);
            this.colorSelectorService.addColorsToArray(this.manuelColor);
        } else {
            this.colorSelectorService.annonceColor(this.hue);
            this.colorSelectorService.addColorsToArray(this.hue);
        }
    }

    get redHexValue(): string {
        const hexVal = this.colorForms.get('red')?.value as string;
        this.fieldEmpty = hexVal.length === 0;

        return hexVal.length > 1 ? hexVal.toUpperCase() : '0' + hexVal.toUpperCase();
    }

    get greenHexValue(): string {
        const hexVal = this.colorForms.get('green')?.value as string;
        this.fieldEmpty = this.fieldEmpty || hexVal.length === 0;

        return hexVal.length > 1 ? hexVal.toUpperCase() : '0' + hexVal.toUpperCase();
    }

    get blueHexValue(): string {
        const hexVal = this.colorForms.get('blue')?.value as string;
        this.fieldEmpty = this.fieldEmpty || hexVal.length === 0;

        return hexVal.length > 1 ? hexVal.toUpperCase() : '0' + hexVal.toUpperCase();
    }

    getEnteredColor(): boolean {
        const color = '#' + this.redHexValue + this.greenHexValue + this.blueHexValue;
        const excludedColors = 'ghijklmnopqrstuvwxyz'.toUpperCase();

        for (const c of color) {
            if (excludedColors.includes(c)) {
                return false;
            }
        }

        if (this.fieldEmpty) {
            return false;
        }

        this.manuelColor = color;
        return true;
    }
}
