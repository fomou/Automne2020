import { Component } from '@angular/core';
import { MatSliderChange } from '@angular/material/slider';
import { BrushService } from '@app/services/tools/brush/brush.service';
import { DrawingTypeSelectorService } from '@app/services/tools/drawing-type/drawing-type-selector.service';
import { EllipseService } from '@app/services/tools/ellipse/ellipse.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PencilService } from '@app/services/tools/pencil/pencil-service';
import { RectangleService } from '@app/services/tools/rectangle/rectangle.service';
import { SidebarService } from '@app/services/tools/slide-bar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';

// tslint:disable: no-magic-numbers

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent {
    constructor(
        private sidebarService: SidebarService,
        private toolsSelectorService: ToolsSelectorService,
        pencilService: PencilService,
        rectangleService: RectangleService,
        ellipseService: EllipseService,
        private lineService: LineService,
        brush: BrushService,
        erase: EraseService,
        private drawingType: DrawingTypeSelectorService,
    ) {
        this.pencil = pencilService;
        this.rectangle = rectangleService;
        this.ellipse = ellipseService;
        this.line = lineService;
        this.brushService = brush;
        this.erase = erase;
    }
    pencil: PencilService;
    rectangle: RectangleService;
    ellipse: EllipseService;
    line: LineService;
    erase: EraseService;
    brushService: BrushService;
    radius: number;

    buttonGuide: boolean = false;

    // isShownBarAtt: boolean = false;
    isShownBarAttTools: boolean = false;
    isShownBarAttShapes: boolean = false;

    isShownPenAtt: boolean = false;
    isShownBrushAtt: boolean = false;
    isShownFeatherAtt: boolean = false;
    isShownSpraypaintAtt: boolean = false;

    isShownBrushes: boolean = false;
    isShownTexture: boolean = false;
    isShownJonctionType: boolean = false;

    isShownPolygoneAtt: boolean = false;
    isShownShapes: boolean = false;
    isShownTraceType: boolean = false;

    isShownBarAttLine: boolean = false;
    isShownLineAtt: boolean = false;

    isShownBarAttEraser: boolean = false;

    brushs: string[] = ['Crayon', 'Pinceau', ' Plume', 'Aérosol'];
    shapes: string[] = ['Rectangle', 'Ellipse', 'Poligone'];
    jonctionTypes: string[] = ['Normal', 'Avec point'];
    brush: string = 'Outils de tracage';
    shape: string = 'Formes';
    jonctionType: string = 'Type de jonction';

    buttonguide(): void {
        this.buttonGuide = !this.buttonGuide;
    }

    getRadius(radius: number): void {
        this.radius = radius;
        this.line.radius = this.radius;
    }

    formatLabel(value: number): string {
        return (value + 'px') as string;
    }

    changeDrawingType(type: string): void {
        this.drawingType.changeDrawingType(type);
    }

    changeWidth(event: MatSliderChange): void {
        this.sidebarService.changeWidth(event.value as number);
    }

    changeBrushWidth(event: MatSliderChange): void {
        this.sidebarService.changeBrushWidth(event.value as number);
    }

    changeEraserSize(event: MatSliderChange): void {
        this.sidebarService.changeEraserSize(event.value as number);
    }

    HideAllBarAtt(): void {
        // this.isShownBarAtt = false;
        this.isShownBarAttTools = false;
        this.isShownBarAttShapes = false;
        this.isShownBarAttLine = false;
        this.isShownBarAttEraser = false;
    }
    closeBar3(): void {
        this.isShownBrushes = false;
        this.isShownTexture = false;
        this.isShownShapes = false;
        this.isShownTraceType = false;
        this.isShownJonctionType = false;
    }
    // BarAttributesTools
    HideAllToolAttrebutes(): void {
        this.isShownBrushAtt = false;
        this.isShownPenAtt = false;
        this.isShownFeatherAtt = false;
        this.isShownSpraypaintAtt = false;
        this.isShownTexture = false;
    }

    ShowBarAttributesTools(): void {
        this.closeBar3();
        this.HideAllBarAtt();
        this.isShownBarAttTools = !this.isShownBarAttTools;
    }

    ShowBrushes(): void {
        this.isShownTexture = false;
        this.isShownBrushes = !this.isShownBrushes;
    }

    ShowTexture(): void {
        this.isShownBrushes = false;
        this.isShownTexture = !this.isShownTexture;
    }
    // tslint:disable: no-magic-numbers
    // Car les parametres passes en argument sont representatifs,
    // et ne sont pas des nombres magiques

    selectTexture1(): void {
        this.sidebarService.selectTexture(1);
    }
    selectTexture2(): void {
        this.sidebarService.selectTexture(2);
    }
    selectTexture3(): void {
        this.sidebarService.selectTexture(3);
    }
    selectTexture4(): void {
        this.sidebarService.selectTexture(4);
    }
    selectTexture5(): void {
        this.sidebarService.selectTexture(5);
    }

    ShowPenAtt(): void {
        this.HideAllToolAttrebutes();
        this.ShowBrushes();
        this.isShownPenAtt = true;
        this.brush = this.brushs[0];
        this.toolsSelectorService.changeTool(this.pencil);
    }

    ShowBrushAttribute(): void {
        this.HideAllToolAttrebutes();
        this.ShowBrushes();
        this.isShownBrushAtt = true;
        this.brush = this.brushs[1];
        this.toolsSelectorService.changeTool(this.brushService);
    }

    ShowFeatherAtt(): void {
        this.HideAllToolAttrebutes();
        this.ShowBrushes();
        this.isShownFeatherAtt = true;
        this.brush = this.brushs[2];
    }

    ShowSpraypaintAtt(): void {
        this.HideAllToolAttrebutes();
        this.ShowBrushes();
        this.isShownSpraypaintAtt = true;
        this.brush = this.brushs[3];
    }

    // BarAttributesShapes

    ShowBarAttributesShapes(): void {
        this.closeBar3();
        this.HideAllBarAtt();
        this.isShownBarAttShapes = !this.isShownBarAttShapes;
    }

    ShowShapes(): void {
        this.isShownTraceType = false;
        this.isShownShapes = !this.isShownShapes;
    }

    ShowTraceType(): void {
        this.isShownShapes = false;
        this.isShownTraceType = !this.isShownTraceType;
    }

    ShowRectangleAtt(): void {
        this.isShownPolygoneAtt = false;
        this.ShowShapes();
        this.shape = this.shapes[0];
        this.toolsSelectorService.changeTool(this.rectangle);
    }

    ShowEllipseAtt(): void {
        this.isShownPolygoneAtt = false;
        this.ShowShapes();
        this.shape = this.shapes[1];
        this.toolsSelectorService.changeTool(this.ellipse);
    }

    ShowPolygoneAtt(): void {
        this.isShownPolygoneAtt = true;
        this.ShowShapes();
        this.shape = this.shapes[2];
    }
    // BarAttributesLine

    ShowBarAttributesLine(): void {
        this.closeBar3();
        this.HideAllBarAtt();
        this.isShownBarAttLine = !this.isShownBarAttLine;
        this.toolsSelectorService.changeTool(this.line);
    }

    ShowJonctionType(): void {
        this.isShownTraceType = false;
        this.isShownJonctionType = !this.isShownJonctionType;
    }

    ShowDefaultJonctionAtt(): void {
        this.isShownLineAtt = false;
        this.ShowJonctionType();
        this.jonctionType = this.jonctionTypes[0];
        this.lineService.pointJoint = false;
    }

    ShowWithDotsJonctionAtt(): void {
        this.isShownLineAtt = true;
        this.ShowJonctionType();
        this.jonctionType = this.jonctionTypes[1];
        this.lineService.pointJoint = true;
    }

    // eraser attrebutes
    ShowBarAttributesEraser(): void {
        this.closeBar3();
        this.HideAllBarAtt();
        this.toolsSelectorService.changeTool(this.erase);
        // this.OpenBarAtt();
        this.isShownBarAttEraser = !this.isShownBarAttEraser;
    }

    Validate(): void {
        this.closeBar3();
    }

    changeWidthShape(event: MatSliderChange): void {
        this.sidebarService.changeWidthShape(event.value as number);
    }

    changeWidthLine(event: MatSliderChange): void {
        this.sidebarService.changeWidthLine(event.value as number);
    }
    returnWidth(): number {
        return this.sidebarService.width;
    }

    returnBrushWidth(): number {
        return this.sidebarService.brushWidth;
    }

    returnShapeBrush(): number {
        return this.sidebarService.widthShape;
    }

    returnLineWidth(): number {
        return this.sidebarService.widthLine;
    }

    returnEraserSize(): number {
        return this.sidebarService.eraserSize;
    }
}
