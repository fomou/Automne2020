import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SidebarComponent } from './sidebar.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable:no-magic-numbers :
describe('SidebarComponent', () => {
    let component: SidebarComponent;
    let fixture: ComponentFixture<SidebarComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SidebarComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SidebarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should change button guide', () => {
        component.buttonguide();
        expect(component['buttonGuide']).toBeTruthy();
    });

    it('should set radius of line tool ', () => {
        const radiusStub = 10;
        component.getRadius(radiusStub);
        expect(component.line.radius).toEqual(component.line.radius);
    });

    it('should correctly format parametre', () => {
        const valueStub = 10;
        component.formatLabel(valueStub);
        expect(component.formatLabel(valueStub)).toEqual('10px');
    });

    it('should hide all menu bars', () => {
        component.HideAllBarAtt();
        const result: boolean =
            component.isShownBarAttShapes || component.isShownBarAttLine || component.isShownBarAttShapes || component.isShownBarAttTools;
        expect(result).toBeFalsy();
    });

    it('should call closeBar3', () => {
        component.closeBar3();
        const result: boolean =
            component.isShownBrushes ||
            component.isShownTexture ||
            component.isShownShapes ||
            component.isShownTraceType ||
            component.isShownJonctionType;
        expect(result).toBeFalsy();
    });

    it('should hide all tools', () => {
        component.HideAllToolAttrebutes();
        const result: boolean =
            component.isShownBrushAtt ||
            component.isShownPenAtt ||
            component.isShownFeatherAtt ||
            component.isShownSpraypaintAtt ||
            component.isShownTexture;
        expect(result).toBeFalsy();
    });

    it('should show tool bar', () => {
        component.ShowBarAttributesTools();
        expect(component['isShownBarAttTools']).toBeTruthy();
    });

    it('should show Brushes', () => {
        component.ShowBrushes();
        expect(component['isShownBrushes']).toBeTruthy();
    });

    it('should show Texture', () => {
        component.ShowTexture();
        expect(component['isShownTexture']).toBeTruthy();
    });

    it('should show Pen Bar menu', () => {
        component.ShowPenAtt();
        expect(component.brush).toEqual(component.brushs[0]);
    });

    it('should show Brush attr1 ', () => {
        component.ShowBrushAttribute();
        expect(component.brush).toEqual(component.brushs[1]);
    });

    it('should show Feather attr2 ', () => {
        component.ShowFeatherAtt();
        expect(component.brush).toEqual(component.brushs[2]);
    });

    it('should show spray attr3 ', () => {
        component.ShowSpraypaintAtt();
        expect(component.brush).toEqual(component.brushs[3]);
    });

    it('should show shapes attribute bar ', () => {
        component.ShowBarAttributesShapes();
        expect(component.isShownBarAttShapes).toBeTruthy();
    });

    it('should show shapes tab ', () => {
        component.ShowShapes();
        expect(component.isShownShapes).toBeTruthy();
    });

    it('should show traces tab ', () => {
        component.ShowTraceType();
        expect(component.isShownTraceType).toBeTruthy();
    });

    it('should show rectangle attribute  ', () => {
        component.ShowRectangleAtt();
        expect(component.shape).toEqual(component.shapes[0]);
    });

    it('should show ellipse attribute bar ', () => {
        component.ShowEllipseAtt();
        expect(component.shape).toEqual(component.shapes[1]);
    });

    it('should show polygon bar  option bar', () => {
        component.ShowPolygoneAtt();
        expect(component.shape).toEqual(component.shapes[2]);
    });

    it('should show lines attribute bar', () => {
        component.ShowBarAttributesLine();
        expect(component.isShownBarAttLine).toBeTruthy();
    });

    it('should show junction type bar ', () => {
        component.ShowJonctionType();
        expect(component.isShownJonctionType).toBeTruthy();
    });

    it('should show default junction type', () => {
        component.ShowDefaultJonctionAtt();
        expect(component.jonctionType).toEqual(component.jonctionTypes[0]);
    });

    it('should show dottet junction type', () => {
        component.ShowWithDotsJonctionAtt();
        expect(component.jonctionType).toEqual(component.jonctionTypes[1]);
    });

    it('should show Eraser attributes ', () => {
        component.ShowBarAttributesEraser();
        expect(component['isShownBarAttEraser']).toBeTruthy();
    });
});
