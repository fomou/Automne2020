import { AfterViewInit, Component, ElementRef, HostListener, ViewChild } from '@angular/core';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import { DEFAULT_HEIGHT, DEFAULT_WIDTH, ERASE_INDEX } from '@app/constantes/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { BrushService } from '@app/services/tools/brush/brush.service';
import { EllipseService } from '@app/services/tools/ellipse/ellipse.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PencilService } from '@app/services/tools/pencil//pencil-service';
import { RectangleService } from '@app/services/tools/rectangle/rectangle.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';
// TODO : Avoir un fichier séparé pour les constantes ?

@Component({
    selector: 'app-drawing',
    templateUrl: './drawing.component.html',
    styleUrls: ['./drawing.component.scss'],
})
export class DrawingComponent implements AfterViewInit {
    @ViewChild('baseCanvas', { static: false }) baseCanvas: ElementRef<HTMLCanvasElement>;
    // On utilise ce canvas pour dessiner sans affecter le dessin final
    @ViewChild('previewCanvas', { static: false }) previewCanvas: ElementRef<HTMLCanvasElement>;

    private baseCtx: CanvasRenderingContext2D;
    private previewCtx: CanvasRenderingContext2D;
    private canvasSize: Vec2 = { x: DEFAULT_WIDTH, y: DEFAULT_HEIGHT };

    // TODO : Avoir un service dédié pour gérer tous les outils ? Ceci peut devenir lourd avec le temps
    private tools: Tool[];
    currentTool: Tool;
    hasEraser: boolean = false;
    constructor(
        private drawingService: DrawingService,
        private toolsSelectorService: ToolsSelectorService,
        pencilService: PencilService,
        rectangleService: RectangleService,
        ellipseService: EllipseService,
        lineService: LineService,
        eraseService: EraseService,
        brushService: BrushService,
    ) {
        this.tools = [pencilService, rectangleService, ellipseService, lineService, eraseService, brushService];
        this.currentTool = this.tools[0];
        this.toolsSelectorService.tool$.subscribe((tool) => {
            this.currentTool = tool;
            if (this.currentTool === this.tools[ERASE_INDEX]) {
                // si le currentTool est eraser
                this.hasEraser = true;
            } else {
                this.hasEraser = false;
            }
        });
    }

    ngAfterViewInit(): void {
        this.baseCtx = this.baseCanvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        this.previewCtx = this.previewCanvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        this.drawingService.baseCtx = this.baseCtx;
        this.drawingService.previewCtx = this.previewCtx;
        this.drawingService.canvas = this.baseCanvas.nativeElement;
    }

    @HostListener('mousemove', ['$event'])
    onMouseMove(event: MouseEvent): void {
        this.currentTool.onMouseMove(event);
    }

    @HostListener('mousedown', ['$event'])
    onMouseDown(event: MouseEvent): void {
        this.currentTool.onMouseDown(event);
    }

    @HostListener('mouseup', ['$event'])
    onMouseUp(event: MouseEvent): void {
        this.currentTool.onMouseUp(event);
    }

    @HostListener('mouseleave', ['$event'])
    onMouseLeave(event: MouseEvent): void {
        this.currentTool.onMouseLeave(event);
    }

    @HostListener('mouseenter', ['$event'])
    onMouseEnter(event: MouseEvent): void {
        this.currentTool.onMouseEnter(event);
    }

    @HostListener('window:keydown', ['$event'])
    onkeydown(event: KeyboardEvent): void {
        if (this.toolsSelectorService.getToolBykey(event) !== undefined) {
            this.currentTool = this.toolsSelectorService.getToolBykey(event);
            if (this.currentTool === this.tools[ERASE_INDEX]) {
                this.hasEraser = true;
            } else {
                this.hasEraser = false;
            }
        } else {
            this.currentTool.onKeyDown(event);
        }
    }
    @HostListener('keyup', ['$event'])
    onKeyUp(event: KeyboardEvent): void {
        this.currentTool.onKeyUp(event);
    }

    @HostListener('click', ['$event'])
    onClick(event: MouseEvent): void {
        this.currentTool.onClick(event);
    }

    @HostListener('dblclick', ['$event'])
    onDoubleClick(event: MouseEvent): void {
        this.currentTool.onDoubleClick(event);
    }
    get width(): number {
        return this.canvasSize.x;
    }

    get height(): number {
        return this.canvasSize.y;
    }

    isBlank(): boolean {
        const blankCanvas: HTMLCanvasElement = document.createElement('canvas');
        blankCanvas.width = this.baseCanvas.nativeElement.width;
        blankCanvas.height = this.baseCanvas.nativeElement.height;
        return this.baseCanvas.nativeElement.toDataURL() === blankCanvas.toDataURL();
    }

    @HostListener('window:keydown.control.o', ['$event'])
    onKeyDown(event: KeyboardEvent): void {
        let confirm = false;
        if (!this.isBlank()) {
            event.preventDefault();
            confirm = window.confirm('Voulez-vous abandonner vos changement ?');
            if (confirm) {
                this.baseCtx.clearRect(0, 0, this.baseCanvas.nativeElement.width, this.baseCanvas.nativeElement.height);
                this.previewCtx.clearRect(0, 0, this.previewCanvas.nativeElement.width, this.previewCanvas.nativeElement.height);
            }
        }
    }
}
