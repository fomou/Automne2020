/**
 * travail inspiré de <<Creating a Color Picker Component with Angular>> de Lukas Marx, 18 septembre 2018,
 * disponible via https://malcoded.com/posts/angular-color-picker/
 */

import { AfterViewInit, Component, ElementRef, EventEmitter, HostListener, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import { Vec2 } from '@app/classes/vec2';
import { COLOR_SLIDER_HEIGHT } from '@app/constantes/constants';
import { MouseButton } from '@app/enums/mouse-button';

@Component({
    selector: 'app-color-palette',
    templateUrl: './color-palette.component.html',
    styleUrls: ['./color-palette.component.scss'],
})
export class ColorPaletteComponent implements AfterViewInit, OnChanges {
    @Input() hue: string;
    color: string;
    @Output() primaryColorEmitter: EventEmitter<string> = new EventEmitter();

    @ViewChild('baseCanvas', { static: false }) baseCanvas: ElementRef<HTMLCanvasElement>;

    private context: CanvasRenderingContext2D;
    private currentPoint: Vec2;
    private mouseDown: boolean;
    private canvasSize: Vec2 = { x: COLOR_SLIDER_HEIGHT, y: COLOR_SLIDER_HEIGHT };

    ngAfterViewInit(): void {
        const CONTEXT2D = '2d';
        this.context = this.baseCanvas.nativeElement.getContext(CONTEXT2D) as CanvasRenderingContext2D;
        this.displayPalette();
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.hue && this.context !== undefined) {
            this.clear();
            this.primaryColorEmitter.emit(this.hue);
            this.displayPalette();
        }
    }

    @HostListener('mousedown', ['$event'])
    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        this.currentPoint = this.getCurrentPoint(event);
        this.clear();
        this.displayPalette();
    }

    @HostListener('mousemove', ['$event'])
    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown) {
            this.currentPoint = this.getCurrentPoint(event);
            this.clear();
            this.displayPalette();
        }
    }

    @HostListener('mouseup', ['$event'])
    onMouseUp(event: MouseEvent): void {
        this.mouseDown = false;
        this.primaryColorEmitter.emit(this.getColorAtPosition(event));
    }

    get width(): number {
        return this.canvasSize.x;
    }

    get height(): number {
        return this.canvasSize.y;
    }

    private getCurrentPoint(event: MouseEvent): Vec2 {
        return { x: event.offsetX, y: event.offsetY };
    }

    private clear(): void {
        this.context.clearRect(0, 0, this.width, this.height);
    }

    private displayPalette(): void {
        this.context = this.baseCanvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        const INDICATEUR_RADIUS = 10;
        this.context.beginPath();

        this.context.fillStyle = this.hue || 'rgba(255,255,255,1)';
        this.context.fillRect(0, 0, this.width, this.height);

        const whiteGrad = this.context.createLinearGradient(0, 0, this.width, 0);
        whiteGrad.addColorStop(0, 'rgba(255,255,255,1)');
        whiteGrad.addColorStop(1, 'rgba(255,255,255,0)');
        this.context.fillStyle = whiteGrad;
        this.context.fillRect(0, 0, this.width, this.height);

        const blackGrad = this.context.createLinearGradient(0, 0, 0, this.height);
        blackGrad.addColorStop(0, 'rgba(0,0,0,0)');
        blackGrad.addColorStop(1, 'rgba(0,0,0,1)');

        this.context.fillStyle = blackGrad;
        this.context.fillRect(0, 0, this.width, this.height);

        if (this.currentPoint) {
            this.context.strokeStyle = 'white';
            this.context.fillStyle = 'white';
            this.context.beginPath();
            this.context.arc(this.currentPoint.x, this.currentPoint.y, INDICATEUR_RADIUS, 0, 2 * Math.PI);
            this.context.stroke();
            this.context.closePath();
        }
    }

    private getColorAtPosition(event: MouseEvent): string {
        const imageData = this.context.getImageData(event.offsetX, event.offsetY, 1, 1).data;

        const redHex = imageData[0].toString(16).length > 1 ? imageData[0].toString(16) : '0' + imageData[0].toString(16);
        const greenHex = imageData[1].toString(16).length > 1 ? imageData[1].toString(16) : '0' + imageData[1].toString(16);
        const blueHex = imageData[2].toString(16).length > 1 ? imageData[2].toString(16) : '0' + imageData[2].toString(16);
        const hexadecimalColor = '#' + (redHex + greenHex + blueHex).toUpperCase();

        return hexadecimalColor;
    }
}
