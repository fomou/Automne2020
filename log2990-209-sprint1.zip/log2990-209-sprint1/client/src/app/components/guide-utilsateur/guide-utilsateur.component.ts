import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { MainPageComponent } from '@app/components/main-page/main-page.component';
import { DiversOuDessiner } from '@app/enums/tab-type';

@Component({
    selector: 'app-guide-utilsateur',
    templateUrl: './guide-utilsateur.component.html',
    styleUrls: ['./guide-utilsateur.component.scss'],
})
export class GuideUtilsateurComponent implements AfterViewInit {
    onglet: DiversOuDessiner;
    showComponent: boolean = true;
    valeur: number = 0;
    // tslint:disable-next-line:no-empty
    constructor() {}

    @ViewChild('appcontainer') container: ElementRef<HTMLDivElement>;
    @ViewChild('x') x: ElementRef<HTMLDivElement>;
    ngAfterViewInit(): void {
        this.x.nativeElement.addEventListener('click', () => {
            this.container.nativeElement.style.visibility = 'hidden';
        });
    }

    closeUserGuide(): boolean {
        this.showComponent = false;
        MainPageComponent.guide = false;
        return this.showComponent;
    }
    openDiversTab(): boolean {
        this.showComponent = false;
        return this.onglet === 'Divers';
    }

    openDrawTab(): boolean {
        this.showComponent = false;
        return this.onglet === 'Dessiner';
    }

    DiversOuDessiner(onglet: DiversOuDessiner): void {
        this.onglet = onglet;
    }
}
