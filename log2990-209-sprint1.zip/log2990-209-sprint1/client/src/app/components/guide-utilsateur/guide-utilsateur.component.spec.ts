import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DiversOuDessiner } from '@app/enums/tab-type';

import { GuideUtilsateurComponent } from './guide-utilsateur.component';

describe('GuideUtilsateurComponent', () => {
    let component: GuideUtilsateurComponent;
    let fixture: ComponentFixture<GuideUtilsateurComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [GuideUtilsateurComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GuideUtilsateurComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should hide user guide when closing', () => {
        component.closeUserGuide();
        expect(component.showComponent).toBeFalsy();
    });

    it('should show when tab "Diver" is open', () => {
        component.onglet = 'Divers';
        component.openDiversTab();
        expect(component.onglet).toEqual('Divers');
    });

    it('should show when tab "Dessiner" is open', () => {
        component.onglet = 'Dessiner';
        component.openDrawTab();
        expect(component.onglet).toEqual('Dessiner');
    });

    it('should set the right tab', () => {
        const tabStub: DiversOuDessiner = 'Divers';
        component.DiversOuDessiner(tabStub);
        expect(component.onglet).toEqual(tabStub);
    });
});
