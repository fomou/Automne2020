import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { ColorPanelComponent } from './color-panel.component';
/*
class MatDialogMock {
    // When the component calls this.dialog.open(...) we'll return an object
    // with an afterClosed method that allows to subscribe to the dialog result observable.
    // tslint:disable-next-line: typedef
    open() {
        return {
            afterClosed: () => of({ action: true }),
        };
    }
}*/
describe('ColorPanelComponent', () => {
    let component: ColorPanelComponent;
    let fixture: ComponentFixture<ColorPanelComponent>;
    let colorSelectorServiceStub: ColorSelectorService;
    // let colorSelectorSpy: jasmine.SpyObj<ColorSelectorService>;
    let matDialogStub: jasmine.SpyObj<MatDialog>;
    // let matDialogStub: MatDialog;

    beforeEach(async(() => {
        colorSelectorServiceStub = new ColorSelectorService();

        // matDialogStub= new MatDialog()
        matDialogStub = jasmine.createSpyObj('MatDialog', ['open']);

        //    colorSelectorSpy = jasmine.createSpyObj('ColorSelectorService', ['getCurrentColor', 'addColorToArray', 'swapColor', 'annonceColor']);

        TestBed.configureTestingModule({
            declarations: [ColorPanelComponent],

            providers: [
                { provide: MatDialog, useValue: matDialogStub },
                { provide: ColorSelectorService, useValue: colorSelectorServiceStub },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ColorPanelComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // colorSelectorSpy = jasmine.createSpyObj('ColorSelectorService', ['getCurrentColor', 'addColorToArray', 'annoceColor']);
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    // it('should set secondaryColor on right click', () => {
    //     component.rigthClick('red');
    //     expect(colorSelectorSpy.annonceColor).toHaveBeenCalled();
    // });

    it('changeSecondaryColor should call open of matDialog', () => {
        component.changePrimaryColor();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('changeSecondaryColor() should call open of matDialog', () => {
        component.changeSecondaryColor();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    // it('swapColors should call swapcolor of colorSelectorService', () => {
    //     component.swapColors();
    //     expect(colorSelectorSpy.swapColor).toHaveBeenCalled();
    // });

    // it('leftClick should call annoceColor of colorSelectorService', () => {
    //     // const annonceSPy = spyOn(colorSelectorSpy,"annonceColor").and.callThrough()
    //     component.leftClick('red');
    //     expect(colorSelectorSpy.annonceColor).toHaveBeenCalled();
    // });
});
