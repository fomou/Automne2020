import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ColorPickerComponent } from '@app/components/color-picker/color-picker/color-picker.component';
import { ColorType } from '@app/enums/color-type';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';

@Component({
    selector: 'app-color-panel',
    templateUrl: './color-panel.component.html',
    styleUrls: ['./color-panel.component.scss'],
})
export class ColorPanelComponent {
    colors: string[];
    primaryColor: string;
    secondaryColor: string;

    constructor(private dialog: MatDialog, public colorSelectorService: ColorSelectorService) {
        this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.primaryColor = color;
        });
        this.colorSelectorService.secondaryColor$.subscribe((color) => {
            this.secondaryColor = color;
        });
        this.colorSelectorService.recentColor$.subscribe((colors) => {
            this.colors = colors;
        });
    }

    rigthClick(color: string): boolean {
        this.colorSelectorService.colorType = ColorType.secondary;
        this.colorSelectorService.annonceColor(color);
        return false;
    }

    leftClick(color: string): void {
        this.colorSelectorService.colorType = ColorType.primary;
        this.colorSelectorService.annonceColor(color);
    }

    changePrimaryColor(): void {
        this.colorSelectorService.colorType = ColorType.primary;
        this.dialog.open(ColorPickerComponent, { disableClose: true });
    }

    changeSecondaryColor(): void {
        this.colorSelectorService.colorType = ColorType.secondary;
        this.dialog.open(ColorPickerComponent, { disableClose: true });
    }

    swapColors(): void {
        this.colorSelectorService.swapColor(this.primaryColor, this.secondaryColor);
    }
}
