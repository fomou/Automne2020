export type DiversOuDessiner = 'Divers' | 'Dessiner';
