export enum Keyboard {
    shift = 'ShiftLeft',
    un = 'Digit1',
    c = 'KeyC',
    l = 'KeyL',
    deux = 'Digit2',
    e = 'KeyE',
    w = 'KeyW',
}
