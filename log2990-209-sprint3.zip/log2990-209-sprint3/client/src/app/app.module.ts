import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './components/app/app.component';
import { ColorPaletteComponent } from './components/color/color-palette/color-palette.component';
import { ColorPanelComponent } from './components/color/color-panel/color-panel.component';
import { ColorPickerComponent } from './components/color/color-picker/color-picker.component';
import { ColorSliderComponent } from './components/color/color-slider/color-slider.component';
import { DrawingToolsComponent } from './components/drawing-tools/drawing-tools.component';
import { DrawingComponent } from './components/drawing/drawing.component';
import { EditorComponent } from './components/editor/editor.component';
import { ExportComponent } from './components/export/export.component';
import { GalleryComponent } from './components/gallery/gallery.component';
import { GridAttributesComponent } from './components/grid-attributes/grid-attributes.component';
import { GridComponent } from './components/grid/grid.component';
import { MainPageComponent } from './components/main-page/main-page.component';
import { PixelPickerComponent } from './components/pixel-picker/pixel-picker.component';
import { SaveDrawingComponent } from './components/save-drawing/save-drawing.component';
import { SelectionAttributesComponent } from './components/selection-attributes/selection-attributes.component';
import { ShapesComponent } from './components/shapes/shapes.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { SnackbarGeneralComponent } from './components/snackbar-general/snackbar-general.component';
import { StampAttributeComponent } from './components/stamp-attribute/stamp-attribute.component';
import { StampComponent } from './components/stamp/stamp.component';
import { TextComponent } from './components/text/text.component';
import { UserGuideComponent } from './components/user-guide/user-guide.component';

@NgModule({
    declarations: [
        AppComponent,
        EditorComponent,
        SidebarComponent,
        DrawingComponent,
        MainPageComponent,
        ColorPickerComponent,
        ColorSliderComponent,
        ColorPaletteComponent,
        ColorPanelComponent,
        UserGuideComponent,
        PixelPickerComponent,
        GalleryComponent,
        ExportComponent,
        SaveDrawingComponent,
        ShapesComponent,
        DrawingToolsComponent,
        TextComponent,
        StampComponent,
        StampAttributeComponent,
        GridComponent,
        GridAttributesComponent,
        SnackbarGeneralComponent,
        SelectionAttributesComponent,
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        MatSliderModule,
        MatDialogModule,
        FormsModule,
        ReactiveFormsModule,
        MatSlideToggleModule,
        MatTooltipModule,
        MatDialogModule,
        MatButtonModule,
        MatIconModule,
        MatFormFieldModule,
        MatButtonModule,
        MatSelectModule,
        MatRadioModule,
        MatInputModule,
        MatChipsModule,
        MatCardModule,
        MatTabsModule,
        MatSnackBarModule,
        MatExpansionModule,
        MatProgressSpinnerModule,
    ],

    exports: [
        AppComponent,
        EditorComponent,
        SidebarComponent,
        DrawingComponent,
        MainPageComponent,
        ColorPickerComponent,
        ColorSliderComponent,
        ColorPaletteComponent,
        ColorPanelComponent,
        UserGuideComponent,
        PixelPickerComponent,
        GalleryComponent,
        ExportComponent,
        SaveDrawingComponent,
        ShapesComponent,
        DrawingToolsComponent,
        StampComponent,
        StampAttributeComponent,
        GridComponent,
        GridAttributesComponent,
    ],

    bootstrap: [AppComponent],
    providers: [],
})
export class AppModule {}
