export const WIDTH_SIDEBAR = 275;
export const canvasSize = {
    DEFAULT_WIDTH: (window.innerWidth - WIDTH_SIDEBAR) / 2,
    DEFAULT_HEIGHT: window.innerHeight / 2,
};

export const MIN_SQUARE_SIZE = 30;
export const MAX_SQUARE_SIZE = 100;
export const SQUARE_STEP = 5;
export const MIN_OPACITY = 0.2;
export const INITIAL_OPACITY = 0.3;
export const MAX_OPACITY = 1;

export const COLOR_PICKER_WIDTH = 50;
export const COLOR_SLIDER_HEIGHT = 250;
export const CURSOR_SIZE = 10;
export const MAXIMUM_COLOR = 10;

export const DEGREE_0 = 0;
export const DEGREE_15 = 15;
export const DEGREE_45 = 45;
export const DEGREE_90 = 90;
export const DEGREE_135 = 135;
export const DEGREE_180 = 180;
export const DEGREE_225 = 225;
export const DEGREE_270 = 270;
export const DEGREE_315 = 315;
export const DEGREE_360 = 360;
export const DEGREE_1 = 1;
export const MIN_0_DEGREE = 337.5;
export const MIN_45_DEGREE = 22.5;
export const MIN_90_DEGREE = 67.5;
export const MIN_135_DEGREE = 112.5;
export const MIN_180_DEGREE = 157.5;
export const MIN_225_DEGREE = 202.5;
export const MIN_270_DEGREE = 247.5;
export const MIN_315_DEGREE = 292.5;

export const CLOSED_LINE = 20;
export const JOIN_MIN_RADIUS = 5;
export const NB_TOOLS = 16;
export const ANGLE_BRUSH = 25;
export const IMAGES_BY_POINT = 5;
export const ERASE_INDEX = 4;
export const WIDTH_RATE = 4;

export const PREVIEW_CIRCLE_RADIUS = 10;
export const CENTER_CIRCLE_RADIUS = 5;
export const MAX_WIDTH = 1;
export const CENTER_RADIUS = 5;

export const NEXT_COLOR = 4;
export const NUMBER_OF_COLORS = 3;
export const CENTER_WIDTH = 20;
export const SIDE_BAR_X_POSITION = 271;

export const COLORS_PER_POSITION = 4;
export const MAX_BIT_NUM = 255;
export const MAX_TOLERANCE = 100;
export const GREEN_COLOR_INDEX = 1;
export const BLUE_COLOR_INDEX = 2;
export const OPACITY_INDEX = 3;
export const RED_INDEX_START = 1;
export const RED_INDEX_END = 3;
export const GREEN_INDEX_END = 5;
export const BLUE_INDEX_END = 7;
export const OPACITY_INDEX_END = 9;
export const A = 10;
export const B = 11;
export const C = 12;
export const D = 13;
export const E = 14;
export const F = 15;
export const HEXADECIMAL = 16;

export const LINE_DASH = 10;

export const OFFSET_ARROW = 3;

export const INITIAL_FONT_SIZE = 15;
export const DISTANCE_BETWEEN_TWO_LINES = 4;
export const TEXT_ZONE_PADDING = 3;
export const TEXT_ZONE_PADDING_RIGHT = 9;

const DEFAULT_RADIUS = 20;
const DEFAULT_EMISSIONS = 1;
const DENSITY = 100;
const DEFAULT_PARTICLES_DIAMETER = 1;
export const SPRAY_DEFAULT_ATTRIBS = { DEFAULT_RADIUS, DEFAULT_EMISSIONS, DENSITY, DEFAULT_PARTICLES_DIAMETER };

export const NAME_INDEX = 30;
export const SVG_POSITION = 4;
export const DELTA_Y_MOUSE = -100;

export const SNACKBAR_DISPLAY_TIME = 2000;
export const SNACKBAR_TIME = 600;

export const MIN_LENGTH_TAG = 3;

export const MINIMUM_WINDOW_SIZE = 250;
export const MAX_SIZE_WIDTH = 300;
export const MAX_SIZE_HEIGHT = 25;

export const NOT_FOUND = -1;
export const ONE_SECOND = 1000;

export const MAX_SIZE = 10000;
export const RESIZE_BOX_AREA = 2.5;
