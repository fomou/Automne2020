import { HttpClient, HttpClientModule, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { Drawing } from '@common/communication/drawing';
import { Observable } from 'rxjs';
import { SaveDrawingService } from './save-drawing.service';

// tslint:disable:no-any
// tslint:disable: no-string-literal
describe('SaveDrawingService', () => {
    let service: SaveDrawingService;
    let client: HttpClient;

    let drawService: DrawingService;

    beforeEach(() => {
        client = new HttpClient({} as HttpHandler);
        drawService = new DrawingService();
        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawService },
                { provide: HttpClient, useValue: client },
            ],
            imports: [HttpClientModule],
        });
        service = TestBed.inject(SaveDrawingService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('addData should call getImage', async () => {
        const drawing: Drawing = { name: 'Test', tags: [''], dataUrl: '' };

        const spy = spyOn<any>(service['drawingService'], 'getImage').and.callFake(() => {
            return 'test';
        });

        spyOn<any>(client.post('', drawing), 'subscribe').and.callFake(() => {
            return 'test';
        });
        service.addData(drawing);
        expect(spy).toHaveBeenCalled();
    });

    it('deleteDate should call delete ', async () => {
        const spy = spyOn<any>(client, 'delete').and.callFake(() => {
            return;
        });
        const stringStub = 'test';
        service.deleteData(stringStub);
        expect(spy).toHaveBeenCalled();
    });

    it('getAllImages should call getImage', async () => {
        const spy = spyOn<any>(service['http'], 'get').and.callFake(() => {
            return new Observable();
        });

        service.getAllImages();
        expect(spy).toHaveBeenCalled();
    });

    it('updateServer should call getAllImages ', async () => {
        const spy = spyOn<any>(service, 'getAllImages');
        service.updateServer();
        expect(spy).toHaveBeenCalled();
    });
});
