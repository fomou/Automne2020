import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { Drawing } from '@common/communication/drawing';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class SaveDrawingService {
    private readonly DEFAULT_SERVER_ADD: string = 'http://localhost:3000/api/drawing/add';
    private readonly DEFAULT_SERVER_DELETE: string = 'http://localhost:3000/api/drawing/delete/';
    private readonly DEFAULT_SERVER_GET: string = 'http://localhost:3000/api/drawing/';

    constructor(private http: HttpClient, private drawingService: DrawingService) {}
    isServerRunning: boolean = true;
    isSpinning: boolean = true;

    addData(drawing: Drawing): Observable<string> {
        drawing.dataUrl = this.drawingService.getImage() as string;
        return this.http.post<string>(this.DEFAULT_SERVER_ADD, drawing);
    }

    deleteData(idImage: string): Observable<string> {
        return this.http.delete<string>(this.DEFAULT_SERVER_DELETE + idImage);
    }

    getAllImages(): Observable<Drawing[]> {
        const subject = new Subject<Drawing[]>();
        this.http.get<Drawing[]>(this.DEFAULT_SERVER_GET).subscribe(
            (data) => {
                this.isSpinning = false;
                this.isServerRunning = true;
                subject.next(data);
            },
            () => {
                this.isSpinning = false;
                this.isServerRunning = false;
            },
        );
        this.isSpinning = true;
        return subject.asObservable();
    }
    updateServer(): void {
        this.getAllImages();
    }
}
