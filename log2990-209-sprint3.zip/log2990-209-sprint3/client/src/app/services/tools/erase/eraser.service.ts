import { Injectable } from '@angular/core';
import { EraserPath } from '@app/classes/eraser-path';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import { WIDTH_RATE } from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
@Injectable({
    providedIn: 'root',
})
export class EraseService extends Tool {
    private pathData: Vec2[];

    constructor(protected drawingService: DrawingService, private sidebarService: SidebarService, private undoRedoService: UndoRedoService) {
        super(drawingService);
        this.clearPath();
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.clearPath();
            this.drawingService.previewCtx.lineWidth = 1;
            this.setShapeAndColor(this.drawingService.baseCtx);
            this.mouseDownCoord = this.getPositionFromMouse(event);
            this.pathData.push(this.mouseDownCoord);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.createCursor(this.drawingService.previewCtx, this.mouseDownCoord.x, this.mouseDownCoord.y);
            this.eraseSquare(this.drawingService.baseCtx, this.mouseDownCoord.x, this.mouseDownCoord.y);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown) {
            const mousePosition = this.getPositionFromMouse(event);
            this.pathData.push(mousePosition);
            const eraserPath = new EraserPath(this.sidebarService.eraserSize, this.pathData);
            this.undoRedoService.addToStack(eraserPath);
        }
        this.mouseDown = false;
        this.undoRedoService.setToolInUse(false);
        this.clearPath();
    }

    onMouseMove(event: MouseEvent): void {
        const mousePosition = this.getPositionFromMouse(event);
        this.drawingService.previewCtx.lineWidth = 1;
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.createCursor(this.drawingService.previewCtx, mousePosition.x, mousePosition.y);
        if (this.mouseDown) {
            this.pathData.push(mousePosition);
            this.eraseLine(this.drawingService.baseCtx, this.pathData);
            this.undoRedoService.setToolInUse(true);
        }
    }

    onMouseLeave(event: MouseEvent): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        const mousePosition = this.getPositionFromMouse(event);
        this.pathData.push(mousePosition);
        this.eraseLine(this.drawingService.baseCtx, this.pathData);
        this.clearPath();
        this.mouseDown = false;
    }

    onMouseEnter(event: MouseEvent): void {
        if (event.buttons === 1) {
            this.mouseDown = true;
        }
    }

    private eraseLine(ctx: CanvasRenderingContext2D, path: Vec2[]): void {
        ctx.beginPath();
        for (const point of path) {
            ctx.lineTo(point.x, point.y);
        }
        ctx.stroke();
    }

    private eraseSquare(ctx: CanvasRenderingContext2D, pointX: number, pointY: number): void {
        ctx.beginPath();
        ctx.rect(pointX, pointY, this.sidebarService.eraserSize / WIDTH_RATE, this.sidebarService.eraserSize / WIDTH_RATE);
        ctx.stroke();
    }

    private setShapeAndColor(ctx: CanvasRenderingContext2D): void {
        ctx.lineCap = 'square';
        ctx.lineWidth = this.sidebarService.eraserSize;
        ctx.fillStyle = 'rgba(255,255,255,1';
        ctx.strokeStyle = 'rgba(255,255,255,1)';
    }

    private createCursor(ctx: CanvasRenderingContext2D, pointX: number, pointY: number): void {
        this.drawingService.previewCtx.strokeStyle = 'black';
        this.drawingService.previewCtx.fillStyle = 'white';
        this.drawingService.previewCtx.strokeRect(
            // centrer le carre blanc au niveau de la souris
            pointX - this.sidebarService.eraserSize / 2,
            pointY - this.sidebarService.eraserSize / 2,
            this.sidebarService.eraserSize,
            this.sidebarService.eraserSize,
        );
    }

    private clearPath(): void {
        this.pathData = [];
    }
}
