import { Injectable, OnDestroy } from '@angular/core';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constants/constants';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { Subscription } from 'rxjs';
@Injectable({
    providedIn: 'root',
})
export class TextService extends Tool implements OnDestroy {
    private cursorPosition: Vec2;
    private startingY: number;
    private startingX: number;
    private subscription: Subscription;
    private color: string;
    private lineHistory: string[];
    private cursorPositionIndex: number;
    private currentLineIndex: number;
    private alignmentX: number;

    font: string = 'Arial';
    fontSize: number = CONSTANT.INITIAL_FONT_SIZE;
    fontStyle: string = 'Normal';
    textAlign: string = 'left';

    constructor(
        protected drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        super(drawingService);
        this.subscription = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });
        this.clearLineHistory();
    }
    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
    private clearLineHistory(): void {
        this.lineHistory = [''];
        this.cursorPositionIndex = 0;
        this.currentLineIndex = 0;
    }
    private initializePosition(event: MouseEvent): void {
        this.cursorPosition = this.getPositionFromMouse(event);
        this.startingX = this.alignmentX = this.cursorPosition.x;
        this.startingY = this.cursorPosition.y;
    }
    private initializeText(ctx: CanvasRenderingContext2D): void {
        const font = this.fontStyle + ' ' + this.fontSize + 'px ' + this.font;
        ctx.font = font;
        ctx.fillStyle = this.color;
        ctx.textAlign = this.textAlign as CanvasTextAlign;
    }

    private creatCursor(): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.drawingService.previewCtx.beginPath();
        this.drawingService.previewCtx.moveTo(this.cursorPosition.x, this.cursorPosition.y);
        this.drawingService.previewCtx.lineTo(this.cursorPosition.x, this.cursorPosition.y - this.fontSize);
        this.drawingService.previewCtx.stroke();
        this.drawingService.previewCtx.closePath();
        this.createTextZone();
    }
    private findBiggestLine(): string {
        let biggestLine = this.lineHistory[0];
        for (let i = 0; i < this.lineHistory.length - 1; i++) {
            if (
                this.drawingService.previewCtx.measureText(biggestLine).width <
                this.drawingService.previewCtx.measureText(this.lineHistory[i + 1]).width
            ) {
                biggestLine = this.lineHistory[i + 1];
            }
        }

        return biggestLine;
    }
    private createTextZone(): void {
        const biggestLine = this.findBiggestLine();
        this.drawingService.previewCtx.beginPath();
        this.drawingService.previewCtx.rect(
            this.startingX - CONSTANT.TEXT_ZONE_PADDING,
            this.startingY - this.fontSize - CONSTANT.TEXT_ZONE_PADDING,
            this.drawingService.previewCtx.measureText(biggestLine).width + CONSTANT.TEXT_ZONE_PADDING_RIGHT,
            this.lineHistory.length * (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) + CONSTANT.TEXT_ZONE_PADDING * 2,
        );
        this.drawingService.previewCtx.stroke();
        this.drawingService.previewCtx.closePath();
        this.alignText();
    }
    onDocumentClick(event: MouseEvent): void {
        if (
            event.clientX <= CONSTANT.SIDE_BAR_X_POSITION ||
            event.clientX >= this.drawingService.canvas.width + CONSTANT.SIDE_BAR_X_POSITION ||
            event.clientY > this.drawingService.canvas.height
        ) {
            this.initializeText(this.drawingService.baseCtx);
            this.writeOnCanvas(this.drawingService.baseCtx);
            this.escapeHandler();
        }
    }

    onClick(event: MouseEvent): void {
        if (this.mouseDown) {
            this.initializeText(this.drawingService.baseCtx);
            this.writeOnCanvas(this.drawingService.baseCtx);
        }
        this.shortcutManagerService.disableShortcut();
        this.clearLineHistory();
        this.initializePosition(event);
        this.initializeText(this.drawingService.previewCtx);
        this.writeOnCanvas(this.drawingService.previewCtx);
        this.creatCursor();
        this.mouseDown = true;
    }
    private alignCenter(): void {
        const biggestLine = this.findBiggestLine();
        const textAreaWidth = this.drawingService.previewCtx.measureText(biggestLine).width + CONSTANT.TEXT_ZONE_PADDING_RIGHT;
        this.alignmentX = (this.startingX + textAreaWidth) / 2;
    }
    private alignLeft(): void {
        this.alignmentX = this.startingX;
    }
    private alignRight(): void {
        const biggestLine = this.findBiggestLine();
        const textAreaWidth = this.drawingService.previewCtx.measureText(biggestLine).width + CONSTANT.TEXT_ZONE_PADDING_RIGHT;
        this.alignmentX = this.startingX + textAreaWidth - CONSTANT.TEXT_ZONE_PADDING;
    }
    private alignText(): void {
        switch (this.textAlign) {
            case 'center':
                this.alignCenter();
                break;
            case 'left':
                this.alignLeft();
                break;
            case 'right':
                this.alignRight();
                break;
        }
    }
    onKeyDown(event: KeyboardEvent): void {
        if (!this.mouseDown) return;
        switch (event.key) {
            case 'Enter':
                this.enterKeyHandler();
                break;
            case 'Backspace':
                this.backSpaceHandler();
                break;
            case 'ArrowRight':
                this.arrowRightHandler();
                break;
            case 'ArrowLeft':
                this.arrowLeftHandler();
                break;
            case 'ArrowUp':
                this.arrowUpHandler();
                break;
            case 'ArrowDown':
                this.arrowDownHandler();
                break;
            case 'Delete':
                this.deleteHandler();
                break;
            case 'Escape':
                this.escapeHandler();
                break;
            default:
                if (event.key.length > 1) return;
                this.writeOnPreviewCanvas(event);
        }
    }

    private writeOnPreviewCanvas(event: KeyboardEvent): void {
        // écrire à la bonne place sur le canvas
        const fistHalfOfSting = this.lineHistory[this.currentLineIndex].slice(0, this.cursorPositionIndex);
        const lastHalfOfString = this.lineHistory[this.currentLineIndex].slice(this.cursorPositionIndex);
        const concatenatedString = fistHalfOfSting + event.key + lastHalfOfString;
        this.lineHistory[this.currentLineIndex] = concatenatedString;
        this.cursorPosition.x += this.drawingService.previewCtx.measureText(event.key).width;
        this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
        this.cursorPositionIndex++;
    }
    private writeOnCanvas(ctx: CanvasRenderingContext2D): void {
        if (!this.mouseDown) return;

        this.initializeText(ctx);
        for (let i = 0; i < this.lineHistory.length; i++) {
            ctx.fillText(this.lineHistory[i], this.alignmentX, this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * i);
        }
    }
    private enterKeyHandler(): void {
        this.currentLineIndex++;
        const fistHalfOfSting = this.lineHistory[this.currentLineIndex - 1].slice(0, this.cursorPositionIndex);
        const lastHalfOfString = this.lineHistory[this.currentLineIndex - 1].slice(this.cursorPositionIndex);
        this.lineHistory[this.currentLineIndex - 1] = fistHalfOfSting;

        this.cursorPositionIndex = 0;

        for (let i = this.lineHistory.length; i > this.currentLineIndex; i--) {
            this.lineHistory[i] = this.lineHistory[i - 1];
        }

        this.lineHistory[this.currentLineIndex] = lastHalfOfString;
        this.cursorPosition.x = this.alignmentX;
        this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
    }
    private arrowUpHandler(): void {
        if (this.currentLineIndex === 0) return;
        this.currentLineIndex--;
        if (this.lineHistory[this.currentLineIndex].length < this.lineHistory[this.currentLineIndex + 1].length) {
            const currentLine = this.lineHistory[this.currentLineIndex];
            this.cursorPosition.x = this.alignmentX + this.drawingService.previewCtx.measureText(currentLine).width;
            this.cursorPositionIndex = this.lineHistory[this.currentLineIndex].length;
        } else {
            const fistHalfOfSting = this.lineHistory[this.currentLineIndex].slice(0, this.cursorPositionIndex);
            this.cursorPosition.x = this.alignmentX + this.drawingService.previewCtx.measureText(fistHalfOfSting).width;
        }
        this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
    }
    private arrowDownHandler(): void {
        if (this.currentLineIndex === this.lineHistory.length - 1) return;
        this.currentLineIndex++;
        if (this.lineHistory[this.currentLineIndex].length < this.lineHistory[this.currentLineIndex - 1].length) {
            const currentLine = this.lineHistory[this.currentLineIndex];
            this.cursorPosition.x = this.alignmentX + this.drawingService.previewCtx.measureText(currentLine).width;
            this.cursorPositionIndex = this.lineHistory[this.currentLineIndex].length;
        } else {
            const fistHalfOfSting = this.lineHistory[this.currentLineIndex].slice(0, this.cursorPositionIndex);
            this.cursorPosition.x = this.alignmentX + this.drawingService.previewCtx.measureText(fistHalfOfSting).width;
        }
        this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
    }

    private arrowRightHandler(): void {
        if (this.cursorPositionIndex === this.lineHistory[this.currentLineIndex].length && this.currentLineIndex === this.lineHistory.length - 1)
            return;
        if (this.cursorPositionIndex === this.lineHistory[this.currentLineIndex].length) {
            this.cursorPositionIndex = 0;
            this.currentLineIndex++;
            this.cursorPosition.x = this.alignmentX;
            this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
        } else {
            const currentLetter = this.lineHistory[this.currentLineIndex].charAt(this.cursorPositionIndex);
            this.cursorPosition.x += this.drawingService.previewCtx.measureText(currentLetter).width;
            this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
            this.cursorPositionIndex++;
        }

        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
    }
    private positionCurserToTheLeft(): void {
        if (this.cursorPositionIndex === 0 && this.currentLineIndex === 0) return;
        if (this.cursorPositionIndex === 0) {
            this.currentLineIndex--;
            this.cursorPositionIndex = this.lineHistory[this.currentLineIndex].length;

            const currentLine = this.lineHistory[this.currentLineIndex];
            this.cursorPosition.x = this.alignmentX + this.drawingService.previewCtx.measureText(currentLine).width;
            this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
        } else {
            this.cursorPositionIndex--;
            const currentLetter = this.lineHistory[this.currentLineIndex].charAt(this.cursorPositionIndex);
            this.cursorPosition.x -= this.drawingService.previewCtx.measureText(currentLetter).width;
            this.cursorPosition.y = this.startingY + (this.fontSize + CONSTANT.DISTANCE_BETWEEN_TWO_LINES) * this.currentLineIndex;
        }
    }
    private deleteLetter(): void {
        const fistHalfOfSting = this.lineHistory[this.currentLineIndex].slice(0, this.cursorPositionIndex);
        const lastHalfOfString = this.lineHistory[this.currentLineIndex].slice(this.cursorPositionIndex + 1);
        const concatenatedString = fistHalfOfSting + lastHalfOfString;
        this.lineHistory[this.currentLineIndex] = concatenatedString;
    }
    private deleteHandler(): void {
        this.deleteLetter();
        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
    }
    private arrowLeftHandler(): void {
        this.positionCurserToTheLeft();
        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
    }

    private backSpaceHandler(): void {
        this.positionCurserToTheLeft();
        this.deleteLetter();
        this.creatCursor();
        this.writeOnCanvas(this.drawingService.previewCtx);
    }
    private escapeHandler(): void {
        this.mouseDown = false;
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.clearLineHistory();
        this.shortcutManagerService.enableShortcut();
    }
}
