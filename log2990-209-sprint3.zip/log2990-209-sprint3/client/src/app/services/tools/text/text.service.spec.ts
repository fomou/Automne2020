import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { TextService } from './text.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: max-file-line-count
describe('TextService', () => {
    let service: TextService;
    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;
    let drawServiceSpy: jasmine.SpyObj<DrawingService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas'], ['stroke']);
        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(TextService);
        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;
        service['cursorPosition'] = {} as Vec2;
        service['drawingService'].canvas = canvasTestHelper.drawCanvas;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('clearLineHistory be clear lineHistory array and initialize the currentLineIndex and the cursorPositionIndex to 0', () => {
        service['clearLineHistory']();
        expect(service['lineHistory']).toEqual(['']);
        expect(service['cursorPositionIndex']).toEqual(0);
        expect(service['currentLineIndex']).toEqual(0);
    });
    it('initializePosition should initialize cursorPosition, startingX, startingY and alignmentX with the right x and y coordinates ', () => {
        const event = {
            pageX: 500,
            pageY: 500,
        } as MouseEvent;
        service['initializePosition'](event);
        expect(service['cursorPosition']).toEqual({ x: 500 - 271, y: 500 });
        expect(service['startingX']).toEqual(500 - 271);
        expect(service['alignmentX']).toEqual(500 - 271);
        expect(service['startingY']).toEqual(500);
    });
    it('initializeText should initialize canvas font, style and textAlign ', () => {
        service['fontStyle'] = 'bold';
        service['fontSize'] = 20;
        service['font'] = 'Arial';
        service['color'] = 'red';
        service['textAlign'] = 'left';

        service['initializeText'](service['drawingService'].previewCtx);
        expect(service['drawingService'].previewCtx.font).toEqual('bold 20px Arial');
        expect(service['drawingService'].previewCtx.fillStyle).toEqual('#ff0000');
        expect(service['drawingService'].previewCtx.textAlign).toEqual('left');
    });
    it('findBiggestLine should find string with the biggest width ', () => {
        service['lineHistory'].push('0123');
        service['lineHistory'].push('01234');
        const biggestLine = service['findBiggestLine']();
        expect(biggestLine).toEqual('01234');
    });
    it('createTextZone should call findBiggestLine and alignText', () => {
        const psyFindBiggestLine = spyOn<any>(service, 'findBiggestLine');
        const spyAlignText = spyOn<any>(service, 'alignText');
        service['createTextZone']();
        expect(psyFindBiggestLine).toHaveBeenCalled();
        expect(spyAlignText).toHaveBeenCalled();
    });
    it('creatCursor should draw on preview canvas and call creatTextZone ', () => {
        const psyCreatTextZone = spyOn<any>(service, 'createTextZone');

        service['cursorPosition'] = { x: 500, y: 500 };
        service['creatCursor']();
        expect(psyCreatTextZone).toHaveBeenCalled();
    });
    it('onDocumentClick should confirm text creation and write on basE canvas if click occurs outside of canvas ', () => {
        const event = {
            clientX: 0,
            clientY: 0,
        } as MouseEvent;
        const psyInitializeText = spyOn<any>(service, 'initializeText');
        const psyWriteOnCanvas = spyOn<any>(service, 'writeOnCanvas');
        const psyEscapeHandler = spyOn<any>(service, 'escapeHandler');
        service['onDocumentClick'](event);
        expect(psyInitializeText).toHaveBeenCalled();
        expect(psyWriteOnCanvas).toHaveBeenCalled();
        expect(psyEscapeHandler).toHaveBeenCalled();
    });
    it('onDocumentClick should do nothing if click occurs inside of canvas ', () => {
        const event = {
            clientX: 300,
            clientY: 10,
        } as MouseEvent;
        const psyInitializeText = spyOn<any>(service, 'initializeText');
        const psyWriteOnCanvas = spyOn<any>(service, 'writeOnCanvas');
        const psyEscapeHandler = spyOn<any>(service, 'escapeHandler');
        service['onDocumentClick'](event);
        expect(psyInitializeText).toHaveBeenCalledTimes(0);
        expect(psyWriteOnCanvas).toHaveBeenCalledTimes(0);
        expect(psyEscapeHandler).toHaveBeenCalledTimes(0);
    });
    it('onClick should initialize baseCanvas and write on it  if mouse is down  ', () => {
        const event = {
            clientX: 300,
            clientY: 10,
        } as MouseEvent;
        service['mouseDown'] = true;
        const psyInitializeText = spyOn<any>(service, 'initializeText');
        const psyWriteOnCanvas = spyOn<any>(service, 'writeOnCanvas');

        service.onClick(event);
        expect(psyInitializeText).toHaveBeenCalled();
        expect(psyWriteOnCanvas).toHaveBeenCalled();
    });
    it('onClick should initialize previewCtx, write on it, creat cursor and put mouseDown to true ', () => {
        const event = {
            clientX: 300,
            clientY: 10,
        } as MouseEvent;
        service['mouseDown'] = false;

        const psyInitializeText = spyOn<any>(service, 'initializeText');
        const psyWriteOnCanvas = spyOn<any>(service, 'writeOnCanvas');

        service.onClick(event);
        expect(psyInitializeText).toHaveBeenCalled();
        expect(psyWriteOnCanvas).toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(true);
    });
    it('alignCenter should calculate alignment position  ', () => {
        const spy = spyOn<any>(service, 'findBiggestLine');
        service['alignCenter']();
        expect(spy).toHaveBeenCalled();
    });
    it('alignLeft should calculate alignment position  ', () => {
        service['startingX'] = 200;
        service['alignLeft']();
        expect(service['alignmentX']).toEqual(200);
    });
    it('alignRight should calculate alignment position  ', () => {
        const spy = spyOn<any>(service, 'findBiggestLine');
        service['alignRight']();
        expect(spy).toHaveBeenCalled();
    });
    it('alignText should call alignCenter if textAlign is equal to center', () => {
        service['textAlign'] = 'center';
        const spy = spyOn<any>(service, 'alignCenter');
        service['alignText']();
        expect(spy).toHaveBeenCalled();
    });
    it('alignText should call alignCenter if alignLeft is equal to left', () => {
        service['textAlign'] = 'left';
        const spy = spyOn<any>(service, 'alignLeft');
        service['alignText']();
        expect(spy).toHaveBeenCalled();
    });
    it('alignText should call alignRight if alignLeft is equal to right', () => {
        service['textAlign'] = 'right';
        const spy = spyOn<any>(service, 'alignRight');
        service['alignText']();
        expect(spy).toHaveBeenCalled();
    });

    it('onKeyDown should return if mouseDown is false ', () => {
        const event = {
            key: 'Enter',
        } as KeyboardEvent;
        service['mouseDown'] = false;
        const psy = spyOn<any>(service, 'enterKeyHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalledTimes(0);
    });
    it('onKeyDown should call enterKeyHandler if mouse down true ', () => {
        const event = {
            key: 'Enter',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'enterKeyHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call backSpaceHandler if mouse down true ', () => {
        const event = {
            key: 'Backspace',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'backSpaceHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call arrowRightHandler if mouse down true ', () => {
        const event = {
            key: 'ArrowRight',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'arrowRightHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call arrowLeftHandler if mouse down true ', () => {
        const event = {
            key: 'ArrowLeft',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'arrowLeftHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call arrowUpHandler if mouse down true ', () => {
        const event = {
            key: 'ArrowUp',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'arrowUpHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call arrowDownHandler if mouse down true ', () => {
        const event = {
            key: 'ArrowDown',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'arrowDownHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call deleteHandler if mouse down true ', () => {
        const event = {
            key: 'Delete',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'deleteHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call escapeHandler if mouse down true ', () => {
        const event = {
            key: 'Escape',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'escapeHandler');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });
    it('onKeyDown should call writeOnPreviewCanvas if mouse down true and ket length grater than 1 ', () => {
        const event = {
            key: 'A',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'writeOnPreviewCanvas');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalled();
    });

    it('onKeyDown should return if key length is greater that 1 ', () => {
        const event = {
            key: 'Alt',
        } as KeyboardEvent;
        service['mouseDown'] = true;
        const psy = spyOn<any>(service, 'writeOnPreviewCanvas');
        service.onKeyDown(event);
        expect(psy).toHaveBeenCalledTimes(0);
    });
    it('writeOnPreviewCanvas put key in lineHistory at the current line and increase cursorPositionIndex ', () => {
        const event = {
            key: 'A',
        } as KeyboardEvent;
        service['cursorPositionIndex'] = 0;
        service['currentLineIndex'] = 0;
        service['writeOnPreviewCanvas'](event);
        expect(service['lineHistory']).toEqual(['A']);
    });
    it('writeOnCanvas should return if mouse down false  ', () => {
        service['mouseDown'] = false;
        const psyInitializeText = spyOn<any>(service, 'initializeText');
        service['writeOnCanvas'](service['drawingService'].previewCtx);
        expect(psyInitializeText).toHaveBeenCalledTimes(0);
    });
    it('writeOnCanvas should call write on canvas if mouse down true ', () => {
        service['mouseDown'] = true;
        const psyInitializeText = spyOn<any>(service, 'initializeText');
        service['writeOnCanvas'](service['drawingService'].previewCtx);
        expect(psyInitializeText).toHaveBeenCalled();
    });
    it('enterKeyHandler should increase currentLine put cursorPosition to 0 and shift lines to the right in lineHistory ', () => {
        service['cursorPositionIndex'] = 1;
        service['currentLineIndex'] = 0;
        service['lineHistory'] = ['1234'];
        const expecterLineHistory = ['1', '234'];
        service['enterKeyHandler']();
        expect(service['lineHistory']).toEqual(expecterLineHistory);
        expect(service['cursorPositionIndex']).toEqual(0);
        expect(service['currentLineIndex']).toEqual(1);
    });
    it('arrowUpHandler should return if currentLineIndex is equal to 0 ', () => {
        service['currentLineIndex'] = 0;
        const result = service['arrowUpHandler']();
        expect(result).toEqual();
    });
    it('arrowUpHandler should put cursorPositionIndex to the length of next line if the next line is smaller than the current line   ', () => {
        service['currentLineIndex'] = 1;
        service['lineHistory'] = ['1234', '12345'];
        service['arrowUpHandler']();
        expect(service['cursorPositionIndex']).toEqual(4);
    });
    it('arrowDownHandler should return if we are at the last line ', () => {
        service['currentLineIndex'] = 1;
        service['lineHistory'] = ['1', '234'];
        const result = service['arrowDownHandler']();
        expect(result).toEqual();
    });
    it('arrowDownHandler should put cursorPositionIndex to the length of next line if the next line is bigger than the current line   ', () => {
        service['currentLineIndex'] = 0;
        service['lineHistory'] = ['12345', '1234'];
        service['arrowDownHandler']();
        expect(service['cursorPositionIndex']).toEqual(4);
    });
    it('arrowRightHandler should return if we are on the last line and last letter ', () => {
        service['cursorPositionIndex'] = 4;
        service['currentLineIndex'] = 1;
        service['lineHistory'] = ['12345', '1234'];
        const result = service['arrowRightHandler']();
        expect(result).toEqual();
    });
    it('arrowRightHandler should put cursorPosition tu 0 and increase currentLineIndex when we RE te the end of a line ', () => {
        service['cursorPositionIndex'] = 5;
        service['currentLineIndex'] = 0;
        service['lineHistory'] = ['12345', '1234'];
        service['arrowRightHandler']();
        expect(service['currentLineIndex']).toEqual(1);
        expect(service['cursorPositionIndex']).toEqual(0);
    });
    it('arrowRightHandler should increase cursor position ', () => {
        service['cursorPositionIndex'] = 2;
        service['currentLineIndex'] = 0;
        service['lineHistory'] = ['12345', '1234'];
        service['arrowRightHandler']();
        expect(service['cursorPositionIndex']).toEqual(3);
    });
    it('positionCurserToTheLeft should return if we are at the first line and first letter ', () => {
        service['cursorPositionIndex'] = 0;
        service['currentLineIndex'] = 0;
        service['lineHistory'] = ['12345', '1234'];
        const result = service['positionCurserToTheLeft']();
        expect(result).toEqual();
    });
    it('positionCurserToTheLeft should decrease currentLineIndex if we are at the beginning of a line ', () => {
        service['cursorPositionIndex'] = 0;
        service['currentLineIndex'] = 1;
        service['lineHistory'] = ['12345', '1234'];
        service['positionCurserToTheLeft']();
        expect(service['currentLineIndex']).toEqual(0);
    });
    it('positionCurserToTheLeft should decrease cursorPositionIndex if we are at the beginning of a line ', () => {
        service['cursorPositionIndex'] = 1;
        service['currentLineIndex'] = 1;
        service['lineHistory'] = ['12345', '1234'];
        service['positionCurserToTheLeft']();
        expect(service['cursorPositionIndex']).toEqual(0);
    });
    it('deleteLetter should delete letter at cursorPositionIndex in the current line ', () => {
        const expectedResult = ['12345', '134'];
        service['cursorPositionIndex'] = 1;
        service['currentLineIndex'] = 1;
        service['lineHistory'] = ['12345', '1234'];
        service['deleteLetter']();
        expect(service['lineHistory']).toEqual(expectedResult);
    });
    it('deleteHandler should call deleteLetter ', () => {
        const spy = spyOn<any>(service, 'deleteLetter');
        service['deleteLetter']();
        expect(spy).toHaveBeenCalled();
    });
    it('arrowLeftHandler should call deleteLetter ', () => {
        const spy = spyOn<any>(service, 'positionCurserToTheLeft');
        service['arrowLeftHandler']();
        expect(spy).toHaveBeenCalled();
    });
    it('backSpaceHandler should call deleteLetter and positionCursor to the left ', () => {
        const positionCurserToTheLeftSpy = spyOn<any>(service, 'positionCurserToTheLeft');
        const deleteLetterSpy = spyOn<any>(service, 'deleteLetter');
        service['backSpaceHandler']();
        expect(positionCurserToTheLeftSpy).toHaveBeenCalled();
        expect(deleteLetterSpy).toHaveBeenCalled();
    });
    it('backSpaceHandler  ', () => {
        const spy = spyOn<any>(service, 'clearLineHistory');
        service['escapeHandler']();
        expect(service['mouseDown']).toEqual(false);
        expect(spy).toHaveBeenCalled();
    });

    it('ngDestroy should unsubscribe the subscription', () => {
        const spy = spyOn(service['subscription'], 'unsubscribe');
        service.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
});
