import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { PaintBucketService } from './paint-bucket.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('PaintBucketService', () => {
    let service: PaintBucketService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let floodFillSpy: jasmine.Spy<any>;
    let contiguousFloodFillSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        TestBed.configureTestingModule({});
        service = TestBed.inject(PaintBucketService);

        floodFillSpy = spyOn<any>(service, 'floodFill').and.callThrough();
        contiguousFloodFillSpy = spyOn<any>(service, 'contiguousFloodFill').and.callThrough();
        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // Tests hexadecimalToDecimal
    it('hexadecimalToDecimal with AB should return 171', () => {
        const expectValue: number = service['hexadecimalToDecimal']('AB');
        expect(expectValue).toEqual(171);
    });

    it('hexadecimalToDecimal with CD should return 205', () => {
        const expectValue: number = service['hexadecimalToDecimal']('CD');
        expect(expectValue).toEqual(205);
    });

    it('hexadecimalToDecimal with EF should return 239', () => {
        const expectValue: number = service['hexadecimalToDecimal']('EF');
        expect(expectValue).toEqual(239);
    });

    it('hexadecimalToDecimal with 09 should return 11', () => {
        const expectValue: number = service['hexadecimalToDecimal']('09');
        expect(expectValue).toEqual(9);
    });

    it('onMouseDown with left click should call floodFill', () => {
        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 0,
        } as MouseEvent;

        spyOnProperty(service['drawingService'].baseCtx.canvas, 'clientWidth').and.returnValue(100);
        spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        service.onMouseDown(mouseEvent);

        expect(floodFillSpy).toHaveBeenCalled();
    });

    it('onMouseDown with right click should call contiguousFloodFill', () => {
        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 2,
        } as MouseEvent;

        spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        service.onMouseDown(mouseEvent);

        expect(contiguousFloodFillSpy).toHaveBeenCalled();
    });

    it('matchPixel with tolerance!=0 ', () => {
        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 0,
        } as MouseEvent;
        service['sidebarService'].tolerance = 50;

        spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        service.onMouseDown(mouseEvent);

        expect(floodFillSpy).toHaveBeenCalled();
    });

    it('colorPixel with a color with opacity', () => {
        const dstImg = new ImageData(100, 100);
        const dstData: Uint8ClampedArray = dstImg.data;

        const hexToDecSpy = spyOn<any>(service, 'hexadecimalToDecimal').and.callThrough();
        service['colorPixel'](dstData, 1, '111111111');

        expect(hexToDecSpy).toHaveBeenCalledTimes(4);
    });

    it('colorPixel with a color without', () => {
        const dstImg = new ImageData(100, 100);
        const dstData: Uint8ClampedArray = dstImg.data;

        const hexToDecSpy = spyOn<any>(service, 'hexadecimalToDecimal').and.callThrough();
        service['colorPixel'](dstData, 1, '1111111');

        expect(hexToDecSpy).toHaveBeenCalledTimes(3);
    });

    it('floodFill test While 1', () => {
        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 0,
        } as MouseEvent;
        service['sidebarService'].tolerance = 50;

        spyOnProperty<any>(service['drawingService'].baseCtx.canvas, 'clientHeight').and.returnValue(10);
        spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        const spy = spyOn<any>(service, 'matchPixel').and.returnValue(true);

        service.onMouseDown(mouseEvent);

        expect(spy).toHaveBeenCalled();
    });

    it('contiguousFloodFill test for loop', () => {
        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        service['sidebarService'].tolerance = 50;

        spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        spyOnProperty<any>(service['drawingService'].baseCtx.canvas, 'clientHeight').and.returnValue(5);
        spyOnProperty<any>(service['drawingService'].baseCtx.canvas, 'clientWidth').and.returnValue(5);
        const spy = spyOn<any>(service, 'getPixelPos');

        service.onMouseDown(mouseEvent);

        expect(spy).toHaveBeenCalledTimes(17);
        expect(contiguousFloodFillSpy).toHaveBeenCalled();
    });

    it('contiguousFloodFill test for loop 2', () => {
        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        service['sidebarService'].tolerance = 50;

        spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        spyOn<any>(service, 'matchPixel').and.returnValue(true);
        spyOnProperty<any>(service['drawingService'].baseCtx.canvas, 'clientHeight').and.returnValue(5);
        spyOnProperty<any>(service['drawingService'].baseCtx.canvas, 'clientWidth').and.returnValue(5);
        const spy = spyOn<any>(service, 'getPixelPos');

        service.onMouseDown(mouseEvent);

        expect(spy).toHaveBeenCalledTimes(17);
        expect(contiguousFloodFillSpy).toHaveBeenCalled();
    });
    it('ngDestroy should unsubscribe the subscriptio', () => {
        const spy = spyOn(service['subscription'], 'unsubscribe');
        service.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
});
