import { Injectable } from '@angular/core';
import { Stamp } from '@app/classes/stamp';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class StampService extends Tool {
    private position: Vec2;
    private scale: number = 1;
    private altKeyPressed: boolean = false;
    private mouseIsOut: boolean = false;

    srcEmitter: BehaviorSubject<string> = new BehaviorSubject<string>('liftarn_Barett');
    srcObserver$: Observable<string> = this.srcEmitter.asObservable();
    src: string = '../../../assets/stamp-images/liftarn_Barett.svg';
    angle: number = 0;
    image: HTMLImageElement = new Image();

    constructor(protected drawingService: DrawingService, private undoRedoService: UndoRedoService) {
        super(drawingService);
    }

    onMouseLeave(): void {
        this.mouseIsOut = true;
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
    }

    onMouseEnter(): void {
        this.mouseIsOut = false;
    }

    onMouseDown(event: MouseEvent): void {
        if (event.button === MouseButton.Left && !this.mouseIsOut) {
            this.position = this.getPositionFromMouse(event);
            this.draw(this.drawingService.baseCtx, this.angle, this.position);
            const stamp = new Stamp(this.position, this.src, this.angle, this.scale);
            this.undoRedoService.addToStack(stamp);
        }
    }
    onMouseMove(event: MouseEvent): void {
        if (this.mouseIsOut) {
            return;
        }
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.position = this.getPositionFromMouse(event);
        this.draw(this.drawingService.previewCtx, this.angle, this.position);
    }

    onMouseWheel(event: WheelEvent): void {
        event.preventDefault();
        if (this.mouseIsOut) {
            return;
        }
        this.angle += this.altKeyPressed
            ? this.normalizeDeltaY(event) * this.convertAngleToRadian(CONSTANT.DEGREE_1)
            : this.normalizeDeltaY(event) * this.convertAngleToRadian(CONSTANT.DEGREE_15);
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.position = this.getPositionFromMouse(event);
        this.draw(this.drawingService.previewCtx, this.angle, this.position);
    }

    onKeyDown(event: KeyboardEvent): void {
        event.preventDefault();
        this.altKeyPressed = event.altKey;
    }

    onKeyUp(event?: KeyboardEvent): void {
        if (this.altKeyPressed) {
            this.altKeyPressed = false;
        }
    }

    changeScale(scale: number): void {
        this.scale = scale;
    }

    changeAngle(angle: number): void {
        this.angle = this.convertAngleToRadian(angle);
    }

    private draw(ctx: CanvasRenderingContext2D, angle: number, position: Vec2): void {
        ctx.save();
        ctx.translate(position.x, position.y);
        ctx.rotate(angle);
        ctx.scale(this.scale, this.scale);
        ctx.translate(-this.image.width / 2, -this.image.height / 2);
        this.image.src = this.src;

        ctx.drawImage(this.image, 0, 0);

        ctx.restore();
    }

    private convertAngleToRadian(angle: number): number {
        return (angle * Math.PI) / CONSTANT.DEGREE_180;
    }
    private normalizeDeltaY(event: WheelEvent): number {
        return event.deltaY / Math.abs(event.deltaY);
    }
}
