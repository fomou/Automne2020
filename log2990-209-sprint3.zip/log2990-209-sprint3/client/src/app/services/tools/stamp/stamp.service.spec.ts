import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { StampService } from './stamp.service';

// tslint:disable:no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
describe('StampService', () => {
    let service: StampService;
    let drawingSpy: jasmine.SpyObj<DrawingService>;
    let mouseEvent: MouseEvent;

    beforeEach(() => {
        drawingSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        TestBed.configureTestingModule({
            providers: [{ DrawingService, useValue: drawingSpy }],
        });
        service = TestBed.inject(StampService);
        service.image = new Image();
        service['scale'] = 1;
        service['drawingService'].canvas = canvasTestHelper.canvas;
        service['drawingService'].previewCtx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        service.src = '';
        mouseEvent = { pageX: 350, pageY: 55, button: 0 } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('#mouseLeave should set mouseIsOut true and call clearCanvas', () => {
        service['mouseIsOut'] = false;
        const spy = spyOn(service['drawingService'], 'clearCanvas');
        service.onMouseLeave();
        expect(spy).toHaveBeenCalled();
        expect(service['mouseIsOut']).toEqual(true);
    });

    it('#onMouseEnter should set mouseIsOut false', () => {
        service['mouseIsOut'] = true;
        service.onMouseEnter();
        expect(service['mouseIsOut']).toEqual(false);
    });

    it('#mouseDown should call draw and set position', () => {
        service['mouseIsOut'] = false;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        service.onMouseDown(mouseEvent);
        expect(spy).toHaveBeenCalled();
        expect(service['position']).toEqual({ x: 79, y: 55 });
    });

    it('#onMouseDown should do nothing on right click', () => {
        const e = { button: 2 } as MouseEvent;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        service.onMouseDown(e);
        expect(spy).not.toHaveBeenCalled();
    });
    it('#onMouseDown should do nothing if mouse is out', () => {
        service['mouseIsOut'] = true;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        service.onMouseDown(mouseEvent);
        expect(spy).not.toHaveBeenCalled();
    });

    it('#onMouseMove should do nothing if mouse if out', () => {
        service['mouseIsOut'] = true;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        service.onMouseMove(mouseEvent);
        expect(spy).not.toHaveBeenCalled();
        expect(drawingSpy.clearCanvas).not.toHaveBeenCalled();
    });

    it('#onMouseMove should call draw and set position', () => {
        service['mouseIsOut'] = false;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        service.onMouseMove(mouseEvent);
        expect(spy).toHaveBeenCalled();
        expect(service['position']).toEqual({ x: 79, y: 55 });
    });

    it('#onMouseWheel should call draw and set position', () => {
        service['mouseIsOut'] = false;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        const e = new WheelEvent('event');
        service.onMouseWheel(e);
        expect(spy).toHaveBeenCalled();
    });

    it('#onMouseWheel altKeyPressed false with should call draw and set position', () => {
        service['mouseIsOut'] = false;
        service['altKeyPressed'] = true;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        const e = new WheelEvent('event');
        service.onMouseWheel(e);
        expect(spy).toHaveBeenCalled();
    });

    it('#onMouseWheel with mouseIsOut true should return', () => {
        service['mouseIsOut'] = true;
        const spy = spyOn<any>(service, 'draw').and.callFake(() => {
            return;
        });
        const e = new WheelEvent('event');
        service.onMouseWheel(e);
        expect(spy).not.toHaveBeenCalled();
    });

    it('onKeyDown should be true if altKey is pressed', () => {
        const e = new KeyboardEvent('keypress', {
            altKey: true,
        });
        const spy = spyOn(e, 'preventDefault');
        service.onKeyDown(e);
        expect(spy).toHaveBeenCalled();
        expect(service['altKeyPressed']).toEqual(true);
    });

    it('onKeyUp should set altKeyPressed true if altKey is pressed', () => {
        const e = new KeyboardEvent('keypress', {
            altKey: true,
        });
        service['altKeyPressed'] = true;

        service.onKeyUp(e);

        expect(service['altKeyPressed']).toEqual(false);
    });

    it('onKeyUp should not set altKeyPressed if altKey is not pressed', () => {
        const e = new KeyboardEvent('keypress', {
            altKey: false,
        });
        service['altKeyPressed'] = false;

        service.onKeyUp(e);

        expect(service['altKeyPressed']).toEqual(false);
    });

    it('changeScale should set scale', () => {
        const expectResult = 10;
        service.changeScale(10);
        expect(service['scale']).toEqual(expectResult);
    });

    it('changeAngle should call convertAngleToRadian', () => {
        const spy = spyOn<any>(service, 'convertAngleToRadian');
        service.changeAngle(10);
        expect(spy).toHaveBeenCalled();
    });

    it('draw should call drawImage', () => {
        service['scale'] = 10;
        service.image.width = 10;
        service.image.height = 10;
        service.src = 'yes';
        const vec = { x: 20, y: 20 } as Vec2;
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const spy = spyOn<any>(ctx, 'save');
        service['draw'](ctx, 20, vec);
        expect(spy).toHaveBeenCalled();
    });
});
