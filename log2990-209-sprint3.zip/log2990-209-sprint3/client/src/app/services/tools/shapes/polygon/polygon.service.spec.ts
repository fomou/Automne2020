import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { PolygonService } from './polygon.service';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable:no-magic-numbers
describe('PolygonService', () => {
    let service: PolygonService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let drawShapeSpy: jasmine.Spy<any>;
    let drawPreviewPerimeterSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(PolygonService);

        drawShapeSpy = spyOn<any>(service, 'drawShape').and.callThrough();
        drawPreviewPerimeterSpy = spyOn<any>(service, 'drawPreviewPerimeter').and.callThrough();
        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 30,
            pageY: 30,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('onMouseUp should call clearCanvas if mouse was already down', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = true;
        service['radius'] = 2;
        service['circleCenter'] = { x: 25, y: 25 };

        service.onMouseUp(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(false);
    });

    it('onMouseUp should  not call clearCanvas if mouse was not already down', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = false;

        service.onMouseUp(mouseEvent);

        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
    });

    it('onMouseMove with outline drawing style should call drawShape and drawPreviewPerimeter', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = true;
        service['shiftPressed'] = true;
        service['drawingType'] = 'outline';

        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawShapeSpy).toHaveBeenCalled();
        expect(drawPreviewPerimeterSpy).toHaveBeenCalled();
    });

    it('onMouseMove with fill drawing style should call drawShape and drawPreviewPerimeter', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = true;
        service['drawingType'] = 'fill';

        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawShapeSpy).toHaveBeenCalled();
        expect(drawPreviewPerimeterSpy).toHaveBeenCalled();
    });

    it('onMouseMove with stroke drawing style should call drawShape and drawPreviewPerimeter', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = true;
        service['drawingType'] = 'stroke';

        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawShapeSpy).toHaveBeenCalled();
        expect(drawPreviewPerimeterSpy).toHaveBeenCalled();
    });

    it('onMouseMove should not call drawShape if mouseDown is false', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = false;

        service.onMouseMove(mouseEvent);

        expect(drawShapeSpy).not.toHaveBeenCalled();
    });
});
