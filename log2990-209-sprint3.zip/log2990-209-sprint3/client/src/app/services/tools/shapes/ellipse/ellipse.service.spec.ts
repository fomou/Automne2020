import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { EllipseService } from './ellipse.service';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
describe('EllipseService', () => {
    let service: EllipseService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let drawShapeSpy: jasmine.Spy<any>;
    let drawPreviewPerimeterSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(EllipseService);

        drawShapeSpy = spyOn<any>(service, 'drawShape').and.callThrough();
        drawPreviewPerimeterSpy = spyOn<any>(service, 'drawPreviewPerimeter').and.callThrough();
        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 30,
            pageY: 30,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('onMouseUp should call clearCanvas if mouse was already down', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = true;
        service['radiusX'] = 2;
        service['radiusY'] = 2;
        service['circleCenter'] = { x: 25, y: 25 };

        service.onMouseUp(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(false);
    });

    it('onMouseUp should  not call clearCanvas if mouse was not already down', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = false;

        service.onMouseUp(mouseEvent);

        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
    });

    it('onMouseMove with outline drawing style should call drawShape and drawPreviewPerimeter', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = true;
        service['shiftPressed'] = true;
        service['drawingType'] = 'outline';

        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawShapeSpy).toHaveBeenCalled();
        expect(drawPreviewPerimeterSpy).toHaveBeenCalled();
    });

    it('onMouseMove with fill drawing style should call drawShape and drawPreviewPerimeter', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = true;
        service['drawingType'] = 'fill';

        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawShapeSpy).toHaveBeenCalled();
        expect(drawPreviewPerimeterSpy).toHaveBeenCalled();
    });

    it('onMouseMove with stroke drawing style should call drawShape and drawPreviewPerimeter', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 40, y: 40 };
        service['mouseDown'] = true;
        service['drawingType'] = 'stroke';

        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(drawShapeSpy).toHaveBeenCalled();
        expect(drawPreviewPerimeterSpy).toHaveBeenCalled();
    });

    it('onMouseMove should not call drawShape if mouseDown is false', () => {
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 0, y: 0 };
        service['mouseDown'] = false;

        service.onMouseMove(mouseEvent);

        expect(drawShapeSpy).not.toHaveBeenCalled();
    });

    it('onKeyDown should set shiftPressed to true', () => {
        const keyboardEvent = { key: 'Shift' } as KeyboardEvent;
        service['mouseDown'] = true;
        service['shiftPressed'] = false;

        service.onKeyDown(keyboardEvent);

        expect(service['shiftPressed']).toEqual(true);
    });

    it('onKeyDown should not set shiftPressed if shift was not the event key', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service['mouseDown'] = true;
        service['shiftPressed'] = false;

        service.onKeyDown(keyboardEvent);

        expect(service['shiftPressed']).toEqual(false);
    });

    it('onKeyUp should set shiftPressed to false', () => {
        const keyboardEvent = { key: 'Shift' } as KeyboardEvent;
        service['shiftPressed'] = true;
        service['mouseDown'] = true;

        service.onKeyUp(keyboardEvent);

        expect(service['shiftPressed']).toEqual(false);
    });

    it('onKeyUp should not set shiftPressed to false if shift was not the event key', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service['shiftPressed'] = true;
        service['mouseDown'] = true;

        service.onKeyUp(keyboardEvent);

        expect(service['shiftPressed']).toEqual(true);
    });

    it('onKeyUp should not set shiftPressed to false if shift was not the event key', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service['shiftPressed'] = true;
        service['mouseDown'] = true;

        service.onKeyUp(keyboardEvent);

        expect(service['shiftPressed']).toEqual(true);
    });

    // Tests pour la classe abstraite ShapeTool
    it('onMouseDown should set mouseDown true', () => {
        service['mouseDown'] = false;
        service.height = 30;

        service.onMouseDown(mouseEvent);

        expect(service.height).toEqual(0);
        expect(service['mouseDown']).toEqual(true);
    });

    it('onMouseDown with rightClick should not set mouseDown true', () => {
        mouseEvent = {
            pageX: 30,
            pageY: 30,
            button: 2,
        } as MouseEvent;

        service['mouseDown'] = false;
        service.height = 30;

        service.onMouseDown(mouseEvent);
        expect(service['mouseDown']).toEqual(false);
    });

    it('findTopLeftPoint with EndPoint at the top right of startPoint', () => {
        const firstPoint: Vec2 = { x: 25, y: 25 };
        const lastPoint: Vec2 = { x: 50, y: 0 };
        const expectValue: Vec2 = { x: 25, y: 0 };

        const value = service['findTopLeftPoint'](firstPoint, lastPoint);

        expect(value).toEqual(expectValue);
    });

    it('findTopLeftPoint case firstPoint = topLeftPoint', () => {
        const firstPoint: Vec2 = { x: 25, y: 25 };
        const lastPoint: Vec2 = { x: 50, y: 50 };
        const expectValue: Vec2 = { x: 25, y: 25 };

        const value = service['findTopLeftPoint'](firstPoint, lastPoint);

        expect(value).toEqual(expectValue);
    });

    it('findShiftPoint case width < height', () => {
        const firstPoint: Vec2 = { x: 25, y: 25 };
        const lastPoint: Vec2 = { x: 20, y: 0 };
        const expectValue: Vec2 = { x: 20, y: 20 };

        const value = service['findShiftPoint'](firstPoint, lastPoint);

        expect(value).toEqual(expectValue);
    });

    it('findShiftPoint negative case line 71', () => {
        const firstPoint: Vec2 = { x: 0, y: 0 };
        const lastPoint: Vec2 = { x: 20, y: 25 };
        const expectValue: Vec2 = { x: 20, y: 20 };

        const value = service['findShiftPoint'](firstPoint, lastPoint);

        expect(value).toEqual(expectValue);
    });

    it('findShiftPoint case line 76', () => {
        const firstPoint: Vec2 = { x: 25, y: 25 };
        const lastPoint: Vec2 = { x: 20, y: 50 };
        const expectValue: Vec2 = { x: 20, y: 30 };

        const value = service['findShiftPoint'](firstPoint, lastPoint);

        expect(value).toEqual(expectValue);
    });

    it('findShiftPoint case line 85', () => {
        const firstPoint: Vec2 = { x: 25, y: 25 };
        const lastPoint: Vec2 = { x: 50, y: 0 };
        const expectValue: Vec2 = { x: 50, y: 0 };

        const value = service['findShiftPoint'](firstPoint, lastPoint);

        expect(value).toEqual(expectValue);
    });

    it('getCenter negative cases', () => {
        const firstPoint: Vec2 = { x: 20, y: 20 };
        const lastPoint: Vec2 = { x: 40, y: 0 };
        const expectValue: Vec2 = { x: 30, y: 10 };

        const value = service['getCenter'](firstPoint, lastPoint);

        expect(value).toEqual(expectValue);
    });
});
