import { Injectable, OnDestroy } from '@angular/core';
import { Polygon } from '@app/classes/polygon';
import { ShapeTool } from '@app/classes/shape-tool';
import { Vec2 } from '@app/classes/vec2';
import { DrawingType } from '@app/enums/draw-type';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingTypeSelectorService } from '@app/services/drawing-type/drawing-type-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs/internal/Subscription';

@Injectable({
    providedIn: 'root',
})
export class PolygonService extends ShapeTool implements OnDestroy {
    private circleCenter: Vec2;
    private radius: number;
    private subscription: Subscription[] = [];
    sides: number = 3;

    constructor(
        protected drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private sidebarService: SidebarService,
        private undoRedoService: UndoRedoService,
        private drawingTypeService: DrawingTypeSelectorService,
    ) {
        super(drawingService);

        const subColorPrim = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.primaryColor = color;
        });

        const subsSec = this.colorSelectorService.secondaryColor$.subscribe((color) => {
            this.secondaryColor = color;
        });

        const subsDrawType = this.drawingTypeService.drawingType$.subscribe((type) => {
            this.drawingType = type;
        });

        this.subscription.push(subColorPrim);
        this.subscription.push(subsDrawType);
        this.subscription.push(subsSec);
    }
    ngOnDestroy(): void {
        for (const subs of this.subscription) {
            subs.unsubscribe();
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawShape(this.drawingService.baseCtx);

            const polygon = new Polygon(
                this.circleCenter,
                this.radius,
                this.sides,
                this.drawingType,
                this.sidebarService.widthShape,
                this.primaryColor,
                this.secondaryColor,
            );

            this.undoRedoService.addToStack(polygon);
            this.undoRedoService.setToolInUse(false);
            this.mouseDown = false;
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown) {
            this.undoRedoService.setToolInUse(true);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);

            this.drawPreviewPerimeter();
            this.drawShape(this.drawingService.previewCtx);
        }
    }

    protected drawPreviewPerimeter(): void {
        const shiftLastPoint = this.findShiftPoint(this.firstPoint, this.lastPoint);
        this.circleCenter = this.getCenter(this.firstPoint, shiftLastPoint);
        this.radius = Math.abs(this.lastPoint.x - this.firstPoint.x) / 2;

        this.drawingService.previewCtx.beginPath();
        this.drawingService.previewCtx.setLineDash([1, 2]); // ligne pointillée

        this.drawingService.previewCtx.lineWidth = 1;
        this.drawingService.previewCtx.strokeStyle = 'blue';
        this.drawingService.previewCtx.ellipse(this.circleCenter.x, this.circleCenter.y, this.radius, this.radius, 0, 0, Math.PI * 2);
        this.drawingService.previewCtx.stroke();
        this.drawingService.previewCtx.setLineDash([]);
        this.drawingService.previewCtx.closePath();
    }

    protected drawShape(ctx: CanvasRenderingContext2D): void {
        const radiusFinal = this.initializeShapeVariables();

        ctx.beginPath();
        ctx.lineWidth = this.sidebarService.widthShape;
        ctx.strokeStyle = this.secondaryColor;
        ctx.fillStyle = this.primaryColor;

        ctx.moveTo(this.circleCenter.x + radiusFinal * Math.cos(-Math.PI / 2), this.circleCenter.y + radiusFinal * Math.sin(-Math.PI / 2));
        for (let i = 1; i <= this.sides + 1; i++) {
            ctx.lineTo(
                this.circleCenter.x + radiusFinal * Math.cos((i * 2 * Math.PI) / this.sides - Math.PI / 2),
                this.circleCenter.y + radiusFinal * Math.sin((i * 2 * Math.PI) / this.sides - Math.PI / 2),
            );
        }

        switch (this.drawingType) {
            case DrawingType.Stroke:
                ctx.stroke();
                ctx.closePath();
                break;

            case DrawingType.Fill:
                ctx.fill();
                ctx.closePath();
                break;

            case DrawingType.Outline:
                ctx.fill();
                ctx.stroke();
                ctx.closePath();
                break;
        }
    }

    protected initializeShapeVariables(): number {
        const shiftLastPoint = this.findShiftPoint(this.firstPoint, this.lastPoint);
        this.circleCenter = this.getCenter(this.firstPoint, shiftLastPoint);
        this.radius = Math.abs(this.lastPoint.x - this.firstPoint.x) / 2;
        const radiusFinal = Math.abs(this.radius - this.sidebarService.widthShape / 2 - this.sidebarService.widthShape / this.sides);

        return radiusFinal;
    }
}
