import { Injectable } from '@angular/core';
import { PixelData } from '@app/classes/pixel-data';
import { Tool } from '@app/classes/tool';
import * as CONSTANT from '@app/constants/constants';
import { ColorType } from '@app/enums/color-type';
import { MouseButton } from '@app/enums/mouse-button';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class PickerService extends Tool {
    private display: Subject<boolean>;
    private imageDataSource: Subject<PixelData>;

    color: BehaviorSubject<string>;
    displayObs$: Observable<boolean>;
    imageData$: Observable<PixelData>;

    constructor(public colorSelectorService: ColorSelectorService, protected drawingService: DrawingService) {
        super(drawingService);
        this.display = new Subject<boolean>();
        this.imageDataSource = new Subject<PixelData>();
        this.color = new BehaviorSubject<string>('#00000000');
        this.displayObs$ = this.display.asObservable();
        this.imageData$ = this.imageDataSource.asObservable();
    }

    onMouseMove(event: MouseEvent): void {
        if (
            event.offsetX > this.drawingService.canvas.width ||
            event.offsetY > this.drawingService.canvas.height ||
            event.pageX <= CONSTANT.SIDE_BAR_X_POSITION
        ) {
            return;
        }
        const imageData = this.getImageDataAtPosition(this.drawingService.baseCtx, event);
        const point = this.getPositionFromMouse(event);
        this.color.next(this.getColorAtPosition(this.drawingService.baseCtx, event));
        const pixelData: PixelData = { centerPoint: point, imageData };
        this.imageDataSource.next(pixelData);
    }

    onMouseDown(event: MouseEvent): void {
        const color = this.getColorAtPosition(this.drawingService.baseCtx, event);
        if (event.button === MouseButton.Left) {
            this.colorSelectorService.colorType = ColorType.Primary;
            this.colorSelectorService.announceColor(color);
        } else if (event.button === MouseButton.Right) {
            this.colorSelectorService.colorType = ColorType.Secondary;
            this.colorSelectorService.announceColor(color);
        }
    }

    onMouseLeave(): void {
        this.display.next(false);
    }
    onMouseEnter(): void {
        this.display.next(true);
    }

    private getImageDataAtPosition(ctx: CanvasRenderingContext2D, event: MouseEvent): ImageData {
        return ctx.getImageData(
            event.offsetX - CONSTANT.PREVIEW_CIRCLE_RADIUS / 2,
            event.offsetY - CONSTANT.PREVIEW_CIRCLE_RADIUS / 2,
            CONSTANT.PREVIEW_CIRCLE_RADIUS,
            CONSTANT.PREVIEW_CIRCLE_RADIUS,
        );
    }
    private getColorAtPosition(ctx: CanvasRenderingContext2D, event: MouseEvent): string {
        const imageData = ctx.getImageData(event.offsetX, event.offsetY, 1, 1).data;
        const redHex = this.fillString(imageData[0].toString(16));
        const greenHex = this.fillString(imageData[1].toString(16));
        const blueHex = this.fillString(imageData[2].toString(16));
        const hexadecimalColor = '#' + (redHex + greenHex + blueHex + 'FF').toUpperCase();

        return hexadecimalColor;
    }

    private fillString(n: string): string {
        return n.length > 1 ? n : '0' + n;
    }
}
