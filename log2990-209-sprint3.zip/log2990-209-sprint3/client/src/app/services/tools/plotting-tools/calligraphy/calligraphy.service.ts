import { Injectable, OnDestroy } from '@angular/core';
import { Calligraphy } from '@app/classes/calligraphy';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';
@Injectable({
    providedIn: 'root',
})
export class CalligraphyService extends Tool implements OnDestroy {
    private pathData: Vec2[];
    private color: string;
    private height: number;
    private subscription: Subscription;
    constructor(
        protected drawingService: DrawingService,
        private sidebarService: SidebarService,
        private colorSelectorService: ColorSelectorService,
        private undoRedoService: UndoRedoService,
    ) {
        super(drawingService);
        this.subscription = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });
        this.clearPath();
    }
    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
    onMouseWheel(event: WheelEvent): void {
        const wheelDirection = event.deltaY / CONSTANT.DELTA_Y_MOUSE;
        if (event.altKey) {
            this.sidebarService.angleCalligraphy += wheelDirection;
        } else {
            this.sidebarService.angleCalligraphy += wheelDirection * CONSTANT.DEGREE_15;
        }
    }

    onMouseEnter(event: MouseEvent): void {
        if (event.buttons === 1) {
            this.mouseDown = true;
        }
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.clearPath();
            this.mouseDownCoord = this.getPositionFromMouse(event);
            this.pathData.push(this.mouseDownCoord);
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown) {
            const mousePosition = this.getPositionFromMouse(event);
            this.pathData.push(mousePosition);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawLines(this.drawingService.previewCtx);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown) {
            const mousePosition = this.getPositionFromMouse(event);
            this.pathData.push(mousePosition);
            this.drawLines(this.drawingService.baseCtx);
            const angle = this.convertDegreesToRadians(this.sidebarService.angleCalligraphy);
            const calligraphy = new Calligraphy(this.pathData, this.height, angle, this.color);
            this.undoRedoService.addToStack(calligraphy);
        }
        this.mouseDown = false;
        this.clearPath();
    }

    onMouseLeave(event: MouseEvent): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        const mousePosition = this.getPositionFromMouse(event);
        this.pathData.push(mousePosition);
        this.drawLines(this.drawingService.baseCtx);
        this.clearPath();
        this.mouseDown = false;
    }

    private drawLines(ctx: CanvasRenderingContext2D): void {
        this.initializePath(ctx);
        ctx.beginPath();
        for (let i = 0; i < this.pathData.length - 1; i++) {
            ctx.lineTo(this.pathData[i].x, this.pathData[i].y);
            for (let j = 0; j < this.height; j++) {
                const angleInRadians = this.convertDegreesToRadians(this.sidebarService.angleCalligraphy);
                ctx.moveTo(this.pathData[i].x + Math.cos(angleInRadians) * j, this.pathData[i].y - Math.sin(angleInRadians) * j);
                ctx.lineTo(this.pathData[i + 1].x + Math.cos(angleInRadians) * j, this.pathData[i + 1].y - Math.sin(angleInRadians) * j);
            }
        }
        ctx.stroke();
    }

    private convertDegreesToRadians(angleInDegrees: number): number {
        return (angleInDegrees * Math.PI) / CONSTANT.DEGREE_180;
    }

    private initializePath(ctx: CanvasRenderingContext2D): void {
        this.height = this.sidebarService.heightCalligraphy;
        ctx.lineWidth = 2;
        ctx.strokeStyle = this.color;
    }

    private clearPath(): void {
        this.pathData = [];
    }
}
