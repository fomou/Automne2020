import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { CalligraphyService } from './calligraphy.service';

// tslint:disable: no-any
// tslint:disable:no-string-literal
// tslint:disable:no-magic-numbers
describe('CalligraphyService', () => {
    let service: CalligraphyService;
    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let ctxStub: CanvasRenderingContext2D;
    beforeEach(() => {
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        ctxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        TestBed.configureTestingModule({ providers: [{ provide: DrawingService, useValue: drawServiceSpy }] });
        service = TestBed.inject(CalligraphyService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('onMouseWheel with anti clockwise rotation should rotate line by 15 degrees', () => {
        service['sidebarService'].angleCalligraphy = 0;
        const event = { deltaY: -100 } as WheelEvent;
        service.onMouseWheel(event);
        expect(service['sidebarService'].angleCalligraphy).toEqual(15);
    });

    it('onMouseWheel with clockwise rotation and alt key pressed should rotate line by -1 degrees', () => {
        service['sidebarService'].angleCalligraphy = 0;
        const event = { deltaY: 100, altKey: true } as WheelEvent;
        service.onMouseWheel(event);
        expect(service['sidebarService'].angleCalligraphy).toEqual(-1);
    });

    it('onMouseEnter should put mouseDown to true when mouse left button is down ', () => {
        const event = { buttons: 1 } as MouseEvent;
        service.onMouseEnter(event);
        expect(service['mouseDown']).toEqual(true);
    });
    it('onMouseEnter should not change mouseDown state when mouse left button is not down ', () => {
        const event = { buttons: 0 } as MouseEvent;
        service['mouseDown'] = false;
        service.onMouseEnter(event);
        expect(service['mouseDown']).toEqual(false);
    });
    it('onMouseDown should call clearPath and add current mouse coordinate in pathData when mouse left button is down ', () => {
        const event = { button: 0 } as MouseEvent;
        const spy = spyOn<any>(service, 'clearPath');
        service.onMouseDown(event);
        expect(spy).toHaveBeenCalled();
        expect(service['pathData'].length).toEqual(1);
    });
    it('onMouseDown should not add current mouse coordinates to dataPath ', () => {
        const event = { button: 1, pageX: 300, pageY: 300 } as MouseEvent;
        service.onMouseDown(event);
        expect(service['pathData'].length).toEqual(0);
    });
    it('onMouseMove should  add current mouse coordinate in pathData and call drawnLines when mouse left button is down ', () => {
        service['mouseDown'] = true;
        const event = { button: 0 } as MouseEvent;
        const spy = spyOn<any>(service, 'drawLines');
        service.onMouseMove(event);
        expect(spy).toHaveBeenCalled();
        expect(service['pathData'].length).toEqual(1);
    });
    it('onMouseMove should  add current mouse coordinate in pathData and call drawnLines when mouse left button is down ', () => {
        const event = { button: 1, pageX: 300, pageY: 300 } as MouseEvent;
        service.onMouseMove(event);
        expect(service['pathData'].length).toEqual(0);
    });
    it('onMouseUp should  add current mouse coordinate in pathData and call drawnLines when mouse left button is down then put mouseDown to false and clear pathData ', () => {
        service['mouseDown'] = true;
        const event = { button: 0 } as MouseEvent;
        const spy = spyOn<any>(service, 'drawLines');
        service.onMouseUp(event);
        expect(spy).toHaveBeenCalled();
        expect(service['mouseDown']).toBe(false);
        expect(service['pathData'].length).toEqual(0);
    });
    it('onMouseUp should  add current mouse coordinate in pathData and call drawnLines when mouse left button is down then put mouseDown to false and clear pathData ', () => {
        service['mouseDown'] = false;
        const event = { button: 0 } as MouseEvent;
        const spy = spyOn<any>(service, 'drawLines');
        service.onMouseUp(event);
        expect(spy).toHaveBeenCalledTimes(0);
    });
    it('onMouseLeave should  add current mouse coordinate in pathData and call drawnLines when mouse left button is down then put mouseDown to false and clear pathData ', () => {
        const event = { button: 0 } as MouseEvent;
        const spy = spyOn<any>(service, 'drawLines');
        service.onMouseLeave(event);
        expect(spy).toHaveBeenCalled();
        expect(service['mouseDown']).toBe(false);
        expect(service['pathData'].length).toEqual(0);
    });
    it('drawLines should  call initializePath, convertDegreesToRadians and stroke ', () => {
        const spyInitializePath = spyOn<any>(service, 'initializePath');
        const spyConvertToRadians = spyOn<any>(service, 'convertDegreesToRadians');
        const vecPathData1: Vec2 = { x: 10, y: 10 };
        service['pathData'].push(vecPathData1);
        service['pathData'].push(vecPathData1);
        service['height'] = 1;
        service['drawLines'](ctxStub);
        expect(spyInitializePath).toHaveBeenCalled();
        expect(spyConvertToRadians).toHaveBeenCalled();
    });
    it('convertDegreesToRadians should return degrees converted in radians ', () => {
        const angleInDegrees = 180;
        const angleInRadians = service['convertDegreesToRadians'](angleInDegrees);
        expect(angleInRadians).toEqual(Math.PI);
    });
    it('initializePath should initialize the line height its lineWidth  ', () => {
        service['sidebarService'].heightCalligraphy = 10;
        service['initializePath'](ctxStub);
        expect(service['height']).toEqual(10);
        expect(ctxStub.lineWidth).toEqual(2);
    });

    it('ngDestroy should unsubscribe the subscriptio', () => {
        const spy = spyOn(service['subscription'], 'unsubscribe');
        service.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
});
