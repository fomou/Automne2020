import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { BrushService } from '@app/services/tools/plotting-tools/brush/brush.service';

// tslint:disable: no-any
// tslint:disable:no-string-literal
// tslint:disable:no-magic-numbers
describe('BrushService', () => {
    let service: BrushService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;
    // let changeTextureSpy: jasmine.Spy<any>;
    let clearPathSpy: jasmine.Spy<any>;
    let drawServiceSpy: jasmine.SpyObj<DrawingService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({ providers: [{ provide: DrawingService, useValue: drawServiceSpy }] });
        service = TestBed.inject(BrushService);

        clearPathSpy = spyOn<any>(service, 'clearPath').and.callThrough();

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('onMouseDown with right click should do nothing ', () => {
        const vecPathData1: Vec2 = { x: 10, y: 10 };
        const vecPathData2: Vec2 = { x: 15, y: 15 };
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            button: 1, // click droit
        } as MouseEvent;
        service['pathData'] = [vecPathData1, vecPathData2];
        const drawImageSpy = spyOn<any>(service, 'drawImage').and.callFake(() => {
            return;
        });

        service.onMouseDown(mouseEvent);
        expect(drawImageSpy).not.toHaveBeenCalled();
    });

    // Test onMouseUp
    it('onMouseUp should set mouseDown to false', () => {
        service['mouseDown'] = true;
        service.onMouseUp(mouseEvent);
        expect(service['mouseDown']).toEqual(false);
    });
    it('onMouseUp should set mouseDown to false', () => {
        service.onMouseUp(mouseEvent);
        service['mouseDown'] = false;
        expect(service['mouseDown']).toEqual(false);
    });

    // Test onMouseMove
    it('onMouseMove should not draw the texture if mouseDown is false', () => {
        service['mouseDown'] = false;
        const changeTextureSpy = spyOn<any>(service, 'changeTexture').and.callFake(() => {
            return;
        });
        service.onMouseMove(mouseEvent);
        expect(changeTextureSpy).not.toHaveBeenCalled();
    });

    // Test onMouseLeave
    it('onMouseLeave should set mouseDown to false', () => {
        service['mouseDown'] = true;

        const pushSpy = spyOn<any>(service['pathData'], 'push');

        const drawImageSpy = spyOn<any>(service, 'drawImage').and.callFake(() => {
            return;
        });
        service.onMouseLeave(mouseEvent);

        expect(pushSpy).toHaveBeenCalled();
        expect(drawImageSpy).toHaveBeenCalled();
        expect(clearPathSpy).toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(false);
    });

    // Test onMouseEnter
    it(' onMouseEnter should put mouseDown to true if event event.buttons==1', () => {
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            buttons: 1,
        } as MouseEvent;
        service['mouseDown'] = false;
        service.onMouseEnter(mouseEvent);
        expect(service['mouseDown']).toEqual(true);
    });
    it(' onMouseEnter should not put mouseDown to true if event event.buttons!=1', () => {
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            buttons: 0,
        } as MouseEvent;
        service['mouseDown'] = false;
        service.onMouseEnter(mouseEvent);
        expect(service['mouseDown']).toEqual(false);
    });

    // Tests Textures
    it('initializeTexture with texture 1', () => {
        service['sidebarService'].textureNum = 1;
        service['initializeTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/snow.svg');
    });
    it('initializeTexture with texture 2', () => {
        service['sidebarService'].textureNum = 2;
        service['initializeTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/star.svg');
    });
    it('initializeTexture with texture 3', () => {
        service['sidebarService'].textureNum = 3;
        service['initializeTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/boxes.svg');
    });
    it('initializeTexture with texture 4', () => {
        service['sidebarService'].textureNum = 4;
        service['initializeTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/arrow-left.svg');
    });
    it('initializeTexture with texture 5', () => {
        service['sidebarService'].textureNum = 5;
        service['initializeTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/circle.svg');
    });

    it('mousdown should call clear path', () => {
        service['pathData'] = [];
        const drawImageSpy = spyOn<any>(service, 'drawImage').and.callFake(() => {
            return;
        });

        service.onMouseDown(mouseEvent);
        expect(service['mouseDown']).toEqual(true);
        expect(drawImageSpy).toHaveBeenCalled();
    });

    it('onMouseMove should call change texture ', () => {
        service['mouseDown'] = true;
        const spy = spyOn<any>(service, 'initializeTexture').and.callFake(() => {
            return;
        });
        const changeTextureSpy = spyOn<any>(service, 'changeTexture').and.callFake(() => {
            return;
        });
        service.onMouseMove(mouseEvent);
        expect(changeTextureSpy).toHaveBeenCalled();
        expect(spy).toHaveBeenCalled();
    });

    it('change texture should call drawImage', () => {
        const drawImageSpy = spyOn<any>(service, 'drawImage').and.callFake(() => {
            return;
        });
        service['changeTexture'](baseCtxStub, mouseEvent);

        expect(drawImageSpy).toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('getImage should return a canvas this the image', () => {
        service['img'] = new Image();
        service['img'].width = 100;
        service['img'].height = 100;
        const canvas = spyOn(document, 'createElement').and.returnValue(canvasTestHelper.canvas);
        service['getImage']();
        expect(canvas).toHaveBeenCalled();
    });

    it('drawImage should context methods', () => {
        const drawImage = spyOn<any>(service, 'drawImage').and.callFake(() => {
            return;
        });
        const point = { x: 15, y: 15 };
        const path: Vec2[] = [point, point, point, point];
        service['drawImage'](baseCtxStub, path);
        expect(drawImage).toHaveBeenCalled();
    });

    it('distance between should calculate the distance between two point', () => {
        const point1 = { x: 0, y: 0 };
        const point2 = { x: 3, y: 4 };
        expect(service['distanceBetween'](point1, point2)).toEqual(5);
    });
    it('shoud return angle', () => {
        const point1 = { x: 0, y: 0 };
        const point2 = { x: 3, y: 4 };
        const expectedResult = Math.atan2(3, 4);
        expect(service['angleBetween'](point1, point2)).toEqual(expectedResult);
    });

    it('ngDestroy should unsubscribe the subscriptio', () => {
        const spy = spyOn(service['subscription'], 'unsubscribe');
        service.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
});
