import { Injectable, OnDestroy } from '@angular/core';
import { SprayPaint } from '@app/classes/spray-paint';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import { ONE_SECOND, SPRAY_DEFAULT_ATTRIBS } from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class SprayPaintService extends Tool implements OnDestroy {
    private time: number;
    private position: Vec2;
    private color: string;
    private subscription: Subscription;
    private density: number = SPRAY_DEFAULT_ATTRIBS.DENSITY; // il emet 100 particules par intervalle de temps

    throwingRadius: number = SPRAY_DEFAULT_ATTRIBS.DEFAULT_RADIUS;
    particleRadius: number = SPRAY_DEFAULT_ATTRIBS.DEFAULT_PARTICLES_DIAMETER;
    emissionPerSecond: number = SPRAY_DEFAULT_ATTRIBS.DEFAULT_EMISSIONS;

    constructor(
        protected drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private undoRedoService: UndoRedoService,
    ) {
        super(drawingService);
        this.subscription = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });
    }

    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        this.position = this.getPositionFromMouse(event);
        if (this.mouseDown) {
            this.time = this.paint(this.drawingService.previewCtx);
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown) {
            this.position = this.getPositionFromMouse(event);
        }
    }

    onMouseUp(event?: MouseEvent): void {
        if (this.mouseDown) {
            clearInterval(this.time);
            this.drawingService.previewCtx.globalAlpha = 1.0;
            const imagedata = this.drawingService.previewCanvas.toDataURL();
            const sprayPaintPath = new SprayPaint(imagedata);
            this.undoRedoService.addToStack(sprayPaintPath);
            this.drawingService.baseCtx.drawImage(this.drawingService.previewCanvas, 0, 0);
        }
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.mouseDown = false;
    }

    private getRandomRadius(): Vec2 {
        const randomAngle = Math.random() * 2 * Math.PI;
        const randomRadius = Math.random() * this.throwingRadius;
        return {
            x: Math.cos(randomAngle) * randomRadius,
            y: Math.sin(randomAngle) * randomRadius,
        };
    }

    private generateParticle(ctx: CanvasRenderingContext2D, position: Vec2): void {
        ctx.lineJoin = ctx.lineCap = 'round';
        ctx.fillStyle = this.color;
        for (let i = 0; i < this.density; ++i) {
            const offset = this.getRandomRadius();
            const x = position.x + offset.x;
            const y = position.y + offset.y;
            ctx.globalAlpha = Math.random();
            ctx.fillRect(x, y, this.particleRadius, this.particleRadius);
        }
        ctx.restore();
    }

    private paint(ctx: CanvasRenderingContext2D): number {
        return window.setInterval(() => {
            this.generateParticle(ctx, this.position);
        }, ONE_SECOND / this.emissionPerSecond);
    }
}
