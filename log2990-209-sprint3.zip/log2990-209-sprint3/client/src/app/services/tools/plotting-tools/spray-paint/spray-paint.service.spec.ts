import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SprayPaintService } from './spray-paint.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('SprayPaintService', () => {
    let service: SprayPaintService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(SprayPaintService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;

        mouseEvent = {
            pageX: 296, // 25 + taille de la sidebar
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // test unsubscribe
    it('ngOnDestroy should call unsubscribe', () => {
        const spy = spyOn(service['subscription'], 'unsubscribe');
        service.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });

    // tests onMouseDown

    it('onMouseDown should call paint if mouseDown true', () => {
        service['mouseDown'] = false;

        const spy = spyOn<any>(service, 'getPositionFromMouse');
        const paintSpy = spyOn<any>(service, 'paint');

        service.onMouseDown(mouseEvent);

        expect(spy).toHaveBeenCalled();
        expect(paintSpy).toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(true);
    });

    it('onMouseDown with rightClick should not call paint', () => {
        service['mouseDown'] = false;
        mouseEvent = {
            pageX: 296, // 25 + taille de la sidebar
            pageY: 25,
            button: 2,
        } as MouseEvent;

        const spy = spyOn<any>(service, 'getPositionFromMouse');
        const paintSpy = spyOn<any>(service, 'paint');

        service.onMouseDown(mouseEvent);

        expect(spy).toHaveBeenCalled();
        expect(paintSpy).not.toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(false);
    });

    // tests onMouseMove

    it('onMouseMove with mouseDown true should call getPositionFromMouse', () => {
        service['mouseDown'] = true;

        const spy = spyOn<any>(service, 'getPositionFromMouse');

        service.onMouseMove(mouseEvent);

        expect(spy).toHaveBeenCalled();
    });

    it('onMouseMove with mouseDown false should not call getPositionFromMouse', () => {
        service['mouseDown'] = false;

        const spy = spyOn<any>(service, 'getPositionFromMouse');

        service.onMouseMove(mouseEvent);

        expect(spy).not.toHaveBeenCalled();
    });

    // tests onMouseUp

    it('onMouseUp with mouseDown true should call drawImage', () => {
        service['mouseDown'] = true;
        service['time'] = 40;

        spyOn<any>(service['drawingService'].previewCanvas, 'toDataURL');
        const drawImageSpy = spyOn<any>(service['drawingService'].baseCtx, 'drawImage');
        service.onMouseUp(mouseEvent);

        expect(drawImageSpy).toHaveBeenCalled();
    });

    it('onMouseUp with mouseDown false should not call drawImage', () => {
        service['mouseDown'] = false;
        service['time'] = 40;

        spyOn<any>(service['drawingService'].previewCanvas, 'toDataURL');
        const drawImageSpy = spyOn<any>(service['drawingService'].baseCtx, 'drawImage');
        service.onMouseUp(mouseEvent);

        expect(drawImageSpy).not.toHaveBeenCalled();
    });

    // test getRandomRadius

    it('getRandomRadius should call random', () => {
        service.throwingRadius = 20;
        service['time'] = 40;

        const spy = spyOn(Math, 'random');

        service['getRandomRadius']();

        expect(spy).toHaveBeenCalledTimes(2);
    });

    // test generateParticle

    it('generateParticle should call getRandomRadius', () => {
        service['color'] = 'red';
        service.particleRadius = 10;
        service['density'] = 1;
        const point = { x: 25, y: 25 };
        const spy = spyOn<any>(service, 'getRandomRadius').and.returnValue({ x: 25, y: 25 });

        service['generateParticle'](service['drawingService'].baseCtx, point);

        expect(spy).toHaveBeenCalled();
    });

    // test paint

    it('paint should call generateParticle', () => {
        service.emissionPerSecond = 20;
        service['position'] = { x: 25, y: 25 };

        const setIntervalSpy = spyOn(window, 'setInterval');

        service['paint'](service['drawingService'].baseCtx);

        expect(setIntervalSpy).toHaveBeenCalled();
    });
});
