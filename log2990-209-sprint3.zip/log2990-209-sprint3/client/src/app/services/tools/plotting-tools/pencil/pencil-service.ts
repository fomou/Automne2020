import { Injectable, OnDestroy } from '@angular/core';
import { PencilPath } from '@app/classes/pencil-path';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import { MouseButton } from '@app/enums/mouse-button';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class PencilService extends Tool implements OnDestroy {
    private pathData: Vec2[];
    private color: string;
    private subscription: Subscription;
    constructor(
        protected drawingService: DrawingService,
        private sidebarService: SidebarService,
        private colorSelectorService: ColorSelectorService,
        private undoRedoService: UndoRedoService,
    ) {
        super(drawingService);
        this.subscription = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });
        this.clearPath();
    }

    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.clearPath();
            this.mouseDownCoord = this.getPositionFromMouse(event);
            this.pathData.push(this.mouseDownCoord);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown) {
            const mousePosition = this.getPositionFromMouse(event);
            this.pathData.push(mousePosition);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawLine(this.drawingService.baseCtx, this.pathData);
            const pencilPath = new PencilPath(this.pathData, this.color, this.sidebarService.width);
            this.undoRedoService.addToStack(pencilPath);
            this.undoRedoService.setToolInUse(false);
        }
        this.mouseDown = false;
        this.clearPath();
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown) {
            const mousePosition = this.getPositionFromMouse(event);
            this.pathData.push(mousePosition);
            this.undoRedoService.setToolInUse(true);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawLine(this.drawingService.previewCtx, this.pathData);
        }
    }

    onMouseLeave(event: MouseEvent): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        const mousePosition = this.getPositionFromMouse(event);
        this.pathData.push(mousePosition);
        this.drawLine(this.drawingService.baseCtx, this.pathData);
        this.clearPath();
        if (this.mouseDown) {
            const pencilPath = new PencilPath(this.pathData, this.color, this.sidebarService.width);
            this.undoRedoService.addToStack(pencilPath);
        }
        this.mouseDown = false;
    }

    onMouseEnter(event: MouseEvent): void {
        if (event.buttons === 1) {
            this.mouseDown = true;
        }
    }

    private drawLine(ctx: CanvasRenderingContext2D, path: Vec2[]): void {
        ctx.beginPath();
        ctx.strokeStyle = this.color;
        ctx.lineCap = 'round';
        ctx.lineWidth = this.sidebarService.width;
        for (const point of path) {
            ctx.lineTo(point.x, point.y);
        }
        ctx.stroke();
    }

    private clearPath(): void {
        this.pathData = [];
    }
}
