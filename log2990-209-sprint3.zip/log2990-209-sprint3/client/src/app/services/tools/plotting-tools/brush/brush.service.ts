import { Injectable, OnDestroy } from '@angular/core';
import { BrushPath } from '@app/classes/brush-path';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { Texture } from '@app/enums/texture-number';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class BrushService extends Tool implements OnDestroy {
    private pathData: Vec2[];
    private img: HTMLImageElement = new Image();
    private color: string;
    private subscription: Subscription;
    constructor(
        protected drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private sidebarService: SidebarService,
        private undoRedoService: UndoRedoService,
    ) {
        super(drawingService);

        this.subscription = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });

        this.img.src = '../../../../assets/snow.svg';
        this.clearPath();
    }
    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.clearPath();
            this.mouseDownCoord = this.getPositionFromMouse(event);
            const closestPoint: Vec2 = { x: this.mouseDownCoord.x + 1, y: this.mouseDownCoord.y + 1 };
            this.pathData.push(this.mouseDownCoord);
            this.pathData.push(closestPoint);
            this.drawImage(this.drawingService.baseCtx, this.pathData);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown) {
            const mousePosition = this.getPositionFromMouse(event);
            this.pathData.push(mousePosition);
            const brushPath = new BrushPath(this.pathData, this.color, this.sidebarService.brushWidth, this.img);
            this.undoRedoService.addToStack(brushPath);
            this.drawImage(this.drawingService.baseCtx, this.pathData);
        }
        this.undoRedoService.setToolInUse(false);
        this.mouseDown = false;
        this.clearPath();
    }

    onMouseMove(event: MouseEvent): void {
        this.initializeTexture(this.drawingService.previewCtx);
        if (this.mouseDown) {
            this.undoRedoService.setToolInUse(true);
            this.changeTexture(this.drawingService.previewCtx, event);
        }
    }
    onMouseLeave(event: MouseEvent): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        const mousePosition = this.getPositionFromMouse(event);
        this.pathData.push(mousePosition);
        this.drawImage(this.drawingService.baseCtx, this.pathData);
        this.clearPath();
        this.mouseDown = false;
    }

    onMouseEnter(event: MouseEvent): void {
        if (event.buttons === 1) {
            this.mouseDown = true;
        }
    }

    private changeTexture(ctx: CanvasRenderingContext2D, event: MouseEvent): void {
        const mousePosition = this.getPositionFromMouse(event);
        this.pathData.push(mousePosition);
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.drawImage(this.drawingService.previewCtx, this.pathData);
    }

    private initializeTexture(ctx: CanvasRenderingContext2D): void {
        ctx.lineJoin = ctx.lineCap = 'round';
        switch (this.sidebarService.textureNum) {
            case Texture.Texture1:
                this.img.src = '../../../../assets/snow.svg';
                break;
            case Texture.Texture2:
                this.img.src = '../../../../assets/star.svg';
                break;
            case Texture.Texture3:
                this.img.src = '../../../../assets/boxes.svg';
                break;
            case Texture.Texture4:
                this.img.src = '../../../../assets/arrow-left.svg';
                break;
            case Texture.Texture5:
                this.img.src = '../../../../assets/circle.svg';
                break;
        }
    }

    private getImage(): HTMLCanvasElement {
        const canvas: HTMLCanvasElement = document.createElement('canvas');
        canvas.width = this.img.width;
        canvas.height = this.img.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.fillStyle = this.color;
        copyCanvas.fillRect(0, 0, this.img.width, this.img.height);
        copyCanvas.globalCompositeOperation = 'destination-in';
        copyCanvas.drawImage(this.img, 0, 0, this.img.width / this.sidebarService.brushWidth, this.img.height / this.sidebarService.brushWidth);
        return canvas;
    }

    private drawImage(ctx: CanvasRenderingContext2D, path: Vec2[]): void {
        ctx.beginPath();
        const size: number = path.length;
        const canvasImage: HTMLCanvasElement = this.getImage();
        for (let i = 0; i < size - 1; i++) {
            const dist: number = this.distanceBetween(path[i], path[i + 1]);
            const angle: number = this.angleBetween(path[i], path[i + 1]);
            for (let j = 0; j < dist; j = j + CONSTANT.IMAGES_BY_POINT) {
                let x: number;
                let y: number;
                if (this.sidebarService.brushWidth === CONSTANT.MAX_WIDTH) {
                    x = path[i].x + Math.sin(angle) * j - CONSTANT.ANGLE_BRUSH;
                    y = path[i].y + Math.cos(angle) * j - CONSTANT.ANGLE_BRUSH;
                } else {
                    x = path[i].x + Math.sin(angle) * j - CONSTANT.ANGLE_BRUSH / CONSTANT.WIDTH_RATE;
                    y = path[i].y + Math.cos(angle) * j - CONSTANT.ANGLE_BRUSH / CONSTANT.WIDTH_RATE;
                }
                ctx.drawImage(canvasImage, x, y);
            }
        }
        ctx.stroke();
    }

    private distanceBetween(point1: Vec2, point2: Vec2): number {
        return Math.sqrt(Math.pow(point2.x - point1.x, 2) + Math.pow(point2.y - point1.y, 2));
    }

    private angleBetween(point1: Vec2, point2: Vec2): number {
        return Math.atan2(point2.x - point1.x, point2.y - point1.y);
    }

    private clearPath(): void {
        this.pathData = [];
    }
}
