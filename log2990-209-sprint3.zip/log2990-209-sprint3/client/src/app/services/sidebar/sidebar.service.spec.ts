import { TestBed } from '@angular/core/testing';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { SidebarService } from './sidebar.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('SidebarService', () => {
    let service: SidebarService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(SidebarService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('changeWidth should set width', () => {
        const widthExpect = 5;
        service.changeWidth(widthExpect);
        expect(service.width).toEqual(widthExpect);
    });

    it('changeBrushWidth should set brushWidth', () => {
        const brushWidthExpect = 50;
        service.changeBrushWidth(brushWidthExpect);
        expect(service.brushWidth).toEqual(brushWidthExpect);
    });

    it('selectTexture should set textureNumber', () => {
        const textureNumExpect = 2;
        service.selectTexture(textureNumExpect);
        expect(service.textureNum).toEqual(textureNumExpect);
    });

    it('changeWidthShape should set widthShape', () => {
        const expectResult = 20;
        service.changeWidthShape(20);
        expect(service.widthShape).toEqual(expectResult);
    });

    it('changeWidthLine should set widthLine', () => {
        const expectResult = 20;
        service.changeWidthLine(20);
        expect(service.widthLine).toEqual(expectResult);
    });

    it('changeBrushWidth should set brushWidth', () => {
        const eraserSizeExpect = 20;
        service.changeEraserSize(eraserSizeExpect);
        expect(service.eraserSize).toEqual(eraserSizeExpect);
    });

    it('changeTolerance should set tolerance', () => {
        const expectResult = 20;
        service.changeTolerance(20);
        expect(service.tolerance).toEqual(expectResult);
    });

    it('changeCalligraphyHeight should set heightCalligraphy', () => {
        const expectResult = 20;
        service.changeCalligraphyHeight(20);
        expect(service.heightCalligraphy).toEqual(expectResult);
    });

    it('changeCalligraphyAngle should set angleCalligraphy', () => {
        const expectResult = 20;
        service.changeCalligraphyAngle(20);
        expect(service.angleCalligraphy).toEqual(expectResult);
    });

    it('changeGridOpacity should set opacityEmitter', () => {
        const spy = spyOn(service['opacityEmitter'], 'next');
        service.changeGridOpacity(20);
        expect(spy).toHaveBeenCalled();
    });

    it('changeSquareSize should set squareSizeEmitter', () => {
        const spy = spyOn(service['squareSizeEmitter'], 'next');
        service.changeSquareSize(20);
        expect(spy).toHaveBeenCalled();
    });

    it('disableGrid should set gridDisabled', () => {
        const spy = spyOn(service['gridDisabled'], 'next');
        service.disableGrid(true);
        expect(spy).toHaveBeenCalled();
    });

    it('changeCalligraphyAngle should set angleCalligraphy', () => {
        const colorSelectorService = new ColorSelectorService();
        const drawingService = new DrawingService();
        const tool = new PickerService(colorSelectorService, drawingService);
        service.tool = tool;
        service.returnCurrentTool(tool);
        expect(service.tool).toEqual(tool);
    });
});
