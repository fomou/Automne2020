import { Injectable } from '@angular/core';
import { Tool } from '@app/classes/tool';
import { MIN_OPACITY, MIN_SQUARE_SIZE } from '@app/constants/constants';
import { ResizingBox } from '@app/enums/resizing-box';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class SidebarService {
    width: number = 1;
    textureNum: number = 1;
    eraserSize: number = 5;
    brushWidth: number = 10;
    widthShape: number = 1;
    widthLine: number = 1;
    tolerance: number = 0;
    opacity: number = 1;
    isDisableGrid: boolean = false;
    isMagnetism: boolean = false;
    anchorPoint: number = 1;
    private opacityEmitter: BehaviorSubject<number> = new BehaviorSubject<number>(MIN_OPACITY);
    opacityObs$: Observable<number> = this.opacityEmitter.asObservable();

    private squareSizeEmitter: BehaviorSubject<number> = new BehaviorSubject<number>(MIN_SQUARE_SIZE);
    squareSizeObs$: Observable<number> = this.squareSizeEmitter.asObservable();

    private gridDisabled: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.isDisableGrid);
    disabledObs$: Observable<boolean> = this.gridDisabled.asObservable();

    private magnetismDisabled: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.isMagnetism);
    disabledMagnetismObs$: Observable<boolean> = this.magnetismDisabled.asObservable();

    private anchor: BehaviorSubject<ResizingBox> = new BehaviorSubject<ResizingBox>(this.anchorPoint);
    anchorType$: Observable<ResizingBox> = this.anchor.asObservable();

    heightCalligraphy: number = 10;
    angleCalligraphy: number = 0;
    tool: Tool;

    changeWidth(lineWidth: number): void {
        this.width = lineWidth;
    }

    changeBrushWidth(brushWidth: number): void {
        this.brushWidth = brushWidth;
    }

    selectTexture(textureNumber: number): void {
        this.textureNum = textureNumber;
    }

    changeEraserSize(eraserSize: number): void {
        this.eraserSize = eraserSize;
    }

    changeWidthShape(widthShape: number): void {
        this.widthShape = widthShape;
    }

    changeWidthLine(widthLine: number): void {
        this.widthLine = widthLine;
    }

    changeTolerance(tolerance: number): void {
        this.tolerance = tolerance;
    }

    changeCalligraphyHeight(height: number): void {
        this.heightCalligraphy = height;
    }

    changeCalligraphyAngle(angle: number): void {
        this.angleCalligraphy = angle;
    }

    changeGridOpacity(opacity: number): void {
        this.opacityEmitter.next(opacity);
    }

    changeSquareSize(squareSize: number): void {
        this.squareSizeEmitter.next(squareSize);
    }

    disableGrid(disable: boolean): void {
        this.gridDisabled.next(disable);
    }

    anchorTypes(anchor: number): void {
        this.anchor.next(anchor);
    }
    disableMagnetism(disable: boolean): void {
        this.magnetismDisabled.next(disable);
    }

    returnCurrentTool(tool: Tool): void {
        this.tool = tool;
    }
}
