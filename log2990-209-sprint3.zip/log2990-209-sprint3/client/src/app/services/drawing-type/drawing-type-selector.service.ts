import { Injectable } from '@angular/core';
import { DrawingType } from '@app/enums/draw-type';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class DrawingTypeSelectorService {
    private drawingTypeSource: BehaviorSubject<string>;
    drawingType$: Observable<string>;

    constructor() {
        this.drawingTypeSource = new BehaviorSubject<string>(DrawingType.Stroke);
        this.drawingType$ = this.drawingTypeSource.asObservable();
    }

    changeDrawingType(type: string): void {
        this.drawingTypeSource.next(type);
    }
}
