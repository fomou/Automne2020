import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ShortcutManagerService {
    private shortcutDisable: Subject<boolean>;
    shortcutObs$: Observable<boolean>;
    constructor() {
        this.shortcutDisable = new Subject<boolean>();
        this.shortcutObs$ = this.shortcutDisable.asObservable();
    }

    disableShortcut(): void {
        this.shortcutDisable.next(true);
    }

    enableShortcut(): void {
        this.shortcutDisable.next(false);
    }
}
