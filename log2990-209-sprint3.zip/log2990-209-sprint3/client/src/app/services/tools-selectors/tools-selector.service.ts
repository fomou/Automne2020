import { Injectable } from '@angular/core';
import { Tool } from '@app/classes/tool';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SelectionEllipseService } from '@app/services/selections/selection/selection-ellipse/selection-ellipse.service';
import { MagicWandService } from '@app/services/selections/selection/selection-magic-wand/magic-wand.service';
import { SelectionRectangleService } from '@app/services/selections/selection/selection-rectangle/selection-rectangle.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { BrushService } from '@app/services/tools/plotting-tools/brush/brush.service';
import { CalligraphyService } from '@app/services/tools/plotting-tools/calligraphy/calligraphy.service';
import { PencilService } from '@app/services/tools/plotting-tools/pencil/pencil-service';
import { SprayPaintService } from '@app/services/tools/plotting-tools/spray-paint/spray-paint.service';
import { EllipseService } from '@app/services/tools/shapes/ellipse/ellipse.service';
import { PolygonService } from '@app/services/tools/shapes/polygon/polygon.service';
import { RectangleService } from '@app/services/tools/shapes/rectangle/rectangle.service';
import { StampService } from '@app/services/tools/stamp/stamp.service';
import { TextService } from '@app/services/tools/text/text.service';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ToolsSelectorService {
    toolSource: BehaviorSubject<Tool>;
    toolsMap: Map<string, Tool> = new Map<string, Tool>();
    tool$: Observable<Tool>;
    plottingTool: Tool;
    shapeTool: Tool;
    selectionTool: Tool;

    constructor(
        private drawingService: DrawingService,
        pencilService: PencilService,
        rectangleService: RectangleService,
        ellipseService: EllipseService,
        lineService: LineService,
        eraseService: EraseService,
        brushService: BrushService,
        polygonService: PolygonService,
        picker: PickerService,
        paintBucket: PaintBucketService,
        private selectionRectangleService: SelectionRectangleService,
        private selectionEllipseService: SelectionEllipseService,
        private magicWandService: MagicWandService,
        stamp: StampService,
        sprayPaint: SprayPaintService,
        calligraphyService: CalligraphyService,
        textService: TextService,
    ) {
        this.toolsMap.set(Keyboard.One, rectangleService);
        this.toolsMap.set(Keyboard.Two, ellipseService);
        this.toolsMap.set(Keyboard.Three, polygonService);
        this.toolsMap.set(Keyboard.L, lineService);
        this.toolsMap.set(Keyboard.C, pencilService);
        this.toolsMap.set(Keyboard.E, eraseService);
        this.toolsMap.set(Keyboard.W, brushService);
        this.toolsMap.set(Keyboard.I, picker);
        this.toolsMap.set(Keyboard.B, paintBucket);
        this.toolsMap.set(Keyboard.R, this.selectionRectangleService);
        this.toolsMap.set(Keyboard.S, this.selectionEllipseService);
        this.toolsMap.set(Keyboard.D, stamp);
        this.toolsMap.set(Keyboard.A, sprayPaint);
        this.toolsMap.set(Keyboard.P, calligraphyService);
        this.toolsMap.set(Keyboard.V, this.magicWandService);
        this.toolsMap.set(Keyboard.T, textService);

        this.toolSource = new BehaviorSubject<Tool>(pencilService);
        this.tool$ = this.toolSource.asObservable();
        this.plottingTool = pencilService;
        this.shapeTool = rectangleService;
        this.selectionTool = selectionRectangleService;
    }
    changeTool(tool: Tool): void {
        if (!this.selectionRectangleService.ctrlPressed && !this.selectionEllipseService.ctrlPressed && !this.magicWandService.ctrlPressed) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.selectionRectangleService.cancelSelection();
            this.selectionEllipseService.cancelSelection();
            this.magicWandService.isSelected = false;
            this.magicWandService.isMoving = false;
            this.toolSource.next(tool);
        }
    }

    getToolByKey(key: string): Tool {
        return this.toolsMap.get(key) as Tool;
    }

    replaceCursor(): boolean {
        const bool = this.toolSource.getValue() instanceof StampService || this.toolSource.getValue() instanceof EraseService;
        return bool;
    }
}
