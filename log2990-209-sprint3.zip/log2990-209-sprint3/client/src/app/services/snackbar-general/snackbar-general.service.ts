import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class SnackBarGeneralService {
    valueDisplay: string = '';
    displayContext(value: string): void {
        this.valueDisplay = value;
    }
}
