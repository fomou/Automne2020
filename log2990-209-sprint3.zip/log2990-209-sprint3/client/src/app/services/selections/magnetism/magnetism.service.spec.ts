import { TestBed } from '@angular/core/testing';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { ResizingBox } from '@app/enums/resizing-box';
import { MagnetismService } from './magnetism.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('MagnetismService', () => {
    let service: MagnetismService;
    let topLeftPoint: Vec2;
    let size: Size;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(MagnetismService);
        topLeftPoint = { x: 20, y: 20 };
        size = { width: 20, height: 20 };
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // tests useMagnetism
    it('useMagnetism case TopMiddle', () => {
        service.anchorPoint = ResizingBox.TopMiddle;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 20, y: 30 });
    });

    it('useMagnetism case RightMiddle', () => {
        service.anchorPoint = ResizingBox.RightMiddle;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 10, y: 20 });
    });

    it('useMagnetism case LeftMiddle', () => {
        service.anchorPoint = ResizingBox.LeftMiddle;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 30, y: 20 });
    });

    it('useMagnetism case BottomMiddle', () => {
        service.anchorPoint = ResizingBox.BottomMiddle;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 20, y: 10 });
    });

    it('useMagnetism case Center', () => {
        service.anchorPoint = ResizingBox.Center;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 20, y: 20 });
    });

    it('useMagnetism case TopRight', () => {
        service.anchorPoint = ResizingBox.TopRight;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 10, y: 30 });
    });

    it('useMagnetism case TopLeft', () => {
        service.anchorPoint = ResizingBox.TopLeft;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 30, y: 30 });
    });

    it('useMagnetism case BottomRight', () => {
        service.anchorPoint = ResizingBox.BottomRight;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 10, y: 10 });
    });

    it('useMagnetism case BottomLeft', () => {
        service.anchorPoint = ResizingBox.BottomLeft;
        service.squareSize = 20;
        topLeftPoint = { x: 20, y: 20 };
        const result = service.useMagnetism(topLeftPoint, size);
        expect(result).toEqual({ x: 30, y: 10 });
    });

    // tests findIntersection

    it('findIntersection case topLeftIntersection', () => {
        service.anchorPoint = ResizingBox.TopLeft;
        service.squareSize = 20;
        topLeftPoint = { x: 8, y: 8 };
        const result = service['findIntersection'](topLeftPoint, size);
        expect(result).toEqual({ x: 0, y: 0 });
    });

    it('findIntersection case bottomRightIntersection', () => {
        service.anchorPoint = ResizingBox.TopLeft;
        service.squareSize = 20;
        topLeftPoint = { x: 15, y: 15 };
        const result = service['findIntersection'](topLeftPoint, size);
        expect(result).toEqual({ x: 20, y: 20 });
    });

    // tests findAnchorPoint

    it('findAnchorPoint case TopMiddle', () => {
        service.anchorPoint = ResizingBox.TopMiddle;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 30, y: 20 });
    });

    it('findAnchorPoint case RightMiddle', () => {
        service.anchorPoint = ResizingBox.RightMiddle;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 40, y: 30 });
    });

    it('findAnchorPoint case LeftMiddle', () => {
        service.anchorPoint = ResizingBox.LeftMiddle;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 20, y: 30 });
    });

    it('findAnchorPoint case BottomMiddle', () => {
        service.anchorPoint = ResizingBox.BottomMiddle;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 30, y: 40 });
    });

    it('findAnchorPoint case Center', () => {
        service.anchorPoint = ResizingBox.Center;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 30, y: 30 });
    });

    it('findAnchorPoint case TopRight', () => {
        service.anchorPoint = ResizingBox.TopRight;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 40, y: 20 });
    });

    it('findAnchorPoint case TopLeft', () => {
        service.anchorPoint = ResizingBox.TopLeft;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 20, y: 20 });
    });

    it('findAnchorPoint case BottomRight', () => {
        service.anchorPoint = ResizingBox.BottomRight;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 40, y: 40 });
    });

    it('findAnchorPoint case BottomLeft', () => {
        service.anchorPoint = ResizingBox.BottomLeft;
        const result = service['findAnchorPoint'](topLeftPoint, size);
        expect(result).toEqual({ x: 20, y: 40 });
    });
    it('ngDestroy should unsuscribe the subscriptions', () => {
        const spy1 = spyOn(service['subscriptionMagnetism'], 'unsubscribe');
        const spy2 = spyOn(service['subscriptionAnchorPoint'], 'unsubscribe');
        service.ngOnDestroy();
        expect(spy1).toHaveBeenCalled();
        expect(spy2).toHaveBeenCalled();
    });
});
