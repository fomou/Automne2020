import { Injectable, OnDestroy } from '@angular/core';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { MIN_SQUARE_SIZE } from '@app/constants/constants';
import { ResizingBox } from '@app/enums/resizing-box';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { Subscription } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class MagnetismService implements OnDestroy {
    squareSize: number = MIN_SQUARE_SIZE;
    anchorPoint: ResizingBox = ResizingBox.TopLeft;
    enableMagnetism: boolean = false;
    private subscriptionMagnetism: Subscription = new Subscription();
    private subscriptionAnchorPoint: Subscription = new Subscription();
    constructor(private sidebarService: SidebarService) {
        this.subscriptionMagnetism = this.sidebarService.disabledMagnetismObs$.subscribe((disabled) => {
            this.enableMagnetism = disabled;
        });
        this.subscriptionAnchorPoint = this.sidebarService.anchorType$.subscribe((anchor) => {
            this.anchorPoint = anchor as ResizingBox;
        });
    }
    ngOnDestroy(): void {
        this.subscriptionMagnetism.unsubscribe();
        this.subscriptionAnchorPoint.unsubscribe();
    }
    useMagnetism(topLeftPoint: Vec2, size: Size): Vec2 {
        this.sidebarService.squareSizeObs$.subscribe((squareSize) => {
            this.squareSize = squareSize;
        });
        const intersectionPoint = this.findIntersection(topLeftPoint, size);
        console.log('before Switch', this.anchorPoint);
        switch (this.anchorPoint) {
            case ResizingBox.TopMiddle: {
                intersectionPoint.x = intersectionPoint.x - size.width / 2;
                intersectionPoint.y = intersectionPoint.y;
                break;
            }
            case ResizingBox.RightMiddle: {
                intersectionPoint.x = intersectionPoint.x - size.width;
                intersectionPoint.y = intersectionPoint.y - size.height / 2;
                break;
            }
            case ResizingBox.LeftMiddle: {
                intersectionPoint.x = intersectionPoint.x;
                intersectionPoint.y = intersectionPoint.y - size.height / 2;
                break;
            }
            case ResizingBox.BottomMiddle: {
                intersectionPoint.x = intersectionPoint.x - size.width / 2;
                intersectionPoint.y = intersectionPoint.y - size.height;
                break;
            }
            case ResizingBox.Center: {
                intersectionPoint.x = intersectionPoint.x - size.width / 2;
                intersectionPoint.y = intersectionPoint.y - size.height / 2;
                break;
            }
            case ResizingBox.TopRight: {
                intersectionPoint.x = intersectionPoint.x - size.width;
                intersectionPoint.y = intersectionPoint.y;
                break;
            }
            case ResizingBox.TopLeft: {
                intersectionPoint.x = intersectionPoint.x;
                intersectionPoint.y = intersectionPoint.y;
                break;
            }
            case ResizingBox.BottomRight: {
                intersectionPoint.x = intersectionPoint.x - size.width;
                intersectionPoint.y = intersectionPoint.y - size.height;
                break;
            }
            case ResizingBox.BottomLeft: {
                intersectionPoint.x = intersectionPoint.x;
                intersectionPoint.y = intersectionPoint.y - size.height;
                break;
            }
        }
        return intersectionPoint;
    }
    // Trouve l'intersection de la grille la plus proche du point d'alignement
    private findIntersection(topLeftPoint: Vec2, size: Size): Vec2 {
        const intersectionPoint = this.findAnchorPoint(topLeftPoint, size);
        if (intersectionPoint.x % this.squareSize > this.squareSize / 2) {
            intersectionPoint.x = Math.floor(intersectionPoint.x / this.squareSize) * this.squareSize + this.squareSize;
        } else {
            intersectionPoint.x = Math.floor(intersectionPoint.x / this.squareSize) * this.squareSize;
        }

        if (intersectionPoint.y % this.squareSize > this.squareSize / 2) {
            intersectionPoint.y = Math.floor(intersectionPoint.y / this.squareSize) * this.squareSize + this.squareSize;
        } else {
            intersectionPoint.y = Math.floor(intersectionPoint.y / this.squareSize) * this.squareSize;
        }
        return intersectionPoint;
    }

    private findAnchorPoint(topLeftPoint: Vec2, size: Size): Vec2 {
        const intersectionPoint: Vec2 = { x: 0, y: 0 };
        switch (this.anchorPoint) {
            case ResizingBox.TopMiddle: {
                intersectionPoint.x = topLeftPoint.x + size.width / 2;
                intersectionPoint.y = topLeftPoint.y;
                break;
            }
            case ResizingBox.RightMiddle: {
                intersectionPoint.x = topLeftPoint.x + size.width;
                intersectionPoint.y = topLeftPoint.y + size.height / 2;
                break;
            }
            case ResizingBox.LeftMiddle: {
                intersectionPoint.x = topLeftPoint.x;
                intersectionPoint.y = topLeftPoint.y + size.height / 2;
                break;
            }
            case ResizingBox.BottomMiddle: {
                intersectionPoint.x = topLeftPoint.x + size.width / 2;
                intersectionPoint.y = topLeftPoint.y + size.height;
                break;
            }
            case ResizingBox.Center: {
                intersectionPoint.x = topLeftPoint.x + size.width / 2;
                intersectionPoint.y = topLeftPoint.y + size.height / 2;
                break;
            }
            case ResizingBox.TopRight: {
                intersectionPoint.x = topLeftPoint.x + size.width;
                intersectionPoint.y = topLeftPoint.y;
                break;
            }
            case ResizingBox.TopLeft: {
                intersectionPoint.x = topLeftPoint.x;
                intersectionPoint.y = topLeftPoint.y;
                break;
            }
            case ResizingBox.BottomRight: {
                intersectionPoint.x = topLeftPoint.x + size.width;
                intersectionPoint.y = topLeftPoint.y + size.height;
                break;
            }
            case ResizingBox.BottomLeft: {
                intersectionPoint.x = topLeftPoint.x;
                intersectionPoint.y = topLeftPoint.y + size.height;
                break;
            }
        }
        return intersectionPoint;
    }
}
