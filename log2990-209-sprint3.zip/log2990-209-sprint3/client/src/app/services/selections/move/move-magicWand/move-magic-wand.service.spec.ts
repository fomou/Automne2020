import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ResizeMagicWandService } from '@app/services/selections/resize/resize-magic-wand/resize-magic-wand.service';
import { MoveMagicWandService } from './move-magic-wand.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('MoveMagicWandService', () => {
    let service: MoveMagicWandService;
    let topLeftPoint: Vec2;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let resizeMagicWandServiceSpy: jasmine.SpyObj<ResizeMagicWandService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        resizeMagicWandServiceSpy = jasmine.createSpyObj<any>('ResizeRectangleService', ['drawResizingRectangle', 'updateSelectionVariables']);

        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: ResizeMagicWandService, useValue: resizeMagicWandServiceSpy },
            ],
        });
        service = TestBed.inject(MoveMagicWandService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        topLeftPoint = { x: 25, y: 25 };
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // tests activateSelectionArrows

    it('activateSelectionArrows with ArrowLeft should set arrowLeftPressed true', () => {
        const keyboardEvent = { key: 'ArrowLeft' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    it('activateSelectionArrows with ArrowRight should set arrowRightPressed true', () => {
        const keyboardEvent = { key: 'ArrowRight' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    it('activateSelectionArrows with ArrowUp should set arrowUpPressed true', () => {
        const keyboardEvent = { key: 'ArrowUp' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    it('activateSelectionArrows with ArrowDown should set arrowDownPressed true', () => {
        const keyboardEvent = { key: 'ArrowDown' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(true);
    });

    it('activateSelectionArrows with random key should do nothing', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    // tests disableSelectionArrows

    it('disableSelectionArrows with ArrowLeft should set arrowLeftPressed false', () => {
        const keyboardEvent = { key: 'ArrowLeft' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeMagicWandServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with ArrowRight should set arrowRightPressed false', () => {
        const keyboardEvent = { key: 'ArrowRight' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeMagicWandServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with ArrowUp should set arrowUpPressed false', () => {
        const keyboardEvent = { key: 'ArrowUp' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeMagicWandServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with ArrowDown should set arrowDownPressed false', () => {
        const keyboardEvent = { key: 'ArrowDown' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(false);
        expect(resizeMagicWandServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with random key should do nothing', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeMagicWandServiceSpy.drawResizingRectangle).not.toHaveBeenCalled();
    });

    // tests moveSelectionArrows

    it('moveSelectionArrows with arrowLeftPressed true should call clearCanvas and putImage Data', () => {
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;
        const size = { width: 25, height: 25 };

        const spy = spyOn<any>(service, 'drawSelection');

        service.moveSelectionArrows(topLeftPoint, size);

        expect(spy).toHaveBeenCalledTimes(4);
    });

    it('moveSelectionArrows with arrowPressed false should not call drawSelection ', () => {
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;
        const size = { width: 25, height: 25 };

        const spy = spyOn<any>(service, 'drawSelection');
        service.moveSelectionArrows(topLeftPoint, size);

        expect(spy).not.toHaveBeenCalled();
    });
});
