import { Injectable } from '@angular/core';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { OFFSET_ARROW } from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { MagnetismService } from '@app/services/selections/magnetism/magnetism.service';
import { ResizeMagicWandService } from '@app/services/selections/resize/resize-magic-wand/resize-magic-wand.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';

@Injectable({
    providedIn: 'root',
})
export class MoveMagicWandService {
    private arrowLeftPressed: boolean;
    private arrowRightPressed: boolean;
    private arrowUpPressed: boolean;
    private arrowDownPressed: boolean;

    angle: number;
    topLeftPoint: Vec2;

    constructor(
        private drawingService: DrawingService,
        private resizeMagicWandService: ResizeMagicWandService,
        private magnetismService: MagnetismService,
        private magicWand: RotationRectangleService,
    ) {}

    activateSelectionArrows(event: KeyboardEvent): void {
        switch (event.key) {
            case 'ArrowLeft': {
                this.arrowLeftPressed = true;
                break;
            }
            case 'ArrowRight': {
                this.arrowRightPressed = true;
                break;
            }
            case 'ArrowUp': {
                this.arrowUpPressed = true;
                break;
            }
            case 'ArrowDown': {
                this.arrowDownPressed = true;
                break;
            }
        }
    }

    disableSelectionArrows(event: KeyboardEvent): void {
        switch (event.key) {
            case 'ArrowLeft': {
                this.arrowLeftPressed = false;
                this.resizeMagicWandService.drawResizingRectangle();
                break;
            }
            case 'ArrowRight': {
                this.arrowRightPressed = false;
                this.resizeMagicWandService.drawResizingRectangle();
                break;
            }
            case 'ArrowUp': {
                this.arrowUpPressed = false;
                this.resizeMagicWandService.drawResizingRectangle();
                break;
            }
            case 'ArrowDown': {
                this.arrowDownPressed = false;
                this.resizeMagicWandService.drawResizingRectangle();
                break;
            }
        }
    }

    moveSelectionArrows(topLeftPoint: Vec2, size: Size): void {
        let offsetMovement: number = OFFSET_ARROW;
        if (this.magnetismService.enableMagnetism) {
            const magnetismPoint = this.magnetismService.useMagnetism(topLeftPoint, size);
            offsetMovement = this.magnetismService.squareSize;
            topLeftPoint.x = magnetismPoint.x;
            topLeftPoint.y = magnetismPoint.y;
        }

        if (this.arrowLeftPressed) {
            topLeftPoint.x -= offsetMovement;
            this.drawSelection(topLeftPoint);
        }

        if (this.arrowRightPressed) {
            topLeftPoint.x += offsetMovement;
            this.drawSelection(topLeftPoint);
        }

        if (this.arrowUpPressed) {
            topLeftPoint.y -= offsetMovement;
            this.drawSelection(topLeftPoint);
        }

        if (this.arrowDownPressed) {
            topLeftPoint.y += offsetMovement;
            this.drawSelection(topLeftPoint);
        }

        this.resizeMagicWandService.updateSelectionVariables(topLeftPoint);
    }
    private drawSelection(point: Vec2): void {
        this.magicWand.selectionTopLeft = point;
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.magicWand.rotate(this.drawingService.previewCtx, this.angle);
    }
}
