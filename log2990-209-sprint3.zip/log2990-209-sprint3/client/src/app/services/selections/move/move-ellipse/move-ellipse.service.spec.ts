import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ResizeEllipseService } from '@app/services/selections/resize/resize-ellipse/resize-ellipse.service';
import { MoveEllipseService } from './move-ellipse.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('MoveEllipseService', () => {
    let service: MoveEllipseService;
    let topLeftPoint: Vec2;
    let center: Vec2;
    let imageData: ImageData;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let resizeEllipseServiceSpy: jasmine.SpyObj<ResizeEllipseService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        resizeEllipseServiceSpy = jasmine.createSpyObj<any>('ResizeEllipseService', ['drawResizingRectangle', 'updateSelectionVariables']);

        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: ResizeEllipseService, useValue: resizeEllipseServiceSpy },
            ],
        });
        service = TestBed.inject(MoveEllipseService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        topLeftPoint = { x: 25, y: 25 };
        center = { x: 50, y: 50 };
        imageData = new ImageData(100, 100);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // test putSelection
    it('putSelection should call clearCanvas and putImageData', () => {
        const spy = spyOn(service['drawingService'].baseCtx, 'putImageData');

        service.putSelection(service['drawingService'].baseCtx, imageData, topLeftPoint.x, topLeftPoint.y);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(spy).toHaveBeenCalled();
    });

    // test deleteEllipse
    it('deleteEllipse should call clearCanvas ', () => {
        const size = { width: 25, height: 25 };

        service.deleteEllipse(center, size.width, size.height);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    // test isInsideEllipseData
    it('isInsideEllipseData case true ', () => {
        const radius = { width: 25, height: 25 };
        const line = 50;
        const column = 50;

        const boolExpect = service.isInsideEllipseData(line, column, center.x, center.y, radius.width, radius.height);

        expect(boolExpect).toEqual(true);
    });

    it('isInsideEllipseData case false ', () => {
        const radius = { width: 1, height: 1 };
        const line = 300;
        const column = 300;

        const boolExpect = service.isInsideEllipseData(line, column, center.x, center.y, radius.width, radius.height);

        expect(boolExpect).toEqual(false);
    });

    // tests activateSelectionArrows

    it('activateSelectionArrows with ArrowLeft should set arrowLeftPressed true', () => {
        const keyboardEvent = { key: 'ArrowLeft' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    it('activateSelectionArrows with ArrowRight should set arrowRightPressed true', () => {
        const keyboardEvent = { key: 'ArrowRight' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    it('activateSelectionArrows with ArrowUp should set arrowUpPressed true', () => {
        const keyboardEvent = { key: 'ArrowUp' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    it('activateSelectionArrows with ArrowDown should set arrowDownPressed true', () => {
        const keyboardEvent = { key: 'ArrowDown' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(true);
    });

    it('activateSelectionArrows with random key should do nothing', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;

        service.activateSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(false);
    });

    // tests disableSelectionArrows

    it('disableSelectionArrows with ArrowLeft should set arrowLeftPressed false', () => {
        const keyboardEvent = { key: 'ArrowLeft' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(false);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeEllipseServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with ArrowRight should set arrowRightPressed false', () => {
        const keyboardEvent = { key: 'ArrowRight' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(false);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeEllipseServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with ArrowUp should set arrowUpPressed false', () => {
        const keyboardEvent = { key: 'ArrowUp' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(false);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeEllipseServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with ArrowDown should set arrowDownPressed false', () => {
        const keyboardEvent = { key: 'ArrowDown' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(false);
        expect(resizeEllipseServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('disableSelectionArrows with random key should do nothing', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;

        service.disableSelectionArrows(keyboardEvent);

        expect(service['arrowLeftPressed']).toEqual(true);
        expect(service['arrowRightPressed']).toEqual(true);
        expect(service['arrowUpPressed']).toEqual(true);
        expect(service['arrowDownPressed']).toEqual(true);
        expect(resizeEllipseServiceSpy.drawResizingRectangle).not.toHaveBeenCalled();
    });

    // tests moveSelectionArrows

    it('moveSelectionArrows with arrowLeftPressed true should call clearCanvas and putImage Data', () => {
        service['arrowLeftPressed'] = true;
        service['arrowRightPressed'] = true;
        service['arrowUpPressed'] = true;
        service['arrowDownPressed'] = true;
        const size = { width: 25, height: 25 };
        const point = { x: 25, y: 25 };
        (service['ellipseRotationService'].topLeftPoint = point), (service['ellipseRotationService'].center = point);
        service['ellipseRotationService'].imageData = new ImageData(100, 100);
        service.topLeftPoint = service.circleCenter = point;
        const spy = spyOn<any>(service['ellipseRotationService'], 'rotate');

        service.moveSelectionArrows(imageData, size, point, point);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalledTimes(4);
        expect(spy).toHaveBeenCalledTimes(4);
    });

    it('moveSelectionArrows with arrowRightPressed true should call clearCanvas and putImage Data', () => {
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;
        const size = { width: 25, height: 25 };

        const spy = spyOn<any>(service['drawingService'].previewCtx, 'putImageData');
        service.moveSelectionArrows(imageData, size, topLeftPoint, center);

        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
        expect(spy).not.toHaveBeenCalled();
    });

    it('moveSelectionArrows should call useMagnetisme if magnetisme is enabled', () => {
        service['arrowLeftPressed'] = false;
        service['arrowRightPressed'] = false;
        service['arrowUpPressed'] = false;
        service['arrowDownPressed'] = false;
        service['magnetismService'].enableMagnetism = true;
        const size = { width: 25, height: 25 };
        const point = { x: 25, y: 25 };
        service.topLeftPoint = service.circleCenter = point;
        const spy = spyOn<any>(service['magnetismService'], 'useMagnetism').and.callFake(() => {
            return { x: 25, y: 25 };
        });
        service.moveSelectionArrows(imageData, size, topLeftPoint, center);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
        expect(spy).toHaveBeenCalled();
        expect(topLeftPoint).toEqual({ x: 25, y: 25 });
    });
});
