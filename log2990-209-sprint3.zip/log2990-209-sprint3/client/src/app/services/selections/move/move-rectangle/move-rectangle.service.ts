import { Injectable } from '@angular/core';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { OFFSET_ARROW } from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { MagnetismService } from '@app/services/selections/magnetism/magnetism.service';
import { ResizeRectangleService } from '@app/services/selections/resize/resize-rectangle/resize-rectangle.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';
@Injectable({
    providedIn: 'root',
})
export class MoveRectangleService {
    private arrowLeftPressed: boolean;
    private arrowRightPressed: boolean;
    private arrowUpPressed: boolean;
    private arrowDownPressed: boolean;
    angle: number = 0;
    constructor(
        private drawingService: DrawingService,
        private resizeRectangleService: ResizeRectangleService,
        private rotationRectangleService: RotationRectangleService,
        private magnetismService: MagnetismService,
    ) {}

    putSelection(ctx: CanvasRenderingContext2D, imgData: ImageData, topLeftPoint: Vec2): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        ctx.putImageData(imgData, topLeftPoint.x, topLeftPoint.y);
    }

    deleteRectangle(topLeftPoint: Vec2, size: Size): void {
        this.drawingService.baseCtx.fillStyle = 'white';
        this.drawingService.baseCtx.fillRect(topLeftPoint.x, topLeftPoint.y, size.width + 1, size.height + 1);
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
    }

    activateSelectionArrows(event: KeyboardEvent): void {
        switch (event.key) {
            case 'ArrowLeft': {
                this.arrowLeftPressed = true;
                break;
            }
            case 'ArrowRight': {
                this.arrowRightPressed = true;
                break;
            }
            case 'ArrowUp': {
                this.arrowUpPressed = true;
                break;
            }
            case 'ArrowDown': {
                this.arrowDownPressed = true;
                break;
            }
        }
    }

    disableSelectionArrows(event: KeyboardEvent): void {
        switch (event.key) {
            case 'ArrowLeft': {
                this.arrowLeftPressed = false;
                this.resizeRectangleService.drawResizingRectangle();
                break;
            }
            case 'ArrowRight': {
                this.arrowRightPressed = false;
                this.resizeRectangleService.drawResizingRectangle();
                break;
            }
            case 'ArrowUp': {
                this.arrowUpPressed = false;
                this.resizeRectangleService.drawResizingRectangle();
                break;
            }
            case 'ArrowDown': {
                this.arrowDownPressed = false;
                this.resizeRectangleService.drawResizingRectangle();
                break;
            }
        }
    }

    moveSelectionArrows(imgData: ImageData, topLeftPoint: Vec2, size: Size, angle: number): void {
        let offsetMovement: number = OFFSET_ARROW;
        if (this.magnetismService.enableMagnetism) {
            const magnetismPoint = this.magnetismService.useMagnetism(topLeftPoint, size);
            offsetMovement = this.magnetismService.squareSize;
            topLeftPoint.x = magnetismPoint.x;
            topLeftPoint.y = magnetismPoint.y;
        }

        if (this.arrowLeftPressed) {
            topLeftPoint.x -= offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.rotationRectangleService.imageData = imgData;
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, angle);
        }

        if (this.arrowRightPressed) {
            topLeftPoint.x += offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.rotationRectangleService.imageData = imgData;
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, angle);
        }

        if (this.arrowUpPressed) {
            topLeftPoint.y -= offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.rotationRectangleService.imageData = imgData;
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, angle);
        }

        if (this.arrowDownPressed) {
            topLeftPoint.y += offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.rotationRectangleService.imageData = imgData;
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, angle);
        }

        this.resizeRectangleService.updateSelectionVariables(topLeftPoint);
    }
}
