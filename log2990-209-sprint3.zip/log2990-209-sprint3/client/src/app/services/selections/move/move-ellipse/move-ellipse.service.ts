import { Injectable } from '@angular/core';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { BLUE_COLOR_INDEX, COLORS_PER_POSITION, GREEN_COLOR_INDEX, OFFSET_ARROW, OPACITY_INDEX } from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { MagnetismService } from '@app/services/selections/magnetism/magnetism.service';
import { ResizeEllipseService } from '@app/services/selections/resize/resize-ellipse/resize-ellipse.service';
import { RotationEllipseService } from '@app/services/selections/rotation/rotation-ellipse/rotation-ellipse.service';

@Injectable({
    providedIn: 'root',
})
export class MoveEllipseService {
    private arrowLeftPressed: boolean;
    private arrowRightPressed: boolean;
    private arrowUpPressed: boolean;
    private arrowDownPressed: boolean;
    topLeftPoint: Vec2;
    circleCenter: Vec2;
    angle: number;

    constructor(
        private drawingService: DrawingService,
        private resizeEllipseService: ResizeEllipseService,
        private ellipseRotationService: RotationEllipseService,
        private magnetismService: MagnetismService,
    ) {}

    putSelection(ctx: CanvasRenderingContext2D, imgData: ImageData, x: number, y: number): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        ctx.putImageData(imgData, x, y);
    }

    deleteEllipse(circleCenter: Vec2, radiusX: number, radiusY: number): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.drawingService.baseCtx.beginPath();
        this.drawingService.baseCtx.fillStyle = 'white';
        this.drawingService.baseCtx.ellipse(circleCenter.x, circleCenter.y, radiusX, radiusY, 0, 0, Math.PI * 2);
        this.drawingService.baseCtx.fill();
        this.drawingService.baseCtx.closePath();
    }

    isInsideEllipseData(line: number, column: number, circleCenterX: number, circleCenterY: number, radiusX: number, radiusY: number): boolean {
        return Math.pow(line - circleCenterX, 2) / Math.pow(radiusX, 2) + Math.pow(column - circleCenterY, 2) / Math.pow(radiusY, 2) <= 1;
    }

    activateSelectionArrows(event: KeyboardEvent): void {
        switch (event.key) {
            case 'ArrowLeft': {
                this.arrowLeftPressed = true;
                break;
            }
            case 'ArrowRight': {
                this.arrowRightPressed = true;
                break;
            }
            case 'ArrowUp': {
                this.arrowUpPressed = true;
                break;
            }
            case 'ArrowDown': {
                this.arrowDownPressed = true;
                break;
            }
        }
    }

    disableSelectionArrows(event: KeyboardEvent): void {
        switch (event.key) {
            case 'ArrowLeft': {
                this.arrowLeftPressed = false;
                this.resizeEllipseService.drawResizingRectangle();
                break;
            }
            case 'ArrowRight': {
                this.arrowRightPressed = false;
                this.resizeEllipseService.drawResizingRectangle();
                break;
            }
            case 'ArrowUp': {
                this.arrowUpPressed = false;
                this.resizeEllipseService.drawResizingRectangle();
                break;
            }
            case 'ArrowDown': {
                this.arrowDownPressed = false;
                this.resizeEllipseService.drawResizingRectangle();
                break;
            }
        }
    }

    getEllipseImageData(imageData: ImageData, mousePosX: number, mousePosY: number, width: number, height: number): ImageData {
        let row: number;
        let column: number;
        const baseImageData: ImageData = this.drawingService.baseCtx.getImageData(mousePosX, mousePosY, width, height);
        for (row = 0; row < width; row++) {
            for (column = 0; column < height; column++) {
                if (!this.isInsideEllipseData(row, column, width / 2, height / 2, width / 2, height / 2)) {
                    const index: number = (column * width + row) * COLORS_PER_POSITION;
                    imageData.data[index] = baseImageData.data[index];
                    imageData.data[index + GREEN_COLOR_INDEX] = baseImageData.data[index + GREEN_COLOR_INDEX];
                    imageData.data[index + BLUE_COLOR_INDEX] = baseImageData.data[index + BLUE_COLOR_INDEX];
                    imageData.data[index + OPACITY_INDEX] = baseImageData.data[index + OPACITY_INDEX];
                }
            }
        }
        return imageData;
    }

    moveSelectionArrows(imgData: ImageData, size: Size, topLeftPoint: Vec2, circleCenter: Vec2): void {
        let offsetMovement: number = OFFSET_ARROW;
        if (this.magnetismService.enableMagnetism) {
            const magnetismPoint = this.magnetismService.useMagnetism(topLeftPoint, size);
            offsetMovement = this.magnetismService.squareSize;
            topLeftPoint.x = magnetismPoint.x;
            topLeftPoint.y = magnetismPoint.y;
            circleCenter.x = topLeftPoint.x + size.width / 2;
            circleCenter.y = topLeftPoint.y + size.height / 2;
        }
        if (this.arrowLeftPressed) {
            this.circleCenter.x -= offsetMovement;
            this.topLeftPoint.x -= offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.ellipseRotationService.topLeftPoint = this.topLeftPoint;
            this.ellipseRotationService.center = this.circleCenter;
            this.ellipseRotationService.imageData = this.getEllipseImageData(
                imgData,
                this.topLeftPoint.x,
                this.topLeftPoint.y,
                size.width,
                size.height,
            );
            this.ellipseRotationService.rotate(this.drawingService.previewCtx, this.angle);
        }

        if (this.arrowRightPressed) {
            this.circleCenter.x += offsetMovement;
            this.topLeftPoint.x += offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.ellipseRotationService.topLeftPoint = this.topLeftPoint;
            this.ellipseRotationService.center = this.circleCenter;
            this.ellipseRotationService.imageData = this.getEllipseImageData(
                imgData,
                this.topLeftPoint.x,
                this.topLeftPoint.y,
                size.width,
                size.height,
            );
            this.ellipseRotationService.rotate(this.drawingService.previewCtx, this.angle);
        }

        if (this.arrowUpPressed) {
            this.circleCenter.y -= offsetMovement;
            this.topLeftPoint.y -= offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.ellipseRotationService.topLeftPoint = this.topLeftPoint;
            this.ellipseRotationService.center = this.circleCenter;
            this.ellipseRotationService.imageData = this.getEllipseImageData(
                imgData,
                this.topLeftPoint.x,
                this.topLeftPoint.y,
                size.width,
                size.height,
            );
            this.ellipseRotationService.rotate(this.drawingService.previewCtx, this.angle);
        }

        if (this.arrowDownPressed) {
            this.circleCenter.y += offsetMovement;
            this.topLeftPoint.y += offsetMovement;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.ellipseRotationService.topLeftPoint = this.topLeftPoint;
            this.ellipseRotationService.center = this.circleCenter;
            this.ellipseRotationService.imageData = this.getEllipseImageData(
                imgData,
                this.topLeftPoint.x,
                this.topLeftPoint.y,
                size.width,
                size.height,
            );
            this.ellipseRotationService.rotate(this.drawingService.previewCtx, this.angle);
        }
        this.resizeEllipseService.updateSelectionVariables(this.topLeftPoint);
    }
}
