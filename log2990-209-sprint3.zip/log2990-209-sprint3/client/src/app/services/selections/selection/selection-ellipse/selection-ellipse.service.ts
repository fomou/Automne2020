import { Injectable } from '@angular/core';
import { EllipseSelection } from '@app/classes/ellipse-selection';
import { ShapeTool } from '@app/classes/shape-tool';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ClipboardEllipseService } from '@app/services/selections/clipboard/clipboard-ellipse/clipboard-ellipse.service';
import { MagnetismService } from '@app/services/selections/magnetism/magnetism.service';
import { MoveEllipseService } from '@app/services/selections/move/move-ellipse/move-ellipse.service';
import { ResizeEllipseService } from '@app/services/selections/resize/resize-ellipse/resize-ellipse.service';
import { RotationEllipseService } from '@app/services/selections/rotation/rotation-ellipse/rotation-ellipse.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';

@Injectable({
    providedIn: 'root',
})
export class SelectionEllipseService extends ShapeTool {
    private isResizing: boolean = false;
    private angle: number = 0;
    private altKeyPressed: boolean = false;
    private center: Vec2;
    private distance: Vec2;
    private deletedCircleCenter: Vec2;

    imageData: ImageData;
    circleCenter: Vec2;
    topLeftPoint: Vec2;
    radius: Vec2;
    size: Size;
    isSelected: boolean = false;
    isMoving: boolean = false;
    ctrlPressed: boolean = false;

    constructor(
        protected drawingService: DrawingService,
        private moveEllipseService: MoveEllipseService,
        private clipboardEllipseService: ClipboardEllipseService,
        private ellipseRotation: RotationEllipseService,
        private resizeEllipseService: ResizeEllipseService,
        private undoRedoService: UndoRedoService,
        private magnetismService: MagnetismService,
    ) {
        super(drawingService);
        this.primaryColor = '000000';
        this.secondaryColor = 'FFFFFF';
        this.drawingType = 'stroke';
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            if (this.clipboardEllipseService.cutting) this.isSelected = false;
            if (!this.isSelected) {
                this.firstPoint = this.getPositionFromMouse(event);
                this.width = 0;
                this.height = 0;
                this.clipboardEllipseService.cutting = false;
            } else {
                if (this.resizeEllipseService.resizingTest(this.getPositionFromMouse(event).x, this.getPositionFromMouse(event).y, this.size)) {
                    this.isResizing = true;
                } else if (!this.isInsideEllipse(event)) {
                    this.ellipseRotation.rotate(this.drawingService.baseCtx, this.angle);
                    const ellipseImageData: ImageData = this.getEllipseImageData(this.topLeftPoint.x, this.topLeftPoint.y);
                    const ellipse = new EllipseSelection(ellipseImageData, this.center, this.deletedCircleCenter, this.angle);
                    this.undoRedoService.undoStack.pop();
                    this.undoRedoService.addToStack(ellipse);
                    this.cancelSelection();
                    this.clipboardEllipseService.disableCopy();
                    this.resetSelectionVariables();
                    this.firstPoint = this.getPositionFromMouse(event);
                    this.width = 0;
                    this.height = 0;
                } else {
                    this.isMoving = true;
                    this.distance = {
                        x: this.getPositionFromMouse(event).x - this.topLeftPoint.x,
                        y: this.getPositionFromMouse(event).y - this.topLeftPoint.y,
                    };
                    this.undoRedoService.undoStack.pop();
                    this.drawingService.previewCtx.restore();
                }
            }
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown && this.isResizing) {
            const resizePoint = this.resizeEllipseService.resizeSelection(event, this.imageData, this.topLeftPoint, this.size, this.shiftPressed);
            this.ellipseRotation.imageData = this.resizeEllipseService.resizedImageData;
            this.ellipseRotation.topLeftPoint = resizePoint;
            this.ellipseRotation.center = {
                x: resizePoint.x + this.resizeEllipseService.size.width / 2,
                y: resizePoint.y + this.resizeEllipseService.size.height / 2,
            };
            this.ellipseRotation.rotate(this.drawingService.previewCtx, this.angle);
            this.resizeEllipseService.drawControlPoints(resizePoint.x, resizePoint.y);
        } else if (this.mouseDown && !this.isMoving) {
            this.drawingService.previewCtx.restore();
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawSelection(this.drawingService.previewCtx);
            this.angle = 0;
        } else if (this.mouseDown && this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            let mousePos: Vec2 = { x: this.getPositionFromMouse(event).x - this.distance.x, y: this.getPositionFromMouse(event).y - this.distance.y };
            if (this.magnetismService.enableMagnetism) mousePos = this.magnetismService.useMagnetism(mousePos, this.size);
            this.ellipseRotation.topLeftPoint = { x: mousePos.x, y: mousePos.y };
            this.ellipseRotation.center = { x: mousePos.x + this.radius.x, y: mousePos.y + this.radius.y };
            this.ellipseRotation.rotate(this.drawingService.previewCtx, this.angle);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.isResizing) {
            let resizePoint: Vec2 = { x: 0, y: 0 };
            resizePoint = this.resizeEllipseService.resizeSelection(event, this.imageData, this.topLeftPoint, this.size, this.shiftPressed);
            this.initializeResizeVariables(resizePoint.x, resizePoint.y);
        } else if (this.mouseDown && !this.isMoving) {
            this.drawingService.previewCtx.restore();
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);

            this.initializeSelectionVariables();
            if (this.size.width === 0) this.size.width += 1;
            if (this.size.height === 0) this.size.height += 1;
            if (this.size.width > 0 && this.size.height > 0) {
                this.imageData = this.drawingService.baseCtx.getImageData(
                    this.topLeftPoint.x,
                    this.topLeftPoint.y,
                    this.size.width,
                    this.size.height,
                );
            }
            this.center = this.circleCenter;
            this.ellipseRotation.imageData = this.getEllipseImageData(this.topLeftPoint.x, this.topLeftPoint.y);
            this.ellipseRotation.topLeftPoint = this.topLeftPoint;
            this.ellipseRotation.center = this.circleCenter;
            this.moveEllipseService.deleteEllipse(this.circleCenter, this.radius.x, this.radius.y);
            const ellipse = new EllipseSelection(this.imageData, this.center, this.deletedCircleCenter, this.angle);
            this.undoRedoService.addToStack(ellipse);
            this.drawingService.previewCtx.putImageData(
                this.getEllipseImageData(this.topLeftPoint.x, this.topLeftPoint.y),
                this.topLeftPoint.x,
                this.topLeftPoint.y,
            );
            this.drawSelection(this.drawingService.previewCtx);
        } else if (this.mouseDown && this.isMoving) {
            this.mouseDown = false;
            this.topLeftPoint.x = this.getPositionFromMouse(event).x - this.distance.x;
            this.topLeftPoint.y = this.getPositionFromMouse(event).y - this.distance.y;
            if (this.magnetismService.enableMagnetism) this.topLeftPoint = this.magnetismService.useMagnetism(this.topLeftPoint, this.size);
            this.circleCenter.x = this.topLeftPoint.x + this.radius.x;
            this.circleCenter.y = this.topLeftPoint.y + this.radius.y;
            this.center = { x: this.circleCenter.x, y: this.circleCenter.y };
            this.resizeEllipseService.updateSelectionVariables(this.topLeftPoint);
            this.ellipseRotation.center = this.circleCenter;
            this.ellipseRotation.topLeftPoint = this.topLeftPoint;
            this.ellipseRotation.rotate(this.drawingService.previewCtx, this.angle);
            const ellipse = new EllipseSelection(this.imageData, this.center, this.deletedCircleCenter, this.angle);
            this.undoRedoService.addToStack(ellipse);
        }
        this.resizeEllipseService.drawResizingRectangle();
    }

    onKeyDown(event: KeyboardEvent): void {
        if (event.altKey) {
            event.preventDefault();
            this.altKeyPressed = true;
        }
        if (event.ctrlKey) {
            this.ctrlPressed = true;
        }
        if (event.key === 'Shift') {
            this.shiftPressed = true;
        }
        if (event.key === 'Escape' && this.isSelected) {
            this.ellipseRotation.rotate(this.drawingService.baseCtx, this.angle);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.cancelSelection();
            this.clipboardEllipseService.disableCopy();
            this.resetSelectionVariables();
        }
        if (this.isSelected) {
            this.moveEllipseService.activateSelectionArrows(event);
            this.moveEllipseService.topLeftPoint = this.topLeftPoint;
            this.moveEllipseService.circleCenter = this.circleCenter;
            this.moveEllipseService.angle = this.angle;
            this.clipboardEllipseService.center = this.circleCenter;
            this.clipboardEllipseService.deletedCenter = this.deletedCircleCenter;
            this.clipboardEllipseService.angle = this.angle;
            this.moveEllipseService.moveSelectionArrows(this.imageData, this.size, this.topLeftPoint, this.circleCenter);
            this.clipboardEllipseService.copy(event, this.imageData);
            this.clipboardEllipseService.cut(event, this.imageData);
            this.clipboardEllipseService.paste(event, this.topLeftPoint, this.circleCenter, this.deletedCircleCenter, this.size);

            if (event.code === 'Delete') {
                this.clipboardEllipseService.delete();
                this.isSelected = false;
                this.isMoving = false;
            }
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        this.moveEllipseService.disableSelectionArrows(event);
        if (event.ctrlKey) {
            this.ctrlPressed = false;
        }
        if (event.key === 'Shift') {
            this.shiftPressed = false;
        }
        if (this.altKeyPressed) {
            this.altKeyPressed = false;
        }
    }

    onMouseWheel(event: WheelEvent): void {
        if (this.isSelected) {
            this.drawingService.previewCtx.restore();
            this.angle += this.altKeyPressed
                ? this.normalizeEvent(event) * this.convertAngleToRadian(CONSTANT.DEGREE_1)
                : this.normalizeEvent(event) * this.convertAngleToRadian(CONSTANT.DEGREE_15);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.ellipseRotation.rotate(this.drawingService.previewCtx, this.angle);
            const ellipse = new EllipseSelection(this.imageData, this.center, this.deletedCircleCenter, this.angle);
            this.undoRedoService.undoStack.pop();
            this.undoRedoService.addToStack(ellipse);
            this.resizeEllipseService.drawResizingRectangle();
        }
    }
    private initializeSelectionVariables(): void {
        this.topLeftPoint = this.findTopLeftPoint(this.firstPoint, this.lastPoint);
        this.circleCenter = this.deletedCircleCenter = this.getCenter(this.firstPoint, this.lastPoint);
        this.radius = { x: Math.abs(this.firstPoint.x - this.lastPoint.x) / 2, y: Math.abs(this.firstPoint.y - this.lastPoint.y) / 2 };
        this.size = { width: Math.abs(this.firstPoint.x - this.lastPoint.x), height: Math.abs(this.firstPoint.y - this.lastPoint.y) };
        this.resizeEllipseService.topLeftPoint = { x: this.topLeftPoint.x, y: this.topLeftPoint.y };
        this.resizeEllipseService.size = { width: this.size.width, height: this.size.height };
        this.isSelected = true;
        this.mouseDown = false;
    }

    private initializeResizeVariables(x: number, y: number): void {
        this.topLeftPoint.x = this.resizeEllipseService.topLeftPoint.x = x;
        this.topLeftPoint.y = this.resizeEllipseService.topLeftPoint.y = y;
        this.size.width = this.resizeEllipseService.size.width;
        this.size.height = this.resizeEllipseService.size.height;
        this.radius.x = this.size.width / 2;
        this.radius.y = this.size.height / 2;
        this.circleCenter.x = this.topLeftPoint.x + this.radius.x;
        this.circleCenter.y = this.topLeftPoint.y + this.radius.y;
        this.imageData = this.resizeEllipseService.resizedImageData;
        this.isResizing = false;
        this.mouseDown = false;
        this.ellipseRotation.topLeftPoint = this.topLeftPoint;
        this.ellipseRotation.center = this.circleCenter;
        this.ellipseRotation.imageData = this.getEllipseImageData(this.topLeftPoint.x, this.topLeftPoint.y);
        this.ellipseRotation.rotate(this.drawingService.previewCtx, this.angle);
    }

    private resetSelectionVariables(): void {
        this.circleCenter.x = 0;
        this.circleCenter.y = 0;
        this.topLeftPoint.x = 0;
        this.topLeftPoint.y = 0;
        this.radius.x = 0;
        this.radius.y = 0;
        this.size.width = 0;
        this.size.height = 0;
        this.angle = 0;
    }

    private isInsideEllipse(event: MouseEvent): boolean {
        return (
            Math.pow(this.getPositionFromMouse(event).x - this.circleCenter.x, 2) / Math.pow(this.radius.x, 2) +
                Math.pow(this.getPositionFromMouse(event).y - this.circleCenter.y, 2) / Math.pow(this.radius.y, 2) <=
            1
        );
    }

    private isInsideEllipseData(
        line: number,
        column: number,
        circleCenterX: number,
        circleCenterY: number,
        radiusX: number,
        radiusY: number,
    ): boolean {
        return Math.pow(line - circleCenterX, 2) / Math.pow(radiusX, 2) + Math.pow(column - circleCenterY, 2) / Math.pow(radiusY, 2) <= 1;
    }

    private getEllipseImageData(mousePosX: number, mousePosY: number): ImageData {
        let row: number;
        let column: number;
        const baseImageData: ImageData = this.drawingService.baseCtx.getImageData(mousePosX, mousePosY, this.size.width, this.size.height);
        for (row = 0; row < this.size.width; row++) {
            for (column = 0; column < this.size.height; column++) {
                if (!this.isInsideEllipseData(row, column, this.size.width / 2, this.size.height / 2, this.size.width / 2, this.size.height / 2)) {
                    const index: number = (column * this.size.width + row) * CONSTANT.COLORS_PER_POSITION;
                    this.imageData.data[index] = baseImageData.data[index];
                    this.imageData.data[index + CONSTANT.GREEN_COLOR_INDEX] = baseImageData.data[index + CONSTANT.GREEN_COLOR_INDEX];
                    this.imageData.data[index + CONSTANT.BLUE_COLOR_INDEX] = baseImageData.data[index + CONSTANT.BLUE_COLOR_INDEX];
                    this.imageData.data[index + CONSTANT.OPACITY_INDEX] = baseImageData.data[index + CONSTANT.OPACITY_INDEX];
                }
            }
        }
        return this.imageData;
    }

    cancelSelection(): void {
        this.isSelected = false;
        this.isMoving = false;
    }

    drawSelection(ctx: CanvasRenderingContext2D): void {
        this.circleCenter = this.getCenter(this.firstPoint, this.lastPoint);
        this.radius = { x: Math.abs(this.firstPoint.x - this.lastPoint.x) / 2, y: Math.abs(this.firstPoint.y - this.lastPoint.y) / 2 };

        if (this.shiftPressed) {
            const shiftLastPoint = this.findShiftPoint(this.firstPoint, this.lastPoint);
            this.circleCenter = this.circleCenter = this.getCenter(this.firstPoint, shiftLastPoint);
            this.radius = { x: Math.abs(this.firstPoint.x - shiftLastPoint.x) / 2, y: Math.abs(this.firstPoint.y - shiftLastPoint.y) / 2 };
            this.size = { width: this.radius.x * 2, height: this.radius.y * 2 };
        }
        ctx.beginPath();
        ctx.setLineDash([CONSTANT.LINE_DASH, CONSTANT.LINE_DASH]);
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'blue';
        ctx.ellipse(this.circleCenter.x, this.circleCenter.y, this.radius.x, this.radius.y, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.closePath();
    }

    private convertAngleToRadian(angle: number): number {
        return (angle * Math.PI) / CONSTANT.DEGREE_180;
    }
    private normalizeEvent(event: WheelEvent): number {
        return event.deltaY / Math.abs(event.deltaY);
    }
}
