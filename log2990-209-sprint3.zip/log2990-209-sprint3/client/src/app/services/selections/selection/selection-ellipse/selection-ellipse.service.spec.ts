import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ClipboardEllipseService } from '@app/services/selections/clipboard/clipboard-ellipse/clipboard-ellipse.service';
import { MoveEllipseService } from '@app/services/selections/move/move-ellipse/move-ellipse.service';
import { ResizeEllipseService } from '@app/services/selections/resize/resize-ellipse/resize-ellipse.service';
import { RotationEllipseService } from '@app/services/selections/rotation/rotation-ellipse/rotation-ellipse.service';
import { SelectionEllipseService } from './selection-ellipse.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: max-file-line-count
describe('SelectionEllipseService', () => {
    let service: SelectionEllipseService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let resizeEllipseServiceSpy: jasmine.SpyObj<ResizeEllipseService>;
    let rotationEllipseServiceSpy: jasmine.SpyObj<RotationEllipseService>;
    let moveEllipseServiceSpy: jasmine.SpyObj<MoveEllipseService>;
    let clipBoardEllipseServiceSpy: jasmine.SpyObj<ClipboardEllipseService>;
    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        resizeEllipseServiceSpy = jasmine.createSpyObj<any>('ResizeEllipseService', [
            'resizingTest',
            'resizeSelection',
            'drawResizingRectangle',
            'drawResizedSelection',
            'updateSelectionVariables',
            'drawControlPoints',
        ]);
        moveEllipseServiceSpy = jasmine.createSpyObj('MoveEllipseService', [
            'putSelection',
            'activateSelectionArrows',
            'moveSelectionArrows',
            'deleteEllipse',
            'disableSelectionArrows',
            'getEllipseImageData',
            'isInsideEllipseData',
        ]);
        clipBoardEllipseServiceSpy = jasmine.createSpyObj<any>(
            'ClipboardEllipseService',
            ['disableCopy', 'copy', 'cut', 'paste', 'delete'],
            ['stopSelection'],
        );
        rotationEllipseServiceSpy = jasmine.createSpyObj<any>('RotationEllipseService', ['rotate']);
        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: ResizeEllipseService, useValue: resizeEllipseServiceSpy },
                { provide: RotationEllipseService, useValue: rotationEllipseServiceSpy },
                { provide: MoveEllipseService, useValue: moveEllipseServiceSpy },
                { provide: ClipboardEllipseService, useValue: clipBoardEllipseServiceSpy },
            ],
        });
        service = TestBed.inject(SelectionEllipseService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // tests OnMouseDown

    it('onMouseDown with no selection should set mouseDown true and initialize firstPoint', () => {
        service['mouseDown'] = false;
        service['isSelected'] = false;
        service.height = 30;
        const expectPoint: Vec2 = { x: 25, y: 25 };

        service.onMouseDown(mouseEvent);

        expect(service.height).toEqual(0);
        expect(service['mouseDown']).toEqual(true);
        expect(service['firstPoint']).toEqual(expectPoint);
    });

    it('onMouseDown on a resizing box should put isResizing true ', () => {
        service['mouseDown'] = false;
        service.isSelected = true;
        service['isResizing'] = false;

        resizeEllipseServiceSpy.resizingTest.and.returnValue(1);

        service.onMouseDown(mouseEvent);

        expect(service['isResizing']).toEqual(true);
    });

    it('onMouseDown outside the selection should call cancelSelection ', () => {
        service['mouseDown'] = false;
        service.isSelected = true;
        service.size = { width: 25, height: 25 };
        service.topLeftPoint = { x: 25, y: 25 };

        resizeEllipseServiceSpy.resizingTest.and.returnValue(0);
        spyOn<any>(service, 'isInsideEllipse').and.returnValue(false);
        const cancelSpy = spyOn(service, 'cancelSelection');
        spyOn<any>(service, 'resetSelectionVariables');
        spyOn<any>(service, 'getEllipseImageData').and.returnValue(new ImageData(100, 100));

        service.onMouseDown(mouseEvent);

        expect(cancelSpy).toHaveBeenCalled();
    });

    it('onMouseDown inside the selection should set isMoving to true ', () => {
        service['mouseDown'] = false;
        service.isSelected = true;
        service.isMoving = false;
        service.topLeftPoint = { x: 25, y: 25 };

        resizeEllipseServiceSpy.resizingTest.and.returnValue(0);
        spyOn<any>(service, 'isInsideEllipse').and.returnValue(true);

        service.onMouseDown(mouseEvent);

        expect(service.isMoving).toEqual(true);
    });

    it('onMouseDown with rightClick should not set mouseDown true', () => {
        mouseEvent = {
            pageX: 30,
            pageY: 30,
            button: 2,
        } as MouseEvent;

        service['mouseDown'] = false;

        service.onMouseDown(mouseEvent);
        expect(service['mouseDown']).toEqual(false);
    });

    // tests onMouseMove

    it('onMouseMove with no selection should set lastPoint and call drawSelection', () => {
        service['mouseDown'] = true;
        service['isResizing'] = false;
        service.isMoving = false;
        const expectPoint: Vec2 = { x: 25, y: 25 };

        const drawSelectionSpy = spyOn<any>(service, 'drawSelection');

        service.onMouseMove(mouseEvent);

        expect(service['lastPoint']).toEqual(expectPoint);
        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseMove with isResizing true should call resizeSelection', () => {
        service['mouseDown'] = true;
        service['isResizing'] = true;
        service.imageData = new ImageData(100, 100);
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };
        service['resizeEllipseService'].size = { width: 25, height: 25 };

        // spyOn(service['ellipseRotation'], 'rotate');
        resizeEllipseServiceSpy.resizeSelection.and.returnValue({ x: 25, y: 25 });
        service.onMouseMove(mouseEvent);

        expect(resizeEllipseServiceSpy.resizeSelection).toHaveBeenCalled();
    });

    it('onMouseMove with a selection should  call rotate', () => {
        service['mouseDown'] = true;
        service['isResizing'] = false;
        service.isMoving = true;
        service['distance'] = { x: 25, y: 25 };
        service['radius'] = { x: 25, y: 25 };

        service.onMouseMove(mouseEvent);

        expect(rotationEllipseServiceSpy.rotate).toHaveBeenCalled();
    });

    it('onMouseMove with mouseDown false should do nothing', () => {
        service['mouseDown'] = false;

        const drawSelectionSpy = spyOn<any>(service, 'drawSelection');

        service.onMouseMove(mouseEvent);

        expect(service['mouseDown']).toEqual(false);
        expect(rotationEllipseServiceSpy.rotate).not.toHaveBeenCalled();
        expect(drawSelectionSpy).not.toHaveBeenCalled();
        expect(resizeEllipseServiceSpy.resizeSelection).not.toHaveBeenCalled();
    });

    // tests onMouseUp

    it('onMouseUp with no selection should call drawSelection', () => {
        service['mouseDown'] = true;
        service.isMoving = false;
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = { x: 20, y: 20 };
        service.circleCenter = { x: 20, y: 20 };
        service.radius = { x: 20, y: 20 };
        service['deletedCircleCenter'] = { x: 20, y: 20 };
        service['angle'] = 10;
        service['center'] = { x: 20, y: 20 };

        spyOn<any>(service, 'findTopLeftPoint').and.returnValue({ x: 25, y: 25 });
        spyOn<any>(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        spyOn<any>(service['drawingService'].previewCtx, 'putImageData');
        spyOn<any>(service, 'initializeSelectionVariables');
        const drawSelectionSpy = spyOn<any>(service, 'drawSelection');

        service.onMouseUp(mouseEvent);

        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseUp with no selection with width < 0 should call drawSelection', () => {
        service['mouseDown'] = true;
        service.isMoving = false;
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = { x: 20, y: 20 };
        service.circleCenter = { x: 20, y: 20 };
        service.radius = { x: 20, y: 20 };
        service['deletedCircleCenter'] = { x: 20, y: 20 };
        service['angle'] = 10;
        service['center'] = { x: 20, y: 20 };

        service.width = -10;
        service.height = -30;

        spyOn<any>(service, 'findTopLeftPoint').and.returnValue({ x: 25, y: 25 });
        spyOn<any>(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        spyOn<any>(service['drawingService'].previewCtx, 'putImageData');
        spyOn<any>(service, 'initializeSelectionVariables');
        const drawSelectionSpy = spyOn<any>(service, 'drawSelection');

        service.onMouseUp(mouseEvent);

        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseUp with isResizing true should call initializeResizeVariables', () => {
        service['mouseDown'] = true;
        service['isResizing'] = true;
        service.imageData = new ImageData(100, 100);
        service.topLeftPoint = { x: 25, y: 25 };
        service['shiftPressed'] = false;
        service.size = { width: 25, height: 25 };
        service['angle'] = 50;

        resizeEllipseServiceSpy.resizeSelection.and.callFake(() => {
            return { x: 25, y: 25 };
        });

        const spy = spyOn<any>(service, 'initializeResizeVariables');

        service.onMouseUp(mouseEvent);

        expect(spy).toHaveBeenCalled();
    });

    it('onMouseUp with isMoving true should call drawResizingRectangle', () => {
        service['isResizing'] = false;
        service['mouseDown'] = true;
        service.isMoving = true;
        service['distance'] = { x: 25, y: 25 };
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };
        service.circleCenter = { x: 20, y: 20 };
        service.radius = { x: 20, y: 20 };
        service['deletedCircleCenter'] = { x: 20, y: 20 };
        service['angle'] = 10;
        service['center'] = { x: 20, y: 20 };

        service.onMouseUp(mouseEvent);

        expect(service['mouseDown']).toEqual(false);
        expect(rotationEllipseServiceSpy.rotate).toHaveBeenCalled();
        expect(resizeEllipseServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    // onMouseWheel
    it('onMouseWheel with isSelected and altKeyPressed true should call selectionRotationService.rotate with angle = 1 degree', () => {
        const wheelEvent = {
            deltaY: 30,
        } as WheelEvent;

        service.isSelected = true;
        service['altKeyPressed'] = true;
        service['distance'] = { x: 25, y: 25 };
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };

        service.onMouseWheel(wheelEvent);

        expect(service['angle']).toEqual((Math.PI * 1) / 180);
        expect(rotationEllipseServiceSpy.rotate).toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('onMouseWheel with isSelected true and altKeyPressed false should call selectionRotationService.rotate with angle = 15 degree', () => {
        const wheelEvent = {
            deltaY: 30,
        } as WheelEvent;

        service.isSelected = true;
        service['altKeyPressed'] = false;
        service['distance'] = { x: 25, y: 25 };
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };

        service.onMouseWheel(wheelEvent);

        expect(service['angle']).toEqual((Math.PI * 15) / 180);
        expect(rotationEllipseServiceSpy.rotate).toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('onMouseWheel with isSelected false should do nothing', () => {
        const wheelEvent = {
            deltaY: 30,
        } as WheelEvent;

        service.isSelected = false;
        service.onMouseWheel(wheelEvent);

        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
    });
    // tests onKeyDown

    it('onKeyDown with altKey should put altKeyPressed true', () => {
        const keyboardEvent = new KeyboardEvent('keypress', {
            altKey: true,
        });
        service['altKeyPressed'] = false;

        service.onKeyDown(keyboardEvent);

        expect(service['altKeyPressed']).toEqual(true);
    });

    it('onKeyDown with ctrlKey should put ctrlPressed true', () => {
        const keyboardEvent = { ctrlKey: true } as KeyboardEvent;
        service.ctrlPressed = false;
        service.isSelected = false;

        service.onKeyDown(keyboardEvent);

        expect(service.ctrlPressed).toEqual(true);
    });

    it('onKeyDown with shift should put shiftPressed true', () => {
        const keyboardEvent = { key: 'Shift' } as KeyboardEvent;
        service['shiftPressed'] = false;

        service.onKeyDown(keyboardEvent);

        expect(service['shiftPressed']).toEqual(true);
    });

    it('onKeyDown with Escape should call cancelSelection', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service.isSelected = true;

        const spy = spyOn(service, 'cancelSelection');
        spyOn<any>(service, 'resetSelectionVariables');

        service.onKeyDown(keyboardEvent);

        expect(spy).toHaveBeenCalled();
    });

    it('onKeyDown with Delete should call clipBoardRectangleService.delete', () => {
        const keyboardEvent = { code: 'Delete' } as KeyboardEvent;
        service.isSelected = true;

        service.onKeyDown(keyboardEvent);

        expect(clipBoardEllipseServiceSpy.delete).toHaveBeenCalled();
    });

    // tests onKeyUp

    it('onKeyUp with ctrlKey should put ctrlPressed false', () => {
        const keyboardEvent = { ctrlKey: true } as KeyboardEvent;
        service.ctrlPressed = true;

        service.onKeyUp(keyboardEvent);

        expect(service.ctrlPressed).toEqual(false);
        expect(moveEllipseServiceSpy.disableSelectionArrows).toHaveBeenCalled();
    });

    it('onKeyUp with Shift should put shiftPressed false', () => {
        const keyboardEvent = { key: 'Shift' } as KeyboardEvent;
        service['shiftPressed'] = true;

        service.onKeyUp(keyboardEvent);

        expect(service['shiftPressed']).toEqual(false);
        expect(moveEllipseServiceSpy.disableSelectionArrows).toHaveBeenCalled();
    });

    it('onKeyUp with altKeyPressed should put altKeyPressed false', () => {
        const keyboardEvent = { altKey: true } as KeyboardEvent;
        service['altKeyPressed'] = true;

        service.onKeyUp(keyboardEvent);

        expect(service['altKeyPressed']).toEqual(false);
        expect(moveEllipseServiceSpy.disableSelectionArrows).toHaveBeenCalled();
    });

    // test initializeResizeVariables
    it('initializeResizeVariables should set isResizing to false', () => {
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };
        service.imageData = new ImageData(100, 100);
        service['isResizing'] = true;
        service['mouseDown'] = true;
        service['angle'] = 50;
        service['resizeEllipseService'].topLeftPoint = { x: 25, y: 25 };
        service['resizeEllipseService'].size = { width: 25, height: 25 };
        service['resizeEllipseService'].resizedImageData = new ImageData(100, 100);
        service.radius = { x: 20, y: 20 };
        service.circleCenter = { x: 20, y: 20 };

        service['initializeResizeVariables'](10, 10);

        expect(service['isResizing']).toEqual(false);
        expect(service['mouseDown']).toEqual(false);
    });

    // test initializeSelectionVariables
    it('initializeSelectionVariables should set isSelected to false', () => {
        service.topLeftPoint = { x: 25, y: 25 };
        service['firstPoint'] = { x: 25, y: 25 };
        service['lastPoint'] = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };
        service.imageData = new ImageData(100, 100);
        service['mouseDown'] = true;
        service['angle'] = 50;
        service['resizeEllipseService'].topLeftPoint = { x: 25, y: 25 };
        service['resizeEllipseService'].size = { width: 25, height: 25 };
        service['resizeEllipseService'].resizedImageData = new ImageData(100, 100);
        service.radius = { x: 20, y: 20 };
        service.circleCenter = { x: 20, y: 20 };
        spyOn<any>(service, 'findTopLeftPoint').and.returnValue({ x: 25, y: 25 });
        spyOn<any>(service, 'getCenter').and.returnValue({ x: 25, y: 25 });

        service['initializeSelectionVariables']();

        expect(service['isSelected']).toEqual(true);
        expect(service['mouseDown']).toEqual(false);
    });

    // tests resetSelectionVariables
    it('resetSelectionVariables should reset topLeftPoint and size', () => {
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };
        service.radius = { x: 20, y: 20 };
        service.circleCenter = { x: 20, y: 20 };

        service['resetSelectionVariables']();

        expect(service.topLeftPoint).toEqual({ x: 0, y: 0 });
        expect(service.size).toEqual({ width: 0, height: 0 });
    });

    // tests isInsideEllipse
    it('isInsideEllipse case true', () => {
        service.radius = { x: 20, y: 20 };
        service.circleCenter = { x: 20, y: 20 };

        const result = service['isInsideEllipse'](mouseEvent);

        expect(result).toEqual(true);
    });

    it('isInsideEllipse case false', () => {
        service.radius = { x: 20, y: 20 };
        service.circleCenter = { x: 500, y: 500 };

        const result = service['isInsideEllipse'](mouseEvent);

        expect(result).toEqual(false);
    });

    // test cancelSelection
    it('cancelSelection should set isSelected and isMoving to false', () => {
        service.isMoving = true;
        service.isSelected = true;

        service.cancelSelection();

        expect(service.isMoving).toEqual(false);
        expect(service.isSelected).toEqual(false);
    });

    // tests drawSelection
    it('drawSelection should call findTopLeftPoint', () => {
        service['firstPoint'] = { x: 10, y: 10 };
        service['lastPoint'] = { x: 30, y: 30 };
        service['shiftPressed'] = false;

        const spy = spyOn<any>(service, 'getCenter').and.returnValue({ x: 25, y: 25 });
        service['drawSelection'](service['drawingService'].baseCtx);

        expect(spy).toHaveBeenCalled();
    });

    it('drawSelection with shiftPressed should call findTopLeftPoint', () => {
        service['firstPoint'] = { x: 10, y: 10 };
        service['lastPoint'] = { x: 30, y: 30 };
        service['shiftPressed'] = true;

        const shiftSpy = spyOn<any>(service, 'findShiftPoint').and.returnValue({ x: 25, y: 25 });
        const spy = spyOn<any>(service, 'getCenter').and.returnValue({ x: 25, y: 25 });
        service['drawSelection'](service['drawingService'].baseCtx);

        expect(shiftSpy).toHaveBeenCalled();
        expect(spy).toHaveBeenCalled();
    });
});
