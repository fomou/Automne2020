import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Color } from '@app/classes/color';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ClipboardMagicWandService } from '@app/services/selections/clipboard/clipboard-magic-wand/clipboard-magic-wand.service';
import { MoveMagicWandService } from '@app/services/selections/move/move-magicWand/move-magic-wand.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';
import { MagicWandService } from './magic-wand.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: max-file-line-count
describe('MagicWandService', () => {
    let service: MagicWandService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let rotationRectangleServiceSpy: jasmine.SpyObj<RotationRectangleService>;
    let moveMagicWandServiceSpy: jasmine.SpyObj<MoveMagicWandService>;
    let clipboardMagicWandSpy: jasmine.SpyObj<ClipboardMagicWandService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        rotationRectangleServiceSpy = jasmine.createSpyObj<any>('RotationRectangleService', ['rotate']);
        moveMagicWandServiceSpy = jasmine.createSpyObj('MoveMagicWandService', [
            'putSelection',
            'activateSelectionArrows',
            'moveSelectionArrows',
            'deleteRectangle',
            'disableSelectionArrows',
        ]);
        clipboardMagicWandSpy = jasmine.createSpyObj<any>(
            'ClipboardMagicWandService',
            ['disableCopy', 'copy', 'cut', 'paste', 'delete'],
            ['stopSelection'],
        );
        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: RotationRectangleService, useValue: rotationRectangleServiceSpy },
                { provide: RotationRectangleService, useValue: rotationRectangleServiceSpy },
                { provide: MoveMagicWandService, useValue: moveMagicWandServiceSpy },
                { provide: ClipboardMagicWandService, useValue: clipboardMagicWandSpy },
            ],
        });
        service = TestBed.inject(MagicWandService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 296, // 25 + taille de la sidebar
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // test get
    it('getPixelPos should return the good number', () => {
        const result = service.getPixelPos(10, 10);
        expect(result).toEqual(40);
    });

    // test matchPixel
    it('matchPixel with tolerance!=0 ', () => {
        const position = 2;
        const imageData = new ImageData(100, 100);
        const data = imageData.data;
        const color: Color = { r: 1, g: 1, b: 1, a: 1 };

        const result = service.matchPixel(data, position, color);

        expect(result).toEqual(false);
    });

    // tests findResizingPoints
    it('findResizingPoints should call Math.floor', () => {
        const position = 2;
        const topLeftPoint = { x: 25, y: 25 };
        const bottomRightPoint = { x: 25, y: 25 };

        const spy = spyOn(Math, 'floor');
        service.findResizingPoints(topLeftPoint, bottomRightPoint, position);

        expect(spy).toHaveBeenCalled();
    });

    // tests drawSelectionOnPreviews
    it('drawSelectionOnPreview should call Math.floor', () => {
        const position = 2;
        const selectionImage = new ImageData(100, 100);
        const baseImage = new ImageData(100, 100);

        service.drawSelectionOnPreview(selectionImage, baseImage, position);

        expect(service).toBeTruthy();
    });

    // tests initializeImageData
    it('drawSelectionOnPreview should call Math.floor', () => {
        service['bottomRightPoint'] = { x: 50, y: 50 };
        service['topLeftPoint'] = { x: 25, y: 25 };
        const spy = spyOn(service['drawingService'].previewCtx, 'getImageData');

        service.initializeImageData(mouseEvent);

        expect(spy).toHaveBeenCalled();
    });

    // tests initializeImageData
    it('floodFillSelection should call getImageData and putImageData', () => {
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;
        const getBaseSpy = spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        const getPreviewSpy = spyOn(service['drawingService'].previewCtx, 'getImageData');
        const putBaseSpy = spyOn(service['drawingService'].baseCtx, 'putImageData');
        const putPreviewSpy = spyOn(service['drawingService'].previewCtx, 'putImageData');
        service.floodFillSelection(5, 5);

        expect(getBaseSpy).toHaveBeenCalled();
        expect(getPreviewSpy).toHaveBeenCalled();
        expect(putBaseSpy).toHaveBeenCalled();
        expect(putPreviewSpy).toHaveBeenCalled();
    });

    // tests initializeImageData
    it('contiguousFloodFillSelection should call getImageData and putImageData', () => {
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;
        const getBaseSpy = spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        const getPreviewSpy = spyOn(service['drawingService'].previewCtx, 'getImageData');
        const putBaseSpy = spyOn(service['drawingService'].baseCtx, 'putImageData');
        const putPreviewSpy = spyOn(service['drawingService'].previewCtx, 'putImageData');
        service.contiguousFloodFillSelection(5, 5);

        expect(getBaseSpy).toHaveBeenCalled();
        expect(getPreviewSpy).toHaveBeenCalled();
        expect(putBaseSpy).toHaveBeenCalled();
        expect(putPreviewSpy).toHaveBeenCalled();
    });

    // tests isInsideSelection
    it('isInsideSelection should call getPixelPos', () => {
        const imageData = new ImageData(100, 100);
        service.color = { r: 1, g: 1, b: 1, a: 1 };
        const spy = spyOn(service, 'getPixelPos');
        service.isInsideSelection(imageData, 25, 25);

        expect(spy).toHaveBeenCalled();
    });

    // tests drawSelection
    it('drawSelection should call getPixelPos', () => {
        const selectionImage = new ImageData(100, 100);
        const baseImage = new ImageData(100, 100);
        service.color = { r: 1, g: 1, b: 1, a: 1 };

        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientHeight').and.returnValue(2);
        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientWidth').and.returnValue(2);
        const getSpy = spyOn(service, 'getPixelPos');
        service.drawSelection(selectionImage, baseImage);

        expect(getSpy).toHaveBeenCalledTimes(4);
    });

    // test cancelSelection
    it('cancelSelection should set isSelected and isMoving to false', () => {
        service.isMoving = true;
        service.isSelected = true;
        const getBaseSpy = spyOn(service['drawingService'].baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        const getPreviewSpy = spyOn(service['drawingService'].previewCtx, 'getImageData');
        const putBaseSpy = spyOn(service['drawingService'].baseCtx, 'putImageData');
        service.cancelSelection();

        expect(service.isMoving).toEqual(false);
        expect(service.isSelected).toEqual(false);
        expect(getBaseSpy).toHaveBeenCalled();
        expect(getPreviewSpy).toHaveBeenCalled();
        expect(putBaseSpy).toHaveBeenCalled();
    });

    // tests onMouseDown
    it('onMouseDown with isSelected false should call initialize and set isSelected true', () => {
        service.isSelected = false;
        service['mouseDown'] = false;

        const spy = spyOn<any>(service, 'initialize');

        service.onMouseDown(mouseEvent);

        expect(spy).toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(true);
        expect(service.isSelected).toEqual(true);
    });

    it('onMouseDown with isSelected case resize', () => {
        service.isSelected = true;
        service.size = { width: 20, height: 20 };
        service['mouseDown'] = false;
        service['isResizing'] = false;
        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientHeight').and.returnValue(20);
        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientWidth').and.returnValue(20);
        spyOn(service['drawingService'].previewCtx, 'getImageData');

        spyOn(service['resizeMagicWandService'], 'resizingTest').and.callFake(() => {
            return 1;
        });
        service.onMouseDown(mouseEvent);

        expect(service['mouseDown']).toEqual(true);
        expect(service['isResizing']).toEqual(true);
    });

    it('onMouseDown with isSelected case isInside should set isMoving true', () => {
        service.isMoving = false;
        service.isSelected = true;
        service.size = { width: 20, height: 20 };
        service['mouseDown'] = false;
        service.topLeftPoint = { x: 25, y: 25 };
        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientHeight').and.returnValue(20);
        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientWidth').and.returnValue(20);
        spyOn(service['drawingService'].previewCtx, 'getImageData');

        spyOn(service['resizeMagicWandService'], 'resizingTest').and.returnValue(0);
        spyOn(service, 'isInsideSelection').and.callFake(() => {
            return true;
        });
        service.onMouseDown(mouseEvent);

        expect(service['mouseDown']).toEqual(true);
        expect(service.isMoving).toEqual(true);
    });

    it('onMouseDown with isSelected case outside the selection should call cancelSelection', () => {
        service.isMoving = false;
        service.isSelected = true;
        service.size = { width: 20, height: 20 };
        service['mouseDown'] = false;
        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientHeight').and.returnValue(20);
        spyOnProperty(service['drawingService'].previewCtx.canvas, 'clientWidth').and.returnValue(20);
        spyOn(service['drawingService'].previewCtx, 'getImageData');

        spyOn(service['resizeMagicWandService'], 'resizingTest').and.returnValue(0);
        spyOn(service, 'isInsideSelection').and.callFake(() => {
            return false;
        });
        const spy = spyOn(service, 'cancelSelection');
        service.onMouseDown(mouseEvent);

        expect(service['mouseDown']).toEqual(true);
        expect(spy).toHaveBeenCalled();
    });

    // tests onMouseMove
    it('onMouseMove case resizing should call resizeSelection', () => {
        service['mouseDown'] = true;
        service['isResizing'] = true;

        const resizeSpy = spyOn(service['resizeMagicWandService'], 'resizeSelection').and.returnValue({ x: 25, y: 25 });
        const controlPointsSpy = spyOn<any>(service['resizeMagicWandService'], 'drawControlPoints');
        service.onMouseMove(mouseEvent);

        expect(resizeSpy).toHaveBeenCalled();
        expect(controlPointsSpy).toHaveBeenCalled();
    });

    it('onMouseMove case move should call rotate', () => {
        service['mouseDown'] = true;
        service['isResizing'] = false;
        service['isSelected'] = true;
        service['isMoving'] = true;
        service['magnetismService'].enableMagnetism = false;
        service['distance'] = { x: 25, y: 25 };

        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(rotationRectangleServiceSpy.rotate).toHaveBeenCalled();
    });

    it('onMouseMove case move with magnetism should call rotate', () => {
        service['mouseDown'] = true;
        service['isResizing'] = false;
        service['isSelected'] = true;
        service['isMoving'] = true;
        service['magnetismService'].enableMagnetism = true;
        service['distance'] = { x: 25, y: 25 };

        spyOn(service['magnetismService'], 'useMagnetism').and.returnValue({ x: 25, y: 25 });
        service.onMouseMove(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(rotationRectangleServiceSpy.rotate).toHaveBeenCalled();
    });

    // tests onMouseUp
    it('onMouseUp case resizing', () => {
        service['mouseDown'] = true;
        service['isResizing'] = true;
        service['resizeMagicWandService'].topLeftPoint = { x: 25, y: 25 };
        service['resizeMagicWandService'].size = { width: 20, height: 20 };
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 20, height: 20 };
        const resizeSpy = spyOn(service['resizeMagicWandService'], 'resizeSelection').and.returnValue({ x: 25, y: 25 });
        service.onMouseUp(mouseEvent);

        expect(resizeSpy).toHaveBeenCalled();
        expect(rotationRectangleServiceSpy.rotate).toHaveBeenCalled();
    });

    it('onMouseUp case move should clear and redraw', () => {
        service['mouseDown'] = true;
        service['isResizing'] = false;
        service['isSelected'] = true;
        service['isMoving'] = true;
        service['distance'] = { x: 25, y: 25 };
        service['magnetismService'].enableMagnetism = false;
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 20, height: 20 };
        const updateSpy = spyOn(service['resizeMagicWandService'], 'updateSelectionVariables');
        const drawSpy = spyOn(service['resizeMagicWandService'], 'drawResizingRectangle');
        service.onMouseUp(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(updateSpy).toHaveBeenCalled();
        expect(drawSpy).toHaveBeenCalled();
        expect(rotationRectangleServiceSpy.rotate).toHaveBeenCalled();
    });

    it('onMouseUp case move with magnetism should clear and redraw', () => {
        service['mouseDown'] = true;
        service['isResizing'] = false;
        service['isSelected'] = true;
        service['isMoving'] = true;
        service['distance'] = { x: 25, y: 25 };
        service['magnetismService'].enableMagnetism = true;
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 20, height: 20 };
        const updateSpy = spyOn(service['resizeMagicWandService'], 'updateSelectionVariables');
        const drawSpy = spyOn(service['resizeMagicWandService'], 'drawResizingRectangle');
        service.onMouseUp(mouseEvent);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(updateSpy).toHaveBeenCalled();
        expect(drawSpy).toHaveBeenCalled();
        expect(rotationRectangleServiceSpy.rotate).toHaveBeenCalled();
    });

    // tests onKeyDown
    it('onKeyDown with altKey should put altKeyPressed true', () => {
        const keyboardEvent = new KeyboardEvent('keypress', {
            altKey: true,
        });
        service['altKeyPressed'] = false;

        service.onKeyDown(keyboardEvent);

        expect(service['altKeyPressed']).toEqual(true);
    });

    it('onKeyDown with ctrlKey should put ctrlPressed true', () => {
        const keyboardEvent = { ctrlKey: true } as KeyboardEvent;
        service.ctrlPressed = false;
        service.isSelected = false;

        service.onKeyDown(keyboardEvent);

        expect(service.ctrlPressed).toEqual(true);
    });

    it('onKeyDown with Escape should call cancelSelection', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service.isSelected = true;

        const spy = spyOn(service, 'cancelSelection');
        service.onKeyDown(keyboardEvent);

        expect(spy).toHaveBeenCalled();
    });

    it('onKeyDown with Delete should call clipBoardRectangleService.delete', () => {
        const keyboardEvent = { code: 'Delete' } as KeyboardEvent;
        service.isSelected = true;

        service.onKeyDown(keyboardEvent);

        expect(clipboardMagicWandSpy.delete).toHaveBeenCalled();
    });

    // tests onKeyUp
    it('onKeyUp case ctrlKey should put ctrlPressed', () => {
        const keyboardEvent = { ctrlKey: true } as KeyboardEvent;
        service.ctrlPressed = true;

        service.onKeyUp(keyboardEvent);

        expect(service.ctrlPressed).toEqual(false);
    });

    it('onKeyUp case altKey should put altKeyPressed', () => {
        const keyboardEvent = new KeyboardEvent('keypress', {
            altKey: true,
        });
        service['altKeyPressed'] = true;

        service.onKeyUp(keyboardEvent);

        expect(service['altKeyPressed']).toEqual(false);
    });

    // tests onMouseWheel
    it('onMouseWheel with isSelected and altKeyPressed true should call selectionRotationService.rotate with angle = 1 degree', () => {
        const wheelEvent = {
            deltaY: 30,
        } as WheelEvent;

        service.isSelected = true;
        service['altKeyPressed'] = true;
        service['distance'] = { x: 25, y: 25 };
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };

        service.onMouseWheel(wheelEvent);

        expect(service['angle']).toEqual((Math.PI * 1) / 180);
        expect(rotationRectangleServiceSpy.rotate).toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('onMouseWheel with isSelected true and altKeyPressed false should call selectionRotationService.rotate with angle = 15 degree', () => {
        const wheelEvent = {
            deltaY: 30,
        } as WheelEvent;

        service.isSelected = true;
        service['altKeyPressed'] = false;
        service['distance'] = { x: 25, y: 25 };
        service.topLeftPoint = { x: 25, y: 25 };
        service.size = { width: 25, height: 25 };

        service.onMouseWheel(wheelEvent);

        expect(service['angle']).toEqual((Math.PI * 15) / 180);
        expect(rotationRectangleServiceSpy.rotate).toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('onMouseWheel with isSelected false should do nothing', () => {
        const wheelEvent = {
            deltaY: 30,
        } as WheelEvent;

        service.isSelected = false;
        service.onMouseWheel(wheelEvent);

        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
    });

    // tests initialize
    it('initialize with floodFillSelection', () => {
        const point = { x: 25, y: 25 };

        const floodSpy = spyOn(service, 'floodFillSelection');
        const contiguousSpy = spyOn(service, 'contiguousFloodFillSelection');
        spyOn(service, 'initializeImageData');
        service.imgData = new ImageData(100, 100);
        service['initialize'](mouseEvent, point);

        expect(floodSpy).toHaveBeenCalled();
        expect(contiguousSpy).not.toHaveBeenCalled();
    });

    it('initialize with contiguousFloodFillSelection', () => {
        const point = { x: 25, y: 25 };
        mouseEvent = {
            pageX: 296, // 25 + taille de la sidebar
            pageY: 25,
            button: 2,
        } as MouseEvent;

        const floodSpy = spyOn(service, 'floodFillSelection');
        const contiguousSpy = spyOn(service, 'contiguousFloodFillSelection');
        spyOn(service, 'initializeImageData');
        service.imgData = new ImageData(100, 100);
        service['initialize'](mouseEvent, point);

        expect(floodSpy).not.toHaveBeenCalled();
        expect(contiguousSpy).toHaveBeenCalled();
    });
});
