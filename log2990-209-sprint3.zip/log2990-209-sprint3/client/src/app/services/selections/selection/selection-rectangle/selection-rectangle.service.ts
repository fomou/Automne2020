import { Injectable } from '@angular/core';
import { RectangleSelection } from '@app/classes/rectangle-selection';
import { ShapeTool } from '@app/classes/shape-tool';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { DEGREE_1, DEGREE_15, DEGREE_180, LINE_DASH } from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ClipboardRectangleService } from '@app/services/selections/clipboard/clipboard-rectangle/clipboard-rectangle.service';
import { MagnetismService } from '@app/services/selections/magnetism/magnetism.service';
import { MoveRectangleService } from '@app/services/selections/move/move-rectangle/move-rectangle.service';
import { ResizeRectangleService } from '@app/services/selections/resize/resize-rectangle/resize-rectangle.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';

@Injectable({
    providedIn: 'root',
})
export class SelectionRectangleService extends ShapeTool {
    private distance: Vec2;
    private angle: number = 0;
    private isResizing: boolean = false;
    private altKeyPressed: boolean = false;
    private startPoint: Vec2;

    imageData: ImageData;
    topLeftPoint: Vec2;
    size: Size;
    isSelected: boolean = false;
    isMoving: boolean = false;
    ctrlPressed: boolean = false;

    constructor(
        protected drawingService: DrawingService,
        private undoRedoService: UndoRedoService,
        private moveRectangleService: MoveRectangleService,
        private clipBoardRectangleService: ClipboardRectangleService,
        private resizeRectangleService: ResizeRectangleService,
        private rotationRectangleService: RotationRectangleService,
        private magnetismService: MagnetismService,
    ) {
        super(drawingService);
        this.primaryColor = '000000';
        this.secondaryColor = 'FFFFFF';
        this.drawingType = 'stroke';
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            if (this.clipBoardRectangleService.cutting === true) this.isSelected = false;
            if (!this.isSelected) {
                this.firstPoint = this.getPositionFromMouse(event);
                this.width = 0;
                this.height = 0;
                this.clipBoardRectangleService.cutting = false;
                this.drawingService.previewCtx.restore();
            } else {
                if (this.resizeRectangleService.resizingTest(this.getPositionFromMouse(event).x, this.getPositionFromMouse(event).y, this.size)) {
                    this.isResizing = true;
                } else if (!this.isInsideRectangle(event)) {
                    this.cancelSelection();
                    this.clipBoardRectangleService.disableCopy();
                    this.rotationRectangleService.selectionTopLeft = this.topLeftPoint;
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);

                    this.rotationRectangleService.rotate(this.drawingService.baseCtx, this.angle);
                    const rectangle = new RectangleSelection(
                        this.imageData,
                        this.startPoint,
                        this.topLeftPoint,
                        this.size.width,
                        this.size.height,
                        this.angle,
                    );
                    this.undoRedoService.undoStack.pop();
                    this.undoRedoService.addToStack(rectangle);
                    this.firstPoint = this.getPositionFromMouse(event);
                    this.width = 0;
                    this.height = 0;
                    this.angle = 0;
                    this.drawingService.previewCtx.restore();
                } else {
                    this.isMoving = true;
                    this.distance = {
                        x: this.getPositionFromMouse(event).x - this.topLeftPoint.x,
                        y: this.getPositionFromMouse(event).y - this.topLeftPoint.y,
                    };
                    this.undoRedoService.undoStack.pop();
                }
            }
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown && this.isResizing) {
            const resizePoint: Vec2 = this.resizeRectangleService.resizeSelection(
                event,
                this.imageData,
                this.topLeftPoint,
                this.size,
                this.shiftPressed,
            );
            this.rotationRectangleService.selectionTopLeft = resizePoint;
            this.rotationRectangleService.imageData = this.resizeRectangleService.resizedImageData;
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, this.angle);
            this.resizeRectangleService.drawControlPoints(resizePoint.x, resizePoint.y);
        } else if (this.mouseDown && !this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawSelection(this.drawingService.previewCtx);
        } else if (this.mouseDown && this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawingService.previewCtx.restore();
            let topLeftPoint: Vec2 = {
                x: this.getPositionFromMouse(event).x - this.distance.x,
                y: this.getPositionFromMouse(event).y - this.distance.y,
            };
            if (this.magnetismService.enableMagnetism) topLeftPoint = this.magnetismService.useMagnetism(topLeftPoint, this.size);
            this.rotationRectangleService.selectionTopLeft = { x: topLeftPoint.x, y: topLeftPoint.y };
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, this.angle);
            this.resizeRectangleService.updateSelectionVariables(this.rotationRectangleService.selectionTopLeft);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.isResizing) {
            let resizePoint: Vec2 = { x: 0, y: 0 };
            resizePoint = this.resizeRectangleService.resizeSelection(event, this.imageData, this.topLeftPoint, this.size, this.shiftPressed);
            this.initializeResizeVariables(resizePoint.x, resizePoint.y);
            const rectangle = new RectangleSelection(
                this.imageData,
                this.startPoint,
                this.topLeftPoint,
                this.size.width,
                this.size.height,
                this.angle,
            );
            this.undoRedoService.addToStack(rectangle);
        } else if (this.mouseDown && !this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);

            const topLeftPoint = this.findTopLeftPoint(this.firstPoint, this.lastPoint);
            if (this.width >= 0 && this.height >= 0) {
                this.imageData = this.drawingService.baseCtx.getImageData(topLeftPoint.x, topLeftPoint.y, this.width + 1, this.height + 1);
            }

            this.drawSelection(this.drawingService.previewCtx);

            this.angle = 0;
            this.initializeSelectionVariables(topLeftPoint.x, topLeftPoint.y);
            this.startPoint = topLeftPoint;
            this.rotationRectangleService.selectionTopLeft = topLeftPoint;
            this.rotationRectangleService.imageData = this.imageData;
            this.moveRectangleService.deleteRectangle(this.topLeftPoint, this.size);
            const rectangle = new RectangleSelection(this.imageData, this.startPoint, this.topLeftPoint, this.size.width, this.size.height, 0);

            this.undoRedoService.addToStack(rectangle);
            this.drawingService.previewCtx.putImageData(this.imageData, this.topLeftPoint.x, this.topLeftPoint.y);
        } else if (this.mouseDown && this.isMoving) {
            this.mouseDown = false;
            this.topLeftPoint.x = this.getPositionFromMouse(event).x - this.distance.x;
            this.topLeftPoint.y = this.getPositionFromMouse(event).y - this.distance.y;
            if (this.magnetismService.enableMagnetism) this.topLeftPoint = this.magnetismService.useMagnetism(this.topLeftPoint, this.size);
            this.resizeRectangleService.updateSelectionVariables(this.topLeftPoint);
            this.rotationRectangleService.selectionTopLeft = this.topLeftPoint;
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, this.angle);
            const rectangle = new RectangleSelection(this.imageData, this.startPoint, this.topLeftPoint, this.size.width, this.size.height, 0);
            this.undoRedoService.addToStack(rectangle);
        }
        this.resizeRectangleService.drawResizingRectangle();
    }

    onMouseWheel(event: WheelEvent): void {
        if (this.isSelected) {
            this.drawingService.previewCtx.restore();
            this.angle += this.altKeyPressed
                ? this.normalizeEvent(event) * this.convertAngleToRadian(DEGREE_1)
                : this.normalizeEvent(event) * this.convertAngleToRadian(DEGREE_15);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, this.angle);

            const rectangle = new RectangleSelection(
                this.imageData,
                this.startPoint,
                this.topLeftPoint,
                this.size.width,
                this.size.height,
                this.angle,
            );
            this.undoRedoService.undoStack.pop();
            this.undoRedoService.addToStack(rectangle);
            this.resizeRectangleService.drawResizingRectangle();
        }
    }

    onKeyDown(event: KeyboardEvent): void {
        if (event.altKey) {
            event.preventDefault();
            this.altKeyPressed = true;
        }

        if (event.ctrlKey) this.ctrlPressed = true;
        if (event.key === 'Shift') {
            this.shiftPressed = true;
        }
        if (event.key === 'Escape' && this.isSelected) {
            this.rotationRectangleService.rotate(this.drawingService.baseCtx, this.angle);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.cancelSelection();
            this.clipBoardRectangleService.disableCopy();
            this.resetSelectionVariables();
        }

        if (this.isSelected) {
            this.drawingService.previewCtx.restore();
            this.moveRectangleService.activateSelectionArrows(event);
            this.rotationRectangleService.selectionTopLeft = this.topLeftPoint;
            this.moveRectangleService.moveSelectionArrows(this.imageData, this.topLeftPoint, this.size, this.angle);
            this.clipBoardRectangleService.topLeftPoint = this.topLeftPoint;
            this.clipBoardRectangleService.startPoint = this.startPoint;
            this.clipBoardRectangleService.angle = this.angle;

            this.clipBoardRectangleService.copy(event, this.imageData);

            this.clipBoardRectangleService.cut(event, this.imageData);

            this.clipBoardRectangleService.paste(event, this.topLeftPoint);

            if (event.code === 'Delete') {
                this.clipBoardRectangleService.clipBoard = this.imageData;
                this.clipBoardRectangleService.delete();
                this.isSelected = false;
                this.isMoving = false;
            }
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        this.moveRectangleService.disableSelectionArrows(event);
        if (event.ctrlKey) this.ctrlPressed = false;
        if (event.key === 'Shift') {
            this.shiftPressed = false;
        }

        if (this.altKeyPressed) {
            this.altKeyPressed = false;
        }
    }
    private initializeSelectionVariables(x: number, y: number): void {
        this.topLeftPoint = { x, y };
        this.size = { width: this.width, height: this.height };
        this.resizeRectangleService.topLeftPoint = { x, y };
        this.resizeRectangleService.size = { width: this.width, height: this.height };
        this.isSelected = true;
        this.mouseDown = false;
    }
    private resetSelectionVariables(): void {
        this.topLeftPoint.x = 0;
        this.topLeftPoint.y = 0;
        this.size.width = 0;
        this.size.height = 0;
    }

    private initializeResizeVariables(x: number, y: number): void {
        this.topLeftPoint.x = this.resizeRectangleService.topLeftPoint.x = x;
        this.topLeftPoint.y = this.resizeRectangleService.topLeftPoint.y = y;
        this.size.width = this.resizeRectangleService.size.width;
        this.size.height = this.resizeRectangleService.size.height;
        this.imageData = this.resizeRectangleService.resizedImageData;
        this.isResizing = false;
        this.mouseDown = false;
        this.rotationRectangleService.selectionTopLeft = this.topLeftPoint;
        this.rotationRectangleService.imageData = this.imageData;
        this.rotationRectangleService.rotate(this.drawingService.previewCtx, this.angle);
    }

    private isInsideRectangle(event: MouseEvent): boolean {
        let isInside: boolean = this.getPositionFromMouse(event).x <= this.topLeftPoint.x + this.size.width;
        isInside = isInside && this.getPositionFromMouse(event).x >= this.topLeftPoint.x;
        isInside = isInside && this.getPositionFromMouse(event).y <= this.topLeftPoint.y + this.size.height;
        isInside = isInside && this.getPositionFromMouse(event).y >= this.topLeftPoint.y;
        this.drawingService.previewCtx.restore();
        return isInside;
    }

    cancelSelection(): void {
        this.isSelected = false;
        this.isMoving = false;
    }

    private drawSelection(ctx: CanvasRenderingContext2D): void {
        const startPoint = this.firstPoint;
        let endPoint = this.lastPoint;

        if (this.shiftPressed) {
            endPoint = this.findShiftPoint(this.firstPoint, this.lastPoint);
        }

        this.width = Math.abs(startPoint.x - endPoint.x);
        this.height = Math.abs(startPoint.y - endPoint.y);
        const topLeftPoint = this.findTopLeftPoint(startPoint, endPoint);

        ctx.beginPath();
        ctx.setLineDash([LINE_DASH, LINE_DASH]); // ligne pointillée
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'blue';
        ctx.strokeRect(topLeftPoint.x, topLeftPoint.y, this.width, this.height);
        ctx.setLineDash([]); // remettre la ligne normale
        ctx.closePath();
    }
    private convertAngleToRadian(angle: number): number {
        return (angle * Math.PI) / DEGREE_180;
    }
    private normalizeEvent(event: WheelEvent): number {
        return event.deltaY / Math.abs(event.deltaY);
    }
}
