import { Injectable } from '@angular/core';
import { Color } from '@app/classes/color';
import { MagicWand } from '@app/classes/magic-wand';
import { Size } from '@app/classes/size';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constants/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ClipboardMagicWandService } from '@app/services/selections/clipboard/clipboard-magic-wand/clipboard-magic-wand.service';
import { MagnetismService } from '@app/services/selections/magnetism/magnetism.service';
import { MoveMagicWandService } from '@app/services/selections/move/move-magicWand/move-magic-wand.service';
import { ResizeMagicWandService } from '@app/services/selections/resize/resize-magic-wand/resize-magic-wand.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
@Injectable({
    providedIn: 'root',
})
export class MagicWandService extends Tool {
    private bottomRightPoint: Vec2;
    private distance: Vec2;
    private isResizing: boolean = false;
    private angle: number = 0;
    private altKeyPressed: boolean;
    private baseImageData: ImageData;

    imgData: ImageData;
    topLeftPoint: Vec2;
    size: Size;
    color: Color;
    isMoving: boolean = false;
    isSelected: boolean = false;
    ctrlPressed: boolean = false;

    constructor(
        protected drawingService: DrawingService,
        private moveMagicWandService: MoveMagicWandService,
        private clipboardMagicWand: ClipboardMagicWandService,
        private resizeMagicWandService: ResizeMagicWandService,
        private rotationRectangle: RotationRectangleService,
        private undoRedoService: UndoRedoService,
        private magnetismService: MagnetismService,
    ) {
        super(drawingService);
    }

    getPixelPos(x: number, y: number): number {
        return (y * this.drawingService.baseCtx.canvas.clientWidth + x) * CONSTANT.COLORS_PER_POSITION;
    }

    matchPixel(data: Uint8ClampedArray, position: number, colorAtStart: Color): boolean {
        return (
            data[position] === colorAtStart.r &&
            data[position + CONSTANT.GREEN_COLOR_INDEX] === colorAtStart.g &&
            data[position + CONSTANT.BLUE_COLOR_INDEX] === colorAtStart.b &&
            data[position + CONSTANT.OPACITY_INDEX] === colorAtStart.a
        );
    }

    findResizingPoints(topLeftPoint: Vec2, bottomRightPoint: Vec2, currentPos: number): void {
        const x = (currentPos / CONSTANT.COLORS_PER_POSITION) % this.drawingService.baseCtx.canvas.clientWidth;
        const y = Math.floor(currentPos / CONSTANT.COLORS_PER_POSITION / this.drawingService.baseCtx.canvas.clientWidth);
        if (x < topLeftPoint.x) topLeftPoint.x = x;
        if (y < topLeftPoint.y) topLeftPoint.y = y;
        if (x > bottomRightPoint.x) bottomRightPoint.x = x;
        if (y > bottomRightPoint.y) bottomRightPoint.y = y;
    }

    drawSelectionOnPreview(selectionImg: ImageData, baseImg: ImageData, currentPos: number): void {
        this.color = { r: 0, b: 0, g: 0, a: 0 };
        selectionImg.data[currentPos] = this.color.r = baseImg.data[currentPos];
        selectionImg.data[currentPos + CONSTANT.GREEN_COLOR_INDEX] = this.color.g = baseImg.data[currentPos + CONSTANT.GREEN_COLOR_INDEX];
        selectionImg.data[currentPos + CONSTANT.BLUE_COLOR_INDEX] = this.color.b = baseImg.data[currentPos + CONSTANT.BLUE_COLOR_INDEX];
        selectionImg.data[currentPos + CONSTANT.OPACITY_INDEX] = this.color.a = baseImg.data[currentPos + CONSTANT.OPACITY_INDEX];
        baseImg.data[currentPos] = CONSTANT.MAX_BIT_NUM;
        baseImg.data[currentPos + CONSTANT.GREEN_COLOR_INDEX] = CONSTANT.MAX_BIT_NUM;
        baseImg.data[currentPos + CONSTANT.BLUE_COLOR_INDEX] = CONSTANT.MAX_BIT_NUM;
    }
    initializeImageData(event: MouseEvent): void {
        this.size = { width: this.bottomRightPoint.x - this.topLeftPoint.x, height: this.bottomRightPoint.y - this.topLeftPoint.y };
        this.imgData = this.drawingService.previewCtx.getImageData(this.topLeftPoint.x, this.topLeftPoint.y, this.size.width, this.size.height);
        this.distance = {
            x: this.getPositionFromMouse(event).x - this.topLeftPoint.x,
            y: this.getPositionFromMouse(event).y - this.topLeftPoint.y,
        };
        this.resizeMagicWandService.topLeftPoint = { x: this.topLeftPoint.x, y: this.topLeftPoint.y };
        this.resizeMagicWandService.size = { width: this.size.width, height: this.size.height };
        this.resizeMagicWandService.drawResizingRectangle();
    }
    floodFillSelection(startX: number, startY: number): void {
        const topLeftPoint: Vec2 = { x: this.drawingService.previewCanvas.width, y: this.drawingService.previewCanvas.height };
        const bottomRightPoint: Vec2 = { x: 0, y: 0 };
        const size: Size = { width: this.drawingService.baseCtx.canvas.clientWidth, height: this.drawingService.baseCtx.canvas.clientHeight };
        const baseImg: ImageData = this.drawingService.baseCtx.getImageData(0, 0, size.width, size.height);
        const baseData: Uint8ClampedArray = baseImg.data;
        const selectionImg: ImageData = this.drawingService.previewCtx.getImageData(0, 0, size.width, size.height);
        const startPos: number = this.getPixelPos(startX, startY);
        const colorAtStart = {
            r: baseData[startPos],
            g: baseData[startPos + CONSTANT.GREEN_COLOR_INDEX],
            b: baseData[startPos + CONSTANT.BLUE_COLOR_INDEX],
            a: baseData[startPos + CONSTANT.OPACITY_INDEX],
        };
        const positionToBeEdited: number[][] = [[startX, startY]];
        const editedPositions = new Set();
        while (positionToBeEdited.length) {
            const pos: number[] = positionToBeEdited.pop() as number[];
            const x: number = pos[0];
            let y: number = pos[1];
            let currentPos: number = this.getPixelPos(x, y);
            if (editedPositions.has(currentPos)) continue;
            editedPositions.add(currentPos);
            while (y-- >= 0 && this.matchPixel(baseData, currentPos, colorAtStart)) {
                currentPos -= this.drawingService.baseCtx.canvas.clientWidth * CONSTANT.COLORS_PER_POSITION;
            }
            currentPos += this.drawingService.baseCtx.canvas.clientWidth * CONSTANT.COLORS_PER_POSITION;
            ++y; // descendre d une ligne
            let reachLeft = false;
            let reachRight = false;
            while (y++ < this.drawingService.baseCtx.canvas.clientHeight - 1 && this.matchPixel(baseData, currentPos, colorAtStart)) {
                this.drawSelectionOnPreview(selectionImg, baseImg, currentPos);
                this.findResizingPoints(topLeftPoint, bottomRightPoint, currentPos);
                if (x > 0) {
                    if (this.matchPixel(baseData, currentPos - CONSTANT.COLORS_PER_POSITION, colorAtStart)) {
                        if (!reachLeft) {
                            positionToBeEdited.push([x - 1, y]);
                            reachLeft = true;
                        }
                    } else if (reachLeft) {
                        reachLeft = false;
                    }
                }
                if (x < this.drawingService.baseCtx.canvas.clientWidth - 1) {
                    if (this.matchPixel(baseData, currentPos + CONSTANT.COLORS_PER_POSITION, colorAtStart)) {
                        if (!reachRight) {
                            positionToBeEdited.push([x + 1, y]);
                            reachRight = true;
                        }
                    } else if (reachRight) {
                        reachRight = false;
                    }
                }
                currentPos += this.drawingService.baseCtx.canvas.clientWidth * CONSTANT.COLORS_PER_POSITION;
            }
        }
        this.drawingService.baseCtx.putImageData(baseImg, 0, 0);
        this.baseImageData = baseImg;
        this.drawingService.previewCtx.putImageData(selectionImg, 0, 0);
        this.topLeftPoint = { x: topLeftPoint.x, y: topLeftPoint.y };
        this.bottomRightPoint = { x: bottomRightPoint.x, y: bottomRightPoint.y };
        editedPositions.clear();
    }
    contiguousFloodFillSelection(startX: number, startY: number): void {
        const topLeftPoint: Vec2 = { x: this.drawingService.previewCanvas.width, y: this.drawingService.previewCanvas.height };
        const bottomRightPoint: Vec2 = { x: 0, y: 0 };
        const size: Size = { width: this.drawingService.baseCtx.canvas.clientWidth, height: this.drawingService.baseCtx.canvas.clientHeight };
        const baseImg: ImageData = this.drawingService.baseCtx.getImageData(0, 0, size.width, size.height);
        const baseData: Uint8ClampedArray = baseImg.data;
        const selectionImg: ImageData = this.drawingService.previewCtx.getImageData(0, 0, size.width, size.height);
        const startPos: number = this.getPixelPos(startX, startY);
        const colorAtStart: Color = {
            r: baseData[startPos],
            g: baseData[startPos + CONSTANT.GREEN_COLOR_INDEX],
            b: baseData[startPos + CONSTANT.BLUE_COLOR_INDEX],
            a: baseData[startPos + CONSTANT.OPACITY_INDEX],
        };
        for (let row = 0; row < this.drawingService.baseCtx.canvas.clientWidth - 1; row++) {
            for (let column = 0; column < this.drawingService.baseCtx.canvas.clientHeight - 1; column++) {
                const currentPos: number = this.getPixelPos(row, column);
                if (this.matchPixel(baseData, currentPos, colorAtStart)) {
                    this.drawSelectionOnPreview(selectionImg, baseImg, currentPos);
                    this.findResizingPoints(topLeftPoint, bottomRightPoint, currentPos);
                }
            }
        }
        this.baseImageData = baseImg;
        this.imgData = selectionImg;
        this.drawingService.baseCtx.putImageData(baseImg, 0, 0);
        this.drawingService.previewCtx.putImageData(this.imgData, 0, 0);
        this.topLeftPoint = { x: topLeftPoint.x, y: topLeftPoint.y };
        this.bottomRightPoint = { x: bottomRightPoint.x, y: bottomRightPoint.y };
    }

    isInsideSelection(imgData: ImageData, startX: number, startY: number): boolean {
        let isInside = imgData.data[this.getPixelPos(startX, startY)] === this.color.r;
        isInside = isInside && imgData.data[this.getPixelPos(startX, startY) + CONSTANT.GREEN_COLOR_INDEX] === this.color.g;
        isInside = isInside && imgData.data[this.getPixelPos(startX, startY) + CONSTANT.BLUE_COLOR_INDEX] === this.color.b;
        isInside = isInside && imgData.data[this.getPixelPos(startX, startY) + CONSTANT.OPACITY_INDEX] === this.color.a;
        return isInside;
    }
    drawSelection(baseImgData: ImageData, selectionImg: ImageData): void {
        for (let line = 0; line < this.drawingService.previewCtx.canvas.clientHeight; line++) {
            for (let column = 0; column < this.drawingService.previewCtx.canvas.clientWidth; column++) {
                if (this.isInsideSelection(selectionImg, column, line)) {
                    baseImgData.data[this.getPixelPos(column, line)] = this.color.r;
                    baseImgData.data[this.getPixelPos(column, line) + CONSTANT.GREEN_COLOR_INDEX] = this.color.g;
                    baseImgData.data[this.getPixelPos(column, line) + CONSTANT.BLUE_COLOR_INDEX] = this.color.b;
                    baseImgData.data[this.getPixelPos(column, line) + CONSTANT.OPACITY_INDEX] = this.color.a;
                }
            }
        }
    }

    cancelSelection(): void {
        const size: Size = { width: this.drawingService.baseCtx.canvas.clientWidth, height: this.drawingService.baseCtx.canvas.clientHeight };
        const selectionImg: ImageData = this.drawingService.previewCtx.getImageData(0, 0, size.width, size.height);
        const baseImgData: ImageData = this.drawingService.baseCtx.getImageData(0, 0, size.width, size.height);
        this.drawSelection(baseImgData, selectionImg);
        this.drawingService.baseCtx.putImageData(baseImgData, 0, 0);
        this.baseImageData = baseImgData;
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.clipboardMagicWand.disableCopy();
        this.isMoving = this.isSelected = false;
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        const startPoint = this.getPositionFromMouse(event);
        if (!this.isSelected) {
            this.isSelected = true;
            this.initialize(event, startPoint);
        } else {
            const size: Size = { width: this.drawingService.baseCtx.canvas.clientWidth, height: this.drawingService.baseCtx.canvas.clientHeight };
            const selectionImg: ImageData = this.drawingService.previewCtx.getImageData(0, 0, size.width, size.height);
            if (this.resizeMagicWandService.resizingTest(this.getPositionFromMouse(event).x, this.getPositionFromMouse(event).y, this.size)) {
                this.isResizing = true;
            } else if (this.isInsideSelection(selectionImg, startPoint.x, startPoint.y)) {
                this.isMoving = true;
                this.distance = { x: startPoint.x - this.topLeftPoint.x, y: startPoint.y - this.topLeftPoint.y };
            } else {
                this.cancelSelection();
            }
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown && this.isResizing) {
            const resizePoint: Vec2 = this.resizeMagicWandService.resizeSelection(event, this.imgData, this.topLeftPoint, this.size);
            this.rotationRectangle.selectionTopLeft = resizePoint;
            this.rotationRectangle.imageData = this.resizeMagicWandService.resizedImageData;
            this.rotationRectangle.rotate(this.drawingService.previewCtx, this.angle);
            this.resizeMagicWandService.drawControlPoints(resizePoint.x, resizePoint.y);
        } else if (this.mouseDown && this.isSelected && this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            let topLeftPoint = {
                x: this.getPositionFromMouse(event).x - this.distance.x,
                y: this.getPositionFromMouse(event).y - this.distance.y,
            };
            if (this.magnetismService.enableMagnetism) topLeftPoint = this.magnetismService.useMagnetism(topLeftPoint, this.size);
            this.rotationRectangle.selectionTopLeft = topLeftPoint;
            this.rotationRectangle.imageData = this.imgData;
            this.rotationRectangle.rotate(this.drawingService.previewCtx, this.angle);
        }
    }

    onMouseUp(event: MouseEvent): void {
        if (this.isResizing) {
            let resizePoint: Vec2 = { x: 0, y: 0 };
            resizePoint = this.resizeMagicWandService.resizeSelection(event, this.imgData, this.topLeftPoint, this.size);
            this.topLeftPoint.x = this.resizeMagicWandService.topLeftPoint.x = resizePoint.x;
            this.topLeftPoint.y = this.resizeMagicWandService.topLeftPoint.y = resizePoint.y;
            this.size.width = this.resizeMagicWandService.size.width;
            this.size.height = this.resizeMagicWandService.size.height;
            this.imgData = this.resizeMagicWandService.resizedImageData;
            this.isResizing = false;
            this.mouseDown = false;
            this.rotationRectangle.selectionTopLeft = this.topLeftPoint;
            this.rotationRectangle.imageData = this.resizeMagicWandService.resizedImageData;
            this.rotationRectangle.rotate(this.drawingService.previewCtx, this.angle);
            this.resizeMagicWandService.drawResizingRectangle();
        } else if (this.mouseDown && this.isSelected && this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.topLeftPoint.x = this.getPositionFromMouse(event).x - this.distance.x;
            this.topLeftPoint.y = this.getPositionFromMouse(event).y - this.distance.y;
            if (this.magnetismService.enableMagnetism) this.topLeftPoint = this.magnetismService.useMagnetism(this.topLeftPoint, this.size);
            this.resizeMagicWandService.updateSelectionVariables(this.topLeftPoint);
            this.rotationRectangle.selectionTopLeft = this.topLeftPoint;
            this.rotationRectangle.imageData = this.imgData;
            this.rotationRectangle.rotate(this.drawingService.previewCtx, this.angle);
            this.resizeMagicWandService.drawResizingRectangle();
            this.undoRedoService.addToStack(new MagicWand(this.rotationRectangle.imageData, this.baseImageData, this.topLeftPoint, this.angle));
        }
        this.mouseDown = false;
    }

    onKeyDown(event: KeyboardEvent): void {
        if (event.altKey) {
            this.altKeyPressed = true;
        }
        if (event.ctrlKey) {
            this.ctrlPressed = true;
        }
        if (event.key === 'Escape' && this.isSelected) this.cancelSelection();
        if (this.isSelected) {
            this.clipboardMagicWand.angle = this.moveMagicWandService.angle = this.angle;
            this.moveMagicWandService.activateSelectionArrows(event);
            this.moveMagicWandService.moveSelectionArrows(this.topLeftPoint, this.size);
            this.clipboardMagicWand.copy(event, this.imgData);
            this.clipboardMagicWand.cut(event, this.imgData);
            this.clipboardMagicWand.paste(event, this.topLeftPoint, this.color);
            if (event.code === 'Delete') {
                this.clipboardMagicWand.delete();
                this.isSelected = false;
                this.isMoving = false;
            }
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        this.undoRedoService.addToStack(
            new MagicWand(this.rotationRectangle.imageData, this.baseImageData, this.rotationRectangle.selectionTopLeft, this.angle),
        );
        this.moveMagicWandService.disableSelectionArrows(event);
        if (event.ctrlKey) {
            this.ctrlPressed = false;
        }
        if (this.altKeyPressed) this.altKeyPressed = false;
    }

    onMouseWheel(event: WheelEvent): void {
        if (this.isSelected) {
            this.angle += this.altKeyPressed
                ? this.normalizeEvent(event) * this.convertAngleToRadian(CONSTANT.DEGREE_1)
                : this.normalizeEvent(event) * this.convertAngleToRadian(CONSTANT.DEGREE_15);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.rotationRectangle.selectionTopLeft = this.topLeftPoint;
            this.rotationRectangle.rotate(this.drawingService.previewCtx, this.angle);
            this.undoRedoService.addToStack(new MagicWand(this.imgData, this.baseImageData, this.topLeftPoint, this.angle));
        }
    }
    private convertAngleToRadian(angle: number): number {
        return (angle * Math.PI) / CONSTANT.DEGREE_180;
    }
    private normalizeEvent(event: WheelEvent): number {
        return event.deltaY / Math.abs(event.deltaY);
    }
    private initialize(event: MouseEvent, point: Vec2): void {
        if (event.button === 0) {
            this.floodFillSelection(point.x, point.y);
        } else if (event.button === 2) {
            this.contiguousFloodFillSelection(point.x, point.y);
        }
        this.initializeImageData(event);
        this.rotationRectangle.imageData = this.imgData;
        this.angle = 0;
    }
}
