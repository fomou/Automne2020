import { Injectable } from '@angular/core';
import { CutElement } from '@app/classes/cut-element';
import { RectangleSelection } from '@app/classes/rectangle-selection';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ResizeRectangleService } from '@app/services/selections/resize/resize-rectangle/resize-rectangle.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';

@Injectable({
    providedIn: 'root',
})
export class ClipboardRectangleService {
    private enableCopy: boolean = false;
    private copying: boolean = false;
    private rectangle: RectangleSelection;

    clipBoard: ImageData;
    cutting: boolean = false;
    startPoint: Vec2;
    topLeftPoint: Vec2;
    angle: number;

    constructor(
        private drawingService: DrawingService,
        private resizeRectangleService: ResizeRectangleService,
        private undoRedoService: UndoRedoService,
        private rotationRectangleService: RotationRectangleService,
    ) {}

    disableCopy(): void {
        this.enableCopy = false;
    }

    copy(event: KeyboardEvent, imageData: ImageData): void {
        if (event.ctrlKey && event.code === 'KeyC') {
            this.enableCopy = true;
            this.clipBoard = imageData;
            this.copying = true;
            this.rectangle = new RectangleSelection(
                this.clipBoard,
                { x: 0, y: 0 },
                { x: 0, y: 0 },
                this.clipBoard.width,
                this.clipBoard.height,
                this.angle,
            );
        }
    }

    cut(event: KeyboardEvent, imageData: ImageData): void {
        if (event.code === 'KeyX' && event.ctrlKey) {
            this.clipBoard = imageData;
            this.enableCopy = true;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.cutting = true;
            this.copying = false;

            this.rectangle = new RectangleSelection(
                this.clipBoard,
                this.startPoint,
                { x: 0, y: 0 },
                this.clipBoard.width,
                this.clipBoard.height,
                this.angle,
            );
        }
    }

    paste(event: KeyboardEvent, topLeftPoint: Vec2): void {
        if (event.code === 'KeyV' && event.ctrlKey && this.enableCopy === true) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            if (this.copying) this.rotationRectangleService.rotate(this.drawingService.baseCtx, this.angle);
            this.rotationRectangleService.selectionTopLeft = { x: 0, y: 0 };
            this.rotationRectangleService.rotate(this.drawingService.previewCtx, this.angle);
            topLeftPoint.x = 0;
            topLeftPoint.y = 0;
            this.resizeRectangleService.updateSelectionVariables(topLeftPoint);
            this.resizeRectangleService.drawResizingRectangle();
            this.cutting = false;
            this.copying = false;
            this.undoRedoService.undoStack.pop();
            this.undoRedoService.addToStack(this.rectangle);
        }
    }

    delete(): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.enableCopy = false;
        this.copying = false;
        const rectangle = new CutElement(this.topLeftPoint, this.clipBoard.width, this.clipBoard.height, true);
        this.undoRedoService.addToStack(rectangle);
    }
}
