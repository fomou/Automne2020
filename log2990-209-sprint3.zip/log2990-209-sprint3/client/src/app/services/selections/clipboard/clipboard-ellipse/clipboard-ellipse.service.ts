import { Injectable } from '@angular/core';
import { CutElement } from '@app/classes/cut-element';
import { EllipseSelection } from '@app/classes/ellipse-selection';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { MoveEllipseService } from '@app/services/selections/move/move-ellipse/move-ellipse.service';
import { ResizeEllipseService } from '@app/services/selections/resize/resize-ellipse/resize-ellipse.service';
import { RotationEllipseService } from '@app/services/selections/rotation/rotation-ellipse/rotation-ellipse.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';

@Injectable({
    providedIn: 'root',
})
export class ClipboardEllipseService {
    private enableCopy: boolean = false;
    private copying: boolean = false;
    private clipBoard: ImageData;
    private ellipse: EllipseSelection;

    center: Vec2;
    cutting: boolean = false;
    angle: number;
    deletedCenter: Vec2;

    constructor(
        private drawingService: DrawingService,
        private moveEllipseService: MoveEllipseService,
        private resizeEllipseService: ResizeEllipseService,
        private rotationEllipse: RotationEllipseService,
        private undoRedoService: UndoRedoService,
    ) {}

    disableCopy(): void {
        this.enableCopy = false;
    }

    copy(event: KeyboardEvent, imageData: ImageData): void {
        if (event.ctrlKey && event.code === 'KeyC') {
            this.enableCopy = true;
            this.clipBoard = imageData;
            this.copying = true;
            this.ellipse = new EllipseSelection(
                this.clipBoard,
                { x: this.clipBoard.width / 2, y: this.clipBoard.height / 2 },
                { x: this.clipBoard.width / 2, y: this.clipBoard.height / 2 },
                this.angle,
            );
        }
    }

    cut(event: KeyboardEvent, imageData: ImageData): void {
        if (event.code === 'KeyX' && event.ctrlKey) {
            this.clipBoard = imageData;
            this.enableCopy = true;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.cutting = true;
            this.copying = false;
            this.ellipse = new EllipseSelection(
                this.clipBoard,
                { x: this.clipBoard.width / 2, y: this.clipBoard.height / 2 },
                this.deletedCenter,
                this.angle,
            );
            const ellipse = new CutElement(this.center, this.clipBoard.width, this.clipBoard.height, false);
            this.undoRedoService.addToStack(ellipse);
        }
    }

    paste(event: KeyboardEvent, topLeftPoint: Vec2, circleCenter: Vec2, deletedCircleCenter: Vec2, size: Size): void {
        if (event.code === 'KeyV' && event.ctrlKey && this.enableCopy === true) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            if (this.copying) {
                this.rotationEllipse.imageData = this.moveEllipseService.getEllipseImageData(
                    this.clipBoard,
                    topLeftPoint.x,
                    topLeftPoint.y,
                    size.width,
                    size.height,
                );
                this.rotationEllipse.rotate(this.drawingService.baseCtx, this.angle);
            }

            this.rotationEllipse.imageData = this.clipBoard;
            this.rotationEllipse.center = { x: this.clipBoard.width / 2, y: this.clipBoard.height / 2 };
            this.rotationEllipse.rotate(this.drawingService.previewCtx, this.angle);
            topLeftPoint.x = 0;
            topLeftPoint.y = 0;
            circleCenter.x = deletedCircleCenter.x = 0 + size.width / 2;
            circleCenter.y = deletedCircleCenter.y = 0 + size.height / 2;
            this.resizeEllipseService.updateSelectionVariables(topLeftPoint);
            this.resizeEllipseService.drawResizingRectangle();
            this.cutting = false;
            this.copying = true;
            this.undoRedoService.undoStack.pop();
            this.undoRedoService.addToStack(this.ellipse);
        }
    }

    delete(): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.enableCopy = false;
        this.copying = false;
        const ellipse = new CutElement(this.center, this.clipBoard.width, this.clipBoard.height, false);
        this.undoRedoService.addToStack(ellipse);
    }
}
