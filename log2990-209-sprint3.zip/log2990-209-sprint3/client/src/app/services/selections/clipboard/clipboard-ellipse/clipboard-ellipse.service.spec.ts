import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { MoveEllipseService } from '@app/services/selections/move/move-ellipse/move-ellipse.service';
import { ResizeEllipseService } from '@app/services/selections/resize/resize-ellipse/resize-ellipse.service';
import { ClipboardEllipseService } from './clipboard-ellipse.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('ClipboardEllipseService', () => {
    let service: ClipboardEllipseService;
    let topLeftPoint: Vec2;
    let imageData: ImageData;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let resizeEllipseServiceSpy: jasmine.SpyObj<ResizeEllipseService>;
    let moveEllipseServiceSpy: jasmine.SpyObj<MoveEllipseService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        resizeEllipseServiceSpy = jasmine.createSpyObj<any>('ResizeEllipseService', ['drawResizingRectangle', 'updateSelectionVariables']);
        moveEllipseServiceSpy = jasmine.createSpyObj<any>('MoveEllipseService', ['getEllipseImageData']);

        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: ResizeEllipseService, useValue: resizeEllipseServiceSpy },
                { provide: MoveEllipseService, useValue: moveEllipseServiceSpy },
            ],
        });
        service = TestBed.inject(ClipboardEllipseService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;
        service['clipBoard'] = new ImageData(100, 100);

        topLeftPoint = { x: 25, y: 25 };
        imageData = new ImageData(100, 100);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // test disableCopy
    it('disableCopy should set enableCopy to false', () => {
        service['enableCopy'] = true;

        service.disableCopy();

        expect(service['enableCopy']).toEqual(false);
    });

    // tests copy

    it('copy with ctrl C should set enableCopy and copying to true', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyC' } as KeyboardEvent;
        const expectImageCopy = new ImageData(100, 100);
        service['enableCopy'] = false;
        service['copying'] = false;

        service.copy(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(true);
        expect(service['copying']).toEqual(true);
        expect(service['clipBoard']).toEqual(expectImageCopy);
    });

    it('copy without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyC' } as KeyboardEvent;
        service['enableCopy'] = false;
        service['copying'] = false;

        service.copy(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(false);
    });

    // test cut
    it('cut with ctrl X should set enableCopy and stopSelection to true and call clearCanvas', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyX' } as KeyboardEvent;
        const expectImageCopy = new ImageData(100, 100);
        service['enableCopy'] = false;
        service['copying'] = true;
        service.cutting = false;

        service.cut(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(true);
        expect(service['copying']).toEqual(false);
        expect(service.cutting).toEqual(true);
        expect(service['clipBoard']).toEqual(expectImageCopy);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('cut without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyX' } as KeyboardEvent;
        service['enableCopy'] = false;
        service['copying'] = true;
        service.cutting = false;

        service.cut(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(true);
        expect(service.cutting).toEqual(false);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
    });

    // tests paste

    it('paste with ctrl V and copying false should call drawResizingRectangle', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = false;
        const center = { x: 25, y: 25 };
        const deletedCenter = { x: 25, y: 25 };
        const size = { width: 25, height: 25 };

        const spy = spyOn<any>(service['drawingService'].baseCtx, 'putImageData');
        spyOn<any>(service['drawingService'].previewCtx, 'putImageData');

        service.paste(keyboardEvent, topLeftPoint, center, deletedCenter, size);

        expect(spy).not.toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(resizeEllipseServiceSpy.updateSelectionVariables).toHaveBeenCalled();
        expect(resizeEllipseServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('paste with ctrl V and copying true should call putImageData on basCtx', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = true;
        const center = { x: 25, y: 25 };
        const deletedCenter = { x: 25, y: 25 };
        const size = { width: 25, height: 25 };
        service['rotationEllipse'].imageData = new ImageData(100, 100);
        service['clipBoard'] = imageData = new ImageData(100, 100);
        const spy = spyOn<any>(service['rotationEllipse'], 'rotate');

        service.paste(keyboardEvent, topLeftPoint, center, deletedCenter, size);

        expect(spy).toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(resizeEllipseServiceSpy.updateSelectionVariables).toHaveBeenCalled();
        expect(resizeEllipseServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('paste without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = false;
        const center = { x: 25, y: 25 };
        const deletedCenter = { x: 25, y: 25 };
        const size = { width: 25, height: 25 };

        service.paste(keyboardEvent, topLeftPoint, center, deletedCenter, size);

        expect(resizeEllipseServiceSpy.drawResizingRectangle).not.toHaveBeenCalled();
    });

    // test delete
    it('delete should set enableCopy and copying to false and call clearCanvas', () => {
        service['enableCopy'] = true;
        service['copying'] = true;

        service.delete();
        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(false);
    });
});
