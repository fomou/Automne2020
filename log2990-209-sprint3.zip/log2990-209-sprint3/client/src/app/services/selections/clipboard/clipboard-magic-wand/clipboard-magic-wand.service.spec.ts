import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Color } from '@app/classes/color';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ResizeMagicWandService } from '@app/services/selections/resize/resize-magic-wand/resize-magic-wand.service';
import { ClipboardMagicWandService } from './clipboard-magic-wand.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('ClipboardMagicWandService', () => {
    let service: ClipboardMagicWandService;
    let topLeftPoint: Vec2;
    let imageData: ImageData;
    let color: Color;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let resizeMagicWandServiceSpy: jasmine.SpyObj<ResizeMagicWandService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        resizeMagicWandServiceSpy = jasmine.createSpyObj<any>('ResizeMagicWandService', ['drawResizingRectangle', 'updateSelectionVariables']);

        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: ResizeMagicWandService, useValue: resizeMagicWandServiceSpy },
            ],
        });
        service = TestBed.inject(ClipboardMagicWandService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        topLeftPoint = { x: 25, y: 25 };
        imageData = new ImageData(100, 100);
        color = { r: 1, g: 1, b: 1, a: 1 };
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // test getPixelPos
    it('getPixelPos case false ', () => {
        spyOnProperty<any>(service['drawingService'].baseCtx.canvas, 'clientWidth').and.returnValue(3);
        const expectBool = service.getPixelPos(topLeftPoint.x, topLeftPoint.y);
        expect(expectBool).toEqual(400);
    });

    // tests isInsideSelection

    it('isInsideSelection case false ', () => {
        spyOn<any>(service, 'getPixelPos');
        const expectBool = service.isInsideSelection(imageData, topLeftPoint.x, topLeftPoint.y, color);
        expect(expectBool).toEqual(false);
    });

    // tests drawSelection

    it('drawSelection should call isInsideSelection and getPixelPos 4 times', () => {
        spyOnProperty<any>(service['drawingService'].previewCtx.canvas, 'clientWidth').and.returnValue(3);
        spyOnProperty<any>(service['drawingService'].previewCtx.canvas, 'clientHeight').and.returnValue(3);
        const getPixelSpy = spyOn<any>(service, 'getPixelPos');
        const isInsideSpy = spyOn<any>(service, 'isInsideSelection').and.returnValue(true);
        service.drawSelection(imageData, imageData, color);
        expect(getPixelSpy).toHaveBeenCalledTimes(36);
        expect(isInsideSpy).toHaveBeenCalled();
    });

    it('drawSelection with isInsideSelection false should not call getPixelPos', () => {
        spyOnProperty<any>(service['drawingService'].previewCtx.canvas, 'clientWidth').and.returnValue(3);
        spyOnProperty<any>(service['drawingService'].previewCtx.canvas, 'clientHeight').and.returnValue(3);
        const getPixelSpy = spyOn<any>(service, 'getPixelPos');
        const isInsideSpy = spyOn<any>(service, 'isInsideSelection').and.returnValue(false);
        service.drawSelection(imageData, imageData, color);
        expect(getPixelSpy).toHaveBeenCalledTimes(0);
        expect(isInsideSpy).toHaveBeenCalled();
    });

    // test disableCopy
    it('disableCopy should set enableCopy to false', () => {
        service['enableCopy'] = true;

        service.disableCopy();

        expect(service['enableCopy']).toEqual(false);
    });

    // tests copy

    it('copy with ctrl C should set enableCopy and copying to true', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyC' } as KeyboardEvent;
        const expectImageCopy = new ImageData(100, 100);
        service['enableCopy'] = false;
        service['copying'] = false;

        service.copy(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(true);
        expect(service['copying']).toEqual(true);
        expect(service['clipBoard']).toEqual(expectImageCopy);
    });

    it('copy without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyC' } as KeyboardEvent;
        service['enableCopy'] = false;
        service['copying'] = false;

        service.copy(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(false);
    });

    // test cut
    it('cut with ctrl X should set enableCopy and stopSelection to true and call clearCanvas', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyX' } as KeyboardEvent;
        const expectImageCopy = new ImageData(100, 100);
        service['enableCopy'] = false;
        service['copying'] = true;
        service.stopSelection = false;

        service.cut(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(true);
        expect(service['copying']).toEqual(false);
        expect(service.stopSelection).toEqual(true);
        expect(service['clipBoard']).toEqual(expectImageCopy);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('cut without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyX' } as KeyboardEvent;
        service['enableCopy'] = false;
        service['copying'] = true;
        service.stopSelection = false;

        service.cut(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(true);
        expect(service.stopSelection).toEqual(false);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
    });

    // tests paste

    it('paste with ctrl V and copying false should call drawResizingRectangle', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = false;
        service['drawingService'].baseCtx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        spyOn<any>(service['drawingService'].previewCtx, 'getImageData');
        spyOn<any>(service['drawingService'].baseCtx, 'getImageData');
        spyOn<any>(service, 'drawSelection');
        spyOn<any>(service['rotationMagicWand'], 'rotate');

        service.paste(keyboardEvent, topLeftPoint, color);

        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(resizeMagicWandServiceSpy.updateSelectionVariables).toHaveBeenCalled();
        expect(resizeMagicWandServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('paste with ctrl V and copying true should call putImageData on basCtx', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = true;
        service['drawingService'].baseCtx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        spyOn<any>(service['drawingService'].previewCtx, 'getImageData');
        spyOn<any>(service['drawingService'].baseCtx, 'getImageData');
        const spy = spyOn<any>(service['drawingService'].baseCtx, 'putImageData');
        spyOn<any>(service, 'drawSelection');
        spyOn<any>(service['rotationMagicWand'], 'rotate');

        service.paste(keyboardEvent, topLeftPoint, color);

        expect(spy).toHaveBeenCalled();
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(resizeMagicWandServiceSpy.updateSelectionVariables).toHaveBeenCalled();
        expect(resizeMagicWandServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('paste without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = false;

        service.paste(keyboardEvent, topLeftPoint, color);

        expect(resizeMagicWandServiceSpy.drawResizingRectangle).not.toHaveBeenCalled();
    });

    // test delete
    it('delete should set enableCopy and copying to false and call clearCanvas', () => {
        service['enableCopy'] = true;
        service['copying'] = true;

        service.delete();

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(false);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });
});
