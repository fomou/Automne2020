import { Injectable } from '@angular/core';
import { Color } from '@app/classes/color';
import { MagicWand } from '@app/classes/magic-wand';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ResizeMagicWandService } from '@app/services/selections/resize/resize-magic-wand/resize-magic-wand.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';

@Injectable({
    providedIn: 'root',
})
export class ClipboardMagicWandService {
    private enableCopy: boolean = false;
    private copying: boolean = false;

    clipBoard: ImageData;
    angle: number;
    stopSelection: boolean = false;
    magicWand: MagicWand;

    constructor(
        private drawingService: DrawingService,
        private resizeMagicWandService: ResizeMagicWandService,
        private rotationMagicWand: RotationRectangleService,
    ) {}

    getPixelPos(x: number, y: number): number {
        return (y * this.drawingService.baseCtx.canvas.clientWidth + x) * CONSTANT.COLORS_PER_POSITION;
    }

    isInsideSelection(imgData: ImageData, startX: number, startY: number, color: Color): boolean {
        let isInside = imgData.data[this.getPixelPos(startX, startY)] === color.r;
        isInside = isInside && imgData.data[this.getPixelPos(startX, startY) + CONSTANT.GREEN_COLOR_INDEX] === color.g;
        isInside = isInside && imgData.data[this.getPixelPos(startX, startY) + CONSTANT.BLUE_COLOR_INDEX] === color.b;
        isInside = isInside && imgData.data[this.getPixelPos(startX, startY) + CONSTANT.OPACITY_INDEX] === color.a;
        return isInside;
    }

    drawSelection(baseImgData: ImageData, selectionImg: ImageData, color: Color): void {
        for (let line = 0; line < this.drawingService.previewCtx.canvas.clientHeight; line++) {
            for (let column = 0; column < this.drawingService.previewCtx.canvas.clientWidth; column++) {
                if (this.isInsideSelection(selectionImg, column, line, color)) {
                    baseImgData.data[this.getPixelPos(column, line)] = color.r;
                    baseImgData.data[this.getPixelPos(column, line) + CONSTANT.GREEN_COLOR_INDEX] = color.g;
                    baseImgData.data[this.getPixelPos(column, line) + CONSTANT.BLUE_COLOR_INDEX] = color.b;
                    baseImgData.data[this.getPixelPos(column, line) + CONSTANT.OPACITY_INDEX] = color.a;
                }
            }
        }
    }

    disableCopy(): void {
        this.enableCopy = false;
    }

    copy(event: KeyboardEvent, imageData: ImageData): void {
        if (event.ctrlKey && event.code === 'KeyC') {
            this.enableCopy = true;
            this.clipBoard = imageData;
            this.copying = true;
            this.magicWand = new MagicWand(this.clipBoard, this.clipBoard, { x: 0, y: 0 }, this.angle);
        }
    }

    cut(event: KeyboardEvent, imageData: ImageData): void {
        if (event.code === 'KeyX' && event.ctrlKey) {
            this.clipBoard = imageData;
            this.enableCopy = true;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.stopSelection = true;
            this.copying = false;
        }
    }

    paste(event: KeyboardEvent, topLeftPoint: Vec2, color: Color): void {
        if (event.code === 'KeyV' && event.ctrlKey && this.enableCopy === true) {
            const canvasWidth = this.drawingService.baseCtx.canvas.clientWidth;
            const canvasHeight = this.drawingService.baseCtx.canvas.clientHeight;
            const selectionImg: ImageData = this.drawingService.previewCtx.getImageData(0, 0, canvasWidth, canvasHeight);
            const baseImgData: ImageData = this.drawingService.baseCtx.getImageData(0, 0, canvasWidth, canvasHeight);
            this.drawSelection(baseImgData, selectionImg, color);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            if (this.copying) this.drawingService.baseCtx.putImageData(baseImgData, 0, 0);
            this.rotationMagicWand.selectionTopLeft = { x: 0, y: 0 };
            this.rotationMagicWand.rotate(this.drawingService.previewCtx, this.angle);
            topLeftPoint.x = 0;
            topLeftPoint.y = 0;
            this.resizeMagicWandService.updateSelectionVariables(topLeftPoint);
            this.resizeMagicWandService.drawResizingRectangle();
            this.stopSelection = false;
            this.copying = true;
        }
    }

    delete(): void {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.enableCopy = false;
        this.copying = false;
    }
}
