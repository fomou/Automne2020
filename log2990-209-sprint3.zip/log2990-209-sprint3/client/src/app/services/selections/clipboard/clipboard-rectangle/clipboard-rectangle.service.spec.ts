import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ResizeRectangleService } from '@app/services/selections/resize/resize-rectangle/resize-rectangle.service';
import { ClipboardRectangleService } from './clipboard-rectangle.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('ClipboardRectangleService', () => {
    let service: ClipboardRectangleService;
    let topLeftPoint: Vec2;
    let imageData: ImageData;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let resizeRectangleServiceSpy: jasmine.SpyObj<ResizeRectangleService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        resizeRectangleServiceSpy = jasmine.createSpyObj<any>('ResizeRectangleService', ['drawResizingRectangle', 'updateSelectionVariables']);

        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: ResizeRectangleService, useValue: resizeRectangleServiceSpy },
            ],
        });
        service = TestBed.inject(ClipboardRectangleService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        topLeftPoint = { x: 25, y: 25 };
        imageData = new ImageData(100, 100);
        service.clipBoard = imageData;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // test disableCopy
    it('disableCopy should set enableCopy to false', () => {
        service['enableCopy'] = true;

        service.disableCopy();

        expect(service['enableCopy']).toEqual(false);
    });

    // tests copy

    it('copy with ctrl C should set enableCopy and copying to true', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyC' } as KeyboardEvent;
        const expectImageCopy = new ImageData(100, 100);
        service['enableCopy'] = false;
        service['copying'] = false;

        service.copy(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(true);
        expect(service['copying']).toEqual(true);
        expect(service['clipBoard']).toEqual(expectImageCopy);
    });

    it('copy without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyC' } as KeyboardEvent;
        service['enableCopy'] = false;
        service['copying'] = false;

        service.copy(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(false);
    });

    // test cut
    it('cut with ctrl X should set enableCopy and stopSelection to true and call clearCanvas', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyX' } as KeyboardEvent;
        const expectImageCopy = new ImageData(100, 100);
        service['enableCopy'] = false;
        service['copying'] = true;
        service.cutting = false;

        service.cut(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(true);
        expect(service['copying']).toEqual(false);
        expect(service.cutting).toEqual(true);
        expect(service['clipBoard']).toEqual(expectImageCopy);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });

    it('cut without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyX' } as KeyboardEvent;
        service['enableCopy'] = false;
        service['copying'] = true;
        service.cutting = false;

        service.cut(keyboardEvent, imageData);

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(true);
        expect(service.cutting).toEqual(false);
        expect(drawServiceSpy.clearCanvas).not.toHaveBeenCalled();
    });

    // tests paste

    it('paste with ctrl V and copying false should call drawResizingRectangle', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = false;

        const spy = spyOn<any>(service['rotationRectangleService'], 'rotate');

        service.paste(keyboardEvent, topLeftPoint);

        expect(spy).toHaveBeenCalledTimes(1);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(resizeRectangleServiceSpy.updateSelectionVariables).toHaveBeenCalled();
        expect(resizeRectangleServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('paste with ctrl V and copying true should call putImageData on basCtx', () => {
        const keyboardEvent = { ctrlKey: true, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = true;

        const spy = spyOn<any>(service['rotationRectangleService'], 'rotate');

        service.paste(keyboardEvent, topLeftPoint);

        expect(spy).toHaveBeenCalledTimes(2);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
        expect(resizeRectangleServiceSpy.updateSelectionVariables).toHaveBeenCalled();
        expect(resizeRectangleServiceSpy.drawResizingRectangle).toHaveBeenCalled();
    });

    it('paste without ctrl should do nothing', () => {
        const keyboardEvent = { ctrlKey: false, code: 'KeyV' } as KeyboardEvent;
        service['enableCopy'] = true;
        service['copying'] = false;

        service.paste(keyboardEvent, topLeftPoint);

        expect(resizeRectangleServiceSpy.drawResizingRectangle).not.toHaveBeenCalled();
    });

    // test delete
    it('delete should set enableCopy and copying to false and call clearCanvas', () => {
        service['enableCopy'] = true;
        service['copying'] = true;
        service.clipBoard = new ImageData(100, 100);

        service.delete();

        expect(service['enableCopy']).toEqual(false);
        expect(service['copying']).toEqual(false);
        expect(drawServiceSpy.clearCanvas).toHaveBeenCalled();
    });
});
