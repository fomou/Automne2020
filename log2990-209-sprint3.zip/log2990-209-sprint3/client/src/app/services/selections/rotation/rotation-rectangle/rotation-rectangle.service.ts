import { Injectable } from '@angular/core';
import { Vec2 } from '@app/classes/vec2';

@Injectable({
    providedIn: 'root',
})
export class RotationRectangleService {
    imageData: ImageData;
    selectionTopLeft: Vec2;

    rotate(ctx: CanvasRenderingContext2D, angle: number): void {
        const canvas: HTMLCanvasElement = document.createElement('canvas');
        canvas.width = this.imageData.width;
        canvas.height = this.imageData.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.putImageData(this.imageData, 0, 0);
        ctx.save();
        ctx.translate(this.selectionTopLeft.x + canvas.width / 2, this.selectionTopLeft.y + canvas.height / 2);
        ctx.rotate(angle);
        ctx.translate(-canvas.width / 2, -canvas.height / 2);
        ctx.drawImage(canvas, 0, 0);
        ctx.restore();
    }
}
