import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { RotationEllipseService } from './rotation-ellipse.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('RotationEllipseService', () => {
    let service: RotationEllipseService;
    let baseCtxStub: CanvasRenderingContext2D;
    let angle: number;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        angle = 90;
        TestBed.configureTestingModule({});
        service = TestBed.inject(RotationEllipseService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // test rotate
    it('rotate should call rotate save, translate, rotate, draw image and restore from ctx', () => {
        service.imageData = new ImageData(100, 100);
        service.topLeftPoint = { x: 25, y: 25 };
        service.center = { x: 50, y: 50 };
        const saveSpy = spyOn(baseCtxStub, 'save');
        const translateSpy = spyOn(baseCtxStub, 'translate');
        const rotateSpy = spyOn(baseCtxStub, 'rotate');
        const drawImageSpy = spyOn(baseCtxStub, 'drawImage');
        const restoreSpy = spyOn(baseCtxStub, 'restore');

        service.rotate(baseCtxStub, angle);
        expect(saveSpy).toHaveBeenCalled();
        expect(translateSpy).toHaveBeenCalledTimes(2);
        expect(rotateSpy).toHaveBeenCalled();
        expect(drawImageSpy).toHaveBeenCalled();
        expect(restoreSpy).toHaveBeenCalled();
    });
});
