import { Injectable } from '@angular/core';
import { Vec2 } from '@app/classes/vec2';

@Injectable({
    providedIn: 'root',
})
export class RotationEllipseService {
    imageData: ImageData;
    topLeftPoint: Vec2;
    center: Vec2;
    rotate(ctx: CanvasRenderingContext2D, angle: number): void {
        const canvas: HTMLCanvasElement = document.createElement('canvas');
        canvas.width = this.imageData.width;
        canvas.height = this.imageData.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.putImageData(this.imageData, 0, 0);
        ctx.save();
        ctx.translate(this.center.x, this.center.y);
        ctx.rotate(angle);
        ctx.beginPath();
        ctx.strokeStyle = '#00000000'; // contour transparent
        ctx.ellipse(0, 0, canvas.width / 2, canvas.height / 2, 0, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.clip();
        ctx.closePath();
        ctx.translate(-canvas.width / 2, -canvas.height / 2);
        ctx.drawImage(canvas, 0, 0);
        ctx.restore();
    }
}
