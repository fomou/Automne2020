import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { ResizeRectangleService } from './resize-rectangle.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: max-file-line-count
describe('ResizeRectangleService', () => {
    let service: ResizeRectangleService;
    let topLeftPoint: Vec2;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawResizingPreviewSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        TestBed.configureTestingModule({});
        service = TestBed.inject(ResizeRectangleService);
        drawResizingPreviewSpy = spyOn<any>(service, 'drawResizingBox').and.callThrough();

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        topLeftPoint = { x: 25, y: 25 };
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // TESTS DE LA CLASSE ABSTRAITE

    // test drawResizingBox
    it('drawResizingBox should call stroke from previewCtx', () => {
        const spy = spyOn<any>(service['drawingService'].previewCtx, 'stroke');
        service['drawResizingBox'](topLeftPoint.x, topLeftPoint.y);
        expect(spy).toHaveBeenCalled();
    });

    // test drawControlPoints
    it('drawControlPoints should call drawResizingBox 8 times', () => {
        service.size = { width: 25, height: 25 };
        service['drawControlPoints'](topLeftPoint.x, topLeftPoint.y);
        expect(drawResizingPreviewSpy).toHaveBeenCalledTimes(8);
    });

    // test drawResizingRectangle
    it('drawResizingRectangle should call strokeRect from previewCtx and drawControlPoints ', () => {
        service.size = { width: 25, height: 25 };
        service.topLeftPoint = topLeftPoint;
        const strokeSpy = spyOn<any>(service['drawingService'].previewCtx, 'strokeRect');
        const drawControlPointsSpy = spyOn<any>(service, 'drawControlPoints');
        service.drawResizingRectangle();
        expect(strokeSpy).toHaveBeenCalled();
        expect(drawControlPointsSpy).toHaveBeenCalled();
    });

    // test updateSelectionVariables
    it('updateSelectionVariables should set topLeftPoint', () => {
        service.topLeftPoint = { x: 35, y: 35 };
        const expectResult = { x: 25, y: 25 };
        service.updateSelectionVariables(topLeftPoint);
        expect(service.topLeftPoint).toEqual(expectResult);
    });

    // test resizingTest
    it('resizingTest case TopLeft (1)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 35, height: 35 };
        const point = { x: 25, y: 25 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(1);
    });

    it('resizingTest case TopRight (2)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 35, height: 35 };
        const point = { x: 45, y: 25 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(2);
    });

    it('resizingTest case BottomRight (3)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 35, height: 35 };
        const point = { x: 45, y: 45 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(3);
    });

    it('resizingTest case BottomLeft (4)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 35, height: 35 };
        const point = { x: 25, y: 45 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(4);
    });

    it('resizingTest case TopMiddle (5)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 20, height: 20 };
        const point = { x: 35, y: 25 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(5);
    });

    it('resizingTest case BottomMiddle (6)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 20, height: 20 };
        const point = { x: 35, y: 45 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(6);
    });

    it('resizingTest case LeftMiddle (7)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 20, height: 20 };
        const point = { x: 25, y: 35 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(7);
    });

    it('resizingTest case RightMiddle (8)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 20, height: 20 };
        const point = { x: 45, y: 35 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(8);
    });

    it('resizingTest case nothing (0)', () => {
        service.topLeftPoint = topLeftPoint;
        service.size = { width: 20, height: 20 };
        service['boxLength'] = 14;
        const size = { width: 20, height: 20 };
        const point = { x: 80, y: 80 };

        const result = service.resizingTest(point.x, point.y, size);
        expect(result).toEqual(0);
    });

    // findShiftPoint

    it('findShiftPoint case width < height', () => {
        const firstPoint: Vec2 = { x: 25, y: 25 };
        const lastPoint: Vec2 = { x: 20, y: 0 };
        const size = { width: 20, height: 20 };

        service['findShiftPoint'](firstPoint, lastPoint, size);

        expect(size.height).toEqual(20);
    });

    it('findShiftPoint case width < height 2', () => {
        const firstPoint: Vec2 = { x: 25, y: 25 };
        const lastPoint: Vec2 = { x: 20, y: 50 };
        const size = { width: 20, height: 20 };

        service['findShiftPoint'](firstPoint, lastPoint, size);

        expect(size.height).toEqual(20);
    });

    it('findShiftPoint case width < height', () => {
        const firstPoint: Vec2 = { x: 50, y: 0 };
        const lastPoint: Vec2 = { x: 25, y: 20 };
        const size = { width: 20, height: 20 };

        service['findShiftPoint'](firstPoint, lastPoint, size);

        expect(size.height).toEqual(20);
    });

    it('findShiftPoint case width < height', () => {
        const firstPoint: Vec2 = { x: 0, y: 0 };
        const lastPoint: Vec2 = { x: 25, y: 20 };
        const size = { width: 20, height: 20 };

        service['findShiftPoint'](firstPoint, lastPoint, size);

        expect(size.height).toEqual(20);
    });

    // createCopyCanvas
    it('createCopyCanvas should call clearCanvas', () => {
        const imageData = new ImageData(100, 100);

        const spy = spyOn<any>(service['drawingService'], 'clearCanvas');
        service.createCopyCanvas(imageData);

        expect(spy).toHaveBeenCalled();
    });
    // TESTS DU SERVICE

    // tests updateSize

    it('updateSize case TopLeft', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 1;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case TopLeft with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 1;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case TopRight', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 2;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 0, height: 20 });
    });

    it('updateSize case TopRight with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 2;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case BottomRight', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 3;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 0, height: 0 });
    });

    it('updateSize case BottomRight with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 3;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case BottomLeft', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 4;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 0 });
    });

    it('updateSize case BottomLeft with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 4;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case TopMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 5;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case BottomMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 6;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 0 });
    });

    it('updateSize case LeftMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 7;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case RightMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 8;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 0, height: 20 });
    });

    // test getDestinationCanvas

    it('getDestinationCanvas should return a new canvas', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };

        const updateSpy = spyOn<any>(service, 'updateSize');
        const documentSpy = spyOn<any>(document, 'createElement').and.returnValue(canvasTestHelper.canvas);
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;
        const ctx = service['getDestinationCanvas'](mouseEvent, topLeftPoint, size, false);

        expect(updateSpy).toHaveBeenCalled();
        expect(documentSpy).toHaveBeenCalled();
        expect(ctx.canvas.width).toEqual(service['drawingService'].previewCanvas.width);
    });

    // test resizeSelection

    it('resizeSelection should call scale', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });

    it('resizeSelection case width === 0', () => {
        service.size = { width: 0, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 0, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });

    it('resizeSelection case mirror x', () => {
        service.size = { width: -20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });

    it('resizeSelection case mirror y', () => {
        service.size = { width: 20, height: -20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });
});
