import { Injectable } from '@angular/core';
import { ResizeSelection } from '@app/classes/resize-selection';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { SIDE_BAR_X_POSITION } from '@app/constants/constants';
import { ResizingBox } from '@app/enums/resizing-box';
import { DrawingService } from '@app/services/drawing/drawing.service';

@Injectable({
    providedIn: 'root',
})
export class ResizeMagicWandService extends ResizeSelection {
    constructor(protected drawingService: DrawingService) {
        super(drawingService);
    }

    private updateSize(event: MouseEvent, topLeftPoint: Vec2, size: Size): void {
        switch (this.resizeButton) {
            case ResizingBox.TopLeft:
                this.size.width = topLeftPoint.x + size.width - (event.pageX - SIDE_BAR_X_POSITION);
                this.size.height = topLeftPoint.y + size.height - event.pageY;
                this.topLeftPoint.x = event.pageX - SIDE_BAR_X_POSITION;
                this.topLeftPoint.y = event.pageY;
                break;
            case ResizingBox.TopRight:
                this.size.width = event.pageX - SIDE_BAR_X_POSITION - topLeftPoint.x;
                this.size.height = topLeftPoint.y + size.height - event.pageY;
                this.topLeftPoint.y = event.pageY;
                break;
            case ResizingBox.BottomRight:
                this.size.width = event.pageX - SIDE_BAR_X_POSITION - topLeftPoint.x;
                this.size.height = event.pageY - topLeftPoint.y;
                break;
            case ResizingBox.BottomLeft:
                this.size.width = topLeftPoint.x + size.width - (event.pageX - SIDE_BAR_X_POSITION);
                this.size.height = event.pageY - topLeftPoint.y;
                this.topLeftPoint.x = event.pageX - SIDE_BAR_X_POSITION;
                break;
            case ResizingBox.TopMiddle:
                this.size.height = topLeftPoint.y + size.height - event.pageY;
                this.topLeftPoint.y = event.pageY;
                break;
            case ResizingBox.BottomMiddle:
                this.size.height = event.pageY - topLeftPoint.y;
                break;
            case ResizingBox.LeftMiddle:
                this.size.width = topLeftPoint.x + size.width - (event.pageX - SIDE_BAR_X_POSITION);
                this.topLeftPoint.x = event.pageX - SIDE_BAR_X_POSITION;
                break;
            case ResizingBox.RightMiddle:
                this.size.width = event.pageX - SIDE_BAR_X_POSITION - topLeftPoint.x;
                break;
        }
    }

    private getDestinationCanvas(event: MouseEvent, topLeftPoint: Vec2, size: Size): CanvasRenderingContext2D {
        this.updateSize(event, topLeftPoint, size);
        const destinationCanvas: HTMLCanvasElement = document.createElement('canvas');
        destinationCanvas.width = this.drawingService.previewCanvas.width;
        destinationCanvas.height = this.drawingService.previewCanvas.height;
        const destinationCtx: CanvasRenderingContext2D = destinationCanvas.getContext('2d') as CanvasRenderingContext2D;
        return destinationCtx;
    }

    resizeSelection(event: MouseEvent, imageData: ImageData, topLeftPoint: Vec2, size: Size): Vec2 {
        const canvas = this.createCopyCanvas(imageData);
        const destinationCtx = this.getDestinationCanvas(event, topLeftPoint, size);
        destinationCtx.scale(this.size.width / imageData.width, this.size.height / imageData.height);
        const resizePoint: Vec2 = { x: this.topLeftPoint.x, y: this.topLeftPoint.y };

        if (this.size.width === 0 || this.size.height === 0) {
            return resizePoint;
        }

        let x = 0;
        let y = 0;
        if (this.size.width / imageData.width < 0) {
            x = -imageData.width;
            resizePoint.x = this.topLeftPoint.x + this.size.width;
            this.size.width = -this.size.width;
        }
        if (this.size.height / imageData.height < 0) {
            y = -imageData.height;
            resizePoint.y = this.topLeftPoint.y + this.size.height;
            this.size.height = -this.size.height;
        }
        destinationCtx.drawImage(canvas, x, y);
        this.resizedImageData = destinationCtx.getImageData(0, 0, this.size.width, this.size.height);

        return resizePoint;
    }
}
