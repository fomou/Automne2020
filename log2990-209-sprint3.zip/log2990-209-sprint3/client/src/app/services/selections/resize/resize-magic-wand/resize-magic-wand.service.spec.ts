import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { ResizeMagicWandService } from './resize-magic-wand.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('ResizeMagicWandService', () => {
    let service: ResizeMagicWandService;
    let topLeftPoint: Vec2;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        TestBed.configureTestingModule({});
        service = TestBed.inject(ResizeMagicWandService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        topLeftPoint = { x: 25, y: 25 };
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // tests updateSize

    it('updateSize case TopLeft', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 1;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case TopRight', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 2;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 0, height: 20 });
    });

    it('updateSize case BottomRight', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 3;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 0, height: 0 });
    });

    it('updateSize case BottomLeft', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 4;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 20, height: 0 });
    });

    it('updateSize case TopMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 5;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case BottomMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 6;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 20, height: 0 });
    });

    it('updateSize case LeftMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 7;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case RightMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 8;

        service['updateSize'](mouseEvent, topLeftPoint, size);

        expect(service.size).toEqual({ width: 0, height: 20 });
    });

    // test getDestinationCanvas

    it('getDestinationCanvas should return a new canvas', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };

        const updateSpy = spyOn<any>(service, 'updateSize');
        const documentSpy = spyOn<any>(document, 'createElement').and.returnValue(canvasTestHelper.canvas);
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;
        const ctx = service['getDestinationCanvas'](mouseEvent, topLeftPoint, size);

        expect(updateSpy).toHaveBeenCalled();
        expect(documentSpy).toHaveBeenCalled();
        expect(ctx.canvas.width).toEqual(service['drawingService'].previewCanvas.width);
    });

    // test resizeSelection

    it('resizeSelection should call scale', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });

    it('resizeSelection case width === 0', () => {
        service.size = { width: 0, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 0, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });

    it('resizeSelection case mirror x', () => {
        service.size = { width: -20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });

    it('resizeSelection case mirror y', () => {
        service.size = { width: 20, height: -20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };

        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(service, 'getDestinationCanvas').and.callFake(() => {
            return ctx;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });
});
