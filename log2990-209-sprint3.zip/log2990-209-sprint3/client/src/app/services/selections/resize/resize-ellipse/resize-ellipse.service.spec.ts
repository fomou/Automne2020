import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { ResizeEllipseService } from './resize-ellipse.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('ResizeEllipseService', () => {
    let service: ResizeEllipseService;
    let topLeftPoint: Vec2;
    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;

        TestBed.configureTestingModule({});
        service = TestBed.inject(ResizeEllipseService);

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;
        topLeftPoint = { x: 25, y: 25 };
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // tests updateSize
    it('updateSize case TopLeft', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 1;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case TopLeft with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 1;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case TopRight', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 2;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 0, height: 20 });
    });

    it('updateSize case TopRight with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 2;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case BottomRight', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 3;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 0, height: 0 });
    });

    it('updateSize case BottomRight with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 3;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case BottomLeft', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 4;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 0 });
    });

    it('updateSize case BottomLeft with shift', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 4;

        const spy = spyOn<any>(service, 'findShiftPoint');
        service['updateSize'](mouseEvent, topLeftPoint, size, true);

        expect(spy).toHaveBeenCalled();
    });

    it('updateSize case TopMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 5;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case BottomMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 6;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 0 });
    });

    it('updateSize case LeftMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 7;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 20, height: 20 });
    });

    it('updateSize case RightMiddle', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const size = { width: 20, height: 20 };
        service['resizeButton'] = 8;

        service['updateSize'](mouseEvent, topLeftPoint, size, false);

        expect(service.size).toEqual({ width: 0, height: 20 });
    });

    // test clipEllipseCanvas
    it('clipEllipseCanvas should call drawImage', () => {
        service.size = { width: 20, height: 20 };
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const canvas = canvasTestHelper.canvas;

        const spy = spyOn(ctx, 'drawImage');
        service.clipEllipseCanvas(ctx, canvas);

        expect(spy).toHaveBeenCalled();
    });

    // test resizeSelection
    it('resizeSelection should call scale', () => {
        service.size = { width: 20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const canvas = canvasTestHelper.canvas;
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;

        spyOn<any>(service, 'updateSize');
        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(document, 'createElement').and.callFake(() => {
            return canvas;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
    });

    it('resizeSelection case width === 0', () => {
        service.size = { width: 0, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 0, height: 20 };
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;
        const canvas = canvasTestHelper.canvas;
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(document, 'createElement').and.callFake(() => {
            return canvas;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
    });

    it('resizeSelection case mirror x', () => {
        service.size = { width: -20, height: 20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;
        const canvas = canvasTestHelper.canvas;
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(document, 'createElement').and.callFake(() => {
            return canvas;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
    });

    it('resizeSelection case mirror y', () => {
        service.size = { width: 20, height: -20 };
        service.topLeftPoint = topLeftPoint;
        const mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 2,
        } as MouseEvent;
        const imageData = new ImageData(100, 100);
        const size = { width: 20, height: 20 };
        service['drawingService'].previewCanvas = canvasTestHelper.canvas;
        const canvas = canvasTestHelper.canvas;
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;

        const canvasSpy = spyOn<any>(service, 'createCopyCanvas').and.returnValue(canvasTestHelper.canvas);
        const destinationCtxSpy = spyOn<any>(document, 'createElement').and.callFake(() => {
            return canvas;
        });
        const scaleSpy = spyOn<any>(ctx, 'scale');

        service.resizeSelection(mouseEvent, imageData, topLeftPoint, size, false);

        expect(canvasSpy).toHaveBeenCalled();
        expect(scaleSpy).toHaveBeenCalled();
        expect(destinationCtxSpy).toHaveBeenCalled();
    });
});
