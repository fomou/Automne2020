import { Injectable } from '@angular/core';
import { ResizeSelection } from '@app/classes/resize-selection';
import { Size } from '@app/classes/size';
import { Vec2 } from '@app/classes/vec2';
import { SIDE_BAR_X_POSITION } from '@app/constants/constants';
import { ResizingBox } from '@app/enums/resizing-box';
import { DrawingService } from '@app/services/drawing/drawing.service';

@Injectable({
    providedIn: 'root',
})
export class ResizeEllipseService extends ResizeSelection {
    circleCenter: Vec2;
    radius: Vec2;

    constructor(protected drawingService: DrawingService) {
        super(drawingService);
    }

    private updateSize(event: MouseEvent, topLeftPoint: Vec2, size: Size, isShiftPressed: boolean): void {
        const bottomRightPoint: Vec2 = { x: topLeftPoint.x + size.width, y: topLeftPoint.y + size.height };
        const topRightPoint: Vec2 = { x: topLeftPoint.x + size.width, y: topLeftPoint.y };
        const bottomLeftPoint: Vec2 = { x: topLeftPoint.x, y: topLeftPoint.y + size.height };
        switch (this.resizeButton) {
            case ResizingBox.TopLeft:
                this.size.width = topLeftPoint.x + size.width - (event.pageX - SIDE_BAR_X_POSITION);
                this.size.height = topLeftPoint.y + size.height - event.pageY;
                this.topLeftPoint.x = event.pageX - SIDE_BAR_X_POSITION;
                this.topLeftPoint.y = event.pageY;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                if (isShiftPressed) this.findShiftPoint(bottomRightPoint, this.topLeftPoint, this.size);
                break;
            case ResizingBox.TopRight:
                this.size.width = event.pageX - SIDE_BAR_X_POSITION - topLeftPoint.x;
                this.size.height = topLeftPoint.y + size.height - event.pageY;
                this.topLeftPoint.y = event.pageY;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                if (isShiftPressed) this.findShiftPoint(bottomLeftPoint, topRightPoint, this.size);
                break;
            case ResizingBox.BottomRight:
                this.size.width = event.pageX - SIDE_BAR_X_POSITION - topLeftPoint.x;
                this.size.height = event.pageY - topLeftPoint.y;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                if (isShiftPressed) this.findShiftPoint(this.topLeftPoint, bottomRightPoint, this.size);
                break;
            case ResizingBox.BottomLeft:
                this.size.width = topLeftPoint.x + size.width - (event.pageX - SIDE_BAR_X_POSITION);
                this.size.height = event.pageY - topLeftPoint.y;
                this.topLeftPoint.x = event.pageX - SIDE_BAR_X_POSITION;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                if (isShiftPressed) this.findShiftPoint(topRightPoint, bottomLeftPoint, this.size);
                break;
            case ResizingBox.TopMiddle:
                this.size.height = topLeftPoint.y + size.height - event.pageY;
                this.topLeftPoint.y = event.pageY;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                break;
            case ResizingBox.BottomMiddle:
                this.size.height = event.pageY - topLeftPoint.y;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                break;
            case ResizingBox.LeftMiddle:
                this.size.width = topLeftPoint.x + size.width - (event.pageX - SIDE_BAR_X_POSITION);
                this.topLeftPoint.x = event.pageX - SIDE_BAR_X_POSITION;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                break;
            case ResizingBox.RightMiddle:
                this.size.width = event.pageX - SIDE_BAR_X_POSITION - topLeftPoint.x;
                this.circleCenter = { x: this.topLeftPoint.x + this.size.width / 2, y: this.topLeftPoint.y + this.size.height / 2 };
                this.radius = { x: this.size.width / 2, y: this.size.height / 2 };
                break;
        }
    }

    clipEllipseCanvas(destinationCtx: CanvasRenderingContext2D, newCanvas: HTMLCanvasElement): void {
        destinationCtx.beginPath();
        destinationCtx.strokeStyle = '#00000000';
        destinationCtx.setLineDash([1, 2]);
        destinationCtx.ellipse(this.size.width / 2, this.size.height / 2, this.size.width / 2, this.size.height / 2, 0, 0, Math.PI * 2);
        destinationCtx.stroke();
        destinationCtx.clip();
        destinationCtx.closePath();
        destinationCtx.drawImage(newCanvas, 0, 0);
    }

    resizeSelection(event: MouseEvent, imageData: ImageData, topLeftPoint: Vec2, size: Size, isShiftPressed: boolean): Vec2 {
        const canvas = this.createCopyCanvas(imageData);
        this.updateSize(event, topLeftPoint, size, isShiftPressed);
        const newCanvas: HTMLCanvasElement = document.createElement('canvas');
        newCanvas.width = this.drawingService.previewCanvas.width;
        newCanvas.height = this.drawingService.previewCanvas.height;
        const newCtx: CanvasRenderingContext2D = newCanvas.getContext('2d') as CanvasRenderingContext2D;
        newCtx.scale(this.size.width / imageData.width, this.size.height / imageData.height);
        const resizePoint: Vec2 = { x: this.topLeftPoint.x, y: this.topLeftPoint.y };

        if (this.size.width === 0 || this.size.height === 0) {
            return resizePoint;
        }

        let x = 0;
        let y = 0;
        if (this.size.width / imageData.width < 0) {
            x = -imageData.width;
            resizePoint.x = this.topLeftPoint.x + this.size.width;
            this.size.width = -this.size.width;
        }
        if (this.size.height / imageData.height < 0) {
            y = -imageData.height;
            resizePoint.y = this.topLeftPoint.y + this.size.height;
            this.size.height = -this.size.height;
        }
        newCtx.drawImage(canvas, x, y);
        const destinationCanvas: HTMLCanvasElement = document.createElement('canvas');
        destinationCanvas.width = this.drawingService.previewCanvas.width;
        destinationCanvas.height = this.drawingService.previewCanvas.height;
        const destinationCtx: CanvasRenderingContext2D = destinationCanvas.getContext('2d') as CanvasRenderingContext2D;
        this.clipEllipseCanvas(destinationCtx, newCanvas);
        this.resizedImageData = destinationCtx.getImageData(0, 0, this.size.width, this.size.height);

        return resizePoint;
    }
}
