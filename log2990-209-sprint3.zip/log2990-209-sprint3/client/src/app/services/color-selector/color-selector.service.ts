import { Injectable } from '@angular/core';
import { MAXIMUM_COLOR } from '@app/constants/constants';
import { ColorType } from '@app/enums/color-type';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ColorSelectorService {
    primaryColorSource: BehaviorSubject<string> = new BehaviorSubject<string>('#000000FF');
    secondaryColorSource: BehaviorSubject<string> = new BehaviorSubject<string>('#FF0000FF');
    recentColorsHandler: BehaviorSubject<string[]> = new BehaviorSubject<string[]>([]);
    hueKeeper: BehaviorSubject<string> = new BehaviorSubject<string>('#000000FF');
    colorType: string;

    primaryColor$: Observable<string> = this.primaryColorSource.asObservable();
    secondaryColor$: Observable<string> = this.secondaryColorSource.asObservable();
    recentColor$: Observable<string[]> = this.recentColorsHandler.asObservable();

    announceColor(color: string): void {
        this.colorType === ColorType.Primary ? this.primaryColorSource.next(color) : this.secondaryColorSource.next(color);
    }

    swapColor(primaryColor: string, secondarySecondary: string): void {
        this.primaryColorSource.next(secondarySecondary);
        this.secondaryColorSource.next(primaryColor);
    }

    getCurrentColor(): string {
        return this.colorType === ColorType.Primary ? this.primaryColorSource.getValue() : this.secondaryColorSource.getValue();
    }

    addColorsToArray(color: string): void {
        const colors = this.recentColorsHandler.getValue();
        if (colors.length === MAXIMUM_COLOR) {
            colors.shift();
        }
        if (colors.includes(color)) {
            return;
        }
        colors.push(color);
        this.recentColorsHandler.next(colors);
    }

    keepHue(color: string): void {
        this.hueKeeper.next(color);
    }

    getHue(): string {
        return this.hueKeeper.getValue();
    }
}
