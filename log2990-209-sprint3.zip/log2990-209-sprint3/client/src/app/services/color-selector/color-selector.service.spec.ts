import { TestBed } from '@angular/core/testing';

import { MAXIMUM_COLOR } from '@app/constants/constants';
import { ColorType } from '@app/enums/color-type';
import { ColorSelectorService } from './color-selector.service';

// tslint:disable: no-magic-numbers
describe('ColorSelectorService', () => {
    let service: ColorSelectorService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(ColorSelectorService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('should give right primary color', () => {
        service.colorType = ColorType.Primary;
        service.announceColor('red');
        expect(service.primaryColorSource.getValue()).toEqual('red');
    });

    it('should give right secondaryColor', () => {
        service.colorType = ColorType.Secondary;
        service.announceColor('red');
        expect(service.secondaryColorSource.getValue()).toEqual('red');
    });

    it('should swap primaryColor and secondaryColor', () => {
        service.swapColor('red', 'green');
        expect(service.primaryColorSource.getValue()).toEqual('green');
        expect(service.secondaryColorSource.getValue()).toEqual('red');
    });

    it('should add color to the array', () => {
        service.addColorsToArray('red');
        expect(service.recentColorsHandler.getValue()).not.toEqual([]);
    });

    it('should not exceed maximum length', () => {
        for (let i = 0; i < 20; ++i) {
            service.addColorsToArray('red' + i.toString());
        }
        expect(service.recentColorsHandler.getValue().length).toEqual(MAXIMUM_COLOR);
        expect(service.recentColorsHandler.getValue()[0]).toEqual('red10');
    });

    it('getCurrentColor give right color on primaryColor', () => {
        service.colorType = ColorType.Primary;
        service.announceColor('blue');
        expect(service.getCurrentColor()).toEqual('blue');
    });

    it('getCurrentColor give right color on secondaryColor', () => {
        service.colorType = ColorType.Secondary;
        service.announceColor('blue');
        expect(service.getCurrentColor()).toEqual('blue');
    });

    it('getCurrentColor give right color on secondaryColor', () => {
        service.colorType = ColorType.Secondary;
        service.announceColor('blue');
        expect(service.getCurrentColor()).toEqual('blue');
    });

    it('add 2 sames color to the array should add only 1 color', () => {
        service.addColorsToArray('red');
        service.addColorsToArray('red');
        expect(service.recentColorsHandler.getValue().length).toEqual(1);
    });

    it('getHue should return hueKeeper', () => {
        service.keepHue('red');
        expect(service.getHue()).toEqual('red');
    });
});
