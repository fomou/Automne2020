import { Component, HostListener, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSliderChange } from '@angular/material/slider';
import { LoadedImage } from '@app/classes/loaded-image';
import { ExportComponent } from '@app/components/export/export.component';
import { GalleryComponent } from '@app/components/gallery/gallery.component';
import { SaveDrawingComponent } from '@app/components/save-drawing//save-drawing.component';
import { UserGuideComponent } from '@app/components/user-guide/user-guide.component';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ResizeRectangleService } from '@app/services/selections/resize/resize-rectangle/resize-rectangle.service';
import { RotationRectangleService } from '@app/services/selections/rotation/rotation-rectangle/rotation-rectangle.service';
import { SelectionRectangleService } from '@app/services/selections/selection/selection-rectangle/selection-rectangle.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools-selectors/tools-selector.service';
import { LineService } from '@app/services/tools/line/line.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnDestroy {
    private shortcutDisabled: boolean;
    radius: number = 5;
    fontSize: string = '';
    isShownBarAttTools: boolean = true;
    isShownBarAttShapes: boolean = false;
    isShownJonctionType: boolean = false;
    isShownSelections: boolean = false;
    isShownShapes: boolean = false;
    isShownBarAttLine: boolean = false;
    isShownLineAtt: boolean = false;
    isShownBarAttPaintBucket: boolean = false;
    isShownBarAttEraser: boolean = false;
    isShownBarAttSelection: boolean = false;
    isShownBarAttGrid: boolean = false;
    isShowPipetteAttribute: boolean = false;
    isShownBarAttText: boolean = false;
    jonctionTypes: string[] = ['Sans point', 'Avec points'];
    selections: string[] = ['Rectangle de sélection', 'Ellipse de sélection', 'Baguette magique'];
    selection: string = 'Outils de sélection';
    jonctionType: string = 'Sans point';
    showStamp: boolean = false;
    isShowGrid: boolean = true;
    private subscriptionShortcuts: Subscription = new Subscription();
    private subscriptionGrid: Subscription = new Subscription();
    constructor(
        private dialog: MatDialog,
        private galleryWindow: MatDialog,
        private sidebarService: SidebarService,
        private toolsSelectorService: ToolsSelectorService,
        private lineService: LineService,
        private rotationRectangleService: RotationRectangleService,
        private resizeRectangleService: ResizeRectangleService,
        private drawingService: DrawingService,
        private undoRedoService: UndoRedoService,
        private shortcutManagerService: ShortcutManagerService,
        private selectionRectangleService: SelectionRectangleService,
    ) {
        this.subscriptionShortcuts = this.shortcutManagerService.shortcutObs$.subscribe((disable) => {
            this.shortcutDisabled = disable;
        });
        this.subscriptionGrid = this.sidebarService.disabledObs$.subscribe((disableGrid) => {
            this.isShowGrid = disableGrid;
        });
    }
    ngOnDestroy(): void {
        this.subscriptionGrid.unsubscribe();
        this.subscriptionShortcuts.unsubscribe();
    }
    @HostListener('document:keydown.control.e', ['$event'])
    openExportWindow(event?: KeyboardEvent): void {
        if (event) event.preventDefault();
        if (this.shortcutDisabled) return;
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(ExportComponent, {
            disableClose: true,
            height: '460px',
            width: '640px',
        });
    }
    @HostListener('document:keydown.control.a', ['$event'])
    selectAll(event?: KeyboardEvent): void {
        if (event) {
            event.preventDefault();
        }
        this.showBarAttributesSelection();
        this.showRectangSelectionleAtt();
        this.selectionRectangleService.isSelected = true;
        this.selectionRectangleService.imageData = this.rotationRectangleService.imageData = this.drawingService.getImageData();
        this.selectionRectangleService.topLeftPoint = this.rotationRectangleService.selectionTopLeft = { x: 0, y: 0 };
        this.drawingService.baseCtx.fillStyle = 'white';
        this.drawingService.baseCtx.fillRect(0, 0, this.drawingService.canvas.width, this.drawingService.canvas.height);
        this.drawingService.previewCtx.putImageData(this.selectionRectangleService.imageData, 0, 0);
        this.resizeRectangleService.topLeftPoint = { x: 0, y: 0 };
        this.selectionRectangleService.size = { width: this.drawingService.canvas.width, height: this.drawingService.canvas.height };
        this.resizeRectangleService.size = { width: this.drawingService.canvas.width, height: this.drawingService.canvas.height };
    }
    @HostListener('window:keydown.control.s', ['$event'])
    openDialogSauvegarde(event?: KeyboardEvent): void {
        if (event) event.preventDefault();
        if (this.shortcutDisabled) return;
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(SaveDrawingComponent, {
            disableClose: true,
            height: '300px',
            width: '659px',
        });
    }
    @HostListener('window:keydown.control.g', ['$event'])
    galleryManager(event?: KeyboardEvent): void {
        if (event) event.preventDefault();
        if (this.shortcutDisabled) return;
        this.shortcutManagerService.disableShortcut();
        this.galleryWindow.open(GalleryComponent, { disableClose: true, data: this.drawingService.canvas });
    }
    openDialog(): void {
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(UserGuideComponent, { disableClose: true, height: '95%' });
    }
    undo(): void {
        this.undoRedoService.undo();
        this.selectionRectangleService.isMoving = this.selectionRectangleService.isSelected = false;
    }
    redo(): void {
        this.undoRedoService.redo();
    }
    canUndo(): boolean {
        return this.undoRedoService.canUndo();
    }
    canRedo(): boolean {
        return this.undoRedoService.canRedo();
    }
    getRadius(radius: number): void {
        this.radius = radius;
        this.lineService.joinRadius = radius;
    }
    formatLabel(value: number): string {
        return (value + 'px') as string;
    }
    changeWidth(event: MatSliderChange): void {
        this.sidebarService.changeWidth(event.value as number);
    }
    changeEraserSize(event: MatSliderChange): void {
        this.sidebarService.changeEraserSize(event.value as number);
    }
    changeTolerance(event: MatSliderChange): void {
        this.sidebarService.changeTolerance(event.value as number);
    }
    disabledGrid(): void {
        this.sidebarService.disableGrid(this.isShowGrid);
    }
    showPipetteAttribute(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShowPipetteAttribute = !this.isShowPipetteAttribute;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.I));
    }
    hideAllBarAtt(): void {
        this.isShownBarAttShapes = this.isShownBarAttTools = this.isShownBarAttEraser = this.isShownBarAttText = false;
        this.isShownBarAttPaintBucket = this.isShownBarAttLine = this.isShownBarAttEraser = this.showStamp = false;
        this.isShownBarAttEraser = this.isShownBarAttSelection = this.isShowPipetteAttribute = this.isShownBarAttGrid = false;
    }
    closeBar3(): void {
        this.isShownSelections = this.isShownJonctionType = false;
    }
    hideAllToolAttrebutes(): void {
        this.isShowPipetteAttribute = false;
    }
    showBarAttributesTools(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttTools = !this.isShownBarAttTools;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.plottingTool);
    }
    showBarAttributesShapes(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttShapes = !this.isShownBarAttShapes;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.shapeTool);
    }
    showBarAttributesLine(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttLine = !this.isShownBarAttLine;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.L));
    }
    showStampAttribute(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.showStamp = !this.showStamp;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.D));
    }
    showJonctionType(): void {
        this.isShownJonctionType = !this.isShownJonctionType;
    }
    showDefaultJonctionAtt(): void {
        this.isShownLineAtt = this.lineService.pointJoin = false;
        this.showJonctionType();
        this.jonctionType = this.jonctionTypes[0];
    }
    showWithDotsJonctionAtt(): void {
        this.isShownLineAtt = this.lineService.pointJoin = true;
        this.showJonctionType();
        this.jonctionType = this.jonctionTypes[1];
    }
    showBarAttributesGrid(): void {
        this.hideAllBarAtt();
        this.isShownBarAttGrid = true;
        this.disabledGrid();
    }
    showBarAttributesPaintBucket(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttPaintBucket = !this.isShownBarAttPaintBucket;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.B));
    }
    showBarAttributesEraser(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.E));
        this.isShownBarAttEraser = !this.isShownBarAttEraser;
    }
    showBarAttributesSelection(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttSelection = !this.isShownBarAttSelection;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.selectionTool);
    }
    showSelections(): void {
        this.isShownSelections = !this.isShownSelections;
    }
    showRectangSelectionleAtt(): void {
        this.closeBar3();
        this.toolsSelectorService.selectionTool = this.toolsSelectorService.getToolByKey(Keyboard.R);
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.R));
    }
    showEllipseSelectionAtt(): void {
        this.closeBar3();
        this.toolsSelectorService.selectionTool = this.toolsSelectorService.getToolByKey(Keyboard.S);
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.S));
    }
    showMagicWandAtt(): void {
        this.closeBar3();
        this.toolsSelectorService.selectionTool = this.toolsSelectorService.getToolByKey(Keyboard.V);
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.V));
    }
    showBarAttributesText(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttText = !this.isShownBarAttText;
        this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(Keyboard.T));
    }
    changeWidthLine(event: MatSliderChange): void {
        this.sidebarService.changeWidthLine(event.value as number);
    }
    returnWidth(): number {
        return this.sidebarService.width;
    }
    returnLineWidth(): number {
        return this.sidebarService.widthLine;
    }
    returnEraserSize(): number {
        return this.sidebarService.eraserSize;
    }
    isClicked(): void {
        if (!this.undoRedoService.canUndo() && !this.drawingService.imageLoadedFromGallery()) {
            return;
        }
        if (window.confirm('Voulez-vous abandonner vos changement ?')) {
            this.drawingService.clearCanvas(this.drawingService.baseCtx);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.undoRedoService.clearStacks();
            this.undoRedoService.loadedImage.next(new LoadedImage());
            this.drawingService.imageIsLoadedFromGallery.next(false);
            this.drawingService.setBackground(this.drawingService.baseCtx);
        }
    }
    @HostListener('window:keydown', ['$event'])
    onkeydown(event: KeyboardEvent): void {
        if (this.shortcutDisabled) {
            return;
        }
        if (event.ctrlKey && event.code === Keyboard.Z) {
            this.selectionRectangleService.isSelected = false;
            this.selectionRectangleService.isMoving = false;
        }
        this.showShapeTool(event);
        this.showTracingTool(event);
        if (!event.ctrlKey) {
            switch (event.code) {
                case Keyboard.L:
                    this.showBarAttributesLine();
                    break;
                case Keyboard.I:
                    this.showPipetteAttribute();
                    break;
                case Keyboard.E:
                    this.showBarAttributesEraser();
                    break;
                case Keyboard.B:
                    this.showBarAttributesPaintBucket();
                    break;
                case Keyboard.R:
                    this.showBarAttributesSelection();
                    this.showRectangSelectionleAtt();
                    break;
                case Keyboard.S:
                    this.showBarAttributesSelection();
                    this.showEllipseSelectionAtt();
                    break;
                case Keyboard.D:
                    this.showStampAttribute();
                    break;
                case Keyboard.G:
                    this.showBarAttributesGrid();
                    break;
                case Keyboard.V:
                    this.showBarAttributesSelection();
                    this.showMagicWandAtt();
                    break;
            }
        }
    }
    private showShapeTool(event: KeyboardEvent): void {
        const code = event.code;
        if (code === Keyboard.One || code === Keyboard.Two || code === Keyboard.Three) {
            this.showBarAttributesShapes();
            this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(event.code));
        }
    }
    private showTracingTool(event: KeyboardEvent): void {
        if (!event.ctrlKey) {
            const code = event.code;
            if (code === Keyboard.C || code === Keyboard.W || code === Keyboard.A) {
                this.showBarAttributesTools();
                this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolByKey(event.code));
            }
        }
    }
}
