import { Component } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { MatSliderChange } from '@angular/material/slider';
import { TextService } from '@app/services/tools/text/text.service';
@Component({
    selector: 'app-text',
    templateUrl: './text.component.html',
    styleUrls: ['./text.component.scss'],
})
export class TextComponent {
    constructor(private textService: TextService) {}

    chooseTextFont(event: MatSelectChange): void {
        this.textService.font = event.value as string;
    }
    changeTextFontSize(event: MatSliderChange): void {
        this.textService.fontSize = event.value as number;
    }
    chooseTextFontStyle(event: MatSelectChange): void {
        this.textService.fontStyle = event.value as string;
    }
    chooseTextAlign(event: MatSelectChange): void {
        this.textService.textAlign = event.value;
    }
}
