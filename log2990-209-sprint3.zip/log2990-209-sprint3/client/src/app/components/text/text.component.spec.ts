import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSliderChange, MatSliderModule } from '@angular/material/slider';
import { TextService } from '@app/services/tools/text/text.service';
import { TextComponent } from './text.component';
// tslint:disable: no-any
// tslint:disable:no-string-literal
// tslint:disable:no-magic-numbers
describe('TextComponent', () => {
    let component: TextComponent;
    let fixture: ComponentFixture<TextComponent>;
    let event: MatSelectChange;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [TextComponent],
            imports: [MatSelectModule, MatSliderModule],
            providers: [{ provide: TextService, useValue: {} as TextService }],
        }).compileComponents();
        event = {
            value: 'Arial',
        } as MatSelectChange;
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(TextComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(' chooseTextFont should put event value in the attribute font of textService', () => {
        component.chooseTextFont(event);
        expect(component['textService'].font).toEqual('Arial');
    });
    it(' changeTextFontSize should put event value in the attribute font of textService', () => {
        const eventSlider = { value: 20 } as MatSliderChange;
        component.changeTextFontSize(eventSlider);
        expect(component['textService'].fontSize).toEqual(20);
    });
    it(' chooseTextFont should put event value in the attribute font of textService', () => {
        component.chooseTextFontStyle(event);
        expect(component['textService'].fontStyle).toEqual('Arial');
    });
    it(' chooseTextFont should put event value in the attribute font of textService', () => {
        component.chooseTextAlign(event);
        expect(component['textService'].textAlign).toEqual('Arial');
    });
});
