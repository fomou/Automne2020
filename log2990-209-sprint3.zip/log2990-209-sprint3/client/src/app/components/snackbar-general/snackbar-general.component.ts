import { Component } from '@angular/core';
import { SnackBarGeneralService } from '@app/services/snackbar-general/snackbar-general.service';

@Component({
    selector: 'app-snackbar-general',
    templateUrl: './snackbar-general.component.html',
    styleUrls: ['./snackbar-general.component.scss'],
})
export class SnackbarGeneralComponent {
    constructor(private snackBar: SnackBarGeneralService) {}
    displayContext: string = this.snackBar.valueDisplay;
}
