import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SnackbarGeneralComponent } from './snackbar-general.component';

describe('SnackbarGeneralComponent', () => {
    let component: SnackbarGeneralComponent;
    let fixture: ComponentFixture<SnackbarGeneralComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SnackbarGeneralComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SnackbarGeneralComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
