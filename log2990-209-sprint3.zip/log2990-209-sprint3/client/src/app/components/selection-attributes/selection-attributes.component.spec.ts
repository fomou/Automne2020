import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSlideToggle, MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SelectionAttributesComponent } from './selection-attributes.component';

describe('SelectionAttributesComponent', () => {
    let component: SelectionAttributesComponent;
    let fixture: ComponentFixture<SelectionAttributesComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SelectionAttributesComponent],
            imports: [
                BrowserModule,
                HttpClientModule,
                BrowserAnimationsModule,
                MatSliderModule,
                MatSlideToggleModule,
                MatDialogModule,
                FormsModule,
                ReactiveFormsModule,
                MatDialogModule,
                MatButtonModule,
                MatIconModule,
                MatFormFieldModule,
                MatButtonModule,
                MatSelectModule,
                MatRadioModule,
                MatInputModule,
                MatChipsModule,
                MatSnackBarModule,
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SelectionAttributesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('ngOnDestroy should unsubscribe the subscription', () => {
        // tslint:disable: no-string-literal
        const gridSpy = spyOn(component['subscriptioMagnetisme'], 'unsubscribe');
        const shortCuts = spyOn(component['subscriptionAnchor'], 'unsubscribe');
        component.ngOnDestroy();
        expect(gridSpy).toHaveBeenCalled();
        expect(shortCuts).toHaveBeenCalled();
    });

    it('selectAnchor should give the value form event', () => {
        const event = { value: 20 } as MatSelectChange;
        const spy = spyOn(component['sidebarService'], 'anchorTypes').and.callFake(() => {
            return;
        });
        component.selectAnchor(event);
        // tslint:disable: no-magic-numbers
        expect(component.anchorPoint).toEqual(20);
        expect(spy).toHaveBeenCalled();
    });

    it('selectAnchor should give the value form event', () => {
        const event = { checked: true } as MatSlideToggle;
        const spy = spyOn(component['sidebarService'], 'disableMagnetism').and.callFake(() => {
            return;
        });
        component.disable(event);
        expect(component.disabled).toEqual(true);
        expect(spy).toHaveBeenCalled();
    });
});
