import { Component, OnDestroy } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { ResizingBox } from '@app/enums/resizing-box';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-selection-attributes',
    templateUrl: './selection-attributes.component.html',
    styleUrls: ['./selection-attributes.component.scss'],
})
export class SelectionAttributesComponent implements OnDestroy {
    disabled: boolean = false;
    anchorPoint: ResizingBox = 1;
    private subscriptioMagnetisme: Subscription = new Subscription();
    private subscriptionAnchor: Subscription = new Subscription();

    constructor(private sidebarService: SidebarService) {
        this.sidebarService.disabledMagnetismObs$.subscribe((disabled) => {
            this.disabled = disabled;
        });
        this.sidebarService.anchorType$.subscribe((anchor) => {
            this.anchorPoint = anchor as ResizingBox;
        });
    }
    ngOnDestroy(): void {
        this.subscriptioMagnetisme.unsubscribe();
        this.subscriptionAnchor.unsubscribe();
    }
    disable(event: MatSlideToggle): void {
        this.disabled = event.checked;
        this.sidebarService.disableMagnetism(this.disabled);
    }
    selectAnchor(event: MatSelectChange): void {
        this.anchorPoint = parseInt(event.value, 10);
        this.sidebarService.anchorTypes(this.anchorPoint);
    }
}
