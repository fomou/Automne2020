import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import * as CONSTANT from '@app/constants/constants';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-pixel-picker',
    templateUrl: './pixel-picker.component.html',
    styleUrls: ['./pixel-picker.component.scss'],
})
export class PixelPickerComponent implements AfterViewInit, OnDestroy {
    @ViewChild('previewCircleCanvas', { static: false }) canvas: ElementRef<HTMLCanvasElement>;

    private context: CanvasRenderingContext2D;
    private subscriptions: Subscription[];

    constructor(private pickerService: PickerService) {
        this.subscriptions = [];
    }

    ngAfterViewInit(): void {
        this.context = this.canvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        const subscription = this.pickerService.displayObs$.subscribe((display) => this.displayClear(display));
        this.draw();
        this.subscriptions.push(subscription);
    }
    ngOnDestroy(): void {
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }
    draw(): void {
        const subscribe = this.pickerService.imageData$.subscribe((image) => {
            this.context.clearRect(0, 0, this.canvas.nativeElement.width, this.canvas.nativeElement.height);
            this.drawImage(image.imageData);
        });

        this.subscriptions.push(subscribe);
    }

    private getStrokeStyle(): string {
        const str = '#808080';
        const gray = parseInt(str.slice(1), 16);
        const currentColor = parseInt(this.pickerService.color.getValue().slice(1), 16);

        return currentColor < gray ? 'white' : 'black';
    }

    private async drawImage(imageData: ImageData): Promise<void> {
        try {
            const bitmap = await createImageBitmap(imageData);
            this.context.imageSmoothingEnabled = false;
            this.context.drawImage(bitmap, 0, 0, this.canvas.nativeElement.width, this.canvas.nativeElement.width);
            this.context.setLineDash([1]);
            console.log(this.context.setLineDash);
            this.context.strokeStyle = this.getStrokeStyle();
            this.context.strokeRect(
                this.canvas.nativeElement.width / 2,
                this.canvas.nativeElement.height / 2,
                CONSTANT.CENTER_WIDTH,
                CONSTANT.CENTER_WIDTH,
            );
            this.context.stroke();
        } catch (err) {
            console.error("impossible de créer un bitmap a partir de l'image reçu");
        }
    }
    private displayClear(isClear: boolean): void {
        if (!isClear) {
            this.context.clearRect(0, 0, this.canvas.nativeElement.width, this.canvas.nativeElement.height);
        }
    }
}
