import { HttpClient, HttpHandler } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatChipInputEvent, MatChipsModule } from '@angular/material/chips';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router, RouterModule } from '@angular/router';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { GalleryComponent } from '@app/components/gallery/gallery.component';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Drawing } from '@common/communication/drawing';
import { Observable } from 'rxjs';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers

describe('GalleryComponent', () => {
    let component: GalleryComponent;
    let fixture: ComponentFixture<GalleryComponent>;
    let saveDrawStub: SaveDrawingService;
    let drawServiceSpy: DrawingService;
    let router: jasmine.SpyObj<Router>;
    let shortcutManagerService: jasmine.SpyObj<ShortcutManagerService>;
    let undoRedoService: jasmine.SpyObj<UndoRedoService>;
    let http: HttpClient;
    let drawingService: DrawingService;
    beforeEach(async(() => {
        http = new HttpClient({} as HttpHandler);
        drawingService = new DrawingService();
        saveDrawStub = new SaveDrawingService(http, drawingService);
        router = jasmine.createSpyObj('Router', ['navigate']);
        shortcutManagerService = jasmine.createSpyObj('ShortcutManagerService', ['enableShortcut']);
        undoRedoService = jasmine.createSpyObj('UndoRedoService', ['clearStacks', 'canUndo', '']);
        drawServiceSpy = new DrawingService();
        const canvasStub = canvasTestHelper.canvas;
        const ctxStub = canvasStub.getContext('2d') as CanvasRenderingContext2D;
        canvasStub.width = 40;
        canvasStub.height = 40;
        drawServiceSpy.canvas = canvasStub;
        drawServiceSpy.previewCtx = ctxStub;
        drawServiceSpy.previewCanvas = canvasStub;
        drawServiceSpy.baseCtx = ctxStub;
        drawServiceSpy.background = canvasTestHelper.div;
        drawServiceSpy.borderCanvas = canvasTestHelper.div;
        TestBed.configureTestingModule({
            declarations: [GalleryComponent],
            imports: [MatIconModule, MatChipsModule, MatDialogModule, MatFormFieldModule, BrowserAnimationsModule, RouterModule, FormsModule],
            providers: [
                { provide: SaveDrawingService, useValue: saveDrawStub },
                { provide: DrawingService, useValue: drawServiceSpy },
                { provide: Router, useValue: router },
                { provide: ShortcutManagerService, useValue: shortcutManagerService },
                { provide: UndoRedoService, useValue: undoRedoService },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GalleryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        spyOn(component['saveDraw'], 'getAllImages').and.callFake(() => {
            return new Observable();
        });
        expect(component).toBeTruthy();
    });

    it('add should put tag in tag array if the tag length is grater or equal to 3 and if it is not already in the array ', () => {
        const spy = spyOn(component.tags, 'push');
        const htmlInput = document.createElement('input');
        const event = { value: '  123  ', input: htmlInput } as MatChipInputEvent;
        component.add(event);
        expect(spy).toHaveBeenCalled();
        expect(event.input.value).toBe('');
    });
    it('event should call add() and expect event value length to be < than 3', () => {
        const event = { value: '12' } as MatChipInputEvent;
        component.add(event);
        expect(event.value.length).toBeLessThan(3);
    });
    it(' should call remove(tag) and  splice tag from the tags array', () => {
        const spyIndexOf = spyOn(component.tags, 'indexOf').and.returnValue(2);
        const spySplice = spyOn(component.tags, 'splice');
        component.remove('');
        expect(spyIndexOf).toHaveBeenCalled();
        expect(spySplice).toHaveBeenCalled();
    });
    it(' should call remove() and expect the tags array length to be equal 1', () => {
        spyOn(component, 'refresh').and.callFake(() => {
            return;
        });
        spyOn(component.tags, 'indexOf').and.returnValue(-1);
        expect(component.tags.length).toEqual(0);
    });
    it(' should call search() and expect  and resetIterators() to have been called ', () => {
        let drawingDataStub: Drawing[];
        drawingDataStub = [{ name: 'drawingName', tags: [''] }];
        spyOn(component, 'filter').and.returnValue(drawingDataStub);
        const spyResetIterators = spyOn(component, 'resetIterators');
        component.search();
        expect(spyResetIterators).toHaveBeenCalled();
    });
    it(' should call filter() and expect updateIterators() to have been called', () => {
        let tags: string[];
        tags = ['', ''];
        component.tags = tags;
        let drawingDataStub: Drawing[];
        drawingDataStub = [
            { name: 'drawingName', tags: ['', ''] },
            { name: 'drawingName', tags: [''] },
        ];
        component.imageData = drawingDataStub;
        const spyUpdateIterators = spyOn(component, 'updateIterators');
        component.filter();
        expect(spyUpdateIterators).toHaveBeenCalled();
    });
    it(' should call refresh() and expect getAllImage() to have been called ', () => {
        const spyRefresh = spyOn(component, 'getAllImage');
        component.refresh();
        expect(spyRefresh).toHaveBeenCalled();
    });
    it(' should call scrollRight()and make nextImage increment', () => {
        component.nextImage = -2;
        component.scrollRight();
        expect(component.nextImage).toEqual(-1);
    });
    it('should call  scrollRight() and and have nextImage equal 0', () => {
        component.nextImage = -1;
        component.scrollRight();
        expect(component.nextImage).toEqual(0);
    });
    it(' should call scrollLeft() and make perImage decrement ', () => {
        component.prevImage = 1;
        component.scrollLeft();
        expect(component.prevImage).toEqual(0);
    });
    it(' should call scrollLeft() and make perImage equal to -1 ', () => {
        component.prevImage = 0;
        component.scrollLeft();
        expect(component.prevImage).toEqual(-1);
    });
    it(' should call updateIterators() and make nextImage=1 and prevImage=0 ', () => {
        component.nextImage = 0;
        component.prevImage = 0;
        component.updateIterators();
        expect(component.nextImage).toEqual(1);
        expect(component.prevImage).toEqual(0);
    });
    it(' should call getAllImage() and return data of all images and update iterators ', async () => {
        const spy = spyOn(component.saveDraw, 'getAllImages').and.callFake(() => {
            return new Observable();
        });
        component.getAllImage();
        expect(spy).toHaveBeenCalled();
    });
    it(' should call resetIterators() and make nextImage=1 imageCenter=0 and prevImage=someNumber-1 ', () => {
        const someNumber = 1;
        component.resetIterators(someNumber);
        expect(component.prevImage).toEqual(0);
        expect(component.nextImage).toEqual(1);
        expect(component.imageCenter).toEqual(0);
    });

    it(' keyboardNavigation() should call scrollLeft() when pressing on left arrow ', () => {
        const spyKeyboardNavigation = spyOn(component, 'scrollLeft');
        const event = { code: Keyboard.LeftArrow } as KeyboardEvent;
        component.keyboardNavigation(event);
        expect(spyKeyboardNavigation).toHaveBeenCalled();
    });
    it(' keyboardNavigation() should call scrollRight() when pressing on right arrow ', () => {
        const spyKeyboardNavigation = spyOn(component, 'scrollRight');
        const event = { code: Keyboard.RightArrow } as KeyboardEvent;
        component.keyboardNavigation(event);
        expect(spyKeyboardNavigation).toHaveBeenCalled();
    });
    it(' enableShortcuts() should call enableShortcut()', () => {
        component.enableShortcuts();
        expect(component['shortcutManagerService'].enableShortcut).toHaveBeenCalled();
    });

    it(' enableShortcuts() should call enableShortcut()', () => {
        component.enableShortcuts();
        expect(component['shortcutManagerService'].enableShortcut).toHaveBeenCalled();
    });

    it(' should call deleteImage() and update iterators ', async () => {
        let drawingDataStub: Drawing[];
        drawingDataStub = [{ name: 'drawingName', tags: [''], dataUrl: '../../../assets/stamp-images/auto.png' }];
        component.imageData = drawingDataStub;
        spyOn(component.saveDraw, 'deleteData').and.callFake(() => {
            return new Observable();
        });
        component.deleteImage();
        expect(component.saveDraw.isSpinning).toEqual(true);
    });

    it('loadImage', () => {
        let drawingDataStub: Drawing[];
        drawingDataStub = [{ name: 'drawingName', tags: [''], dataUrl: '../../../assets/stamp-images/auto.png' }];
        const img = new Image();
        img.src = '../../../assets/stamp-images/auto.png';
        component.imageData = drawingDataStub;
        component.loadImage();
        const b = component['drawingService']['imageIsLoadedFromGallery'].getValue();
        expect(b).toBe(true);
        expect(component['drawingService'].canvas.height).toBe(img.naturalHeight);
    });

    it('select image ', () => {
        undoRedoService.canUndo.and.returnValue(false);
        const spy = spyOn(component, 'loadImage');
        component.selectImg();
        expect(spy).toHaveBeenCalled();
    });
    it('select image ', () => {
        spyOn(window, 'confirm').and.returnValue(true);
        const spy = spyOn(component, 'loadImage');
        component.selectImg();
        expect(spy).toHaveBeenCalled();
    });
});
