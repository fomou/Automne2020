import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, HostListener } from '@angular/core';
import { MatChipInputEvent } from '@angular/material/chips/chip-input';
import { Router } from '@angular/router';
import { LoadedImage } from '@app/classes/loaded-image';
import { canvasSize, MIN_LENGTH_TAG, NOT_FOUND } from '@app/constants/constants';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Drawing } from '@common/communication/drawing';

@Component({
    selector: 'app-gallery',
    templateUrl: './gallery.component.html',
    styleUrls: ['./gallery.component.scss'],
})
export class GalleryComponent {
    imageCenter: number = 0;
    prevImage: number = 0;
    nextImage: number = 0;
    imageData: Drawing[] = [];
    selectable: boolean = true;
    removable: boolean = true;
    addOnBlur: boolean = true;
    readonly separatorKeysCodes: number[] = [ENTER, COMMA];
    tags: string[] = [];

    constructor(
        public saveDraw: SaveDrawingService,
        private shortcutManagerService: ShortcutManagerService,
        private drawingService: DrawingService,
        private router: Router,
        private undoRedoService: UndoRedoService,
    ) {
        this.getAllImage();
    }
    add(event: MatChipInputEvent): void {
        const value = event.value;
        const input = event.input;

        if (value.length >= MIN_LENGTH_TAG && !this.tags.includes(value.trim())) {
            this.tags.push(value.trim());
        }
        if (input) input.value = '';
    }

    remove(tags: string): void {
        const index = this.tags.indexOf(tags);
        if (index >= NOT_FOUND) {
            this.tags.splice(index, 1);
        }
        if (this.tags.length === 0) {
            this.refresh();
        }
    }

    search(): void {
        this.imageData = this.filter();
        this.resetIterators(this.imageData.length);
    }

    filter(): Drawing[] {
        const temp: Drawing[] = [];
        for (const draw of this.imageData) {
            for (const tag of this.tags) {
                if (draw.tags.indexOf(tag) > NOT_FOUND && temp.indexOf(draw) === NOT_FOUND) {
                    temp.push(draw);
                    this.updateIterators();
                    break;
                }
            }
        }
        return temp;
    }

    refresh(): void {
        this.getAllImage();
    }

    scrollRight(): void {
        this.prevImage = this.imageCenter;
        this.imageCenter = this.nextImage;
        if (this.nextImage >= this.imageData.length - 1) {
            this.nextImage = 0;
        } else {
            this.nextImage++;
        }
    }

    scrollLeft(): void {
        this.nextImage = this.imageCenter;
        this.imageCenter = this.prevImage;
        if (this.prevImage === 0) {
            this.prevImage = this.imageData.length - 1;
        } else {
            this.prevImage--;
        }
    }

    updateIterators(): void {
        if (this.nextImage >= this.imageData.length - 1) {
            this.nextImage = 0;
        }
        if (this.prevImage >= this.imageData.length - 1) {
            this.prevImage--;
        }
        if (this.imageCenter >= this.imageData.length - 1) {
            this.imageCenter = this.nextImage;
            this.nextImage++;
            this.prevImage++;
        }
    }

    getAllImage(): void {
        this.saveDraw.getAllImages().subscribe((data) => {
            this.imageData = data;
            this.resetIterators(this.imageData.length);
        });
    }

    resetIterators(size: number): void {
        this.prevImage = size - 1;
        this.nextImage = 1;
        this.imageCenter = 0;
    }

    deleteImage(): void {
        this.saveDraw.isSpinning = true;
        this.saveDraw.deleteData(this.imageData[this.imageCenter].id as string).subscribe(
            () => {
                this.saveDraw.isServerRunning = true;
                this.saveDraw.isSpinning = false;
                this.imageData.splice(this.imageCenter, 1);
                this.updateIterators();
            },
            () => {
                this.saveDraw.isSpinning = false;
                this.saveDraw.isServerRunning = false;
            },
        );
    }

    selectImg(): void {
        if (this.router.url === '/home') {
            this.router.navigate(['/editor']);
            this.loadImage();
            return;
        }

        if (!this.undoRedoService.canUndo()) {
            this.loadImage();
            return;
        }
        if (window.confirm('Voulez-vous abandonner vos changements ? ')) {
            this.drawingService.clearCanvas(this.drawingService.baseCtx);
            this.drawingService.setBackground(this.drawingService.baseCtx);
            this.loadImage();
            this.undoRedoService.clearStacks();
        }
    }

    loadImage(): void {
        const image = new Image();
        image.src = this.imageData[this.imageCenter].dataUrl as string;
        this.drawingService.previewCanvas.height = this.drawingService.canvas.height = image.naturalHeight;
        this.drawingService.previewCanvas.width = this.drawingService.canvas.width = image.naturalWidth;
        this.drawingService.background.style.width = this.drawingService.borderCanvas.style.width = image.naturalWidth + 'px';
        this.drawingService.background.style.height = this.drawingService.borderCanvas.style.height = image.naturalHeight + 'px';
        canvasSize.DEFAULT_WIDTH = this.drawingService.canvas.width;
        canvasSize.DEFAULT_HEIGHT = this.drawingService.canvas.height;
        this.drawingService.imageIsLoadedFromGallery.next(true);
        image.onload = () => {
            this.drawingService.baseCtx.drawImage(image, 0, 0);
            const img = this.drawingService.getImageData();
            this.undoRedoService.loadedImage.next(new LoadedImage(img));
            this.enableShortcuts();
        };
    }

    @HostListener('window:keydown', ['$event'])
    keyboardNavigation(event: KeyboardEvent): void {
        if (event.code === Keyboard.LeftArrow) {
            this.scrollLeft();
        } else if (event.code === Keyboard.RightArrow) {
            this.scrollRight();
        }
    }

    enableShortcuts(): void {
        this.shortcutManagerService.enableShortcut();
    }
}
