import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatChipInputEvent, MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { SnackBarGeneralService } from '@app/services/snackbar-general/snackbar-general.service';
import { Observable } from 'rxjs';
import { SaveDrawingComponent } from './save-drawing.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
describe('SaveDrawingComponent', () => {
    let component: SaveDrawingComponent;
    let fixture: ComponentFixture<SaveDrawingComponent>;
    let saveDrawingStub: jasmine.SpyObj<SaveDrawingService>;
    let dialogStub: jasmine.SpyObj<MatDialog>;
    let shortcutManagerService: jasmine.SpyObj<ShortcutManagerService>;
    let snackBarService: jasmine.SpyObj<SnackBarGeneralService>;
    let snackBar: jasmine.SpyObj<MatSnackBar>;

    beforeEach(async(() => {
        saveDrawingStub = jasmine.createSpyObj('SaveDrawingService', ['addData', 'updateServer']);
        dialogStub = jasmine.createSpyObj('MatDialog', ['open', 'closeAll']);
        shortcutManagerService = jasmine.createSpyObj('ShortcutManagerService', ['enableShortcut']);
        snackBarService = jasmine.createSpyObj('SnackBarGeneralService', ['displayContext']);
        snackBar = jasmine.createSpyObj('MatSnackBar', ['openFromComponent']);

        TestBed.configureTestingModule({
            declarations: [SaveDrawingComponent],
            imports: [MatDialogModule, MatFormFieldModule, MatChipsModule, FormsModule, MatInputModule, BrowserAnimationsModule],
            providers: [
                { provide: SaveDrawingService, useValue: saveDrawingStub },
                { provide: MatDialog, useValue: dialogStub },
                { provide: ShortcutManagerService, useValue: shortcutManagerService },
                { provide: SnackBarGeneralService, useValue: snackBarService },
                { provide: MatSnackBar, useValue: snackBar },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SaveDrawingComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('add should call push to add tag in tags array if the tag has min length of 3 and a max length of 9 ', () => {
        const spy = spyOn(component.tags, 'push');
        const htmlInput = document.createElement('input');
        const event = { value: '  123  ', input: htmlInput } as MatChipInputEvent;
        component.add(event);
        expect(spy).toHaveBeenCalled();
        expect(event.input.value).toBe('');
    });
    it('invalidTag should return false if the pattern does not exist ', () => {
        const event = {
            key: 'a',
        } as KeyboardEvent;
        const validation = component.invalidTag(event);
        expect(validation).toEqual(true);
    });

    it('add should do nothing if the tag does not have has min length of 3 and a max length of 9 ', () => {
        component.tags = ['12'];
        const event = { value: '12' } as MatChipInputEvent;
        component.add(event);
        expect(component.tags.length).toEqual(1);
    });

    it('getDataName() should call getDataTag() ', () => {
        const drawingName = 'drawing';
        const spy = spyOn(component, 'getDataTag');
        component.getDataName(drawingName);
        expect(spy).toHaveBeenCalled();
        expect(component['name']).toEqual(drawingName);
    });
    it('getDataTag() should call confirm() then alert()', async () => {
        spyOn(window, 'confirm').and.returnValue(true);
        saveDrawingStub.addData.and.callFake(() => {
            return new Observable<string>();
        });
        component.getDataTag();
        expect(saveDrawingStub.addData).toHaveBeenCalled();
    });
    it('getDataTag() should call confirm() then alert()', () => {
        const spyConfirm = spyOn(window, 'confirm').and.returnValue(false);
        const spyAlert = spyOn(window, 'alert');
        component.getDataTag();
        expect(spyConfirm).toHaveBeenCalledWith('Voulez-vous sauvegarder le dessin ? ');
        expect(spyAlert).toHaveBeenCalledWith("'Votre dessin n'a pas été enregistré'");
    });

    it('remove should call indexOf() and splice()', () => {
        const spyIndexOf = spyOn(component.tags, 'indexOf').and.returnValue(0);
        const spySplice = spyOn(component.tags, 'splice');
        component.remove('tag2');
        expect(spyIndexOf).toHaveBeenCalled();
        expect(spySplice).toHaveBeenCalled();
    });
    it('should have array tags empty', () => {
        component.tags = ['tag1', 'tag2'];
        component.remove('tag');
        expect(component.tags.length).toEqual(2);
    });
    it('enableShortcuts should call enableShortCut', () => {
        component.enableShortcuts();
        expect(component['shortcutManagerService'].enableShortcut).toHaveBeenCalled();
    });
});
