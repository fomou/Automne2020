import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component } from '@angular/core';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SnackbarGeneralComponent } from '@app/components/snackbar-general/snackbar-general.component';
import { MIN_LENGTH_TAG, SNACKBAR_DISPLAY_TIME, SNACKBAR_TIME } from '@app/constants/constants';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { SnackBarGeneralService } from '@app/services/snackbar-general/snackbar-general.service';
@Component({
    selector: 'app-save-drawing',
    templateUrl: './save-drawing.component.html',
    styleUrls: ['./save-drawing.component.scss'],
})
export class SaveDrawingComponent {
    readonly separatorKeysCodes: number[] = [ENTER, COMMA];
    selectable: boolean = true;
    removable: boolean = true;
    addOnBlur: boolean = true;
    tags: string[] = [];
    name: string = '';
    imageData: string[];

    constructor(
        public saveDraw: SaveDrawingService,
        private dialog: MatDialog,
        private shortcutManagerService: ShortcutManagerService,
        private snackBarService: SnackBarGeneralService,
        private snackBar: MatSnackBar,
    ) {
        this.saveDraw.updateServer();
    }

    add(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;

        if (value.length >= MIN_LENGTH_TAG && !this.tags.includes(value.trim())) this.tags.push(value.trim());
        // Reinitialiser la valeur d'entrée
        if (input) {
            input.value = '';
        }
    }
    invalidTag(event: KeyboardEvent): boolean {
        if (/[^a-zA-Z0-9]/.test(event.key)) {
            event.preventDefault();
            this.snackBarService.displayContext('invalid');
            this.snackBar.openFromComponent(SnackbarGeneralComponent, { duration: SNACKBAR_TIME, panelClass: ['mat-toolbar', 'mat-warn'] });
            return false;
        } else return true;
    }
    remove(tags: string): void {
        const index = this.tags.indexOf(tags);

        if (index >= 0) {
            this.tags.splice(index, 1);
        }
    }

    getDataName(name: string): void {
        this.name = name;
        this.getDataTag();
        this.enableShortcuts();
    }
    getDataTag(): void {
        this.saveDraw.isSpinning = true;
        const TAGS_: string[] = [];
        for (let i = 0; i < this.tags.length; ++i) TAGS_[i] = this.tags[i];
        const confirm = window.confirm('Voulez-vous sauvegarder le dessin ? ');
        if (confirm) {
            this.saveDraw.addData({ name: this.name, tags: TAGS_ }).subscribe(
                () => {
                    this.saveDraw.isSpinning = false;
                    this.saveDraw.isServerRunning = true;
                    this.snackBarService.displayContext('save');
                    this.snackBar.openFromComponent(SnackbarGeneralComponent, {
                        duration: SNACKBAR_DISPLAY_TIME,
                        panelClass: ['mat-toolbar', 'mat-primary'],
                    });
                    this.dialog.closeAll();
                },
                () => {
                    this.saveDraw.isSpinning = false;
                    this.saveDraw.isServerRunning = false;
                    return;
                },
            );
        } else window.alert("'Votre dessin n'a pas été enregistré'");
    }

    enableShortcuts(): void {
        this.shortcutManagerService.enableShortcut();
    }
}
