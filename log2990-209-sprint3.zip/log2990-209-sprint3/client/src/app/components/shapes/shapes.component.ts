import { Component, HostListener, OnDestroy } from '@angular/core';
import { MatSliderChange } from '@angular/material/slider';
import { Keyboard } from '@app/enums/key-board';
import { ToolNames } from '@app/enums/tool-names';
import { ShortcutManagerService } from '@app/services//shortcut-manager/shortcut-manager.service';
import { DrawingTypeSelectorService } from '@app/services/drawing-type/drawing-type-selector.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools-selectors/tools-selector.service';
import { PolygonService } from '@app/services/tools/shapes/polygon/polygon.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-shapes',
    templateUrl: './shapes.component.html',
    styleUrls: ['./shapes.component.scss'],
})
export class ShapesComponent implements OnDestroy {
    private shortCutDisabled: boolean;
    isShowPolygonAttribute: boolean = false;
    isShowTraceType: boolean = false;
    isShowShapes: boolean = false;
    shape: string = ToolNames.Rectangle;
    sides: number = 3;
    private subscription: Subscription = new Subscription();
    constructor(
        private drawingType: DrawingTypeSelectorService,
        private toolsSelectorService: ToolsSelectorService,
        private polygon: PolygonService,
        private sidebarService: SidebarService,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.subscription = this.shortcutManagerService.shortcutObs$.subscribe((disabler) => {
            this.shortCutDisabled = disabler;
        });
    }
    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
    changeWidthShape(event: MatSliderChange): void {
        this.sidebarService.changeWidthShape(event.value as number);
    }

    showShapes(): void {
        this.isShowTraceType = false;
        this.isShowShapes = !this.isShowShapes;
    }

    changeDrawingType(type: string): void {
        this.drawingType.changeDrawingType(type);
        this.isShowTraceType = false;
    }

    formatLabel(value: number): string {
        return (value + 'px') as string;
    }

    showTraceType(): void {
        this.isShowShapes = false;
        this.isShowTraceType = !this.isShowTraceType;
    }

    showRectangleAttribute(): void {
        this.isShowPolygonAttribute = false;
        this.shape = ToolNames.Rectangle;
        const tool = this.toolsSelectorService.getToolByKey(Keyboard.One);
        this.toolsSelectorService.shapeTool = tool;
        this.toolsSelectorService.changeTool(tool);
        this.isShowShapes = false;
    }

    showEllipseAttribute(): void {
        this.isShowPolygonAttribute = false;
        this.shape = ToolNames.Ellipse;
        const tool = this.toolsSelectorService.getToolByKey(Keyboard.Two);
        this.toolsSelectorService.shapeTool = tool;
        this.toolsSelectorService.changeTool(tool);
        this.isShowShapes = false;
    }

    showPolygonAttribute(): void {
        this.isShowPolygonAttribute = true;
        this.shape = ToolNames.Polygon;
        const tool = this.toolsSelectorService.getToolByKey(Keyboard.Three);
        this.toolsSelectorService.shapeTool = tool;
        this.toolsSelectorService.changeTool(tool);
        this.isShowShapes = false;
    }

    getSides(sides: number): void {
        this.sides = sides;
        this.polygon.sides = this.sides;
    }

    returnShapeBrush(): number {
        return this.sidebarService.widthShape;
    }

    @HostListener('window:keydown', ['$event'])
    onkeydown(event: KeyboardEvent): void {
        if (this.shortCutDisabled) {
            return;
        }
        switch (event.code) {
            case Keyboard.Three: {
                this.showPolygonAttribute();
                break;
            }
            case Keyboard.One:
                this.showRectangleAttribute();
                break;
            case Keyboard.Two:
                this.showEllipseAttribute();
                break;
        }
    }
}
