import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatSliderChange, MatSliderModule } from '@angular/material/slider';
import { Tool } from '@app/classes/tool';
import { Keyboard } from '@app/enums/key-board';
import { DrawingTypeSelectorService } from '@app/services/drawing-type/drawing-type-selector.service';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SelectionEllipseService } from '@app/services/selections/selection/selection-ellipse/selection-ellipse.service';
import { MagicWandService } from '@app/services/selections/selection/selection-magic-wand/magic-wand.service';
import { SelectionRectangleService } from '@app/services/selections/selection/selection-rectangle/selection-rectangle.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools-selectors/tools-selector.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { BrushService } from '@app/services/tools/plotting-tools/brush/brush.service';
import { CalligraphyService } from '@app/services/tools/plotting-tools/calligraphy/calligraphy.service';
import { PencilService } from '@app/services/tools/plotting-tools/pencil/pencil-service';
import { SprayPaintService } from '@app/services/tools/plotting-tools/spray-paint/spray-paint.service';
import { EllipseService } from '@app/services/tools/shapes/ellipse/ellipse.service';
import { PolygonService } from '@app/services/tools/shapes/polygon/polygon.service';
import { RectangleService } from '@app/services/tools/shapes/rectangle/rectangle.service';
import { StampService } from '@app/services/tools/stamp/stamp.service';
import { TextService } from '@app/services/tools/text/text.service';
import { ShapesComponent } from './shapes.component';
class ToolSelector extends ToolsSelectorService {
    getToolByKey(s: string): Tool {
        return {} as Tool;
    }
    // tslint:disable:no-empty

    changeTool(t: Tool): void {}
}
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
// tslint:disable: no-any
describe('ShapesComponent', () => {
    let component: ShapesComponent;
    let fixture: ComponentFixture<ShapesComponent>;
    let sideBareStub: SidebarService;
    let toolSelect: ToolsSelectorService;
    let drawType: DrawingTypeSelectorService;
    let polygon: PolygonService;
    let drawingService: jasmine.SpyObj<DrawingService>;

    beforeEach(async(() => {
        sideBareStub = new SidebarService();
        drawType = new DrawingTypeSelectorService();
        const rect = {} as RectangleService;
        const ellipse = {} as EllipseService;
        polygon = { sides: 10 } as PolygonService;
        const pen = {} as PencilService;
        const brush = {} as BrushService;
        const era = {} as EraseService;
        const line = {} as LineService;
        const bucket = {} as PaintBucketService;
        const pipette = {} as PickerService;
        const selRect = {} as SelectionRectangleService;
        const selEll = {} as SelectionEllipseService;
        const stamp = {} as StampService;
        const spray = {} as SprayPaintService;
        const text = {} as TextService;

        const calligraphy = {} as CalligraphyService;
        const magicWand = {} as MagicWandService;
        drawingService = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        toolSelect = new ToolSelector(
            drawingService,
            pen,
            rect,
            ellipse,
            line,
            era,
            brush,
            polygon,
            pipette,
            bucket,
            selRect,
            selEll,
            magicWand,
            stamp,
            spray,
            calligraphy,
            text,
        );

        TestBed.configureTestingModule({
            declarations: [ShapesComponent],
            imports: [MatSliderModule],
            providers: [
                { provide: SidebarService, useValue: sideBareStub },
                { provide: ToolsSelectorService, useValue: toolSelect },
                { provide: DrawingTypeSelectorService, useValue: drawType },
                { provide: PolygonService, useValue: polygon },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ShapesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(' should change shape size in slideBarService ', () => {
        const spy = spyOn(sideBareStub, 'changeWidthShape').and.callThrough();
        const event = { value: 30 } as MatSliderChange;
        component.changeWidthShape(event);
        expect(spy).toHaveBeenCalledWith(event.value as number);
    });

    it('showShape should set v to false and change  showShapes', () => {
        component.isShowShapes = true;
        component.showShapes();
        expect(component.isShowShapes).toBe(false);
        expect(component.isShowTraceType).toBe(false);
    });

    it('changeDrawingType should call changeDrawingType of the service ', () => {
        const spy = spyOn(drawType, 'changeDrawingType').and.callThrough();
        component.changeDrawingType('fill');
        expect(spy).toHaveBeenCalledWith('fill');
        expect(component.isShowTraceType).toBe(false);
    });

    it('formatLab should give a string', () => {
        const expected = '10px';
        expect(component.formatLabel(10)).toBe(expected);
    });

    it('showShape should set v to false and change  showShapes', () => {
        component.isShowTraceType = true;
        component.showTraceType();
        expect(component.isShowShapes).toBe(false);
        expect(component.isShowTraceType).toBe(false);
    });

    it('showRectangleAttributes should change tool', () => {
        const changeSpy = spyOn<any>(toolSelect, 'changeTool').and.callFake(() => {
            return;
        });
        const getSpy = spyOn(toolSelect, 'getToolByKey').and.callThrough();
        component.showRectangleAttribute();
        expect(getSpy).toHaveBeenCalled();
        expect(component.shape).toBe('Rectangle');
        expect(component.isShowPolygonAttribute).toEqual(false);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('showRectangleAttributes should change tool', () => {
        const changeSpy = spyOn<any>(toolSelect, 'changeTool').and.callFake(() => {
            return;
        });
        const getSpy = spyOn(toolSelect, 'getToolByKey').and.callThrough();
        component.showEllipseAttribute();
        expect(getSpy).toHaveBeenCalled();
        expect(component.shape).toBe('Ellipse');
        expect(component.isShowPolygonAttribute).toEqual(false);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('showPolygonAttributes should change tool', () => {
        const changeSpy = spyOn<any>(toolSelect, 'changeTool').and.callFake(() => {
            return;
        });
        const getSpy = spyOn(toolSelect, 'getToolByKey').and.callThrough();
        component.showPolygonAttribute();
        expect(getSpy).toHaveBeenCalled();
        expect(component.shape).toBe('Polygone');
        expect(component.isShowPolygonAttribute).toEqual(true);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('should change polygon sides', () => {
        component.getSides(20);
        expect(polygon.sides).toEqual(20);
    });

    it('should return width from sidebar service', () => {
        const expected = sideBareStub.widthShape;
        expect(component.returnShapeBrush()).toEqual(expected);
    });

    it('onkeydown should call showPolygonAttribute when 3 is hit on keyboard', () => {
        const spy = spyOn(component, 'showPolygonAttribute').and.callThrough();
        const event = { code: Keyboard.Three } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call showRectangleAttribute when 1 is hit on keyboard', () => {
        const spy = spyOn(component, 'showRectangleAttribute').and.callThrough();
        const event = { code: Keyboard.One } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call showEllipseAttribute when 2 is hit on keyboard', () => {
        const spy = spyOn(component, 'showEllipseAttribute').and.callThrough();
        const event = { code: Keyboard.Two } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call showEllipseAttributes when 2 is hit on keyboard', () => {
        component['shortCutDisabled'] = true;
        const spy = spyOn(component, 'showEllipseAttribute').and.callThrough();
        const event = { code: Keyboard.Two } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).not.toHaveBeenCalled();
    });

    it('subscribe should give the value from the service', () => {
        const spy = spyOn(component['subscription'], 'unsubscribe');
        component.ngOnDestroy();
        expect(spy);
    });
});
