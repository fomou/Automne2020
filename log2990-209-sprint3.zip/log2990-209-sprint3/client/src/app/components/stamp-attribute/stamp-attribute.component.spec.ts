import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material/dialog';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { StampService } from '@app/services/tools/stamp/stamp.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { of } from 'rxjs';
import { StampAttributeComponent } from './stamp-attribute.component';

// tslint:disable: no-string-literal
describe('StampAttributeComponent', () => {
    let component: StampAttributeComponent;
    let fixture: ComponentFixture<StampAttributeComponent>;
    let matDialog: jasmine.SpyObj<MatDialogRef<StampAttributeComponent>>;
    let stampService: StampService;
    beforeEach(async(() => {
        matDialog = jasmine.createSpyObj('MatDialogRef', ['close']);
        stampService = new StampService({} as DrawingService, {} as UndoRedoService);
        stampService['srcObserver$'] = of('');
        TestBed.configureTestingModule({
            declarations: [StampAttributeComponent],
            providers: [
                { provide: MatDialogRef, useValue: matDialog },
                { provide: StampService, useValue: stampService },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(StampAttributeComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('changeStamp should pur sting in stamp src', () => {
        component.changeStamp('src');
        expect(component['stamp'].src).toEqual('src');
    });
});
