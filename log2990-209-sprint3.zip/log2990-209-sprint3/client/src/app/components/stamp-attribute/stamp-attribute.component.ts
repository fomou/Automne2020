import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { NAME_INDEX, SVG_POSITION } from '@app/constants/constants';
import { StampService } from '@app/services/tools/stamp/stamp.service';

@Component({
    selector: 'app-stamp-attribute',
    templateUrl: './stamp-attribute.component.html',
    styleUrls: ['./stamp-attribute.component.scss'],
})
export class StampAttributeComponent {
    source: string[] = [];

    constructor(private stamp: StampService, private dialogRef: MatDialogRef<StampAttributeComponent>) {
        this.source.push('../../../assets/stamp-images/liftarn_Barett.svg');
        this.source.push('../../../assets/stamp-images/person_molotov_cocktail.svg');
        this.source.push('../../../assets/stamp-images/liftarn_Raised_fist.svg');
        this.source.push('../../../assets/stamp-images/log2990.png');
        this.source.push('../../../assets/stamp-images/Flag_of_Canada.svg');
        this.source.push('../../../assets/stamp-images/molotov_cocktail.svg');
        this.source.push('../../../assets/stamp-images/butterfly.png');

        this.source.push('../../../assets/stamp-images/liftarn_Black_horse.svg');
        this.source.push('../../../assets/stamp-images/liftarn_Raised_fist_1.svg');
    }

    changeStamp(src: string): void {
        this.stamp.src = src;
        this.stamp.srcEmitter.next(src.slice(NAME_INDEX, src.length - SVG_POSITION));
        this.dialogRef.close();
    }
}
