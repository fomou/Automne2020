import { AfterViewInit, Component, ElementRef, HostListener, OnDestroy, Renderer2, ViewChild } from '@angular/core';
import { Resize } from '@app/classes/resize';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import { canvasSize, MAX_SIZE_HEIGHT, MAX_SIZE_WIDTH, MINIMUM_WINDOW_SIZE, WIDTH_SIDEBAR } from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SelectionEllipseService } from '@app/services/selections/selection/selection-ellipse/selection-ellipse.service';
import { SelectionRectangleService } from '@app/services/selections/selection/selection-rectangle/selection-rectangle.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { ToolsSelectorService } from '@app/services/tools-selectors/tools-selector.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { BrushService } from '@app/services/tools/plotting-tools/brush/brush.service';
import { PencilService } from '@app/services/tools/plotting-tools/pencil//pencil-service';
import { EllipseService } from '@app/services/tools/shapes/ellipse/ellipse.service';
import { RectangleService } from '@app/services/tools/shapes/rectangle/rectangle.service';
import { TextService } from '@app/services/tools/text/text.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-drawing',
    templateUrl: './drawing.component.html',
    styleUrls: ['./drawing.component.scss'],
})
export class DrawingComponent implements AfterViewInit, OnDestroy {
    @ViewChild('baseCanvas', { static: false }) baseCanvas: ElementRef<HTMLCanvasElement>;
    @ViewChild('previewCanvas', { static: false }) previewCanvas: ElementRef<HTMLCanvasElement>;
    @ViewChild('borderCanvas', { static: false }) borderCanvas: ElementRef<HTMLDivElement>;
    @ViewChild('both', { static: true }) both: ElementRef<HTMLDivElement>;
    @ViewChild('bottom', { static: true }) bottom: ElementRef<HTMLDivElement>;
    @ViewChild('right', { static: true }) right: ElementRef<HTMLDivElement>;
    @ViewChild('background', { static: true }) background: ElementRef<HTMLDivElement>;

    shortcutDisable: boolean;
    private baseCtx: CanvasRenderingContext2D;
    private previewCtx: CanvasRenderingContext2D;
    private canvasSize: Vec2 = { x: canvasSize.DEFAULT_WIDTH, y: canvasSize.DEFAULT_HEIGHT };
    private isNotResizing: boolean = true;
    private subscriptions: Subscription[] = [];
    private tools: Tool[];
    private currentTool: Tool;
    private listenMouseDown: () => void;
    private listenMouseMove: () => void;
    private listenMouseUp: () => void;

    shouldReplaceCursor: boolean = false;

    constructor(
        private drawingService: DrawingService,
        private toolsSelectorService: ToolsSelectorService,
        private undoRedoService: UndoRedoService,
        private pencilService: PencilService,
        private rectangleService: RectangleService,
        private ellipseService: EllipseService,
        private lineService: LineService,
        private eraseService: EraseService,
        private brushService: BrushService,
        private paintBucketService: PaintBucketService,
        private selectionEllipseService: SelectionEllipseService,
        private selectionRectangleService: SelectionRectangleService,
        private textService: TextService,
        private renderer2: Renderer2,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.tools = [
            this.pencilService,
            this.rectangleService,
            this.ellipseService,
            this.lineService,
            this.eraseService,
            this.brushService,
            this.paintBucketService,
            this.selectionRectangleService,
            this.selectionEllipseService,
            this.textService,
        ];
        this.currentTool = this.tools[0];
        const subsTools = this.toolsSelectorService.tool$.subscribe((tool) => {
            this.currentTool = tool;
            this.shouldReplaceCursor = this.toolsSelectorService.replaceCursor();
        });

        const subsDisable = this.shortcutManagerService.shortcutObs$.subscribe((disable) => {
            this.shortcutDisable = disable;
        });
        this.subscriptions.push(subsTools);
        this.subscriptions.push(subsDisable);
    }

    get width(): number {
        return this.canvasSize.x;
    }

    get height(): number {
        return this.canvasSize.y;
    }

    ngAfterViewInit(): void {
        this.baseCtx = this.baseCanvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        this.previewCtx = this.previewCanvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        this.drawingService.baseCtx = this.baseCtx;
        this.drawingService.previewCtx = this.previewCtx;
        this.drawingService.canvas = this.baseCanvas.nativeElement;
        this.drawingService.previewCanvas = this.previewCanvas.nativeElement;
        this.drawingService.borderCanvas = this.borderCanvas.nativeElement;
        this.drawingService.background = this.background.nativeElement;
        this.background.nativeElement.style.width = this.borderCanvas.nativeElement.style.width = this.canvasSize.x + 'px';
        this.background.nativeElement.style.height = this.borderCanvas.nativeElement.style.height = this.canvasSize.y + 'px';
        this.drawingService.setBackground(this.drawingService.baseCtx);
        const bothDiv = this.both.nativeElement;
        const rightDiv = this.right.nativeElement;
        const bottom = this.bottom.nativeElement;
        this.listenMouseDown = this.renderer2.listen(bothDiv, 'mousedown', () => {
            this.isNotResizing = false;
            this.listenMouseMove = this.renderer2.listen('window', 'mousemove', (event: MouseEvent) => {
                const width = event.pageX - WIDTH_SIDEBAR;
                const height = event.pageY;
                if (width > MINIMUM_WINDOW_SIZE && width < window.innerWidth - MAX_SIZE_WIDTH)
                    this.borderCanvas.nativeElement.style.width = width + 'px';
                if (height > MINIMUM_WINDOW_SIZE && height < window.innerHeight - MAX_SIZE_HEIGHT)
                    this.borderCanvas.nativeElement.style.height = height + 'px';
                this.undoRedoService.setToolInUse(true);
            });

            this.listenMouseUp = this.renderer2.listen('window', 'mouseup', () => {
                this.listenMouseMove();
                this.listenMouseUp();
                this.undoRedoService.setToolInUse(false);
                const oldCanvas = this.baseCanvas.nativeElement.toDataURL('image/png');
                const image = new Image();

                image.onload = () => {
                    this.drawingService.setBackground(this.baseCtx);
                    this.baseCtx.drawImage(image, 0, 0);
                };

                const dh = parseInt(this.borderCanvas.nativeElement.style.height, 10) - this.baseCanvas.nativeElement.height;
                const dw = parseInt(this.borderCanvas.nativeElement.style.width, 10) - this.baseCanvas.nativeElement.width;

                const resize = new Resize(
                    this.drawingService,
                    image,
                    this.baseCanvas.nativeElement.width,
                    this.baseCanvas.nativeElement.height,
                    dw,
                    dh,
                );
                this.undoRedoService.setToolInUse(false);
                this.undoRedoService.addToStack(resize);
                image.src = oldCanvas;

                this.drawingService.widthGrid = this.canvasSize.x = parseInt(this.borderCanvas.nativeElement.style.width, 10);
                this.drawingService.heightGrid = this.canvasSize.y = parseInt(this.borderCanvas.nativeElement.style.height, 10);
                this.isNotResizing = true;
            });
        });

        this.listenMouseDown = this.renderer2.listen(rightDiv, 'mousedown', () => {
            this.isNotResizing = false;
            this.listenMouseMove = this.renderer2.listen('window', 'mousemove', (event: MouseEvent) => {
                const width = event.pageX - WIDTH_SIDEBAR;
                const height = this.baseCanvas.nativeElement.height;
                if (width > MINIMUM_WINDOW_SIZE && window.innerWidth - MAX_SIZE_WIDTH) this.borderCanvas.nativeElement.style.width = width + 'px';
                if (height > MINIMUM_WINDOW_SIZE && height < window.innerHeight) this.borderCanvas.nativeElement.style.height = height + 'px';
                this.undoRedoService.setToolInUse(true);
            });

            this.listenMouseUp = this.renderer2.listen('window', 'mouseup', () => {
                this.listenMouseMove();
                this.listenMouseUp();

                this.undoRedoService.setToolInUse(false);
                const oldCanvas = this.baseCanvas.nativeElement.toDataURL('image/png');
                const image = new Image();
                image.src = oldCanvas;
                const dw = parseInt(this.borderCanvas.nativeElement.style.width, 10) - this.baseCanvas.nativeElement.width;

                const resize = new Resize(
                    this.drawingService,
                    image,
                    this.baseCanvas.nativeElement.width,
                    this.baseCanvas.nativeElement.height,
                    dw,
                    0,
                );
                this.undoRedoService.addToStack(resize);

                this.drawingService.widthGrid = this.canvasSize.x = parseInt(this.borderCanvas.nativeElement.style.width, 10);
                this.drawingService.heightGrid = this.canvasSize.y = parseInt(this.borderCanvas.nativeElement.style.height, 10);

                this.isNotResizing = true;
                image.onload = () => {
                    this.drawingService.setBackground(this.baseCtx);
                    this.baseCtx.drawImage(image, 0, 0);
                };
            });
        });

        this.listenMouseDown = this.renderer2.listen(bottom, 'mousedown', () => {
            this.isNotResizing = false;

            this.listenMouseMove = this.renderer2.listen('window', 'mousemove', (event: MouseEvent) => {
                const width = this.baseCanvas.nativeElement.width;
                const height = event.offsetY;
                if (width > MINIMUM_WINDOW_SIZE && width < window.innerWidth) this.borderCanvas.nativeElement.style.width = width + 'px';
                if (height > MINIMUM_WINDOW_SIZE && height < window.innerHeight - MAX_SIZE_HEIGHT)
                    this.borderCanvas.nativeElement.style.height = height + 'px';
                this.undoRedoService.setToolInUse(true);
            });

            this.listenMouseUp = this.renderer2.listen('window', 'mouseup', () => {
                this.listenMouseMove();
                this.listenMouseUp();
                this.undoRedoService.setToolInUse(false);
                const oldCanvas = this.baseCanvas.nativeElement.toDataURL('image/png');
                const image = new Image();

                image.onload = () => {
                    this.drawingService.setBackground(this.baseCtx);
                    this.baseCtx.drawImage(image, 0, 0);
                };

                const dh = parseInt(this.borderCanvas.nativeElement.style.height, 10) - this.baseCanvas.nativeElement.height;

                const resize = new Resize(
                    this.drawingService,
                    image,
                    this.baseCanvas.nativeElement.width,
                    this.baseCanvas.nativeElement.height,
                    0,
                    dh,
                );
                this.undoRedoService.addToStack(resize);

                image.src = oldCanvas;
                this.drawingService.widthGrid = this.canvasSize.x = parseInt(this.borderCanvas.nativeElement.style.width, 10);
                this.drawingService.heightGrid = this.canvasSize.y = parseInt(this.borderCanvas.nativeElement.style.height, 10);

                this.isNotResizing = true;
            });
        });
    }

    ngOnDestroy(): void {
        this.listenMouseDown();
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }

    @HostListener('document: mousemove', ['$event'])
    onMouseMove(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onMouseMove(event);
    }

    @HostListener('mousedown', ['$event'])
    onMouseDown(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onMouseDown(event);
    }

    @HostListener('document: mouseup', ['$event'])
    onMouseUp(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onMouseUp(event);
    }

    @HostListener('mouseleave', ['$event'])
    onMouseLeave(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onMouseLeave(event);
        localStorage.setItem('draw', this.drawingService.getImage());
        localStorage.setItem('height', this.drawingService.canvas.height.toString());
        localStorage.setItem('width', this.drawingService.canvas.width.toString());
    }

    @HostListener('mouseenter', ['$event'])
    onMouseEnter(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onMouseEnter(event);
    }
    @HostListener('wheel', ['$event'])
    onMouseWheel(event: WheelEvent): void {
        this.currentTool.onMouseWheel(event);
    }

    @HostListener('window:keydown', ['$event'])
    onkeydown(event: KeyboardEvent): void {
        this.currentTool.onKeyDown(event);
        this.undoRedoService.onKeyDown(event);
    }

    @HostListener('window:keyup', ['$event'])
    onKeyUp(event: KeyboardEvent): void {
        if (this.isNotResizing) this.currentTool.onKeyUp(event);
    }

    @HostListener('click', ['$event'])
    onClick(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onClick(event);
    }
    @HostListener('document:click', ['$event'])
    onDocumentClick(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onDocumentClick(event);
    }

    @HostListener('dblclick', ['$event'])
    onDoubleClick(event: MouseEvent): void {
        if (this.isNotResizing) this.currentTool.onDoubleClick(event);
    }

    @HostListener('window:keydown.control.o', ['$event'])
    createNewDrawing(event: KeyboardEvent): void {
        if (!this.undoRedoService.canUndo() && !this.drawingService.imageLoadedFromGallery()) {
            return;
        }
        event.preventDefault();
        if (window.confirm('Voulez-vous abandonner vos changement ?')) {
            this.drawingService.setBackground(this.drawingService.baseCtx);
            this.undoRedoService.clearStacks();
            this.drawingService.imageIsLoadedFromGallery.next(false);
        }
    }

    @HostListener('contextmenu', ['$event'])
    disableContextMenu(event: MouseEvent): void {
        event.preventDefault();
    }
}
