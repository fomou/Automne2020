import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSliderChange, MatSliderModule } from '@angular/material/slider';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { StampService } from '@app/services/tools/stamp/stamp.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { of } from 'rxjs';
import { StampComponent } from './stamp.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
describe('StampComponent', () => {
    let component: StampComponent;
    let fixture: ComponentFixture<StampComponent>;
    let dialogStub: jasmine.SpyObj<MatDialog>;
    let stampService: StampService;
    beforeEach(async(() => {
        dialogStub = jasmine.createSpyObj('MatDialog', ['open']);
        stampService = new StampService({} as DrawingService, {} as UndoRedoService);
        stampService['srcObserver$'] = of('');
        TestBed.configureTestingModule({
            declarations: [StampComponent],
            imports: [MatSliderModule, MatDialogModule],
            providers: [
                { provide: StampService, useValue: stampService },
                { provide: MatDialog, useValue: dialogStub },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(StampComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('open should call open', () => {
        component.open();
        expect(component['matDialog'].open).toHaveBeenCalled();
    });
    it('changeScale should call changeScale', () => {
        const event = {
            value: 30,
        } as MatSliderChange;
        const spy = spyOn(component['stamp'], 'changeScale');
        component.changeScale(event);
        expect(spy).toHaveBeenCalled();
    });
    it('formatLabelScale should return number as string', () => {
        const result = component.formatLabelScale(10);
        expect(result).toEqual('10');
    });
    it('formatLabel should number as string and add ° to it ', () => {
        const result = component.formatLabel(10);
        expect(result).toEqual('10°');
    });
    it('changeAngle should call changeAngle ', () => {
        const event = {
            value: 30,
        } as MatSliderChange;
        const spy = spyOn(component['stamp'], 'changeAngle');
        component.changeAngle(event);
        expect(spy).toHaveBeenCalled();
    });
    it('angle should call round ', () => {
        const spy = spyOn(Math, 'round');
        component.angle();
        expect(spy).toHaveBeenCalled();
    });

    it('ngDestroy should unsuscribe the subscription', () => {
        const spy = spyOn(component['subscription'], 'unsubscribe');
        component.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
});
