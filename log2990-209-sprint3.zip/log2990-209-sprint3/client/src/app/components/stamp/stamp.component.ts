import { Component, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSliderChange } from '@angular/material/slider';
import { StampAttributeComponent } from '@app/components/stamp-attribute/stamp-attribute.component';
import { DEGREE_180 } from '@app/constants/constants';
import { StampService } from '@app/services/tools/stamp/stamp.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-stamp',
    templateUrl: './stamp.component.html',
    styleUrls: ['./stamp.component.scss'],
})
export class StampComponent implements OnDestroy {
    scale: string = '1';
    angleString: string = '0°';
    stampName: string;
    private subscription: Subscription = new Subscription();

    constructor(private stamp: StampService, private matDialog: MatDialog) {
        this.subscription = this.stamp.srcObserver$.subscribe((name) => {
            this.stampName = name;
        });
    }
    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
    open(): void {
        this.matDialog.open(StampAttributeComponent, {
            width: '600px',
            height: '400px',
        });
    }

    changeScale(event: MatSliderChange): void {
        this.stamp.changeScale(event.value as number);
        this.scale = this.formatLabelScale(event.value as number);
    }

    formatLabelScale(value: number): string {
        return value.toString(10);
    }
    formatLabel(value: number): string {
        return value + '°';
    }

    changeAngle(event: MatSliderChange): void {
        this.stamp.changeAngle(event.value as number);
    }
    angle(): number {
        const angle = Math.round((this.stamp.angle * DEGREE_180) / Math.PI) % DEGREE_180;
        return angle;
    }
}
