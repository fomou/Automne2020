import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderModule } from '@angular/material/slider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ColorPanelComponent } from '@app/components/color/color-panel/color-panel.component';
import { DrawingToolsComponent } from '@app/components/drawing-tools/drawing-tools.component';
import { DrawingComponent } from '@app/components/drawing/drawing.component';
import { GridAttributesComponent } from '@app/components/grid-attributes/grid-attributes.component';
import { GridComponent } from '@app/components/grid/grid.component';
import { PixelPickerComponent } from '@app/components/pixel-picker/pixel-picker.component';
import { ShapesComponent } from '@app/components/shapes/shapes.component';
import { SidebarComponent } from '@app/components/sidebar/sidebar.component';
import { StampComponent } from '@app/components/stamp/stamp.component';
import { EditorComponent } from './editor.component';

describe('EditorComponent', () => {
    let component: EditorComponent;
    let fixture: ComponentFixture<EditorComponent>;
    let matDialogStub: jasmine.SpyObj<MatDialog>;

    beforeEach(async(() => {
        matDialogStub = jasmine.createSpyObj('MatDialog', ['open']);
        TestBed.configureTestingModule({
            declarations: [
                EditorComponent,
                DrawingComponent,
                SidebarComponent,
                ColorPanelComponent,
                DrawingToolsComponent,
                ShapesComponent,
                PixelPickerComponent,
                StampComponent,
                GridAttributesComponent,
                GridComponent,
            ],
            imports: [
                BrowserModule,
                HttpClientModule,
                BrowserAnimationsModule,
                MatSliderModule,
                MatSlideToggleModule,
                MatDialogModule,
                FormsModule,
                ReactiveFormsModule,
                MatDialogModule,
                MatButtonModule,
                MatIconModule,
                MatFormFieldModule,
                MatButtonModule,
                MatSelectModule,
                MatRadioModule,
                MatInputModule,
                MatChipsModule,
                MatSnackBarModule,
            ],
            providers: [{ provide: MatDialog, useValue: matDialogStub }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EditorComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
