import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SnackbarGeneralComponent } from '@app/components/snackbar-general/snackbar-general.component';
import { SNACKBAR_DISPLAY_TIME, SNACKBAR_TIME } from '@app/constants/constants';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { SnackBarGeneralService } from '@app/services/snackbar-general/snackbar-general.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-export',
    templateUrl: './export.component.html',
    styleUrls: ['./export.component.scss'],
})
export class ExportComponent implements OnInit {
    @ViewChild('canvas', { static: true }) canvas: ElementRef<HTMLCanvasElement>;

    private readonly DEFAULT_SERVER_EMAIL: string = 'http://localhost:3000/api/sendEmail';
    private chosenExportMode: string = '';
    private ctx: CanvasRenderingContext2D;

    disabled: boolean = true;
    filters: string[] = ['none', 'sepia(10)', 'grayscale(50%)', 'blur(2px)', 'invert(100)'];
    filter: string;
    typeExport: string = 'Exporter localement';
    fileName: string = '';
    userEmail: string = '';
    exportModes: string[] = ['PNG', 'JPEG'];
    isShownEmail: boolean = false;

    constructor(
        private drawingService: DrawingService,
        private dialogRef: MatDialogRef<ExportComponent>,
        private shortcutManagerService: ShortcutManagerService,
        private http: HttpClient,
        private snackBar: MatSnackBar,
        private snackBarService: SnackBarGeneralService,
    ) {}

    ngOnInit(): void {
        this.loadDrawing();
    }

    loadDrawing(filter: string = 'none'): void {
        this.ctx = this.canvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        const image = new Image();
        image.width = this.ctx.canvas.width;
        image.height = this.ctx.canvas.height;
        image.src = this.drawingService.canvas.toDataURL('image/png');
        this.ctx.filter = filter;
        image.onload = () => {
            this.ctx.drawImage(image, 0, 0, image.width, image.height);
        };
    }

    changeFilter(event: MatRadioChange): void {
        this.filter = event.value;
        this.loadDrawing(this.filter);
    }
    sendAsEmail(event: MatSelectChange): void {
        if (event.value === 'email') {
            this.isShownEmail = true;
            this.validateEmail(this.userEmail);
        } else {
            this.isShownEmail = false;
            this.disabled = true;
        }
    }
    validateEmail(email: string): void {
        const regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        this.disabled = regex.test(String(email).toLowerCase());
    }

    validateName(event: KeyboardEvent): boolean {
        if (event.code !== Keyboard.Period) return true;
        else {
            this.snackBarService.displayContext('invalid');
            this.snackBar.openFromComponent(SnackbarGeneralComponent, { duration: SNACKBAR_TIME, panelClass: ['mat-toolbar', 'mat-warn'] });
            event.preventDefault();
            return false;
        }
    }
    chooseExportingMode(event: MatRadioChange): void {
        this.chosenExportMode = event.value === 'PNG' ? 'png' : 'jpeg';
    }
    exportDraw(): void {
        switch (this.chosenExportMode) {
            case 'png':
                this.export(this.fileName, this.filter);

                break;
            case 'jpeg':
                this.export(this.fileName, this.filter);

                break;
            default:
                alert('Veuillez choisir le format de l image à exporter ');
        }
    }

    export(fileName: string, filter: string): void | Subscription {
        const canvas = document.createElement('canvas');
        const canvasCtx = canvas.getContext('2d') as CanvasRenderingContext2D;
        canvas.width = this.drawingService.canvas.width;
        canvas.height = this.drawingService.canvas.height;
        canvasCtx.filter = filter;
        canvasCtx.drawImage(this.drawingService.canvas, 0, 0);
        const image = canvas.toDataURL('image/' + this.chosenExportMode);
        if (!confirm("'Confirmez l'export du dessin'")) return;
        if (!this.isShownEmail) {
            const link = document.createElement('a');
            link.download = fileName;
            link.href = image;
            link.click();
            link.remove();
            this.cancel();
        } else {
            const drawToExport = {
                drawUrl: image as string,
                fileName: this.fileName,
                email: this.userEmail,
                typeImage: this.chosenExportMode,
            };
            this.cancel();
            this.snackBarService.displayContext('email');
            this.snackBar.openFromComponent(SnackbarGeneralComponent, {
                duration: SNACKBAR_DISPLAY_TIME,
                panelClass: ['mat-toolbar', 'mat-primary'],
            });
            return this.http.post<string>(this.DEFAULT_SERVER_EMAIL, drawToExport).subscribe();
        }
    }

    cancel(): void {
        this.dialogRef.close();
        this.shortcutManagerService.enableShortcut();
    }
}
