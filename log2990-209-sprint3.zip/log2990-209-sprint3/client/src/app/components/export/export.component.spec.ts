import { HttpClient } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatRadioChange, MatRadioModule } from '@angular/material/radio';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { SnackBarGeneralService } from '@app/services/snackbar-general/snackbar-general.service';
import { ExportComponent } from './export.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
describe('ExportComponent', () => {
    let component: ExportComponent;
    let fixture: ComponentFixture<ExportComponent>;
    let drawingService: DrawingService;
    let dialogRefStub: jasmine.SpyObj<MatDialogRef<ExportComponent>>;
    let shortcutManagerService: jasmine.SpyObj<ShortcutManagerService>;
    let snackBarGeneralService: jasmine.SpyObj<SnackBarGeneralService>;
    let snackBar: jasmine.SpyObj<MatSnackBar>;
    let http: jasmine.SpyObj<HttpClient>;
    beforeEach(async(() => {
        dialogRefStub = jasmine.createSpyObj('MatDialogRef', ['close']);
        shortcutManagerService = jasmine.createSpyObj('ShortcutManagerService', ['enableShortcut', 'displayContext']);
        snackBarGeneralService = jasmine.createSpyObj('SnackBarGeneralService', ['displayContext', 'openFromComponent']);
        snackBar = jasmine.createSpyObj('MatSnackBar', ['openFromComponent']);
        http = jasmine.createSpyObj('HttpClient', ['post']);
        drawingService = new DrawingService();
        drawingService.canvas = canvasTestHelper.canvas;
        drawingService.baseCtx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        TestBed.configureTestingModule({
            declarations: [ExportComponent],
            imports: [MatSelectModule, MatRadioModule, MatInputModule, FormsModule, BrowserAnimationsModule],
            providers: [
                { provide: DrawingService, useValue: drawingService },
                { provide: MatDialogRef, useValue: dialogRefStub },
                { provide: ShortcutManagerService, useValue: shortcutManagerService },
                { provide: HttpClient, useValue: http },
                { provide: MatSnackBar, useValue: snackBar },
                { provide: SnackBarGeneralService, useValue: snackBarGeneralService },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('ngOnInit should call loadDrawing', () => {
        const loadDrawingSpy = spyOn(component, 'loadDrawing');
        component.ngOnInit();
        expect(loadDrawingSpy).toHaveBeenCalled();
    });
    it('loadDrawing should draw image of the drawing service canvas in the mini canvas and set its filter to none ', () => {
        component.loadDrawing();
        expect(component['ctx'].filter).toEqual('none');
    });
    it('changeFilter should change filter to event value and call load drawing ', () => {
        const event = {
            value: 'sepia(10)',
        } as MatRadioChange;
        const loadDrawingSpy = spyOn(component, 'loadDrawing');
        component.changeFilter(event);
        expect(component.filter).toEqual('sepia(10)');
        expect(loadDrawingSpy).toHaveBeenCalled();
    });
    it('sendAsEmail should put isShownEmail to true and call validateEmail if event value is equal to email ', () => {
        const event = {
            value: 'email',
        } as MatSelectChange;
        const validateEmailSpy = spyOn(component, 'validateEmail');
        component.sendAsEmail(event);
        expect(component.isShownEmail).toEqual(true);
        expect(validateEmailSpy).toHaveBeenCalled();
    });
    it('sendAsEmail should put isShownEmail to false and disabled to true if event value is not equal to email ', () => {
        const event = {
            value: 'hello',
        } as MatSelectChange;
        component.sendAsEmail(event);
        expect(component.isShownEmail).toEqual(false);
        expect(component.disabled).toEqual(true);
    });
    it('validateEmail should put disabled to false if patter is not found to true if it is found', () => {
        const email = 'hello@polymtl.ca';
        component.validateEmail(email);
        expect(component.disabled).toEqual(true);
    });
    it('validateName should return true if the period key is not pressed', () => {
        const event = {
            code: 'h',
        } as KeyboardEvent;
        const validateName = component.validateName(event);
        expect(validateName).toEqual(true);
    });

    // // testes pour  chooseExportingMode()
    it('chooseExportingMode should set attribute chosenExportMode to png if mat-radio PNG is chosen ', () => {
        const event = { value: 'PNG' } as MatRadioChange;
        component.chooseExportingMode(event);
        expect(component['chosenExportMode']).toBe('png');
    });
    it('chooseExportingMode should set attribute chosenExportMode jpeg if mat-radio JPEG is chosen', () => {
        const event = { value: 'JPEG' } as MatRadioChange;
        component.chooseExportingMode(event);
        expect(component['chosenExportMode']).toBe('jpeg');
    });
    it('exportDraw should call export is chosenExportMode is png or jpeg', () => {
        const exportSpy = spyOn(component, 'export');
        component['chosenExportMode'] = 'png';
        component.exportDraw();
        expect(exportSpy).toHaveBeenCalled();
    });
    it('exportDraw should  call alert()  chosen exporting mode is not png og jpeg', () => {
        const spy = spyOn(window, 'alert');
        component['chosenExportMode'] = '';
        component.exportDraw();
        expect(spy).toHaveBeenCalledWith('Veuillez choisir le format de l image à exporter ');
    });

    // testes pour export()

    it('export should return if export drawing is no confirmed', () => {
        spyOn(window, 'confirm').and.returnValue(false);
        const exportReturn = component.export('fileName', 'sepia(10)');
        expect(exportReturn).toEqual();
    });

    // // test pour close()
    it('should call close()', () => {
        component.cancel();
        expect(dialogRefStub.close).toHaveBeenCalled();
    });
});
