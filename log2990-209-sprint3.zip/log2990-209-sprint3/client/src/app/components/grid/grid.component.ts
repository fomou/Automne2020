import { Component, HostListener, OnDestroy } from '@angular/core';
import { MAX_SQUARE_SIZE, MIN_OPACITY, MIN_SQUARE_SIZE, SQUARE_STEP } from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-grid',
    templateUrl: './grid.component.html',
    styleUrls: ['./grid.component.scss'],
})
export class GridComponent implements OnDestroy {
    private subscriptions: Subscription[] = [];
    opacity: number = MIN_OPACITY;
    squareSize: number = MIN_SQUARE_SIZE + SQUARE_STEP;
    disableGrid: boolean = false;

    constructor(private sidebarService: SidebarService, public drawingService: DrawingService) {
        const opacitySub = this.sidebarService.opacityObs$.subscribe((opacity) => {
            this.opacity = opacity;
        });
        this.subscriptions.push(opacitySub);

        const squareSizeSub = this.sidebarService.squareSizeObs$.subscribe((squareSize) => {
            this.squareSize = squareSize;
        });
        this.subscriptions.push(squareSizeSub);

        const disableGridSub = this.sidebarService.disabledObs$.subscribe((disableGrid) => {
            this.disableGrid = disableGrid;
        });
        this.subscriptions.push(disableGridSub);
    }

    ngOnDestroy(): void {
        for (const sub of this.subscriptions) {
            sub.unsubscribe();
        }
    }
    pathSmallSquare(): string {
        return `M ${this.squareSize} 0 L 0 0 0 ${this.squareSize}`;
    }

    @HostListener('window:keydown.shift.+')
    increase(): void {
        if (this.disableGrid && this.squareSize < MAX_SQUARE_SIZE) {
            this.squareSize += SQUARE_STEP;
        }
    }

    @HostListener('window:keydown.-')
    decrease(): void {
        if (this.disableGrid && this.squareSize > MIN_SQUARE_SIZE) {
            this.squareSize -= SQUARE_STEP;
        }
    }
}
