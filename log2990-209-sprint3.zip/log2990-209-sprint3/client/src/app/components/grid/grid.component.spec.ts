import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MAX_SQUARE_SIZE, MIN_SQUARE_SIZE } from '@app/constants/constants';
import { GridComponent } from './grid.component';

//  tslint:disable: no-magic-numbers
describe('GridComponent', () => {
    let component: GridComponent;
    let fixture: ComponentFixture<GridComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [GridComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GridComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('Should return the canvas path for a square', () => {
        const result = component.pathSmallSquare();
        expect(result).toEqual('M 30 0 L 0 0 0 30');
    });

    it('Should increase squareSize if its below 100', () => {
        const squareSizeStub = 15;
        component.squareSize = 10;
        component.disableGrid = true;
        component.increase();
        expect(component.squareSize).toEqual(squareSizeStub);
    });

    it("Should not increase squareSize if it's 100 or above ", () => {
        component.squareSize = MAX_SQUARE_SIZE;
        component.disableGrid = true;
        component.increase();
        expect(component.squareSize).toEqual(MAX_SQUARE_SIZE);
    });

    it('Should decrease squareSize if its above 30', () => {
        const squareSizeStub = 60;
        component.squareSize = 65;
        component.disableGrid = true;
        component.decrease();
        expect(component.squareSize).toEqual(squareSizeStub);
    });

    it("Should not decrease squareSize if it's 30 or below ", () => {
        component.squareSize = MIN_SQUARE_SIZE;
        component.disableGrid = true;
        component.decrease();
        expect(component.squareSize).toEqual(MIN_SQUARE_SIZE);
    });
});
