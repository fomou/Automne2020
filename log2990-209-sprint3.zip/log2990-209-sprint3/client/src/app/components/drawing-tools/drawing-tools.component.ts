import { Component, HostListener, OnDestroy } from '@angular/core';
import { MatSliderChange } from '@angular/material/slider';
import { Keyboard } from '@app/enums/key-board';
import { ToolNames } from '@app/enums/tool-names';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools-selectors/tools-selector.service';
import { SprayPaintService } from '@app/services/tools/plotting-tools/spray-paint/spray-paint.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-drawing-tools',
    templateUrl: './drawing-tools.component.html',
    styleUrls: ['./drawing-tools.component.scss'],
})
export class DrawingToolsComponent implements OnDestroy {
    toolName: string = ToolNames.Pencil;
    isShownBarAttTools: boolean = false;
    isShownTexture: boolean = false;
    isShownBrushes: boolean = false;
    isShownPenAtt: boolean = true;
    isShownBrushAtt: boolean = false;
    isShownFeatherAtt: boolean = false;
    isShownSprayPaintAtt: boolean = false;
    radius: number = 20;
    dropletDiameter: number = 1;
    emissionPerSecond: number = 1;
    private shortcutDisabled: boolean;
    private subscription: Subscription;

    constructor(
        private toolsSelectorService: ToolsSelectorService,
        private sidebarService: SidebarService,
        private shortcutManagerService: ShortcutManagerService,
        private sprayPaint: SprayPaintService,
    ) {
        this.subscription = this.shortcutManagerService.shortcutObs$.subscribe((disabler) => {
            this.shortcutDisabled = disabler;
        });
    }

    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
    @HostListener('window:keydown', ['$event'])
    onKeyDown(event: KeyboardEvent): void {
        if (this.shortcutDisabled) {
            return;
        }
        switch (event.code) {
            case Keyboard.C:
                this.showBarAttributesTools();
                this.showPenAtt();
                break;
            case Keyboard.W:
                this.showBarAttributesTools();
                this.showBrushAttribute();
                break;

            case Keyboard.A:
                this.showBarAttributesTools();
                this.showSprayPaintAtt();
                break;
            case Keyboard.P:
                this.showBarAttributesTools();
                this.showFeatherAtt();
                break;
        }
    }
    getRadius(event: MatSliderChange): void {
        this.radius = (event.value as number) / 2;
        this.sprayPaint.throwingRadius = this.radius;
    }

    getDropletDiameter(event: MatSliderChange): void {
        this.dropletDiameter = event.value as number;
        this.sprayPaint.particleRadius = this.dropletDiameter;
    }

    changeEmissionPerSecond(event: MatSliderChange): void {
        this.emissionPerSecond = event.value as number;
        this.sprayPaint.emissionPerSecond = this.emissionPerSecond;
    }
    changeBrushWidth(event: MatSliderChange): void {
        this.sidebarService.changeBrushWidth(event.value as number);
    }

    showBarAttributesTools(): void {
        this.isShownBarAttTools = !this.isShownBarAttTools;
    }

    showBrushes(): void {
        this.isShownPenAtt = false;
        this.isShownTexture = false;
        this.isShownFeatherAtt = false;
        this.isShownBrushes = !this.isShownBrushes;
    }

    showTexture(): void {
        this.isShownBrushes = false;
        this.isShownTexture = !this.isShownTexture;
    }

    selectTexture(n: number): void {
        this.sidebarService.selectTexture(n);
        this.isShownTexture = false;
    }

    showPenAtt(): void {
        this.showBrushes();
        this.isShownBrushes = false;
        this.isShownPenAtt = true;
        this.isShownBrushAtt = false;
        this.isShownFeatherAtt = false;
        this.isShownSprayPaintAtt = false;
        this.toolName = ToolNames.Pencil;
        const tool = this.toolsSelectorService.getToolByKey(Keyboard.C);
        this.toolsSelectorService.plottingTool = tool;
        this.toolsSelectorService.changeTool(tool);
    }

    showBrushAttribute(): void {
        this.showBrushes();
        this.isShownBrushAtt = true;
        this.isShownBrushes = false;
        this.toolName = ToolNames.Brush;
        const tool = this.toolsSelectorService.getToolByKey(Keyboard.W);
        this.toolsSelectorService.plottingTool = tool;
        this.toolsSelectorService.changeTool(tool);
    }

    showFeatherAtt(): void {
        this.showBrushes();
        this.isShownBrushes = false;
        this.isShownBrushAtt = false;
        this.isShownFeatherAtt = true;
        this.isShownSprayPaintAtt = false;
        this.toolName = ToolNames.Feather;
        const tool = this.toolsSelectorService.getToolByKey(Keyboard.P);
        this.toolsSelectorService.plottingTool = tool;
        this.toolsSelectorService.changeTool(tool);
    }

    showSprayPaintAtt(): void {
        this.showBrushes();
        this.isShownSprayPaintAtt = true;
        this.isShownBrushes = false;
        this.isShownBrushAtt = false;
        this.toolName = ToolNames.SprayPaint;
        const tool = this.toolsSelectorService.getToolByKey(Keyboard.A);
        this.toolsSelectorService.plottingTool = tool;
        this.toolsSelectorService.changeTool(tool);
    }

    changeWidth(event: MatSliderChange): void {
        this.sidebarService.changeWidth(event.value as number);
    }

    returnWidth(): number {
        return this.sidebarService.width;
    }

    formatLabel(value: number): string {
        return (value + 'px') as string;
    }
    changeCalligraphyHeight(event: MatSliderChange): void {
        this.sidebarService.changeCalligraphyHeight(event.value as number);
    }
    changeCalligraphyAngle(event: MatSliderChange): void {
        this.sidebarService.changeCalligraphyAngle(event.value as number);
    }

    returnBrushWidth(): number {
        return this.sidebarService.brushWidth;
    }
    returnCalligraphyHeight(): number {
        return this.sidebarService.heightCalligraphy;
    }
    returnCalligraphyAngle(): number {
        return this.sidebarService.angleCalligraphy;
    }
}
