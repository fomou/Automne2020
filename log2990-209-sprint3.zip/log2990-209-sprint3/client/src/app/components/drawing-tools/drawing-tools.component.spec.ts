import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatSliderChange, MatSliderModule } from '@angular/material/slider';
import { Tool } from '@app/classes/tool';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SelectionEllipseService } from '@app/services/selections/selection/selection-ellipse/selection-ellipse.service';
import { MagicWandService } from '@app/services/selections/selection/selection-magic-wand/magic-wand.service';
import { SelectionRectangleService } from '@app/services/selections/selection/selection-rectangle/selection-rectangle.service';
import { SidebarService } from '@app/services/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools-selectors/tools-selector.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { BrushService } from '@app/services/tools/plotting-tools/brush/brush.service';
import { CalligraphyService } from '@app/services/tools/plotting-tools/calligraphy/calligraphy.service';
import { PencilService } from '@app/services/tools/plotting-tools/pencil/pencil-service';
import { SprayPaintService } from '@app/services/tools/plotting-tools/spray-paint/spray-paint.service';
import { EllipseService } from '@app/services/tools/shapes/ellipse/ellipse.service';
import { PolygonService } from '@app/services/tools/shapes/polygon/polygon.service';
import { RectangleService } from '@app/services/tools/shapes/rectangle/rectangle.service';
import { StampService } from '@app/services/tools/stamp/stamp.service';
import { TextService } from '@app/services/tools/text/text.service';
import { DrawingToolsComponent } from './drawing-tools.component';
class ToolSelector extends ToolsSelectorService {
    getToolByKey(s: string): Tool {
        return {} as Tool;
    }
    // tslint:disable-next-line:no-empty
    changeTool(t: Tool): void {}
}

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
describe('DrawingToolsComponent', () => {
    let component: DrawingToolsComponent;
    let fixture: ComponentFixture<DrawingToolsComponent>;
    let sideBareStub: SidebarService;
    let toolSelect: ToolsSelectorService;
    let drawingService: jasmine.SpyObj<DrawingService>;
    beforeEach(async(() => {
        sideBareStub = new SidebarService();
        const pen = {} as PencilService;
        const rect = {} as RectangleService;
        const ellipse = {} as EllipseService;
        const line = {} as LineService;
        const era = {} as EraseService;
        const brush = {} as BrushService;
        const poly = { sides: 10 } as PolygonService;
        const pipette = {} as PickerService;
        const bucket = {} as PaintBucketService;
        const selRect = {} as SelectionRectangleService;
        const selEll = {} as SelectionEllipseService;
        const stamp = {} as StampService;
        const spray = {} as SprayPaintService;
        const text = {} as TextService;
        const calligraphy = {} as CalligraphyService;
        const magicWand = {} as MagicWandService;
        drawingService = jasmine.createSpyObj('DrawingService', ['clearCanvas']);
        toolSelect = new ToolSelector(
            drawingService,
            pen,
            rect,
            ellipse,
            line,
            era,
            brush,
            poly,
            pipette,
            bucket,
            selRect,
            selEll,
            magicWand,
            stamp,
            spray,
            calligraphy,
            text,
        );

        TestBed.configureTestingModule({
            declarations: [DrawingToolsComponent],
            imports: [MatSliderModule],
            providers: [
                { provide: SidebarService, useValue: sideBareStub },
                { provide: ToolsSelectorService, useValue: toolSelect },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DrawingToolsComponent);
        fixture.detectChanges();
        component = fixture.componentInstance;
    });

    afterEach(() => {
        fixture.destroy();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('ShowPenAtt should change tool', () => {
        const changeSpy = spyOn(toolSelect, 'changeTool').and.callThrough();
        const getSpy = spyOn(toolSelect, 'getToolByKey').and.callThrough();
        component.showPenAtt();
        expect(getSpy).toHaveBeenCalled();
        expect(component.toolName).toBe('Crayon');
        expect(component.isShownBrushAtt).toEqual(false);
        expect(component.isShownBrushes).toEqual(false);
        expect(component.isShownPenAtt).toEqual(true);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('ShowBrushAttribute should change tool', () => {
        const changeSpy = spyOn(toolSelect, 'changeTool').and.callThrough();
        const getSpy = spyOn(toolSelect, 'getToolByKey').and.callThrough();
        component.showBrushAttribute();
        expect(getSpy).toHaveBeenCalled();
        expect(component.toolName).toBe('Pinceau');
        expect(component.isShownBrushAtt).toEqual(true);
        expect(component.isShownBrushes).toEqual(false);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('ShowFeatherAtt should change name to Plume', () => {
        component.showFeatherAtt();
        expect(component.toolName).toBe('Plume');
        expect(component.isShownFeatherAtt).toBe(true);
    });

    it('ShowFeatherAtt should change name to Aérosol', () => {
        component.showSprayPaintAtt();
        expect(component.toolName).toBe('Aérosol');
        expect(component.isShownSprayPaintAtt).toBe(true);
    });

    it('changeWidth call changeWidth of the service', () => {
        const spy = spyOn(sideBareStub, 'changeWidth').and.callThrough();
        const event = { value: 10 } as MatSliderChange;
        component.changeWidth(event);
        expect(spy).toHaveBeenCalled();
    });

    it('return width should give the width in the sidebar service', () => {
        const expected = sideBareStub.width;
        expect(component.returnWidth()).toEqual(expected);
    });

    it('formate label should convert in to string', () => {
        const expected = '10px';
        expect(component.formatLabel(10)).toEqual(expected);
    });
    it('return brush width should give the width in the sidebar service', () => {
        const expected = sideBareStub.brushWidth;
        expect(component.returnBrushWidth()).toEqual(expected);
    });

    it('changeBrushWidth call changeWidth of the service', () => {
        const spy = spyOn(sideBareStub, 'changeBrushWidth').and.callThrough();
        const event = { value: 10 } as MatSliderChange;
        component.changeBrushWidth(event);
        expect(spy).toHaveBeenCalled();
    });

    it('ShowBarAttributesTools change isShownBarAttTools ', () => {
        component.isShownBarAttTools = false;
        component.showBarAttributesTools();
        expect(component.isShownBarAttTools).toEqual(true);
    });

    it('ShowBrushes should change isShownPenAtt, isShownTexture,isShownBrushes', () => {
        component.isShownBrushes = false;
        component.showBrushes();
        expect(component.isShownPenAtt).toBe(false);
        expect(component.isShownTexture).toBe(false);
        expect(component.isShownBrushes).toEqual(true);
    });

    it('selectTexture should call selectTexture of sidebar service ', () => {
        const spy = spyOn(sideBareStub, 'selectTexture').and.callThrough();
        component.selectTexture(1);
        expect(spy).toHaveBeenCalledWith(1);
        expect(component.isShownTexture).toEqual(false);
    });

    it('onKeyDown should call ShowBarAttributesTools if c is hit on keyboard', () => {
        component['shortcutDisabled'] = false;
        const event = { code: Keyboard.C } as KeyboardEvent;
        const spy = spyOn(component, 'showPenAtt').and.callThrough();
        const spyBrush = spyOn(component, 'showBarAttributesTools').and.callThrough();
        component.onKeyDown(event);

        expect(spy).toHaveBeenCalled();
        expect(spyBrush).toHaveBeenCalled();
    });

    it('onKeyDown should call ShowBrushAttribute if w is hit on keyboard', () => {
        component['shortcutDisabled'] = false;
        const event = { code: Keyboard.W } as KeyboardEvent;
        const spy = spyOn(component, 'showBrushAttribute').and.callThrough();
        const spyBrush = spyOn(component, 'showBarAttributesTools').and.callThrough();
        component.onKeyDown(event);

        expect(spy).toHaveBeenCalled();
        expect(spyBrush).toHaveBeenCalled();
    });

    it('onKeyDown should do nothing if shortcuts is disabled', () => {
        component['shortcutDisabled'] = true;
        const event = { code: Keyboard.W } as KeyboardEvent;
        const spy = spyOn(component, 'showBrushAttribute').and.callThrough();
        const spyBrush = spyOn(component, 'showBarAttributesTools').and.callThrough();
        component.onKeyDown(event);

        expect(spy).not.toHaveBeenCalled();
        expect(spyBrush).not.toHaveBeenCalled();
    });

    it('ShowTexture should change isShownBrushes, isShownTexture', () => {
        component.isShownTexture = false;
        component.showTexture();
        expect(component.isShownTexture).toBe(true);
        expect(component.isShownBrushes).toEqual(false);
    });

    it('Subscribe should give the value from the service', () => {
        component['shortcutManagerService'].disableShortcut();
        component['shortcutManagerService'].shortcutObs$.subscribe((disable) => {
            expect(disable).toEqual(true);
        });
    });
});
