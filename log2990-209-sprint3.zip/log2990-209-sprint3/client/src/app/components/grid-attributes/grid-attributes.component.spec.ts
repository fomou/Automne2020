import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatSlideToggle, MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderChange, MatSliderModule } from '@angular/material/slider';
import { GridAttributesComponent } from './grid-attributes.component';
// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
describe('GridAttributesComponent', () => {
    let component: GridAttributesComponent;
    let fixture: ComponentFixture<GridAttributesComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [GridAttributesComponent],
            imports: [MatSlideToggleModule, MatSliderModule, FormsModule],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GridAttributesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('changeOpacity should set the opacity to slider value', () => {
        const event = {
            value: 15,
        } as MatSliderChange;
        component.changeOpacity(event);
        expect(component.opacity).toEqual(15);
    });

    it('changeSquareSizeSlider should set the square size to slider value', () => {
        const event = {
            value: 15,
        } as MatSliderChange;
        component.changeSquareSizeSlider(event);
        expect(component.squareSize).toEqual(15);
    });
    it('disable should set disabled to true if checker false if not checked  ', () => {
        const event = {
            checked: true,
        } as MatSlideToggle;
        component.disable(event);
        expect(component.disabled).toEqual(true);
    });
    it('disable should reverse disabled value ', () => {
        component.disabled = false;
        component.gIsClicked();
        expect(component.disabled).toEqual(true);
    });

    it('decrease should decrease the grid size through the slider if disable it true and squareSize is grater than 30 ', () => {
        const squareSizeStub = 60;
        component.squareSize = 65;
        component.disabled = true;
        component.decrease();
        expect(component.squareSize).toEqual(squareSizeStub);
    });
    it('decrease should not change squareSize if disable is false or squareSize is not grater than 30 ', () => {
        component.squareSize = 20;
        component.disabled = false;
        component.decrease();
        expect(component.squareSize).toEqual(20);
    });
    it('increase should increase the square size through the slider if disable is true and squareSize is smaller than 100', () => {
        const squareSizeStub = 15;
        component.squareSize = 10;
        component.disabled = true;
        component.increase();
        expect(component.squareSize).toEqual(squareSizeStub);
    });
    it('increase should not change squareSize value if disable is false or squareSize is not smaller than 100', () => {
        component.squareSize = 100;
        component.disabled = false;
        component.increase();
        expect(component.squareSize).toEqual(100);
    });
});
