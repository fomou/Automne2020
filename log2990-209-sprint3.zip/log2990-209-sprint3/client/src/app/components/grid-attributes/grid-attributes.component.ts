import { Component, HostListener } from '@angular/core';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { MatSliderChange } from '@angular/material/slider';
import { INITIAL_OPACITY, MAX_SQUARE_SIZE, MIN_SQUARE_SIZE, SQUARE_STEP } from '@app/constants/constants';
import { SidebarService } from '@app/services/sidebar/sidebar.service';

@Component({
    selector: 'app-grid-attributes',
    templateUrl: './grid-attributes.component.html',
    styleUrls: ['./grid-attributes.component.scss'],
})
export class GridAttributesComponent {
    opacity: number = INITIAL_OPACITY;
    squareSize: number = MIN_SQUARE_SIZE + SQUARE_STEP;
    disabled: boolean = false;

    constructor(private sidebarService: SidebarService) {}

    changeOpacity(event: MatSliderChange): void {
        this.sidebarService.changeGridOpacity(event.value as number);
        this.opacity = event.value as number;
    }

    changeSquareSizeSlider(event: MatSliderChange): void {
        this.sidebarService.changeSquareSize(event.value as number);
        this.squareSize = event.value as number;
    }

    disable(event: MatSlideToggle): void {
        this.disabled = event.checked;
        this.sidebarService.disableGrid(this.disabled);
    }

    @HostListener('window:keydown.g')
    gIsClicked(): void {
        this.disabled = !this.disabled;
        this.sidebarService.disableGrid(this.disabled);
    }

    @HostListener('window:keydown.shift.+')
    increase(): void {
        if (this.disabled && this.squareSize < MAX_SQUARE_SIZE) {
            this.squareSize += SQUARE_STEP;
        }
    }

    @HostListener('window:keydown.-')
    decrease(): void {
        if (this.disabled && this.squareSize > MIN_SQUARE_SIZE) {
            this.squareSize -= SQUARE_STEP;
        }
    }
}
