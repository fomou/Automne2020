import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderChange, MatSliderModule } from '@angular/material/slider';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { ColorPanelComponent } from './color-panel.component';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: no-string-literal
describe('ColorPanelComponent', () => {
    let component: ColorPanelComponent;
    let fixture: ComponentFixture<ColorPanelComponent>;
    let colorSelectorServiceStub: ColorSelectorService;

    let matDialogStub: jasmine.SpyObj<MatDialog>;

    beforeEach(async(() => {
        colorSelectorServiceStub = new ColorSelectorService();

        matDialogStub = jasmine.createSpyObj('MatDialog', ['open']);

        TestBed.configureTestingModule({
            declarations: [ColorPanelComponent],
            imports: [MatDialogModule, MatSlideToggleModule, MatSliderModule],
            providers: [
                { provide: MatDialog, useValue: matDialogStub },
                { provide: ColorSelectorService, useValue: colorSelectorServiceStub },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ColorPanelComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('ngOnDestroy should unsubscribe to all subscriptions ', () => {
        const spy = spyOn(component['subscriptions'][0], 'unsubscribe');
        component.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
    it('should set secondaryColor on right click', () => {
        const announceSPy = spyOn<any>(component['colorSelectorService'], 'announceColor').and.callThrough();
        component.rightClick('red');
        expect(announceSPy).toHaveBeenCalled();
    });

    it('changeSecondaryColor should call open of matDialog', () => {
        component.changePrimaryColor();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('changeSecondaryColor() should call open of matDialog', () => {
        component.changeSecondaryColor();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('swapColors should call swapColor of colorSelectorService', () => {
        const spy = spyOn<any>(component['colorSelectorService'], 'swapColor').and.callThrough();
        component.swapColors();
        expect(spy).toHaveBeenCalled();
    });

    it('leftClick should call announceColor of colorSelectorService', () => {
        const announceSPy = spyOn(component['colorSelectorService'], 'announceColor').and.callThrough();
        component.leftClick('red');
        expect(announceSPy).toHaveBeenCalled();
    });
    it('changePrimaryColorOpacity should set primaryColorOpacity event value and call change color  ', () => {
        const event = {
            value: 0.5,
        } as MatSliderChange;
        const announceSPy = spyOn<any>(component, 'changeColor');
        component.changePrimaryColorOpacity(event);
        expect(component['primaryColorOpacity']).toEqual(0.5);
        expect(announceSPy).toHaveBeenCalled();
    });
    it('changeSecondaryColorOpacity should set secondaryColorOpacity event value and call change color  ', () => {
        const event = {
            value: 0.5,
        } as MatSliderChange;
        const announceSPy = spyOn<any>(component, 'changeColor');
        component.changeSecondaryColorOpacity(event);
        expect(component['secondaryColorOpacity']).toEqual(0.5);
        expect(announceSPy).toHaveBeenCalled();
    });
    it('fillString should return a string in uppercase if the strings length is grater than 1', () => {
        const stringToUppercase = component['fillString']('hello');
        expect(stringToUppercase).toEqual('HELLO');
    });
    it('fillString should return 0+ string in uppercase if the strings length is not grater than 1', () => {
        const stringToUppercase = component['fillString']('h');
        expect(stringToUppercase).toEqual('0H');
    });
    it('changeColor should set colorSelectorService.colorType to color passed in parameters and call announceColor', () => {
        const spy = spyOn(component['colorSelectorService'], 'announceColor');
        component['changeColor']('color', 'type');
        expect(component['colorSelectorService'].colorType).toEqual('type');
        expect(spy).toHaveBeenCalled();
    });
});
