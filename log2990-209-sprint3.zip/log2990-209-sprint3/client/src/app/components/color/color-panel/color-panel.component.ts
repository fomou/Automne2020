import { Component, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSliderChange } from '@angular/material/slider';
import { ColorPickerComponent } from '@app/components/color/color-picker/color-picker.component';
import { BLUE_INDEX_END, MAX_BIT_NUM, MAX_OPACITY } from '@app/constants/constants';
import { ColorType } from '@app/enums/color-type';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-color-panel',
    templateUrl: './color-panel.component.html',
    styleUrls: ['./color-panel.component.scss'],
})
export class ColorPanelComponent implements OnDestroy {
    private subscriptions: Subscription[];
    colors: string[];
    primaryColor: string;
    secondaryColor: string;
    primaryColorOpacity: number = MAX_OPACITY;
    secondaryColorOpacity: number = MAX_OPACITY;

    constructor(
        private dialog: MatDialog,
        private colorSelectorService: ColorSelectorService,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.subscriptions = [];
        const subsPrimaryColor = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.primaryColor = color;
        });
        const subsSecondaryColor = this.colorSelectorService.secondaryColor$.subscribe((color) => {
            this.secondaryColor = color;
        });
        const subsRecentColor = this.colorSelectorService.recentColor$.subscribe((colors) => {
            this.colors = colors;
        });

        this.subscriptions.push(subsPrimaryColor);
        this.subscriptions.push(subsRecentColor);
        this.subscriptions.push(subsSecondaryColor);
    }

    ngOnDestroy(): void {
        for (const sub of this.subscriptions) {
            sub.unsubscribe();
        }
    }

    rightClick(color: string): void {
        this.changeColor(color, ColorType.Secondary);
    }

    leftClick(color: string): void {
        this.changeColor(color, ColorType.Primary);
    }

    changePrimaryColor(): void {
        this.colorSelectorService.colorType = ColorType.Primary;
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(ColorPickerComponent, { disableClose: true });
    }

    changeSecondaryColor(): void {
        this.colorSelectorService.colorType = ColorType.Secondary;
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(ColorPickerComponent, { disableClose: true });
    }

    swapColors(): void {
        this.colorSelectorService.swapColor(this.primaryColor, this.secondaryColor);
    }
    changePrimaryColorOpacity(event: MatSliderChange): void {
        this.primaryColorOpacity = event.value as number;
        this.primaryColor = this.applyOpacity(this.primaryColor, this.primaryColorOpacity);
        this.changeColor(this.primaryColor, ColorType.Primary);
    }

    changeSecondaryColorOpacity(event: MatSliderChange): void {
        this.secondaryColorOpacity = event.value as number;
        this.secondaryColor = this.applyOpacity(this.secondaryColor, this.secondaryColorOpacity);
        this.changeColor(this.secondaryColor, ColorType.Secondary);
    }

    private applyOpacity(color: string, opacity: number): string {
        const colorWithoutAlpha = color.substring(0, BLUE_INDEX_END);
        const opacityValue = Math.round(MAX_BIT_NUM * opacity);
        return colorWithoutAlpha + this.fillString(opacityValue.toString(16).toUpperCase());
    }

    private fillString(n: string): string {
        return n.length > 1 ? n.toUpperCase() : '0' + n.toUpperCase();
    }

    private changeColor(color: string, type: string): void {
        this.colorSelectorService.colorType = type;
        this.colorSelectorService.announceColor(color);
    }
}
