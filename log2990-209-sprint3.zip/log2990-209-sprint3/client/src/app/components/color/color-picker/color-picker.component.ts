import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as CONSTANT from '@app/constants/constants';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';
@Component({
    selector: 'app-color-picker',
    templateUrl: './color-picker.component.html',
    styleUrls: ['./color-picker.component.scss'],
})
export class ColorPickerComponent implements OnInit, OnDestroy {
    private previewColor: string;
    private previewHue: string;
    private fieldEmpty: boolean = true;
    private message: string;
    hue: string;
    color: string;
    colorForms: FormGroup;
    manuelColor: string;
    constructor(
        private colorSelectorService: ColorSelectorService,
        private formsBuilder: FormBuilder,
        private shortcutManagerService: ShortcutManagerService,
        private snackBar: MatSnackBar,
    ) {}

    ngOnInit(): void {
        this.color = this.colorSelectorService.getCurrentColor();
        this.previewColor = this.color;
        this.hue = this.colorSelectorService.getCurrentColor();
        this.previewHue = this.hue;
        this.colorForms = this.formsBuilder.group({
            red: ['', [Validators.required, Validators.maxLength(2)]],
            green: ['', [Validators.required, Validators.maxLength(2)]],
            blue: ['', [Validators.required, Validators.maxLength(2)]],
        });
        this.manuelColor = '';
    }
    ngOnDestroy(): void {
        this.colorSelectorService.keepHue(this.hue);
    }

    confirm(): void {
        this.shortcutManagerService.enableShortcut();
        if (this.previewColor !== this.color) {
            this.message = 'la couleur a été choisi avec succès';
            this.colorSelectorService.announceColor(this.color);
            if (this.previewHue !== this.hue) {
                this.colorSelectorService.addColorsToArray(this.color);
            }
            this.snackBar.open(this.message, '', { duration: CONSTANT.SNACKBAR_DISPLAY_TIME });
            return;
        } else if (this.getEnteredColor()) {
            this.colorSelectorService.announceColor(this.manuelColor);
            this.colorSelectorService.addColorsToArray(this.manuelColor);
            this.snackBar.open(this.message, '', { duration: CONSTANT.SNACKBAR_DISPLAY_TIME });
            return;
        } else {
            this.colorSelectorService.announceColor(this.hue);
            this.colorSelectorService.addColorsToArray(this.hue);
            this.snackBar.open(this.message, this.color, { duration: CONSTANT.SNACKBAR_DISPLAY_TIME });
        }
    }

    get redHexValue(): string {
        const hexVal = this.colorForms.get('red')?.value as string;
        this.fieldEmpty = hexVal.length === 0;

        return this.fillString(hexVal);
    }

    get greenHexValue(): string {
        const hexVal = this.colorForms.get('green')?.value as string;
        this.fieldEmpty = this.fieldEmpty || hexVal.length === 0;

        return this.fillString(hexVal);
    }

    get blueHexValue(): string {
        const hexVal = this.colorForms.get('blue')?.value as string;
        this.fieldEmpty = this.fieldEmpty || hexVal.length === 0;

        return this.fillString(hexVal);
    }

    getEnteredColor(): boolean {
        const color = '#' + this.redHexValue + this.greenHexValue + this.blueHexValue + 'FF';

        const excludedLetters = 'ghijklmnopqrstuvwxyz'.toUpperCase();

        for (const c of color) {
            if (excludedLetters.includes(c)) {
                this.message = 'certains valeurs ne respectent pas les valeurs hexadecimal';
                return false;
            }
        }

        if (this.fieldEmpty) {
            this.message = 'erreur!!! un champ est vide';
            return false;
        }

        this.manuelColor = color;
        return true;
    }

    private fillString(n: string): string {
        return n.length > 1 ? n.toUpperCase() : '0' + n.toUpperCase();
    }

    enableShortcuts(): void {
        this.message = 'le choix de couleur est annulé';
        this.snackBar.open(this.message, '', { duration: CONSTANT.SNACKBAR_DISPLAY_TIME });
        this.shortcutManagerService.enableShortcut();
    }
}
