import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ColorPaletteComponent } from '@app/components/color/color-palette/color-palette.component';
import { ColorSliderComponent } from '@app/components/color/color-slider/color-slider.component';
import { ColorSelectorService } from '@app/services/color-selector/color-selector.service';
import { ColorPickerComponent } from './color-picker.component';

// tslint:disable: no-string-literal
describe('ColorPickerComponent', () => {
    let component: ColorPickerComponent;
    let fixture: ComponentFixture<ColorPickerComponent>;
    let colorFormsStub: FormBuilder;
    let colorSelectorServiceStub: ColorSelectorService;
    let matSnackSpy: jasmine.SpyObj<MatSnackBar>;

    beforeEach(async(() => {
        colorFormsStub = new FormBuilder();
        matSnackSpy = jasmine.createSpyObj('MatSnackBar', ['open']);
        colorSelectorServiceStub = new ColorSelectorService();

        TestBed.configureTestingModule({
            declarations: [ColorPickerComponent, ColorSliderComponent, ColorPaletteComponent],
            imports: [MatSnackBarModule, MatDialogModule, FormsModule, ReactiveFormsModule],
            providers: [
                { provide: FormBuilder, useValue: colorFormsStub },
                { provide: ColorSelectorService, useValue: colorSelectorServiceStub },
                { provide: MatSnackBar, useValue: matSnackSpy },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ColorPickerComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should give correct color entered in the form', () => {
        component.colorForms.setValue({
            red: 'ab',
            green: '1b',
            blue: 'ef',
        });
        component.getEnteredColor();
        expect(component.manuelColor).toBe('#AB1BEFFF');
    });

    it('should complete missing letters with 0 ', () => {
        component.colorForms.setValue({
            red: 'b',
            green: '1',
            blue: 'f',
        });
        component.getEnteredColor();
        expect(component.manuelColor).toBe('#0B010FFF');
    });

    it('should not give color if one field is left empty in the form', () => {
        component.colorForms.setValue({
            red: '',
            green: '1b',
            blue: 'ef',
        });
        component.getEnteredColor();
        expect(component['fieldEmpty']).toEqual(true);
        expect(component.manuelColor).toEqual('');
    });

    it('should send color if it changed', () => {
        component['previewColor'] = 'green';
        component.color = 'red';
        colorSelectorServiceStub.colorType = 'primary';
        component.confirm();

        expect(colorSelectorServiceStub.primaryColorSource.getValue()).toBe('red');
    });

    it('should send manual color if it is in correct form', () => {
        component['previewColor'] = 'green';
        component.color = 'green';

        component.colorForms.setValue({
            red: 'ab',
            green: '1b',
            blue: 'ef',
        });
        component.getEnteredColor();
        colorSelectorServiceStub.colorType = 'primary';
        component.confirm();
        expect(colorSelectorServiceStub.primaryColorSource.getValue()).toEqual(component.manuelColor);
    });

    it('should send manual color if it is in correct form', () => {
        component['previewColor'] = 'green';
        component.color = 'green';

        component.colorForms.setValue({
            red: 'ab',
            green: '',
            blue: '',
        });
        component.hue = 'blue';
        component.getEnteredColor();
        colorSelectorServiceStub.colorType = 'primary';
        component.confirm();
        expect(colorSelectorServiceStub.primaryColorSource.getValue()).toEqual('blue');
    });

    it('getEnteredColor should return false if color hexadecimal value is not valid', () => {
        component.colorForms.setValue({
            red: 'ab',
            green: '1g',
            blue: '22',
        });

        const colorIsValid = component.getEnteredColor();
        expect(colorIsValid).toEqual(false);
        expect(component.manuelColor).toEqual('');
    });
    it('should give right hexadecimal value for red, green and blue', () => {
        component.colorForms.setValue({
            red: 'ab',
            green: '1e',
            blue: '22',
        });

        expect(component.colorForms.get('red')?.value).toEqual('ab');
        expect(component.greenHexValue).toEqual('1E');
        expect(component.blueHexValue).toEqual('22');
    });
});
