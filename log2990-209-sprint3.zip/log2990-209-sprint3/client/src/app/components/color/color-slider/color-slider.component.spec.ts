import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { MouseButton } from '@app/enums/mouse-button';
import { ColorSliderComponent } from './color-slider.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
describe('ColorSliderComponent', () => {
    let component: ColorSliderComponent;
    let fixture: ComponentFixture<ColorSliderComponent>;

    let canvasStub: CanvasRenderingContext2D;

    beforeEach(async(() => {
        canvasStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        TestBed.configureTestingModule({
            declarations: [ColorSliderComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ColorSliderComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        component['context'] = canvasStub;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('afterViewInit should call displaySlider', () => {
        const displaySpy = spyOn<any>(component, 'displaySlider').and.callThrough();
        component.ngAfterViewInit();
        expect(displaySpy).toHaveBeenCalled();
    });

    it('onMouseMove should call displaySlider and clear if the mouse was already down', () => {
        const displaySpy = spyOn<any>(component, 'displaySlider').and.callThrough();
        const clearSpy = spyOn<any>(component, 'clear').and.callThrough();

        component['mouseDown'] = true;

        const event = {} as MouseEvent;

        component.onMouseMove(event);
        expect(displaySpy).toHaveBeenCalled();
        expect(clearSpy).toHaveBeenCalled();
    });

    it('onMouseMove should not call displaySlider and clear if the mouse was not already down', () => {
        const displaySpy = spyOn<any>(component, 'displaySlider').and.callThrough();
        const clearSpy = spyOn<any>(component, 'clear').and.callThrough();

        component['mouseDown'] = false;

        const event = {} as MouseEvent;

        component.onMouseMove(event);
        expect(displaySpy).not.toHaveBeenCalled();
        expect(clearSpy).not.toHaveBeenCalled();
    });

    it('onMouseDown should  call displaySlider and clear and mouseDown to true', () => {
        const displaySpy = spyOn<any>(component, 'displaySlider').and.callThrough();
        const clearSpy = spyOn<any>(component, 'clear').and.callThrough();
        component['mouseDown'] = false;

        const event = { offsetY: 10, button: MouseButton.Left } as MouseEvent;

        component.onMouseDown(event);
        expect(displaySpy).toHaveBeenCalled();
        expect(clearSpy).toHaveBeenCalled();
        expect(component['mouseDown']).toEqual(true);
    });

    it('onMouseUp should set mouseDown to false', () => {
        component['mouseDown'] = true;
        const event = { offsetY: 10 } as MouseEvent;
        const spy = spyOn<any>(component.colorEmitter, 'emit');
        component.onMouseUp(event);
        expect(component['mouseDown']).toEqual(false);
        expect(spy).toHaveBeenCalled();
    });
});
