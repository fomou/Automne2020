import { SimpleChange, SimpleChanges } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MouseButton } from '@app/enums/mouse-button';
import { ColorPaletteComponent } from './color-palette.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
describe('ColorPaletteComponent', () => {
    let component: ColorPaletteComponent;
    let fixture: ComponentFixture<ColorPaletteComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ColorPaletteComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ColorPaletteComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('afterView should call display', () => {
        const displaySpy = spyOn<any>(component, 'displayPalette').and.callThrough();
        component.ngAfterViewInit();
        expect(displaySpy).toHaveBeenCalled();
    });

    it('onMouseMove call display and clear if mouse was already down', () => {
        const displaySpy = spyOn<any>(component, 'displayPalette').and.callThrough();
        const clearSpy = spyOn<any>(component, 'clear').and.callThrough();
        const event = {} as MouseEvent;
        component['mouseDown'] = true;
        component.onMouseMove(event);
        expect(displaySpy).toHaveBeenCalled();
        expect(clearSpy).toHaveBeenCalled();
    });

    it('onMouseMove call display and clear if mouse was already down', () => {
        const displaySpy = spyOn<any>(component, 'displayPalette').and.callThrough();
        const clearSpy = spyOn<any>(component, 'clear').and.callThrough();
        const event = {} as MouseEvent;
        component['mouseDown'] = false;
        component.onMouseMove(event);
        expect(displaySpy).not.toHaveBeenCalled();
        expect(clearSpy).not.toHaveBeenCalled();
    });

    it('onMouseDown call display and clear and mouseDown to true', () => {
        const displaySpy = spyOn<any>(component, 'displayPalette').and.callThrough();
        const clearSpy = spyOn<any>(component, 'clear').and.callThrough();
        const event = { button: MouseButton.Left } as MouseEvent;
        component['mouseDown'] = false;
        component.onMouseDown(event);
        expect(displaySpy).toHaveBeenCalled();
        expect(clearSpy).toHaveBeenCalled();
        expect(component['mouseDown']).toEqual(true);
    });

    it('on mouseUp should set mouseDown to false and call getColorAtPosition', () => {
        component['mouseDown'] = true;
        const event = { offsetX: 25, offsetY: 25 } as MouseEvent;
        const getColorSpy = spyOn<any>(component, 'getColorAtPosition').and.callThrough();
        component.onMouseUp(event);
        expect(component['mouseDown']).toEqual(false);
        expect(getColorSpy).toHaveBeenCalled();
    });

    it('should give position on mouse event', () => {
        const event = { offsetX: 25, offsetY: 25 } as MouseEvent;
        const expectedPoint = { x: 25, y: 25 };
        expect(component['getCurrentPoint'](event)).toEqual(expectedPoint);
    });

    it('simple change should give position on mouse event', () => {
        const event = { offsetX: 25, offsetY: 25 } as MouseEvent;
        const expectedPoint = { x: 25, y: 25 };
        expect(component['getCurrentPoint'](event)).toEqual(expectedPoint);
    });

    it('should change on ngOnchange', () => {
        const change: SimpleChanges = {
            prop1: new SimpleChange(component['hue'], component['hue'], false),
        };

        const spy = spyOn<any>(component, 'clear').and.callThrough();
        component.ngOnChanges(change);
        expect(spy).not.toHaveBeenCalled();
    });
});
