import { Component } from '@angular/core';
import { ShortcutManagerService } from '@app/services/shortcut-manager/shortcut-manager.service';

@Component({
    selector: 'app-user-guide',
    templateUrl: './user-guide.component.html',
    styleUrls: ['./user-guide.component.scss'],
})
export class UserGuideComponent {
    constructor(private shortcutManagerService: ShortcutManagerService) {}

    enableShortcut(): void {
        this.shortcutManagerService.enableShortcut();
    }
}
