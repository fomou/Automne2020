import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { GalleryComponent } from '@app/components/gallery/gallery.component';
import { UserGuideComponent } from '@app/components/user-guide/user-guide.component';
import { canvasSize, WIDTH_SIDEBAR } from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';

@Component({
    selector: 'app-main-page',
    templateUrl: './main-page.component.html',
    styleUrls: ['./main-page.component.scss'],
})
export class MainPageComponent {
    disabled: boolean;

    constructor(public dialog: MatDialog, public galleryWindow: MatDialog, private drawingService: DrawingService, private router: Router) {
        this.disabled = localStorage.hasOwnProperty('draw');
    }

    openDialog(): void {
        this.dialog.open(UserGuideComponent, {
            disableClose: true,
            height: '95%',
        });
    }

    openGallery(): void {
        this.galleryWindow.open(GalleryComponent, { disableClose: true });
    }

    continueDraw(): void {
        this.router.navigate(['/editor']);
        const imageData = localStorage.getItem('draw') as string;
        const image = new Image();
        image.src = imageData as string;
        canvasSize.DEFAULT_WIDTH = parseInt(localStorage.getItem('width') as string, 10);
        canvasSize.DEFAULT_HEIGHT = parseInt(localStorage.getItem('height') as string, 10);
        image.onload = () => {
            this.drawingService.baseCtx.drawImage(image, 0, 0);
        };
    }
    newDraw(): void {
        this.router.navigate(['/editor']);
        localStorage.setItem('draw', ' ');
        localStorage.setItem('height', canvasSize.DEFAULT_HEIGHT.toString());
        localStorage.setItem('width', canvasSize.DEFAULT_WIDTH.toString());
        canvasSize.DEFAULT_WIDTH = (window.innerWidth - WIDTH_SIDEBAR) / 2;
        canvasSize.DEFAULT_HEIGHT = window.innerHeight / 2;
    }
}
