import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { EditorComponent } from '@app/components/editor/editor.component';
import { canvasSize, WIDTH_SIDEBAR } from '@app/constants/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { MainPageComponent } from './main-page.component';

// tslint:disable: no-magic-numbers
describe('MainPageComponent', () => {
    let component: MainPageComponent;
    let fixture: ComponentFixture<MainPageComponent>;
    let matDialogStub: jasmine.SpyObj<MatDialog>;
    let drawingServiceStub: DrawingService;
    let router: Router;

    beforeEach(async(() => {
        drawingServiceStub = new DrawingService();
        const canvasStub: HTMLCanvasElement = document.createElement('canvas');
        const ctxStub = canvasStub.getContext('2d') as CanvasRenderingContext2D;
        canvasStub.width = 40;
        canvasStub.height = 40;
        drawingServiceStub.canvas = canvasStub;
        drawingServiceStub.baseCtx = ctxStub;
        matDialogStub = jasmine.createSpyObj('MatDialog', ['open']);

        TestBed.configureTestingModule({
            declarations: [MainPageComponent],

            providers: [
                { provide: MatDialog, useValue: matDialogStub },
                { provide: DrawingService, useValue: drawingServiceStub },
            ],
            imports: [RouterTestingModule.withRoutes([{ path: 'editor', component: EditorComponent }])],
        }).compileComponents();
        router = TestBed.inject(Router);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MainPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('Should open userGuide Dialog ', () => {
        component.openDialog();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('Should open gallery Dialog ', () => {
        component.openGallery();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('should navigate to the editor on click of the button', () => {
        const navigateSpy = spyOn(router, 'navigate');
        component.continueDraw();
        expect(navigateSpy).toHaveBeenCalledWith(['/editor']);
    });

    it('should retrieve locally stored image data and draw it on the canvas', () => {
        const getImageSpy = spyOn(localStorage, 'getItem').and.callThrough();
        component.continueDraw();
        expect(getImageSpy).toHaveBeenCalled();
    });

    it('should set canvas parameters to DEFAULT values', () => {
        const canvasWidthStub = (window.innerWidth - WIDTH_SIDEBAR) / 2;
        const canvasHeightStub = window.innerHeight / 2;
        component.newDraw();
        expect(canvasSize.DEFAULT_HEIGHT).toEqual(canvasHeightStub);
        expect(canvasSize.DEFAULT_WIDTH).toEqual(canvasWidthStub);
    });
});
