import { canvasTestHelper } from './canvas-test-helper';
import { LoadedImage } from './loaded-image';

// tslint:disable: no-any
describe('LoadedImage', () => {
    it('should create an instance', () => {
        expect(new LoadedImage()).toBeTruthy();
    });

    it('should call draw', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const imageStub = new LoadedImage({} as ImageData);
        const spy = spyOn<any>(ctxStub, 'putImageData').and.callFake(() => {
            return;
        });
        imageStub.draw(ctxStub);
        expect(spy).toHaveBeenCalled();
    });
});
