import { MAX_SIZE, RESIZE_BOX_AREA } from '@app/constants/constants';
import { ResizingBox } from '@app/enums/resizing-box';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { Size } from './size';
import { Vec2 } from './vec2';

export abstract class ResizeSelection {
    protected boxLength: number = 14;
    protected resizeButton: number;

    resizedImageData: ImageData;
    topLeftPoint: Vec2 = { x: 0, y: 0 };
    size: Size = { width: MAX_SIZE, height: MAX_SIZE };

    constructor(protected drawingService: DrawingService) {}

    protected drawResizingBox(pointX: number, pointY: number): void {
        this.drawingService.previewCtx.beginPath();
        this.drawingService.previewCtx.strokeStyle = 'blue';
        this.drawingService.previewCtx.rect(pointX, pointY, this.boxLength, this.boxLength);
        this.drawingService.previewCtx.closePath();
        this.drawingService.previewCtx.stroke();
    }

    drawControlPoints(x: number, y: number): void {
        this.drawResizingBox(x - this.boxLength / 2, y - this.boxLength / 2);
        this.drawResizingBox(x + this.size.width - this.boxLength / 2, y - this.boxLength / 2);
        this.drawResizingBox(x - this.boxLength / 2, this.size.height + y - this.boxLength / 2);
        this.drawResizingBox(x + this.size.width - this.boxLength / 2, this.size.height + y - this.boxLength / 2);
        this.drawResizingBox(x + this.size.width / 2 - this.boxLength / 2, y - this.boxLength / 2);
        this.drawResizingBox(x - this.boxLength / 2, y + this.size.height / 2 - this.boxLength / 2);
        this.drawResizingBox(x + this.size.width - this.boxLength / 2, y + this.size.height / 2 - this.boxLength / 2);
        this.drawResizingBox(x + this.size.width / 2 - this.boxLength / 2, this.size.height + y - this.boxLength / 2);
    }

    drawResizingRectangle(): void {
        this.drawControlPoints(this.topLeftPoint.x, this.topLeftPoint.y);
        this.drawingService.previewCtx.beginPath();
        this.drawingService.previewCtx.setLineDash([1, 2]);
        this.drawingService.previewCtx.strokeStyle = 'blue';
        this.drawingService.previewCtx.strokeRect(this.topLeftPoint.x, this.topLeftPoint.y, this.size.width, this.size.height);
        this.drawingService.previewCtx.setLineDash([]);
        this.drawingService.previewCtx.closePath();
    }

    updateSelectionVariables(topLeftPoint: Vec2): void {
        this.topLeftPoint.x = topLeftPoint.x;
        this.topLeftPoint.y = topLeftPoint.y;
    }

    resizingTest(x: number, y: number, size: Size): number {
        let dx: number;
        let dy: number;
        const bottomRightPoint: Vec2 = { x: this.topLeftPoint.x + this.size.width, y: this.size.height + this.topLeftPoint.y };
        // point haut-gauche
        dx = x - this.topLeftPoint.x;
        dy = y - this.topLeftPoint.y;
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.TopLeft;
            return ResizingBox.TopLeft;
        }
        // point haut-droite
        dx = x - bottomRightPoint.x;
        dy = y - this.topLeftPoint.y;
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.TopRight;
            return ResizingBox.TopRight;
        }
        // point bas-droite
        dx = x - bottomRightPoint.x;
        dy = y - bottomRightPoint.y;
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.BottomRight;
            return ResizingBox.BottomRight;
        }
        // point bas-gauche
        dx = x - this.topLeftPoint.x;
        dy = y - bottomRightPoint.y;
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.BottomLeft;
            return ResizingBox.BottomLeft;
        }
        // point haut-centre
        dx = x - (this.topLeftPoint.x + size.width / 2);
        dy = y - this.topLeftPoint.y;
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.TopMiddle;
            return ResizingBox.TopMiddle;
        }
        // point bas-centre
        dx = x - (this.topLeftPoint.x + size.width / 2);
        dy = y - (this.topLeftPoint.y + size.height);
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.BottomMiddle;
            return ResizingBox.BottomMiddle;
        }
        // point gauche-centre
        dx = x - this.topLeftPoint.x;
        dy = y - (this.topLeftPoint.y + size.height / 2);
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.LeftMiddle;
            return ResizingBox.LeftMiddle;
        }
        // point droite-centre
        dx = x - (this.topLeftPoint.x + size.width);
        dy = y - (this.topLeftPoint.y + size.height / 2);
        if (dx * dx + dy * dy <= this.boxLength * RESIZE_BOX_AREA) {
            this.resizeButton = ResizingBox.RightMiddle;
            return ResizingBox.RightMiddle;
        }
        return 0;
    }

    protected findShiftPoint(startPoint: Vec2, currentPoint: Vec2, size: Size): void {
        const width = Math.abs(currentPoint.x - startPoint.x);
        const height = Math.abs(currentPoint.y - startPoint.y);

        if (width < height) {
            if (
                (currentPoint.x <= startPoint.x && currentPoint.y <= startPoint.y) ||
                (currentPoint.x >= startPoint.x && currentPoint.y <= startPoint.y)
            ) {
                currentPoint.y -= width - height;
                size.height = size.width;
            } else {
                currentPoint.y += width - height;
                size.height = size.width;
            }
        } else {
            if (
                (currentPoint.x <= startPoint.x && currentPoint.y <= startPoint.y) ||
                (currentPoint.x <= startPoint.x && currentPoint.y >= startPoint.y)
            ) {
                currentPoint.x -= height - width;
                size.width = size.height;
            } else {
                currentPoint.x += height - width;
                size.width = size.height;
            }
        }
    }

    createCopyCanvas(imageData: ImageData): HTMLCanvasElement {
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        const canvas: HTMLCanvasElement = document.createElement('canvas');
        canvas.width = imageData.width;
        canvas.height = imageData.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.putImageData(imageData, 0, 0);
        return canvas;
    }
}
