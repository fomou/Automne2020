import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { Resize } from './resize';

// tslint:disable: typedef
class DrawService extends DrawingService {
    canvas = canvasTestHelper.canvas;
    previewCanvas = canvasTestHelper.canvas;
    borderCanvas = canvasTestHelper.div;
    background = canvasTestHelper.div;

    // tslint:disable-next-line: no-empty
    setBackground(ctx: CanvasRenderingContext2D): void {}
}

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('Resize', () => {
    let drawServiceStub: DrawingService;

    beforeEach(() => {
        drawServiceStub = new DrawingService();
        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceStub }],
        });
    });
    it('should create', () => {
        expect(new Resize({} as DrawingService, {} as HTMLImageElement, 4, 4, 2, 2)).toBeTruthy();
    });

    it('#draw should call drawImage ', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const drawingServiceStub = new DrawService();
        const resize = new Resize(drawingServiceStub, {} as HTMLImageElement, 4, 4, 2, 2);

        const spy = spyOn<any>(ctxStub, 'drawImage');
        resize.draw(ctxStub);
        expect(spy).toHaveBeenCalled();
    });

    it('#undraw should call drawImage ', () => {
        const canvasStub = canvasTestHelper.canvas;
        const divStub = canvasTestHelper.div;
        const drawingServiceStub = { canvas: canvasStub, previewCanvas: canvasStub, borderCanvas: divStub, background: divStub } as DrawingService;
        const resize = new Resize(drawingServiceStub, {} as HTMLImageElement, 4, 4, 2, 2);
        resize.undraw();
        expect(canvasStub.width).toBe(4);
        expect(canvasStub.height).toEqual(4);
    });
});
