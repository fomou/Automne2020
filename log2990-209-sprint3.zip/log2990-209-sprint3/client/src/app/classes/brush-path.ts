import * as CONSTANT from '@app/constants/constants';
import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class BrushPath extends Drawable {
    private pathData: Vec2[];
    private color: string;
    private img: HTMLImageElement;
    private width: number;

    constructor(pathData: Vec2[], color: string, width: number, img: HTMLImageElement) {
        super();
        this.pathData = pathData;
        this.color = color;
        this.width = width;
        this.img = img;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.beginPath();
        const size: number = this.pathData.length;
        const canvasImage: HTMLCanvasElement = this.getImage();
        for (let i = 0; i < size - 1; i++) {
            const dist: number = this.distanceBetween(this.pathData[i], this.pathData[i + 1]);
            const angle: number = this.angleBetween(this.pathData[i], this.pathData[i + 1]);
            for (let j = 0; j < dist; j = j + CONSTANT.IMAGES_BY_POINT) {
                const x: number = this.pathData[i].x + Math.sin(angle) * j - CONSTANT.ANGLE_BRUSH;
                const y: number = this.pathData[i].y + Math.cos(angle) * j - CONSTANT.ANGLE_BRUSH;
                ctx.drawImage(canvasImage, x, y);
            }
        }
        ctx.stroke();
    }

    private distanceBetween(point1: Vec2, point2: Vec2): number {
        return Math.sqrt(Math.pow(point2.x - point1.x, 2) + Math.pow(point2.y - point1.y, 2));
    }

    private angleBetween(point1: Vec2, point2: Vec2): number {
        return Math.atan2(point2.x - point1.x, point2.y - point1.y);
    }

    private getImage(): HTMLCanvasElement {
        const canvas: HTMLCanvasElement = document.createElement('canvas');
        canvas.width = this.img.width;
        canvas.height = this.img.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.fillStyle = this.color;
        copyCanvas.fillRect(0, 0, this.img.width, this.img.height);
        copyCanvas.globalCompositeOperation = 'destination-in';
        copyCanvas.drawImage(this.img, 0, 0, this.img.width / this.width, this.img.height / this.width);
        return canvas;
    }
}
