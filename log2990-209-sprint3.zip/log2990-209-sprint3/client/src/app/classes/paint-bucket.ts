import { Drawable } from './drawable';

export class PaintBucket extends Drawable {
    private contiguous: boolean;
    private imageDataContiguous: ImageData;
    private imageDataNoContiguous: ImageData;

    constructor(contiguous: boolean, img: ImageData, imgContiguous: ImageData) {
        super();
        this.contiguous = contiguous;
        this.imageDataNoContiguous = img;
        this.imageDataContiguous = imgContiguous;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        if (this.contiguous) {
            this.fillFlood(ctx, this.imageDataContiguous);
        } else {
            this.fillFlood(ctx, this.imageDataNoContiguous);
        }
    }

    private fillFlood(ctx: CanvasRenderingContext2D, img: ImageData): void {
        ctx.putImageData(img, 0, 0);
    }
}
