import { Vec2 } from './vec2';

export interface PixelData {
    centerPoint: Vec2;
    imageData: ImageData;
    width?: number;
    height?: number;
}
