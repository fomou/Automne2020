import { Drawable } from './drawable';
import { Vec2 } from './vec2';
export class MagicWand extends Drawable {
    private imageData: ImageData;
    private baseImageData: ImageData;
    private selectionTopLeft: Vec2;
    private angle: number;

    constructor(img: ImageData, baseImgData: ImageData, topLeftPoint: Vec2, angle: number) {
        super();
        this.imageData = img;
        this.baseImageData = baseImgData;
        this.selectionTopLeft = topLeftPoint;
        this.angle = angle;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.putImageData(this.baseImageData, 0, 0);
        const canvas: HTMLCanvasElement = document.createElement('canvas');
        canvas.width = this.imageData.width;
        canvas.height = this.imageData.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.putImageData(this.imageData, 0, 0);
        ctx.save();
        ctx.translate(this.selectionTopLeft.x + canvas.width / 2, this.selectionTopLeft.y + canvas.height / 2);
        ctx.rotate(this.angle);
        ctx.translate(-canvas.width / 2, -canvas.height / 2);
        console.log(this.selectionTopLeft.x);
        ctx.drawImage(canvas, 0, 0);
        ctx.restore();
    }
}
