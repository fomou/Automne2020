const WIDTH = 100;
const HEIGHT = 100;

const canvas = document.createElement('canvas');
canvas.width = WIDTH;
canvas.height = HEIGHT;

const drawCanvas = document.createElement('canvas');
drawCanvas.width = WIDTH;
drawCanvas.height = HEIGHT;

const selectionCanvas = document.createElement('canvas');
selectionCanvas.width = WIDTH;
selectionCanvas.height = HEIGHT;

const div = document.createElement('div');
div.style.width = WIDTH + 'px';
div.style.height = HEIGHT + 'px';

const canvasTestHelper = { canvas, drawCanvas, selectionCanvas, div };
export { canvasTestHelper };
