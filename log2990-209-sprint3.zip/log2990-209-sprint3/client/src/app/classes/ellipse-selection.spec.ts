import { canvasTestHelper } from './canvas-test-helper';
import { EllipseSelection } from './ellipse-selection';
import { Vec2 } from './vec2';

// tslint:disable: no-any
// tslint:disable:no-string-literal
// tslint:disable:no-magic-numbers
describe('EllipseSelection', () => {
    const point: Vec2 = { x: 20, y: 30 };
    const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
    const imageData = ctxStub.getImageData(300, 50, canvasTestHelper.canvas.width, canvasTestHelper.canvas.height);
    const ellipseSelection = new EllipseSelection(imageData, point, point, 1);

    it('should create an instance', () => {
        expect(ellipseSelection).toBeTruthy();
    });
    it('draw should call beginPath, stroke,ellipse  and deleteEllipse', () => {
        const beginPathSpy = spyOn<any>(ctxStub, 'beginPath');
        const strokeSpy = spyOn<any>(ctxStub, 'stroke');
        const ellipseSpy = spyOn<any>(ctxStub, 'ellipse');
        const deleteEllipsePsy = spyOn<any>(ellipseSelection, 'deleteEllipse');
        ellipseSelection.draw(ctxStub);
        expect(deleteEllipsePsy).toHaveBeenCalled();
        expect(beginPathSpy).toHaveBeenCalled();
        expect(strokeSpy).toHaveBeenCalled();
        expect(ellipseSpy).toHaveBeenCalled();
    });
    it('deleteEllipse should call beginPath, fill, ellipse, closePath and put canvas fillStyle to white', () => {
        const beginPathSpy = spyOn<any>(ctxStub, 'beginPath');
        const fillSpy = spyOn<any>(ctxStub, 'fill');
        const ellipseSpy = spyOn<any>(ctxStub, 'ellipse');
        const closePathPsy = spyOn<any>(ctxStub, 'closePath');
        ellipseSelection['deleteEllipse'](ctxStub);
        expect(fillSpy).toHaveBeenCalled();
        expect(beginPathSpy).toHaveBeenCalled();
        expect(closePathPsy).toHaveBeenCalled();
        expect(ellipseSpy).toHaveBeenCalled();
        expect(ctxStub.fillStyle).toEqual('#ffffff'); // couleur blanche
    });
    it('getImageDataCanvas should a canvas with the same width, height and imageData ad the one past to the constructor  ', () => {
        const canvas = ellipseSelection['getImageDataCanvas']();
        const ctx = canvas.getContext('2d') as CanvasRenderingContext2D;
        expect(canvas.width).toEqual(100);
        expect(canvas.height).toEqual(100);
        expect(ctx.getImageData(0, 0, canvas.width, canvas.height)).toEqual(imageData);
    });
});
