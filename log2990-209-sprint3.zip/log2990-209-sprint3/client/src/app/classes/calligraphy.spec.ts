import { Calligraphy } from './calligraphy';
import { canvasTestHelper } from './canvas-test-helper';
import { Vec2 } from './vec2';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('Calligraphy', () => {
    it('should create an instance', () => {
        expect(new Calligraphy([], 1, 2, 'red')).toBeTruthy();
    });
    it('should create an instance', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const point = { x: 2, y: 2 } as Vec2;
        const beginPathSpy = spyOn<any>(ctxStub, 'beginPath').and.callThrough();
        const stroke = spyOn<any>(ctxStub, 'stroke').and.callThrough();
        const lineTo = spyOn<any>(ctxStub, 'lineTo').and.callThrough();
        const calligraphy = new Calligraphy([point, point], 1, 2, 'red');
        calligraphy.draw(ctxStub);
        expect(beginPathSpy).toHaveBeenCalled();
        expect(stroke).toHaveBeenCalled();
        expect(lineTo).toHaveBeenCalledTimes(2);
    });
});
