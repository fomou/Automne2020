import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { CutElement } from './cut-element';
import { Vec2 } from './vec2';

// tslint:disable:no-string-literal
// tslint:disable: no-magic-numbers
// tslint:disable:no-any
describe('CutElement', () => {
    it('should create an instance', () => {
        expect(new CutElement({} as Vec2, 10, 10, false)).toBeTruthy();
    });

    it('draw should delete rectangle if the type is a rectangle', () => {
        const element = new CutElement({ x: 20, y: 20 }, 100, 100, true);
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const spy = spyOn<any>(element, 'deleteRectangle');
        element.draw(ctx);
        expect(spy).toHaveBeenCalled();
    });

    it('draw should delete ellipse if the type is a not rectangle', () => {
        const element = new CutElement({ x: 20, y: 20 }, 100, 100, false);
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const spy = spyOn<any>(element, 'deleteEllipse');
        element.draw(ctx);
        expect(spy).toHaveBeenCalled();
    });

    it('deleteRectangle should call fillRect of the context', () => {
        const element = new CutElement({ x: 20, y: 20 }, 100, 100, false);
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const spy = spyOn<any>(ctx, 'fillRect');
        element['deleteRectangle'](ctx);
        expect(spy).toHaveBeenCalled();
    });

    it('deleteEllipse should call fillRect of the context', () => {
        const element = new CutElement({ x: 20, y: 20 }, 100, 100, false);
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const spy = spyOn<any>(ctx, 'ellipse');
        element['deleteEllipse'](ctx);
        expect(spy).toHaveBeenCalled();
    });
});
