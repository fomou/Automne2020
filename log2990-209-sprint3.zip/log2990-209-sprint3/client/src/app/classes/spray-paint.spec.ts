import { SprayPaint } from './spray-paint';

describe('SprayPaint', () => {
    it('should create an instance', () => {
        expect(new SprayPaint('src')).toBeTruthy();
    });
});
