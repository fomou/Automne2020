import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class EllipseSelection extends Drawable {
    private imageData: ImageData;
    private center: Vec2;
    private angle: number;
    private deletedCenter: Vec2;

    constructor(imageData: ImageData, center: Vec2, deletedCenter: Vec2, angle: number) {
        super();
        this.imageData = imageData;
        this.center = center;
        this.angle = angle;
        this.deletedCenter = deletedCenter;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        this.deleteEllipse(ctx);
        const canvas = this.getImageDataCanvas();
        ctx.save();
        ctx.translate(this.center.x, this.center.y);
        ctx.rotate(this.angle);
        ctx.beginPath();
        ctx.strokeStyle = '#00000000'; // contour transparent
        ctx.ellipse(0, 0, canvas.width / 2, canvas.height / 2, 0, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.clip();
        ctx.closePath();
        ctx.translate(-canvas.width / 2, -canvas.height / 2);
        ctx.drawImage(canvas, 0, 0);
        ctx.restore();
    }

    private deleteEllipse(ctx: CanvasRenderingContext2D): void {
        ctx.beginPath();
        ctx.fillStyle = 'white';
        ctx.ellipse(this.deletedCenter.x, this.deletedCenter.y, this.imageData.width / 2, this.imageData.height / 2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();
    }

    private getImageDataCanvas(): HTMLCanvasElement {
        const canvas = document.createElement('canvas');
        canvas.width = this.imageData.width;
        canvas.height = this.imageData.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.putImageData(this.imageData, 0, 0);
        return canvas;
    }
}
