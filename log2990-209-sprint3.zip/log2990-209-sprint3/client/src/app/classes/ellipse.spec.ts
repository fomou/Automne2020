import { canvasTestHelper } from './canvas-test-helper';
import { Ellipse } from './ellipse';
import { Vec2 } from './vec2';

// tslint:disable: no-any
describe('Ellipse ', () => {
    it('should create', () => {
        expect(new Ellipse({} as Vec2, 2, 2, 'fill', 2, 'black', 'red')).toBeTruthy();
    });

    it('case stroke', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const ellipse = new Ellipse({} as Vec2, 2, 2, 'stroke', 2, 'black', 'red');

        const spy = spyOn<any>(ctx, 'stroke').and.callThrough();

        ellipse.draw(ctx);

        expect(spy).toHaveBeenCalled();
    });

    it('case fill', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const ellipse = new Ellipse({} as Vec2, 2, 2, 'fill', 2, 'black', 'red');

        const spy = spyOn<any>(ctx, 'fill').and.callThrough();

        ellipse.draw(ctx);

        expect(spy).toHaveBeenCalled();
    });

    it('case outline', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const ellipse = new Ellipse({} as Vec2, 2, 2, 'outline', 2, 'black', 'red');

        const fillSpy = spyOn<any>(ctx, 'fill').and.callThrough();
        const strokeSpy = spyOn<any>(ctx, 'stroke').and.callThrough();
        ellipse.draw(ctx);

        expect(fillSpy).toHaveBeenCalled();
        expect(strokeSpy).toHaveBeenCalled();
    });
});
