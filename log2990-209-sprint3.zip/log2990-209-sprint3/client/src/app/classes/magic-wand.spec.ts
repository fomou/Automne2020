import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { MagicWand } from './magic-wand';

// tslint:disable:no-magic-numbers
describe('MagicWand', () => {
    const imgData = new ImageData(100, 100);
    const magicWand = new MagicWand(imgData, imgData, { x: 2, y: 2 }, 15);
    it('should create an instance', () => {
        expect(magicWand).toBeTruthy();
    });

    it('#draw should putImage and drawImage', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const drawSpy = spyOn(ctx, 'drawImage');
        magicWand.draw(ctx);
        expect(drawSpy).toHaveBeenCalled();
    });
});
