import { BrushPath } from './brush-path';
import { canvasTestHelper } from './canvas-test-helper';
import { Vec2 } from './vec2';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: no-string-literal
const img: HTMLImageElement = document.createElement('img');
img.width = 10;
img.height = 10;
const brushPath = new BrushPath([], 'red', 1, img);

describe('BrushPath', () => {
    it('should create an instance', () => {
        expect(brushPath).toBeTruthy();
    });
    it('draw should call beginPath, stroke, drawImage ', () => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        const pathBrush = new BrushPath([point1, point2, point1, point2], 'red', 1, img);
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const beginPathSpy = spyOn<any>(ctxStub, 'beginPath');
        const strokeSpy = spyOn<any>(ctxStub, 'stroke');
        const drawImageSpy = spyOn<any>(ctxStub, 'drawImage');
        pathBrush.draw(ctxStub);
        expect(beginPathSpy).toHaveBeenCalled();
        expect(strokeSpy).toHaveBeenCalled();
        expect(drawImageSpy).toHaveBeenCalled();
    });

    it('should calculate distance between two point', () => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        expect(brushPath['distanceBetween'](point1, point2)).toEqual(5);
    });

    it('should calculate angle between two point', () => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        const expectedAngle = Math.atan2(point2.x - point1.x, point2.y - point1.y);
        expect(brushPath['angleBetween'](point1, point2)).toEqual(expectedAngle);
    });

    it('getImage should return HtmlImage', () => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        const pathBrush = new BrushPath([point1, point2, point1, point2], 'red', 1, img);
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const strokeSpy = spyOn<any>(ctxStub, 'stroke').and.callThrough();
        const beginPathSpy = spyOn<any>(ctxStub, 'beginPath').and.callThrough();
        const drawImageSpy = spyOn<any>(ctxStub, 'drawImage').and.callThrough();

        pathBrush.draw(ctxStub);
        expect(strokeSpy).toHaveBeenCalled();
        expect(beginPathSpy).toHaveBeenCalled();
        expect(drawImageSpy).toHaveBeenCalled();
    });
});
