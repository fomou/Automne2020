import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class RectangleSelection extends Drawable {
    private imageData: ImageData;
    private selectedWidth: number;
    private selectedHeight: number;
    private topLeftPoint: Vec2;
    private startPoint: Vec2;
    private angle: number;

    constructor(imagedata: ImageData, startPoint: Vec2, point: Vec2, width: number, height: number, angle: number) {
        super();
        this.imageData = imagedata;
        this.selectedHeight = height;
        this.selectedWidth = width;
        this.topLeftPoint = point;
        this.angle = angle;
        this.startPoint = startPoint;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.fillStyle = 'white';
        ctx.fillRect(this.startPoint.x, this.startPoint.y, this.selectedWidth, this.selectedHeight);
        this.rotate(ctx, this.angle);
    }

    private rotate(ctx: CanvasRenderingContext2D, angle: number): void {
        const canvas = this.getImageDataCanvas();
        ctx.save();
        ctx.translate(this.topLeftPoint.x + canvas.width / 2, this.topLeftPoint.y + canvas.height / 2);
        ctx.rotate(angle);
        ctx.translate(-canvas.width / 2, -canvas.height / 2);
        ctx.drawImage(canvas, 0, 0);
        ctx.restore();
    }

    private getImageDataCanvas(): HTMLCanvasElement {
        const canvas = document.createElement('canvas');
        canvas.width = this.imageData.width;
        canvas.height = this.imageData.height;
        const copyCanvas: CanvasRenderingContext2D = canvas.getContext('2d') as CanvasRenderingContext2D;
        copyCanvas.putImageData(this.imageData, 0, 0);

        return canvas;
    }
}
