import { canvasTestHelper } from './canvas-test-helper';
import { PaintBucket } from './paint-bucket';

// tslint:disable: no-any
// tslint:disable: no-string-literal
describe('PaintBucket', () => {
    it('should create an instance', () => {
        expect(new PaintBucket(false, {} as ImageData, {} as ImageData)).toBeTruthy();
    });

    it('should draw with image on contiguous', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const contiImg = {} as ImageData;
        const painBucket = new PaintBucket(true, {} as ImageData, contiImg);
        const spy = spyOn<any>(painBucket, 'fillFlood');

        painBucket.draw(ctx);

        expect(spy).toHaveBeenCalledWith(ctx, contiImg);
    });

    it('should draw with image on not contiguous', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const noContiImg = {} as ImageData;
        const painBucket = new PaintBucket(false, noContiImg, {} as ImageData);
        const spy = spyOn<any>(painBucket, 'fillFlood');

        painBucket.draw(ctx);

        expect(spy).toHaveBeenCalledWith(ctx, noContiImg);
    });

    it('fillFlood should call putImageData', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const noContiImg = {} as ImageData;
        const painBucket = new PaintBucket(false, noContiImg, {} as ImageData);
        const spy = spyOn<any>(ctx, 'putImageData');

        painBucket['fillFlood'](ctx, noContiImg);

        expect(spy).toHaveBeenCalledWith(noContiImg, 0, 0);
    });
});
