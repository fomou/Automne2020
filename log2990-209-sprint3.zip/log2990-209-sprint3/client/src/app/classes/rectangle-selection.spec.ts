import { canvasTestHelper } from './canvas-test-helper';
import { RectangleSelection } from './rectangle-selection';
import { Vec2 } from './vec2';

// tslint:disable:no-any
// tslint:disable: no-string-literal
// tslint:disable:no-magic-numbers
describe('RectangleSelection', () => {
    it('should create an instance', () => {
        expect(new RectangleSelection({} as ImageData, {} as Vec2, {} as Vec2, 1, 1, 1)).toBeTruthy();
    });

    it('draw should call putImagedata and fillRect', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const rectangle = new RectangleSelection({} as ImageData, {} as Vec2, {} as Vec2, 1, 1, 1);
        const fillRecSpy = spyOn<any>(ctxStub, 'fillRect').and.callFake(() => {
            return;
        });
        const igmSpy = spyOn<any>(rectangle, 'rotate').and.callFake(() => {
            return;
        });
        rectangle.draw(ctxStub);
        expect(fillRecSpy).toHaveBeenCalled();
        expect(igmSpy).toHaveBeenCalled();
    });

    it('rotate should call transformation operation ', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const rectangle = new RectangleSelection(new ImageData(200, 200), {} as Vec2, {} as Vec2, 1, 1, 1);
        const fillRecSpy = spyOn<any>(ctxStub, 'drawImage').and.callFake(() => {
            return;
        });
        const igmSpy = spyOn<any>(ctxStub, 'rotate').and.callFake(() => {
            return;
        });

        const translate = spyOn<any>(ctxStub, 'translate').and.callFake(() => {
            return;
        });

        rectangle['rotate'](ctxStub, 20);
        expect(fillRecSpy).toHaveBeenCalled();
        expect(igmSpy).toHaveBeenCalled();
        expect(translate).toHaveBeenCalledTimes(2);
    });
});
