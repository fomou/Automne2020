import { canvasTestHelper } from './canvas-test-helper';
import { Stamp } from './stamp';
import { Vec2 } from './vec2';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('Stamp', () => {
    it('should create an instance', () => {
        expect(new Stamp({} as Vec2, '', 1, 0.4)).toBeTruthy();
    });
    it(' draw should call save, translate, rotate, drawImage and restore', () => {
        const stamp = new Stamp({} as Vec2, '', 1, 0.4);
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const saveSpy = spyOn<any>(ctxStub, 'save');
        const translateSpy = spyOn<any>(ctxStub, 'translate');
        const rotateSpy = spyOn<any>(ctxStub, 'rotate');
        const drawImageSpy = spyOn<any>(ctxStub, 'drawImage');
        const restoreSpy = spyOn<any>(ctxStub, 'restore');
        stamp.draw(ctxStub);
        expect(saveSpy).toHaveBeenCalled();
        expect(translateSpy).toHaveBeenCalled();
        expect(rotateSpy).toHaveBeenCalled();
        expect(drawImageSpy).toHaveBeenCalled();
        expect(restoreSpy).toHaveBeenCalled();
    });
});
