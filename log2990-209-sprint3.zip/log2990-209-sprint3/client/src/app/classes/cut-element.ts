import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class CutElement extends Drawable {
    private topLetPoint: Vec2;
    private width: number;
    private height: number;
    private rectangleType: boolean;

    constructor(topLeftPoint: Vec2, width: number, height: number, rectangle: boolean) {
        super();
        this.topLetPoint = topLeftPoint;
        this.width = width;
        this.height = height;
        this.rectangleType = rectangle;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        this.rectangleType ? this.deleteRectangle(ctx) : this.deleteEllipse(ctx);
    }

    private deleteRectangle(ctx: CanvasRenderingContext2D): void {
        ctx.fillStyle = 'white';
        ctx.fillRect(this.topLetPoint.x, this.topLetPoint.y, this.width, this.height);
    }

    private deleteEllipse(ctx: CanvasRenderingContext2D): void {
        ctx.beginPath();
        ctx.fillStyle = 'white';
        ctx.ellipse(this.topLetPoint.x, this.topLetPoint.y, this.width / 2, this.height / 2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();
    }
}
