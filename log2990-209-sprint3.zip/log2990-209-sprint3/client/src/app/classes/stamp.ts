import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class Stamp extends Drawable {
    private position: Vec2;
    private angle: number;
    private scale: number;
    private src: string;

    constructor(position: Vec2, src: string, angle: number, scale: number) {
        super();
        this.position = position;
        this.scale = scale;
        this.src = src;
        this.angle = angle;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        ctx.rotate(this.angle);
        ctx.scale(this.scale, this.scale);
        const image = new Image();
        image.src = this.src;
        ctx.translate(-image.width / 2, -image.height / 2);

        ctx.drawImage(image, 0, 0);

        ctx.restore();
    }
}
