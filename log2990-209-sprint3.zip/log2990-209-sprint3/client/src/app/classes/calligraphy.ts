import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class Calligraphy extends Drawable {
    private pathData: Vec2[];
    private height: number;
    private angle: number;
    private color: string;

    constructor(pathData: Vec2[], height: number, angle: number, color: string) {
        super();
        this.pathData = pathData;
        this.angle = angle;
        this.height = height;
        this.color = color;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.lineWidth = 2;
        ctx.strokeStyle = this.color;
        ctx.beginPath();
        for (let i = 0; i < this.pathData.length - 1; i++) {
            ctx.lineTo(this.pathData[i].x, this.pathData[i].y);
            for (let j = 0; j < this.height; j++) {
                ctx.moveTo(this.pathData[i].x + Math.cos(this.angle) * j, this.pathData[i].y - Math.sin(this.angle) * j);
                ctx.lineTo(this.pathData[i + 1].x + Math.cos(this.angle) * j, this.pathData[i + 1].y - Math.sin(this.angle) * j);
            }
        }

        ctx.stroke();
    }
}
