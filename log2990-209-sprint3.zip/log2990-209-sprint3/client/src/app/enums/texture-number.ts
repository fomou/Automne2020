export enum Texture {
    Texture1 = 1,
    Texture2 = 2,
    Texture3 = 3,
    Texture4 = 4,
    Texture5 = 5,
}
