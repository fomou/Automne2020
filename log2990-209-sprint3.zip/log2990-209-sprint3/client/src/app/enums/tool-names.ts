export enum ToolNames {
    Rectangle = 'Rectangle',
    Ellipse = 'Ellipse',
    Polygon = 'Polygone',
    Pencil = 'Crayon',
    Brush = 'Pinceau',
    Feather = 'Plume',
    SprayPaint = 'Aérosol',
}
