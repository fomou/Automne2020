export enum ResizingBox {
    TopLeft = 1,
    TopRight = 2,
    BottomRight = 3,
    BottomLeft = 4,
    TopMiddle = 5,
    BottomMiddle = 6,
    LeftMiddle = 7,
    RightMiddle = 8,
    Center = 9,
}
