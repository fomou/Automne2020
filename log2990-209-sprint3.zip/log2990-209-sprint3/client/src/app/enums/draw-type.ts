export enum DrawingType {
    Fill = 'fill',
    Stroke = 'stroke',
    Outline = 'outline',
}
