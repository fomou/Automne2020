export enum ColorType {
    Primary = 'primary',
    Secondary = 'secondary',
}
