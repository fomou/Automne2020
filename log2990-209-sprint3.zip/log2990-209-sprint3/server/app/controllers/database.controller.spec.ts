import { Application } from '@app/app';
import { DatabaseService } from '@app/services/database.service';
import { TYPES } from '@app/types';
import { Drawing } from '@common/communication/drawing';
import { expect } from 'chai';
import * as fs from 'fs';
import * as Httpstatus from 'http-status-codes';
import * as sinon from 'sinon';
import * as supertest from 'supertest';
import { Stubbed, testingContainer } from '../../test/test-utils';
import { DatabaseController } from './database.controller';

describe('DatabaseController', () => {
    let drawing: Drawing = {
        name: 'redDot',
        tags: ['tag1'],
        dataUrl: 'testData',
    };

    let databaseService: Stubbed<DatabaseService>;
    let app: Express.Application;

    if (!fs.existsSync('../uploads/')) {
        fs.mkdirSync('../uploads/');
    }
    fs.writeFile('../uploads/' + '5fce1055b308703d71326051' + '.png', 'testData', () => {});

    beforeEach(async () => {
        const [container, sandbox] = await testingContainer();
        container.rebind(TYPES.DatabaseService).toConstantValue({
            addDrawing: sandbox.stub().resolves(),
            getSpecificDrawing: sandbox.stub().callsFake(() => {
                return new Promise((resolve) => {
                    databaseService.drawing = [drawing] as Drawing[] & sinon.SinonStub;
                    resolve();
                });
            }),
            ServerImages: sandbox.stub().callsFake(() => {
                return new Promise((resolve) => {
                    databaseService.idImage = ['name1', 'name2'] as string[] & sinon.SinonStub;
                    resolve();
                });
            }),
            deleteDrawing: sandbox.stub().resolves(),

            start: sandbox.stub().resolves(),
            closeConnection: sandbox.stub().resolves(),
        });

        databaseService = container.get(TYPES.DatabaseService);

        app = container.get<Application>(TYPES.Application).app;
    });

    it('Should return all drawings', async () => {
        databaseService.getSpecificDrawing.resolves(drawing);
        await supertest(app).get('/api/drawing/').expect(Httpstatus.StatusCodes.OK);
    });

    it('Should return error when the image is not found', async () => {
        databaseService.ServerImages.rejects();
        return supertest(app).get('/api/drawing/').expect(Httpstatus.StatusCodes.NOT_FOUND);
    });

    it('Should return  status error 500 status when path doesnt exist', async () => {
        return supertest(app).get('/api/drawing/test').expect(Httpstatus.StatusCodes.INTERNAL_SERVER_ERROR);
    });

    it('Should return drawing data on a get request with id to the drawing', async () => {
        return supertest(app).get('/api/drawing/id/:id').expect(Httpstatus.StatusCodes.OK);
    });

    it('Should return BAD REQUEST failing to add the drawing to the server', async () => {
        databaseService.addDrawing.resolves(drawing);
        return supertest(app).post('/api/drawing/add').send(drawing).expect(Httpstatus.StatusCodes.BAD_REQUEST);
    });

    it('Should return no content on a delete request with id to the drawing', async () => {
        return supertest(app).delete('/api/drawing/delete/:id').expect(Httpstatus.StatusCodes.NO_CONTENT);
    });

    it('Should return not found on a delete request with a bad ID to the drawing', async () => {
        databaseService.deleteDrawing.throws();
        return supertest(app).delete('/api/drawing/delete/:id').expect(Httpstatus.StatusCodes.NOT_FOUND);
    });

    it('getDataUrl should return no image data Urls when uploads folder is empty ', async () => {
        const databaseController = new DatabaseController(databaseService);
        const result = databaseController.getDataUrl();
        expect(result.length).to.be.equal(0);
    });
});
