import { SendEmail } from '@app/services/send-email.service';
import { NextFunction, Request, Response, Router } from 'express';
import * as FormData from 'form-data';
import * as Httpstatus from 'http-status-codes';

import { inject, injectable } from 'inversify';
import { TYPES } from '../types';
@injectable()
export class SendEmailController {
    router: Router;

    constructor(@inject(TYPES.SendEmail) private sendEmail: SendEmail) {
        this.configureRouter();
    }

    private configureRouter(): void {
        this.router = Router();

        this.router.post('/', async (req: Request, res: Response, next: NextFunction) => {
            const formData = new FormData();
            formData.append('to', req.body.email);
            const drawingData: string = req.body.drawUrl.split(',')[1];
            formData.append('payload', Buffer.from(drawingData, 'base64'), {
                contentType: 'image/' + req.body.typeImage,
                filename: req.body.fileName + '.' + req.body.typeImage,
            });
            this.sendEmail
                .sendEmail(formData)
                .then(() => {
                    res.status(Httpstatus.StatusCodes.CREATED);
                })
                .catch((err: Error) => {
                    res.status(Httpstatus.StatusCodes.INTERNAL_SERVER_ERROR).send(err.message);
                });
        });
    }
}
