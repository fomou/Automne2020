import { Application } from '@app/app';
import { SendEmail } from '@app/services/send-email.service';
import { TYPES } from '@app/types';
import { expect } from 'chai';
import * as Httpstatus from 'http-status-codes';
import * as supertest from 'supertest';
import { Stubbed, testingContainer } from '../../test/test-utils';

describe('sendEmail Controller', () => {
    let sendEmailService: Stubbed<SendEmail>;
    let app: Express.Application;

    beforeEach(async () => {
        const [container, sandbox] = await testingContainer();

        container.rebind(TYPES.SendEmail).toConstantValue({
            sendEmail: sandbox.stub().returns({}).resolves(),
        });
        sendEmailService = container.get(TYPES.SendEmail);
        app = container.get<Application>(TYPES.Application).app;
    });

    it('Should return internal error when failing to send and email of a drawing ', async () => {
        const drawToExport = {
            drawUrl: 'test,Data',
            fileName: 'fileName',
            email: 'userEmail',
            typeImage: 'chosenExportMode',
        };
        sendEmailService.sendEmail.rejects();
        return supertest(app).post('/api/sendEmail/').send(drawToExport).expect(Httpstatus.StatusCodes.INTERNAL_SERVER_ERROR);
    });
    
    it('Should call sendEmail on successful email post request', async () => {
        const stub = sendEmailService.sendEmail.resolves();
        const drawToExport = {
            drawUrl: 'test,Data',
            fileName: 'fileName',
            email: 'userEmail',
            typeImage: 'chosenExportMode',
        };
        supertest(app).post('/api/sendEmail/').send(drawToExport).then((response)=>{
           expect(stub.called).be.true;
        });
    });
});
