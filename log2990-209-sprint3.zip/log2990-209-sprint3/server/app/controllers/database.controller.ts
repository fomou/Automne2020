import { DatabaseService } from '@app/services/database.service';
import { TYPES } from '@app/types';
import { Drawing } from '@common/communication/drawing';
import { NextFunction, Request, Response, Router } from 'express';
import * as fs from 'fs';
import * as Httpstatus from 'http-status-codes';
import { inject, injectable } from 'inversify';
// tslint:disable: ordered-imports
// tslint:disable: no-require-imports
import ImageTobase64 = require('image-to-base64');

@injectable()
export class DatabaseController {
    router: Router;
    tabUrl: string[] = [];
    constructor(@inject(TYPES.DatabaseService) private databaseService: DatabaseService) {
        this.configureRouter();
        this.databaseService.start();
    }

    private configureRouter(): void {
        this.router = Router();

        this.router.get('/', async (req: Request, res: Response, next: NextFunction) => {
            const promises: Promise<void>[] = [];
            this.databaseService.drawing = [];
            this.databaseService
                .ServerImages()
                .then(() => {
                    for (let i = 0; i < this.databaseService.idImage.length; i++) {
                        promises.push(
                            this.databaseService.getSpecificDrawing(this.databaseService.idImage[i]).then((drawing) => {
                                drawing.dataUrl = this.tabUrl[i];
                                this.databaseService.drawing.unshift(drawing);
                            }),
                        );
                    }
                })
                .then(() => {
                    this.tabUrl = this.getDataUrl();
                })
                .then(() => {
                    Promise.all(promises).then(() => {
                        res.json(this.databaseService.drawing);
                    });
                })
                .catch((error: Error) => {
                    res.status(Httpstatus.StatusCodes.NOT_FOUND).send(error.message);
                });
        });

        this.router.get('/id/:id', async (req: Request, res: Response, next: NextFunction) => {
            try {
                const drawing: Drawing = await this.databaseService.getSpecificDrawing(req.params.id);
                res.json(drawing);
            } catch (err) {
                res.status(Httpstatus.StatusCodes.NOT_FOUND).send(err.message);
            }
        });

        this.router.post('/add', async (req: Request, res: Response, next: NextFunction) => {
            return this.databaseService
                .addDrawing(req.body)
                .then(() => {
                    this.databaseService.drawingData.push(req.body as Drawing);
                    res.status(Httpstatus.StatusCodes.CREATED).send();
                })
                .catch((error: Error) => {
                    res.status(Httpstatus.StatusCodes.BAD_REQUEST).send(error.message);
                });
        });

        this.router.delete('/delete/:id', async (req: Request, res: Response, next: NextFunction) => {
            try {
                await this.databaseService.deleteDrawing(req.params.id);

                res.status(Httpstatus.StatusCodes.NO_CONTENT).send();
            } catch (error) {
                res.status(Httpstatus.StatusCodes.NOT_FOUND).send(error.message);
            }
        });
    }

    getDataUrl(): string[] {
        const testFolder = '../uploads/';
        const tabUrl: string[] = [];
        fs.readdir(testFolder, (err, files) => {
            files.forEach((file) => {
                ImageTobase64('../uploads/' + file)
                    .then((response) => {
                        tabUrl.push('data:image/png;base64,' + response);
                    })
                    .then(() => {
                        return tabUrl;
                    })
                    .catch((error: Error) => {
                        throw error;
                    });
            });
        });
        return tabUrl;
    }
}
