import { Drawing } from '@common/communication/drawing';
import * as fs from 'fs';
import { injectable } from 'inversify';
import { Collection, MongoClient, MongoClientOptions, ObjectId } from 'mongodb';
// tslint:disable-next-line: no-unused-expression
import 'reflect-metadata';

const DATABASE_URL = 'mongodb+srv://omar:omar@cluster0.gl27p.mongodb.net/omar?retryWrites=true&w=majority';
const DATABASE_NAME = 'database';
const DATABASE_COLLECTION = 'drawings';

@injectable()
export class DatabaseService {
    collection: Collection<Drawing>;
    client: MongoClient;
    idImage: string[] = [];
    drawing: Drawing[] = []; // contiendra tous les dessins venant du serveur lors d`un get
    drawingData: Drawing[] = [];
    private options: MongoClientOptions = {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    };

    start(): void {
        MongoClient.connect(DATABASE_URL, this.options)
            .then((client: MongoClient) => {
                this.client = client;
                this.collection = client.db(DATABASE_NAME).collection(DATABASE_COLLECTION);
                console.log('connection successful'.toUpperCase());
            })
            .catch(() => {
                console.error('CONNECTION ERROR. EXITING PROCESS');
                process.exit(1);
            });
    }

    closeConnection(): void {
        this.client.close();
    }

    async addDrawing(drawing: Drawing): Promise<void> {
        return this.collection
            .insertOne({ name: drawing.name, tags: drawing.tags })
            .then((data) => {
                const drawingData = drawing.dataUrl?.replace(/^data:image\/png;base64,/, '');
                if (!fs.existsSync('../uploads/')) {
                    fs.mkdirSync('../uploads/');
                }
                fs.writeFile('../uploads/' + data.insertedId + '.png', drawingData, { encoding: 'base64' }, (error) => {
                    if (error) throw error;
                });
            })
            .catch((error: Error) => {
                throw new Error('Failed to save Drawing');
            });
    }

    async deleteDrawing(drawingId: string): Promise<void> {
        return this.collection
            .findOneAndDelete({ _id: new ObjectId(drawingId) })
            .then(() => {
                fs.unlink('../uploads/' + drawingId + '.png', (error) => {
                    if (error) throw error;
                });
                console.log('draw has been deleted');
            })
            .catch((error: Error) => {
                throw new Error('Failed to delete Drawing');
            });
    }

    async getSpecificDrawing(drawingId: string): Promise<Drawing> {
        return this.collection
            .findOne({ _id: new ObjectId(drawingId) })
            .then((drawing: Drawing) => {
                drawing.id = drawingId;
                return drawing;
            })
            .catch(() => {
                throw new Error('No drawing with this specific id');
            });
    }
    async ServerImages(): Promise<Drawing[]> {
        if (!fs.existsSync('../uploads/')) {
            fs.mkdirSync('../uploads/');
        }
        return new Promise((resolve) => {
            this.idImage = [];
            fs.readdir('../uploads/', (err, files) => {
                files.forEach((file) => {
                    this.idImage.push(file.replace('.png', ''));
                });
                resolve();
            });
        });
    }
}
