import * as axios from 'axios';
import * as FormData from 'form-data';
import { injectable } from 'inversify';
// tslint:disable: no-empty

@injectable()
export class SendEmail {
    async sendEmail(emailData: FormData): Promise<void> {
        return new Promise(() => {
            axios
                .default({
                    method: 'post',
                    url: 'http://log2990.step.polymtl.ca/email?address_validation\n=true&quick_return=true&dry_run=false',
                    headers: {
                        'X-Team-Key': '32b36081-332c-4cb8-8770-e30bff7d8bc6',
                        ...emailData.getHeaders(),
                    },
                    data: emailData,
                })
                .then(() => {})
                .catch(() => {});
        });
    }
}
