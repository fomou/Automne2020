import * as axios from 'axios';
import { expect } from 'chai';
import * as FormData from 'form-data';
import { describe } from 'mocha';
import * as sinon from 'sinon';
import { SendEmail } from './send-email.service';

describe('sendEmail service', () => {
    let sendEmailService: SendEmail;

    beforeEach(async () => {
        sendEmailService = new SendEmail();
    });

    afterEach(async () => {
        sinon.restore();
    });

    it('sendEmail should send a correct email ', async () => {
        const emailTest: FormData = new FormData();
        emailTest.append('keyTest', 'valueTest');
        const postSpy = sinon.stub(axios, 'default').returns(
            new Promise((resolve) => {
                resolve();
            }),
        );
        sendEmailService.sendEmail(emailTest).then(() => {
            expect(postSpy.called).to.be.true;
        });
    });

    it('sendEmail should throw an error when unable to send the email ', async () => {
        const emailTest: FormData = new FormData();
        emailTest.append('keyTest', 'valueTest');
        sinon.stub(axios, 'default').rejects();
        try {
            sendEmailService.sendEmail(emailTest);
        } catch (error) {
            expect(error.message).to.equal('Error');
        }
    });
});
