import { Drawing } from '@common/communication/drawing';
import { expect } from 'chai';
import * as fs from 'fs';
import { describe } from 'mocha';
import { Db, MongoClient, ObjectId } from 'mongodb';
import { MongoMemoryServer } from 'mongodb-memory-server';
import * as sinon from 'sinon';
import { DatabaseService } from './database.service';

describe('Database service', () => {
    let databaseService: DatabaseService;
    let mongoServer: MongoMemoryServer;
    let db: Db;
    let client: MongoClient;
    let testDrawing: Drawing;

    beforeEach(async () => {
        databaseService = new DatabaseService();

        // Start a local test server
        mongoServer = new MongoMemoryServer();
        const mongoUri = await mongoServer.getUri();
        client = await MongoClient.connect(mongoUri, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });

        // We use the local Mongo Instance and not the production database
        db = client.db(await mongoServer.getDbName());
        databaseService.collection = db.collection('test');

        // L'image contient un point rouge
        testDrawing = {
            name: 'redDot',
            tags: ['tag1'],
        };
    });

    afterEach(async () => {
        sinon.restore();
        client.close();
    });

    it('getSpecificDrawing should return a drawing in the DB through its ID ', async () => {
        // On insere le stub a la base de donnees
        const insertedDrawingId: ObjectId = (await databaseService.collection.insertOne(testDrawing)).insertedId;

        // On met a jour l'objet avec l'Id qu'il a recu a partir de l'insertion
        testDrawing = {
            name: 'redDot',
            tags: ['tag1', 'tag2'],
            id: insertedDrawingId.toHexString(),
        };

        databaseService.getSpecificDrawing(insertedDrawingId.toHexString()).then((drawing) => {
            const result = drawing;
            expect(result.id).to.equal(testDrawing.id);
            expect(result.name).to.equal(testDrawing.name);
            expect(result.tags[0]).to.equal(testDrawing.tags[0]);
        });
    });

    it('getSpecificDrawing should return an Error when the drawing doesnt exist ', async () => {
        const unknownDrawingId = '5fce1055b308703d71326051';
        databaseService.getSpecificDrawing(unknownDrawingId).catch((error) => {
            expect(error.message).to.equal('No drawing with this specific id');
        });
    });

    it('Start should connect to the DB client and notify the user ', async () => {
        const stub = sinon.stub(MongoClient, 'connect').resolves(client).callThrough();
        databaseService.start();
        stub.restore();
        expect(stub.called).to.be.true;
    });

    it('addDrawing should insert an element in the Db', async () => {
        sinon.stub(fs, 'writeFile').callsFake(() => {});
        await databaseService.addDrawing(testDrawing);
        const drawings = await databaseService.collection.find({ name: testDrawing.name }).toArray();
        expect(drawings.length).to.equal(1);
        expect(drawings[0].name).to.equal(testDrawing.name);
        expect(drawings[0].tags[0]).to.equal(testDrawing.tags[0]);
    });

    it('AddDrawing should throw an error when unable to save an image ', async () => {
        sinon.stub(fs, 'writeFile').callsFake(() => {});
        sinon.stub(databaseService.collection, 'insertOne').rejects();
        try {
            await databaseService.addDrawing(testDrawing);
        } catch (error) {
            expect(error.message).to.equal('Failed to save Drawing');
            const drawings = await databaseService.collection.find({}).toArray();
            expect(drawings.length).to.equal(0);
        }
    });

    it('deleteDrawing should delete a drawing in the db ', async () => {
        // On insere le stub a la base de donnees
        const insertedDrawingId: ObjectId = (await databaseService.collection.insertOne(testDrawing)).insertedId;
        // On met a jour l'objet avec l'Id qu'il a recu a partir de l'insertion
        sinon.stub(fs, 'unlink');
        testDrawing = {
            name: 'redDot',
            tags: ['tag1', 'tag2'],
            id: insertedDrawingId.toHexString(),
        };
        await databaseService.deleteDrawing(insertedDrawingId.toHexString());
        const drawings = await databaseService.collection.find({}).toArray();
        expect(drawings.length).to.be.equal(0);
    });

    it('deleteDrawing should throw error when trying to delete non existant drawing in the db ', async () => {
        const unknownDrawingId = '5fce1055b308703d71326051';
        // On met a jour l'objet avec l'Id qu'il a recu a partir de l'insertion
        databaseService.deleteDrawing(unknownDrawingId).catch((error) => {
            expect(error.message).to.equal('Failed to delete Drawing');
        });
    });

    it('ServerImages should fail to retrieve drawings when db is empty  ', async () => {
        sinon.stub(fs, 'existsSync').returns(true);
        const drawings: Drawing[] = await databaseService.ServerImages();
        expect(drawings).to.be.undefined;
    });

    it('addDrawing should throw an error when it cant write the file', async () => {
        sinon.stub(fs, 'existsSync').returns(true);
        sinon.stub(fs, 'writeFile').callsFake(() => {});
        try {
            await databaseService.addDrawing(testDrawing);
        } catch (error) {
            expect(error.message).to.equal('Error');
        }
        try {
            databaseService.addDrawing(testDrawing);
        } catch (error) {
            expect(error.message).to.equal('Error');
        }
    });
    it('ServerImages should make a directory for drawings  ', async () => {
        sinon.stub(fs, 'existsSync').returns(false);
        const mkDirSpy = sinon.stub(fs, 'mkdirSync').callsFake(() => {});
        await databaseService.ServerImages();
        expect(mkDirSpy.called).to.true;
    });

    it('CloseConnection should close the client ', async () => {
        const stub = sinon.stub(client, 'close').callsFake(() => {});
        databaseService.client = client;
        databaseService.closeConnection();
        expect(stub.called).to.be.true;
    });
});
