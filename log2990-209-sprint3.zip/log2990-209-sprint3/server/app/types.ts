export const TYPES = {
    Server: Symbol('Server'),
    Application: Symbol('Application'),
    DrawingService: Symbol('DrawingService'),
    DatabaseController: Symbol('DatabaseController'),
    DatabaseService: Symbol('DatabaseService'),
    ServiceServer: Symbol('ServiceServer'),
    SendEmail: Symbol('SendEmail'),
    SendEmailController: Symbol('SendEmailController'),
};
