/* tslint:disable: file-name-casing */
export interface IEnvironment {
    production: boolean;
}
