import { Stack } from './stack';

// tslint:disable: no-any
// tslint:disable: no-string-literal
describe('Stack<T>', () => {
    let stack: Stack<string>;

    beforeEach(() => {
        stack = new Stack<string>();
    });
    it('should create', () => {
        expect(stack).toBeTruthy();
    });

    it('isEmpty should return true if the stack is empty ', () => {
        expect(stack.isEmpty()).toBeTrue();
    });

    it('add() should add elemment to the stack', () => {
        const spy = spyOn<any>(stack['array'], 'push');
        stack.add('blablabla');
        expect(spy).toHaveBeenCalled();
    });

    it('delete should delete an  elemment from  the stack if the element is in the stack', () => {
        const spy = spyOn<any>(stack['array'], 'splice');
        const blabla = 'blablabla';
        stack.add(blabla);
        stack.add('Log2990');
        stack.delete(blabla);
        expect(spy).toHaveBeenCalled();
    });

    it('delete should do nothing if the element is not in the stack', () => {
        const spy = spyOn<any>(stack['array'], 'splice');
        const blabla = 'blablabla';
        stack.delete(blabla);
        expect(spy).not.toHaveBeenCalled();
    });

    it('pop should pop of the array', () => {
        const spy = spyOn<any>(stack['array'], 'pop');
        stack.pop();
        expect(spy).toHaveBeenCalled();
    });

    it('#getAll should return all elements in the stack', () => {
        const array = ['Log', '29', '90'];
        for (const st of array) {
            stack.add(st);
        }
        const resultat = stack.getAll();
        expect(resultat).toEqual(array);
    });
});
