import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { Tool } from './tool';
import { Vec2 } from './vec2';

export abstract class ShapeTool extends Tool {
    firstPoint: Vec2;
    lastPoint: Vec2;
    width: number = 0;
    height: number = 0;
    shiftPressed: boolean = false;

    drawingType: string;
    lineWidth: number;
    primaryColor: string;
    secondaryColor: string;

    constructor(drawingService: DrawingService) {
        super(drawingService);
    }

    /* Sauvegarde le point lorsqu'on appuie sur la souris 
       Remettre les variables à 0*/
    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            this.firstPoint = this.getPositionFromMouse(event);
            this.width = 0;
            this.height = 0;
        }
    }

    /* Dessine la forme*/
    // Méthode virtuelle
    // tslint:disable-next-line:no-empty
    protected drawShape(ctx: CanvasRenderingContext2D): void {}

    /* Dessine le perimètre de prévisualisation
       La forme doit être inscrite dans ce perimètre*/
    // Méthode virtuelle
    // tslint:disable-next-line:no-empty
    protected drawPreviewPerimeter(ctx: CanvasRenderingContext2D): void {}

    /* Trouve la position du coin supérieur gauche*/
    protected findTopLeftPoint(startPoint: Vec2, endPoint: Vec2): Vec2 {
        let x = startPoint.x;
        let y = startPoint.y;

        if (startPoint.x >= endPoint.x && startPoint.y >= endPoint.y) {
            x = endPoint.x;
            y = endPoint.y;
        } else if (startPoint.x > endPoint.x && startPoint.y < endPoint.y) {
            x = endPoint.x;
            y = startPoint.y;
        } else if (startPoint.x < endPoint.x && startPoint.y > endPoint.y) {
            x = startPoint.x;
            y = endPoint.y;
        }
        return { x, y };
    }

    /* Trouve le point formant un carré avec le point de départ */
    protected findShiftPoint(startPoint: Vec2, currentPoint: Vec2): Vec2 {
        const width = Math.abs(currentPoint.x - startPoint.x);
        const heigth = Math.abs(currentPoint.y - startPoint.y);

        const point: Vec2 = currentPoint;

        if (width < heigth) {
            if (
                (currentPoint.x <= startPoint.x && currentPoint.y <= startPoint.y) ||
                (currentPoint.x >= startPoint.x && currentPoint.y <= startPoint.y)
            ) {
                point.y -= width - heigth;
            } else {
                point.y += width - heigth;
            }
        } else {
            if (
                (currentPoint.x <= startPoint.x && currentPoint.y <= startPoint.y) ||
                (currentPoint.x <= startPoint.x && currentPoint.y >= startPoint.y)
            ) {
                point.x -= heigth - width;
            } else {
                point.x += heigth - width;
            }
        }
        return point;
    }

    getCenter(startPoint: Vec2, endPoint: Vec2): Vec2 {
        let y = Math.abs(endPoint.y - startPoint.y) / 2;
        let x = Math.abs(startPoint.x - endPoint.x) / 2;

        x = endPoint.x > startPoint.x ? startPoint.x + x : startPoint.x - x;
        y = endPoint.y > startPoint.y ? startPoint.y + y : startPoint.y - y;

        return { x, y };
    }
}
