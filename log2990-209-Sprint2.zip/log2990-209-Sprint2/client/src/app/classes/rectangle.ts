import { DrawingType } from '@app/enums/draw-type';
import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class Rectangle extends Drawable {
    private topLeftPoint: Vec2;
    private width: number;
    private height: number;
    private type: string;
    private lineWidth: number;
    private primaryColor: string;
    private secondaryColor: string;

    constructor(topLeftPoint: Vec2, width: number, height: number, type: string, lineWidth: number, primaryColor: string, secondaryColor: string) {
        super();
        this.topLeftPoint = topLeftPoint;
        this.width = width;
        this.height = height;
        this.type = type;
        this.lineWidth = lineWidth;
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.beginPath();
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.secondaryColor;
        ctx.fillStyle = this.primaryColor;

        switch (this.type) {
            case DrawingType.stroke:
                ctx.strokeRect(this.topLeftPoint.x, this.topLeftPoint.y, this.width, this.height);

                break;

            case DrawingType.fill:
                ctx.fillRect(this.topLeftPoint.x, this.topLeftPoint.y, this.width, this.height);
                break;

            case DrawingType.outline:
                ctx.fillRect(this.topLeftPoint.x, this.topLeftPoint.y, this.width, this.height);
                ctx.strokeRect(this.topLeftPoint.x, this.topLeftPoint.y, this.width, this.height);
                break;
        }
        ctx.closePath();
    }
}
