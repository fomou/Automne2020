import { canvasTestHelper } from './canvas-test-helper';
import { RectangleSelection } from './rectangle-selection';
import { Vec2 } from './vec2';

describe('RectangleSelection', () => {
    it('should create an instance', () => {
        expect(new RectangleSelection({} as ImageData, {} as Vec2, 1, 1, 1, 1)).toBeTruthy();
    });

    it('draw should call putimagedata and fillRect', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const rectangle = new RectangleSelection({} as ImageData, {} as Vec2, 1, 1, 1, 1);
        // tslint:disable:no-any
        const fillRecSpy = spyOn<any>(ctxStub, 'fillRect').and.callFake(() => {
            return;
        });
        const igmSpy = spyOn<any>(ctxStub, 'putImageData').and.callFake(() => {
            return;
        });
        rectangle.draw(ctxStub);
        expect(fillRecSpy).toHaveBeenCalled();
        expect(igmSpy).toHaveBeenCalled();
    });
});
