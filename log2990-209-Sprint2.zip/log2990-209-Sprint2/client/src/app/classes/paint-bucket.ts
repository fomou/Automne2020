import { Drawable } from './drawable';

export class PaintBucket extends Drawable {
    private contigue: boolean;
    private imageDataContigous: ImageData;
    private imageDataNoContigous: ImageData;
    constructor(contigue: boolean, img: ImageData, imgContigue: ImageData) {
        super();
        this.contigue = contigue;
        this.imageDataNoContigous = img;
        this.imageDataContigous = imgContigue;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        if (this.contigue) {
            this.fillFlod(ctx, this.imageDataContigous);
        } else {
            this.fillFlod(ctx, this.imageDataNoContigous);
        }
    }

    private fillFlod(ctx: CanvasRenderingContext2D, img: ImageData): void {
        ctx.putImageData(img, 0, 0);
    }
}
