import { Drawable } from './drawable';
export class LoadedImage extends Drawable {
    src: ImageData; // attribut pour pouvoir verifier que l'image a été depuis le carrousel

    constructor(src?: ImageData) {
        super();
        this.src = src as ImageData;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.putImageData(this.src, 0, 0);
    }
}
