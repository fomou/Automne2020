import { DrawingService } from '@app/services/drawing/drawing.service';
import { Drawable } from './drawable';

export class Resize extends Drawable {
    private image: HTMLImageElement;
    private width: number;
    private heigth: number;
    private originalWidth: number;
    private originalHeight: number;

    constructor(
        private drawingServing: DrawingService,
        image: HTMLImageElement,
        originalWidth: number,
        originalHeight: number,
        width: number,
        height: number,
    ) {
        super();
        this.image = image;
        this.width = width;
        this.heigth = height;
        this.originalWidth = originalWidth;
        this.originalHeight = originalHeight;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        this.drawingServing.canvas.width += this.width;
        this.drawingServing.canvas.height += this.heigth;

        this.drawingServing.previewCanvas.width += this.width;
        this.drawingServing.previewCanvas.height += this.heigth;

        this.drawingServing.borderCanvas.style.width = this.drawingServing.canvas.width + 'px';

        this.drawingServing.background.style.width = this.drawingServing.canvas.width + 'px';

        this.drawingServing.borderCanvas.style.height = this.drawingServing.canvas.height + 'px';
        this.drawingServing.background.style.height = this.drawingServing.canvas.height + 'px';

        this.drawingServing.setBackground(ctx);

        ctx.drawImage(this.image, 0, 0);
    }

    undraw(): void {
        this.drawingServing.canvas.width = this.originalWidth;
        this.drawingServing.canvas.height = this.originalHeight;

        this.drawingServing.previewCanvas.width = this.originalWidth;
        this.drawingServing.previewCanvas.height = this.originalHeight;
        this.drawingServing.borderCanvas.style.width = this.drawingServing.canvas.width + 'px';
        this.drawingServing.background.style.width = this.drawingServing.canvas.width + 'px';

        this.drawingServing.borderCanvas.style.height = this.drawingServing.canvas.height + 'px';
        this.drawingServing.background.style.height = this.drawingServing.canvas.height + 'px';
    }
}
