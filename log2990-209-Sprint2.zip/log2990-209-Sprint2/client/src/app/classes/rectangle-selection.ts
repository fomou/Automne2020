import { Drawable } from './drawable';
import { Vec2 } from './vec2';
export class RectangleSelection extends Drawable {
    private imageData: ImageData;
    private movedX: number;
    private movedY: number;
    private selectedWidth: number;
    private selectedHeight: number;
    private topLeftPoint: Vec2;
    constructor(imagedata: ImageData, point: Vec2, width: number, height: number, movedX: number, movedY: number) {
        super();
        this.imageData = imagedata;
        this.movedX = movedX;
        this.movedY = movedY;
        this.selectedHeight = height;
        this.selectedWidth = width;
        this.topLeftPoint = point;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        ctx.fillStyle = 'white';
        ctx.fillRect(this.topLeftPoint.x, this.topLeftPoint.y, this.selectedWidth, this.selectedHeight);
        ctx.restore();
        ctx.putImageData(this.imageData, this.movedX, this.movedY);
    }
}
