import { BrushPath } from './brush-path';
import { canvasTestHelper } from './canvas-test-helper';
import { Vec2 } from './vec2';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: no-string-literal
describe('BrushPath', () => {
    it('should create an instance', () => {
        expect(new BrushPath([], 'red', 1, {} as HTMLImageElement)).toBeTruthy();
    });

    it('should calcul distance between two point', () => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        const bushPath = new BrushPath([], 'red', 1, {} as HTMLImageElement);
        expect(bushPath['distanceBetween'](point1, point2)).toEqual(5);
    });

    it('should calcul angle between two point', () => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        const bushPath = new BrushPath([], 'red', 1, {} as HTMLImageElement);

        const expectedAngle = Math.atan2(point2.x - point1.x, point2.y - point1.y);
        expect(bushPath['angleBetween'](point1, point2)).toEqual(expectedAngle);
    });

    it('getImage should return HtmlImage', () => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        const img: HTMLImageElement = document.createElement('img');
        img.width = 10;
        img.height = 10;
        const brushPath = new BrushPath([point1, point2, point1, point2], 'red', 1, img);
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const strokeSpy = spyOn<any>(ctxStub, 'stroke').and.callThrough();
        const beginPathSpy = spyOn<any>(ctxStub, 'beginPath').and.callThrough();
        const drawImageSpy = spyOn<any>(ctxStub, 'drawImage').and.callThrough();

        brushPath.draw(ctxStub);
        expect(strokeSpy).toHaveBeenCalled();
        expect(beginPathSpy).toHaveBeenCalled();
        expect(drawImageSpy).toHaveBeenCalled();
    });
});
