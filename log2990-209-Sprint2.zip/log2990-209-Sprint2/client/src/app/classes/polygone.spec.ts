import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Polygone } from './polygone';
import { Vec2 } from './vec2';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('Polygone', () => {
    it('should create an instance', () => {
        expect(new Polygone({} as Vec2, 2, 3, 'fill', 2, 'black', 'red')).toBeTruthy();
    });

    it('case stroke', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const polygone = new Polygone({} as Vec2, 2, 3, 'stroke', 2, 'black', 'red');

        const spy = spyOn<any>(ctx, 'stroke').and.callThrough();

        polygone.draw(ctx);

        expect(spy).toHaveBeenCalled();
    });

    it('case fill', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const polygone = new Polygone({} as Vec2, 2, 3, 'fill', 2, 'black', 'red');

        const spy = spyOn<any>(ctx, 'fill').and.callThrough();

        polygone.draw(ctx);

        expect(spy).toHaveBeenCalled();
    });

    it('case outline', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const polygone = new Polygone({} as Vec2, 2, 3, 'outline', 2, 'black', 'red');

        const fillSpy = spyOn<any>(ctx, 'fill').and.callThrough();
        const strokeSpy = spyOn<any>(ctx, 'stroke').and.callThrough();
        polygone.draw(ctx);

        expect(fillSpy).toHaveBeenCalled();
        expect(strokeSpy).toHaveBeenCalled();
    });
});
