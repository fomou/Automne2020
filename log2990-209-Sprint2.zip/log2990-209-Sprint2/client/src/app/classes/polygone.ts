import { DrawingType } from '@app/enums/draw-type';
import { Drawable } from './drawable';
import { Vec2 } from './vec2';

export class Polygone extends Drawable {
    private circleCenter: Vec2;
    private radius: number;
    private sides: number;
    private type: string;
    private lineWidth: number;
    private primaryColor: string;
    private secondaryColor: string;

    constructor(center: Vec2, radius: number, sides: number, type: string, lineWidth: number, primaryColor: string, secondaryColor: string) {
        super();
        this.circleCenter = center;
        this.radius = radius;
        this.sides = sides;
        this.type = type;
        this.lineWidth = lineWidth;
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        const radiusFinal = Math.abs(this.radius - this.lineWidth / 2 - this.lineWidth / this.sides);

        ctx.beginPath();
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.secondaryColor;
        ctx.fillStyle = this.primaryColor;
        ctx.moveTo(this.circleCenter.x + radiusFinal * Math.cos(-Math.PI / 2), this.circleCenter.y + radiusFinal * Math.sin(-Math.PI / 2));
        for (let i = 1; i <= this.sides + 1; i++) {
            ctx.lineTo(
                this.circleCenter.x + radiusFinal * Math.cos((i * 2 * Math.PI) / this.sides - Math.PI / 2),
                this.circleCenter.y + radiusFinal * Math.sin((i * 2 * Math.PI) / this.sides - Math.PI / 2),
            );
        }

        switch (this.type) {
            case DrawingType.stroke:
                ctx.stroke();
                break;

            case DrawingType.fill:
                ctx.fill();
                break;

            case DrawingType.outline:
                ctx.fill();
                ctx.stroke();
                break;
        }
        ctx.closePath();
    }
}
