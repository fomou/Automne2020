import { canvasTestHelper } from './canvas-test-helper';
import { EraserPath } from './eraser-path';
import { Vec2 } from './vec2';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('EraserPath', () => {
    it('should create an instance', () => {
        expect(new EraserPath(5, [])).toBeTruthy();
    });
    it('draw should call methodes for context', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const point = { x: 2, y: 2 } as Vec2;
        const beginPathSpy = spyOn<any>(ctxStub, 'beginPath').and.callThrough();
        const stroke = spyOn<any>(ctxStub, 'stroke').and.callThrough();
        const lineTo = spyOn<any>(ctxStub, 'lineTo').and.callThrough();
        const eraser = new EraserPath(5, [point, point]);
        eraser.draw(ctxStub);
        expect(beginPathSpy).toHaveBeenCalled();
        expect(stroke).toHaveBeenCalled();
        expect(lineTo).toHaveBeenCalledTimes(2);
    });
});
