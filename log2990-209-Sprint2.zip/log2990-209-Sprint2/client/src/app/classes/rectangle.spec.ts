import { canvasTestHelper } from './canvas-test-helper';
import { Rectangle } from './rectangle';
import { Vec2 } from './vec2';

// tslint:disable: no-any
describe('Rectangle ', () => {
    it('should create', () => {
        expect(new Rectangle({} as Vec2, 2, 2, 'fill', 2, 'black', 'red')).toBeTruthy();
    });

    it('case stroke', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const rectangle = new Rectangle({} as Vec2, 2, 2, 'stroke', 2, 'black', 'red');

        const spy = spyOn<any>(ctx, 'strokeRect').and.callThrough();

        rectangle.draw(ctx);

        expect(spy).toHaveBeenCalled();
    });

    it('case fill', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const rectangle = new Rectangle({} as Vec2, 2, 2, 'fill', 2, 'black', 'red');

        const spy = spyOn<any>(ctx, 'fillRect').and.callThrough();

        rectangle.draw(ctx);

        expect(spy).toHaveBeenCalled();
    });

    it('case outline', () => {
        const ctx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const rectangle = new Rectangle({} as Vec2, 2, 2, 'outline', 2, 'black', 'red');

        const fillSpy = spyOn<any>(ctx, 'fillRect').and.callThrough();
        const strokeSpy = spyOn<any>(ctx, 'strokeRect').and.callThrough();
        rectangle.draw(ctx);

        expect(fillSpy).toHaveBeenCalled();
        expect(strokeSpy).toHaveBeenCalled();
    });
});
