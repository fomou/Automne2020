import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { PencilPath } from './pencil-path';
import { Vec2 } from './vec2';

// tslint:disable: no-any
describe('pencil path', () => {
    let pencilPath: PencilPath;

    beforeEach(() => {
        const point1: Vec2 = { x: 0, y: 0 };
        const point2: Vec2 = { x: 4, y: 3 };
        pencilPath = new PencilPath([point1, point2], 'red', 2);
    });

    it('sould create ', () => {
        expect(pencilPath).toBeTruthy();
    });

    it('sould call draw with ctx', () => {
        const ctxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        const spy = spyOn<any>(ctxStub, 'beginPath').and.callThrough();
        const lineTo = spyOn<any>(ctxStub, 'lineTo').and.callThrough();
        pencilPath.draw(ctxStub);
        expect(spy).toHaveBeenCalled();
        expect(lineTo).toHaveBeenCalledTimes(2);
    });
});
