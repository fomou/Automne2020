import { Component } from '@angular/core';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';

@Component({
    selector: 'app-guide-utilsateur',
    templateUrl: './guide-utilsateur.component.html',
    styleUrls: ['./guide-utilsateur.component.scss'],
})
export class GuideUtilsateurComponent {
    constructor(private shortcutManagerService: ShortcutManagerService) {}

    enableShortcut(): void {
        this.shortcutManagerService.enableShortcut();
    }
}
