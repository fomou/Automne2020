import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { GuideUtilsateurComponent } from './guide-utilsateur.component';
// tslint:disable: no-any
// tslint:disable: no-string-literal

describe('GuideUtilsateurComponent', () => {
    let component: GuideUtilsateurComponent;
    let fixture: ComponentFixture<GuideUtilsateurComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [GuideUtilsateurComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GuideUtilsateurComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should enable shortcuts', () => {
        const spy = spyOn(component['shortcutManagerService'], 'enableShortcut');
        component.enableShortcut();
        expect(spy).toHaveBeenCalled();
    });
});
