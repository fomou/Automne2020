import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatSliderChange } from '@angular/material/slider';
import { Tool } from '@app/classes/tool';
import { Keyboard } from '@app/enums/key-board';
import { BrushService } from '@app/services/tools/brush/brush.service';
import { EllipseService } from '@app/services/tools/ellipse/ellipse.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { PencilService } from '@app/services/tools/pencil/pencil-service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { PolygoneService } from '@app/services/tools/polygone/polygone.service';
import { RectangleService } from '@app/services/tools/rectangle/rectangle.service';
import { SelectionEllipseService } from '@app/services/tools/selection-ellipse/selection-ellipse.service';
import { SelectionRectangleService } from '@app/services/tools/selection-rectangle/selection-rectangle.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';
import { DrawingToolsComponent } from './drawing-tools.component';

class ToolSelector extends ToolsSelectorService {
    getToolBykey(s: string): Tool {
        return {} as Tool;
    }
    // tslint:disable-next-line:no-empty
    changeTool(t: Tool): void {}
}

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers
describe('DrawingToolsComponent', () => {
    let component: DrawingToolsComponent;
    let fixture: ComponentFixture<DrawingToolsComponent>;
    let sideBareStub: SidebarService;
    let toolSelect: ToolsSelectorService;

    beforeEach(async(() => {
        sideBareStub = new SidebarService();
        const pen = {} as PencilService;
        const rect = {} as RectangleService;
        const ellipse = {} as EllipseService;
        const line = {} as LineService;
        const era = {} as EraseService;
        const brus = {} as BrushService;
        const poly = { sides: 10 } as PolygoneService;
        const pipette = {} as PickerService;
        const seau = {} as PaintBucketService;
        const selRect = {} as SelectionRectangleService;
        const selEll = {} as SelectionEllipseService;

        toolSelect = new ToolSelector(pen, rect, ellipse, line, era, brus, poly, pipette, seau, selRect, selEll);

        TestBed.configureTestingModule({
            declarations: [DrawingToolsComponent],
            providers: [
                { provide: SidebarService, useValue: sideBareStub },
                { provide: ToolsSelectorService, useValue: toolSelect },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DrawingToolsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('ShowPenAtt should change tool', () => {
        const changeSpy = spyOn(toolSelect, 'changeTool').and.callThrough();
        const getSpys = spyOn(toolSelect, 'getToolBykey').and.callThrough();
        component.showPenAtt();
        expect(getSpys).toHaveBeenCalled();
        expect(component.toolName).toBe('Crayon');
        expect(component.isShownBrushAtt).toEqual(false);
        expect(component.isShownBrushes).toEqual(false);
        expect(component.isShownPenAtt).toEqual(true);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('ShowBrushAttribute should change tool', () => {
        const changeSpy = spyOn(toolSelect, 'changeTool').and.callThrough();
        const getSpys = spyOn(toolSelect, 'getToolBykey').and.callThrough();
        component.showBrushAttribute();
        expect(getSpys).toHaveBeenCalled();
        expect(component.toolName).toBe('Pinceau');
        expect(component.isShownBrushAtt).toEqual(true);
        expect(component.isShownBrushes).toEqual(false);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('ShowFeatherAtt should change name to Plume', () => {
        component.showFeatherAtt();
        expect(component.toolName).toBe('Plume');
        expect(component.isShownFeatherAtt).toBe(true);
    });

    it('ShowFeatherAtt should change name to Aérosol', () => {
        component.showSpraypaintAtt();
        expect(component.toolName).toBe('Aérosol');
        expect(component.isShownSprayPaintAtt).toBe(true);
    });

    it('changeWidth call changeWidth of the service', () => {
        const spy = spyOn(sideBareStub, 'changeWidth').and.callThrough();
        const event = { value: 10 } as MatSliderChange;
        component.changeWidth(event);
        expect(spy).toHaveBeenCalled();
    });

    it('return width should give the width in the sideba service', () => {
        const expected = sideBareStub.width;
        expect(component.returnWidth()).toEqual(expected);
    });

    it('formate label should convert in to string', () => {
        const expected = '10px';
        expect(component.formatLabel(10)).toEqual(expected);
    });
    it('return brush width should give the width in the sidebar service', () => {
        const expected = sideBareStub.brushWidth;
        expect(component.returnBrushWidth()).toEqual(expected);
    });

    it('changeBrushWidth call changeWidth of the service', () => {
        const spy = spyOn(sideBareStub, 'changeBrushWidth').and.callThrough();
        const event = { value: 10 } as MatSliderChange;
        component.changeBrushWidth(event);
        expect(spy).toHaveBeenCalled();
    });

    it('ShowBarAttributesTools change isShownBarAttTools ', () => {
        component.isShownBarAttTools = false;
        component.showBarAttributesTools();
        expect(component.isShownBarAttTools).toEqual(true);
    });

    it('ShowBrushes should change isShownPenAtt, isShownTexture,isShownBrushes', () => {
        component.isShownBrushes = false;
        component.showBrushes();
        expect(component.isShownPenAtt).toBe(false);
        expect(component.isShownTexture).toBe(false);
        expect(component.isShownBrushes).toEqual(true);
    });

    it('selectTexture should call selectTexture of sidebar service ', () => {
        const spy = spyOn(sideBareStub, 'selectTexture').and.callThrough();
        component.selectTexture(1);
        expect(spy).toHaveBeenCalledWith(1);
        expect(component.isShownTexture).toEqual(false);
    });

    it('onKeyDown shoul call ShowBarAttributesTools if c is hit on keyboard', () => {
        component['shortcutDisabled'] = false;
        const event = { code: Keyboard.c } as KeyboardEvent;
        const spy = spyOn(component, 'showPenAtt').and.callThrough();
        const spyBrush = spyOn(component, 'showBarAttributesTools').and.callThrough();
        component.onKeyDown(event);

        expect(spy).toHaveBeenCalled();
        expect(spyBrush).toHaveBeenCalled();
    });

    it('onKeyDown shoul call ShowBrushAttribute if w is hit on keyboard', () => {
        component['shortcutDisabled'] = false;
        const event = { code: Keyboard.w } as KeyboardEvent;
        const spy = spyOn(component, 'showBrushAttribute').and.callThrough();
        const spyBrush = spyOn(component, 'showBarAttributesTools').and.callThrough();
        component.onKeyDown(event);

        expect(spy).toHaveBeenCalled();
        expect(spyBrush).toHaveBeenCalled();
    });

    it('onKeyDown should do nothing if shortcuts is disabled', () => {
        component['shortcutDisabled'] = true;
        const event = { code: Keyboard.w } as KeyboardEvent;
        const spy = spyOn(component, 'showBrushAttribute').and.callThrough();
        const spyBrush = spyOn(component, 'showBarAttributesTools').and.callThrough();
        component.onKeyDown(event);

        expect(spy).not.toHaveBeenCalled();
        expect(spyBrush).not.toHaveBeenCalled();
    });

    it('ShowTexture should change isShownBrushes, isShownTexture', () => {
        component.isShownTexture = false;
        component.showTexture();
        expect(component.isShownTexture).toBe(true);
        expect(component.isShownBrushes).toEqual(false);
    });

    it('susbscribe should give the valeur from the service', () => {
        component['shortcutManagerService'].disableShortcut();
        component['shortcutManagerService'].shortcutObs$.subscribe((disable) => {
            expect(disable).toEqual(true);
        });
    });
});
