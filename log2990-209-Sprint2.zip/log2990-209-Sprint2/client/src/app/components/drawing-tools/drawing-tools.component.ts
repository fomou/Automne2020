import { Component, HostListener, OnDestroy } from '@angular/core';
import { MatSliderChange } from '@angular/material/slider';
import { Keyboard } from '@app/enums/key-board';
import { ToolNames } from '@app/enums/tool-names';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-drawing-tools',
    templateUrl: './drawing-tools.component.html',
    styleUrls: ['./drawing-tools.component.scss'],
})
export class DrawingToolsComponent implements OnDestroy {
    toolName: string;
    isShownBarAttTools: boolean;
    isShownTexture: boolean;
    isShownBrushes: boolean;
    isShownPenAtt: boolean;
    isShownBrushAtt: boolean;
    isShownFeatherAtt: boolean;
    isShownSprayPaintAtt: boolean;

    private shortcutDisabled: boolean;
    private subscripion: Subscription;

    constructor(
        private toolsSelectorService: ToolsSelectorService,
        private sidebarService: SidebarService,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.toolName = ToolNames.Pencil;
        this.isShownBarAttTools = false;
        this.isShownTexture = false;
        this.isShownBrushes = false;
        this.isShownPenAtt = true;
        this.isShownBrushAtt = false;
        this.isShownFeatherAtt = false;
        this.isShownSprayPaintAtt = false;
        this.subscripion = this.shortcutManagerService.shortcutObs$.subscribe((disabler) => {
            this.shortcutDisabled = disabler;
        });
    }

    ngOnDestroy(): void {
        this.subscripion.unsubscribe();
    }
    @HostListener('window:keydown', ['$event'])
    onKeyDown(event: KeyboardEvent): void {
        if (this.shortcutDisabled) {
            return;
        }
        switch (event.code) {
            case Keyboard.c:
                this.showBarAttributesTools();
                this.showPenAtt();
                break;
            case Keyboard.w:
                this.showBarAttributesTools();
                this.showBrushAttribute();
                break;
        }
    }

    changeBrushWidth(event: MatSliderChange): void {
        this.sidebarService.changeBrushWidth(event.value as number);
    }

    showBarAttributesTools(): void {
        this.isShownBarAttTools = !this.isShownBarAttTools;
    }

    showBrushes(): void {
        this.isShownPenAtt = false;
        this.isShownTexture = false;
        this.isShownFeatherAtt = false;
        this.isShownBrushes = !this.isShownBrushes;
    }

    showTexture(): void {
        this.isShownBrushes = false;
        this.isShownTexture = !this.isShownTexture;
    }

    selectTexture(n: number): void {
        this.sidebarService.selectTexture(n);
        this.isShownTexture = false;
    }

    showPenAtt(): void {
        this.showBrushes();
        this.isShownBrushes = false;
        this.isShownPenAtt = true;
        this.isShownBrushAtt = false;
        this.isShownFeatherAtt = false;
        this.toolName = ToolNames.Pencil;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.c);
        this.toolsSelectorService.changeTool(tool);
    }

    showBrushAttribute(): void {
        this.showBrushes();
        this.isShownBrushAtt = true;
        this.isShownBrushes = false;
        this.toolName = ToolNames.Brush;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.w);
        this.toolsSelectorService.changeTool(tool);
    }

    showFeatherAtt(): void {
        this.showBrushes();
        this.isShownBrushes = false;
        this.isShownBrushAtt = false;
        this.isShownFeatherAtt = true;
        this.toolName = ToolNames.Feather;
    }

    showSpraypaintAtt(): void {
        this.showBrushes();
        this.isShownSprayPaintAtt = true;
        this.toolName = ToolNames.SprayPaint;
    }

    changeWidth(event: MatSliderChange): void {
        this.sidebarService.changeWidth(event.value as number);
    }

    returnWidth(): number {
        return this.sidebarService.width;
    }

    formatLabel(value: number): string {
        return (value + 'px') as string;
    }

    returnBrushWidth(): number {
        return this.sidebarService.brushWidth;
    }
}
