import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatRadioChange, MatRadioModule } from '@angular/material/radio';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ExportComponent } from './export.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
describe('ExportComponent', () => {
    let component: ExportComponent;
    let fixture: ComponentFixture<ExportComponent>;
    let fakeDrawService: DrawingService;
    let dialogrefstub: jasmine.SpyObj<MatDialogRef<ExportComponent>>;
    const WIDTH = 40;
    const HEIGHT = 40;

    beforeEach(async(() => {
        fakeDrawService = new DrawingService();
        dialogrefstub = jasmine.createSpyObj('MatDialogRef', ['close']);
        const canvasStub: HTMLCanvasElement = document.createElement('canvas');
        const ctxStub = canvasStub.getContext('2d') as CanvasRenderingContext2D;
        canvasStub.width = WIDTH;
        canvasStub.height = HEIGHT;
        fakeDrawService.canvas = canvasStub;
        fakeDrawService.baseCtx = ctxStub;

        TestBed.configureTestingModule({
            declarations: [ExportComponent],
            imports: [MatSelectModule, MatRadioModule, MatInputModule, FormsModule],
            providers: [
                { provide: MatDialogRef, useValue: dialogrefstub },
                { provide: DrawingService, useValue: fakeDrawService },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        component['originalImage'] = fakeDrawService.baseCtx.getImageData(0, 0, fakeDrawService.canvas.width, fakeDrawService.canvas.height);
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    // testes pour changefilter()
    it('should call noFilter()', () => {
        spyOn(component, 'noFilter');
        const filter = 'Original';
        const event = {} as MatRadioChange;
        event.value = filter;
        component.changefilter(event);
        expect(component.noFilter).toHaveBeenCalled();
    });

    it('should call blackAndWhiteFilter()', () => {
        spyOn(component, 'blackAndWhiteFilter').and.callThrough();
        const filter = 'Noir et blanc';
        const event = {} as MatRadioChange;
        event.value = filter;
        component.changefilter(event);
        expect(component.blackAndWhiteFilter).toHaveBeenCalled();
    });

    it('should call onlyBlueFilter()', () => {
        spyOn(component, 'onlyBlueFilter').and.callThrough();
        const filter = 'Le bleu seulement';
        const event = {} as MatRadioChange;
        event.value = filter;
        component.changefilter(event);
        expect(component.onlyBlueFilter).toHaveBeenCalled();
    });

    it('should call onlyRedFilter()', () => {
        spyOn(component, 'onlyRedFilter').and.callThrough();
        const filter = 'Le rouge seulement';
        const event = {} as MatRadioChange;
        event.value = filter;
        component.changefilter(event);
        expect(component.onlyRedFilter).toHaveBeenCalled();
    });

    it('should call  onlyGreenFilter()', () => {
        spyOn(component, 'onlyGreenFilter').and.callThrough();
        const filter = 'Le vert seulement';
        const event = {} as MatRadioChange;
        event.value = filter;
        component.changefilter(event);
        expect(component.onlyGreenFilter).toHaveBeenCalled();
    });

    it('should call darkenColorsFilter()', () => {
        spyOn(component, 'darkenColorsFilter').and.callThrough();
        const filter = 'Ternir les couleurs';
        const event = {} as MatRadioChange;
        event.value = filter;
        component.changefilter(event);
        expect(component.darkenColorsFilter).toHaveBeenCalled();
    });

    // testes pour  chooseExportingMode()
    it('should have attribute chosenExportMode to be equale to png ', () => {
        const event = {} as MatRadioChange;
        event.value = 'png';
        component.chooseExportingMode(event);
        expect(component['chosenExportMode']).toBe('png');
    });
    it('should have attribute chosenExportMode to be equale to jpg', () => {
        const event = {} as MatRadioChange;
        event.value = 'jpg';
        component.chooseExportingMode(event);
        expect(component['chosenExportMode']).toBe('jpg');
    });

    // testes pour export()
    it('should call exportAsPng()', () => {
        spyOn(component, 'exportAsPng').and.callThrough();
        component['chosenExportMode'] = 'png';
        component.export();
        expect(component.exportAsPng).toHaveBeenCalled();
    });
    it('should  call exportAsJpg()', () => {
        spyOn(component, 'exportAsJpg').and.callThrough();
        component['chosenExportMode'] = 'jpg';
        component.export();
        expect(component.exportAsJpg).toHaveBeenCalled();
    });
    it('should  call alert()', () => {
        const spy = spyOn(window, 'alert').and.callThrough();
        component['chosenExportMode'] = 'something';
        component.export();
        expect(spy).toHaveBeenCalledWith('Veuillez choisir le format de limage à exporter ');
    });

    // testes pour sendAsEmail()
    it('should have attribute chosenExportMode to be equale to true', () => {
        const event = {} as MatSelectChange;
        event.value = 'email';
        component.sendAsEmail(event);
        expect(component.isShownEmail).toBe(true);
    });
    it('should have attribute chosenExportMode to be equale to true', () => {
        const event = {} as MatSelectChange;
        event.value = 'local';
        component.sendAsEmail(event);
        expect(component.isShownEmail).toBe(false);
    });
    // test pour close()
    it('should call close()', () => {
        component.cancel();
        expect(dialogrefstub.close).toHaveBeenCalled();
    });
    it('should call putImageData', () => {
        const spy = spyOn(component['ctx'], 'putImageData');
        component.noFilter();
        expect(spy).toHaveBeenCalled();
    });
});
