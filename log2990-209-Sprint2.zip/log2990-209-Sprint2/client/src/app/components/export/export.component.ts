import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelectChange } from '@angular/material/select';
import { DARKEN_COLOR_FACTOR, NEXT_COLOR, NUMBER_OF_COLORS } from '@app/constantes/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';

@Component({
    selector: 'app-export',
    templateUrl: './export.component.html',
    styleUrls: ['./export.component.scss'],
})
export class ExportComponent implements OnInit {
    @ViewChild('canvas', { static: true }) canvas: ElementRef<HTMLCanvasElement>;

    filters: string[];
    filter: string;

    fileName: string = '';

    exportModes: string[];
    isShownEmail: boolean = false;
    private chosenExportMode: string;
    private originalImage: ImageData;
    private ctx: CanvasRenderingContext2D;

    constructor(
        private drawingService: DrawingService,
        private dialogRef: MatDialogRef<ExportComponent>,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.filters = ['Original', 'Noir et blanc', 'Le bleu seulement', 'Le rouge seulement', 'Le vert seulement', 'Ternir les couleurs'];

        this.exportModes = ['png', 'jpg'];
        this.chosenExportMode = '';
    }

    ngOnInit(): void {
        this.loadDrawing();
    }

    loadDrawing(): void {
        this.ctx = this.canvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        const image = new Image();
        image.width = this.ctx.canvas.width;
        image.height = this.ctx.canvas.height;
        image.src = this.drawingService.canvas.toDataURL('image/png');
        image.onload = () => {
            this.ctx.drawImage(image, 0, 0, image.width, image.height);
            this.originalImage = this.ctx.getImageData(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
        };
    }
    changefilter(event: MatRadioChange): void {
        switch (event.value) {
            case 'Original':
                this.noFilter();
                break;

            case 'Noir et blanc':
                this.blackAndWhiteFilter();
                break;

            case 'Le bleu seulement':
                this.onlyBlueFilter();
                break;

            case 'Le rouge seulement':
                this.onlyRedFilter();

                break;

            case 'Le vert seulement':
                this.onlyGreenFilter();
                break;

            case 'Ternir les couleurs':
                this.darkenColorsFilter();
                break;
        }
    }
    noFilter(): void {
        const imagedata = new ImageData(new Uint8ClampedArray(this.originalImage.data), this.originalImage.width, this.originalImage.height);
        this.ctx.putImageData(imagedata, 0, 0);
    }
    blackAndWhiteFilter(): void {
        const imagedata = new ImageData(new Uint8ClampedArray(this.originalImage.data), this.originalImage.width, this.originalImage.height);
        for (let i = 0; i < imagedata.data.length; i += NEXT_COLOR) {
            const color = imagedata.data[i] + imagedata.data[i + 1] + imagedata.data[i + 2];
            imagedata.data[i] = color / NUMBER_OF_COLORS;
            imagedata.data[i + 1] = color / NUMBER_OF_COLORS;
            imagedata.data[i + 2] = color / NUMBER_OF_COLORS;
        }

        this.ctx.putImageData(imagedata, 0, 0);
    }

    onlyBlueFilter(): void {
        const imagedata = new ImageData(new Uint8ClampedArray(this.originalImage.data), this.originalImage.width, this.originalImage.height);
        for (let i = 0; i < imagedata.data.length; i += NEXT_COLOR) {
            imagedata.data[i] = 0;
            imagedata.data[i + 1] = 0;
        }
        this.ctx.putImageData(imagedata, 0, 0);
    }
    onlyRedFilter(): void {
        const imagedata = new ImageData(new Uint8ClampedArray(this.originalImage.data), this.originalImage.width, this.originalImage.height);
        for (let i = 0; i < imagedata.data.length; i += NEXT_COLOR) {
            imagedata.data[i + 1] = 0;
            imagedata.data[i + 2] = 0;
        }

        this.ctx.putImageData(imagedata, 0, 0);
    }
    onlyGreenFilter(): void {
        const imagedata = new ImageData(new Uint8ClampedArray(this.originalImage.data), this.originalImage.width, this.originalImage.height);
        for (let i = 0; i < imagedata.data.length; i += NEXT_COLOR) {
            imagedata.data[i] = 0;
            imagedata.data[i + 2] = 0;
        }

        this.ctx.putImageData(imagedata, 0, 0);
    }
    darkenColorsFilter(): void {
        const imagedata = new ImageData(new Uint8ClampedArray(this.originalImage.data), this.originalImage.width, this.originalImage.height);
        for (let i = 0; i < imagedata.data.length; i += NEXT_COLOR) {
            imagedata.data[i] = DARKEN_COLOR_FACTOR * imagedata.data[i];
            imagedata.data[i + 1] = DARKEN_COLOR_FACTOR * imagedata.data[i + 1];
            imagedata.data[i + 2] = DARKEN_COLOR_FACTOR * imagedata.data[i + 2];
        }

        this.ctx.putImageData(imagedata, 0, 0);
    }

    sendAsEmail(event: MatSelectChange): void {
        if (event.value === 'email') {
            this.isShownEmail = true;
        } else {
            this.isShownEmail = false;
        }
    }
    chooseExportingMode(event: MatRadioChange): void {
        switch (event.value) {
            case 'png':
                this.chosenExportMode = 'png';
                break;
            case 'jpg':
                this.chosenExportMode = 'jpg';
                break;
        }
    }
    export(): void {
        switch (this.chosenExportMode) {
            case 'png':
                this.exportAsPng(this.fileName);
                break;
            case 'jpg':
                this.exportAsJpg(this.fileName);
                break;
            default:
                alert('Veuillez choisir le format de limage à exporter ');
        }
    }
    exportAsPng(fileName: string): void {
        const image = this.ctx.canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.download = fileName;
        link.href = image;
        link.click();
        link.remove();
    }
    exportAsJpg(fileName: string): void {
        const image = this.ctx.canvas.toDataURL('image/jpeg');
        const link = document.createElement('a');
        link.download = fileName;
        link.href = image;
        link.click();
        link.remove();
    }
    cancel(): void {
        this.dialogRef.close();
        this.shortcutManagerService.enableShortcut();
    }
}
