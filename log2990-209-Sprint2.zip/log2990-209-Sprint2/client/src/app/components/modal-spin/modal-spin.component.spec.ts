import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalSpinComponent } from './modal-spin.component';

describe('ModalSpinComponent', () => {
    let component: ModalSpinComponent;
    let fixture: ComponentFixture<ModalSpinComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ModalSpinComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ModalSpinComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
