import { Component } from '@angular/core';
@Component({
    selector: 'app-modal-spin',
    templateUrl: './modal-spin.component.html',
    styleUrls: ['./modal-spin.component.scss'],
})
export class ModalSpinComponent {}
