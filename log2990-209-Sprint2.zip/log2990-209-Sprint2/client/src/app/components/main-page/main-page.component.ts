import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { GalleryComponent } from '@app/components/gallery/gallery.component';
import { GuideUtilsateurComponent } from '@app/components/guide-utilsateur/guide-utilsateur.component';

@Component({
    selector: 'app-main-page',
    templateUrl: './main-page.component.html',
    styleUrls: ['./main-page.component.scss'],
})
export class MainPageComponent {
    readonly title: string = 'ProPaint';

    constructor(public dialog: MatDialog, public galleryWindow: MatDialog) {}

    openDialog(): void {
        this.dialog.open(GuideUtilsateurComponent, { disableClose: true });
    }

    openGallery(): void {
        this.galleryWindow.open(GalleryComponent, { disableClose: true });
    }
}
