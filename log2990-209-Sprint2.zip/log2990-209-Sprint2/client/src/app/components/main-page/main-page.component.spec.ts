import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { MainPageComponent } from './main-page.component';
describe('MainPageComponent', () => {
    let component: MainPageComponent;
    let fixture: ComponentFixture<MainPageComponent>;
    let matDialogStub: jasmine.SpyObj<MatDialog>;

    beforeEach(async(() => {
        matDialogStub = jasmine.createSpyObj('MatDialog', ['open']);
        TestBed.configureTestingModule({
            declarations: [MainPageComponent],
            providers: [{ provide: MatDialog, useValue: matDialogStub }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MainPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it("should have as title 'ProPaint'", () => {
        expect(component.title).toBe('ProPaint');
    });

    it('Should open userguide Dialog ', () => {
        component.openDialog();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('Should open gallery Dialog ', () => {
        component.openGallery();
        expect(matDialogStub.open).toHaveBeenCalled();
    });
});
