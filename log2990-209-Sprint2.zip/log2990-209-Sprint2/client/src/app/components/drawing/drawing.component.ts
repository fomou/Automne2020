import { AfterViewInit, Component, ElementRef, HostListener, OnDestroy, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Resize } from '@app/classes/resize';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import { DEFAULT_HEIGHT, DEFAULT_WIDTH, ERASE_INDEX } from '@app/constantes/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';
import { BrushService } from '@app/services/tools/brush/brush.service';
import { EllipseService } from '@app/services/tools/ellipse/ellipse.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { PencilService } from '@app/services/tools/pencil//pencil-service';
import { RectangleService } from '@app/services/tools/rectangle/rectangle.service';
import { SelectionEllipseService } from '@app/services/tools/selection-ellipse/selection-ellipse.service';
import { SelectionRectangleService } from '@app/services/tools/selection-rectangle/selection-rectangle.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-drawing',
    templateUrl: './drawing.component.html',
    styleUrls: ['./drawing.component.scss'],
})
export class DrawingComponent implements AfterViewInit, OnInit, OnDestroy {
    private shortcutDisable: boolean;
    constructor(
        private drawingService: DrawingService,
        private toolsSelectorService: ToolsSelectorService,
        private undoRedoService: UndoRedoService,
        pencilService: PencilService,
        rectangleService: RectangleService,
        ellipseService: EllipseService,
        lineService: LineService,
        eraseService: EraseService,
        brushService: BrushService,
        paintBucketService: PaintBucketService,
        selectionEllipseService: SelectionEllipseService,
        selectionRectangleService: SelectionRectangleService,
        private renderer2: Renderer2,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.tools = [
            pencilService,
            rectangleService,
            ellipseService,
            lineService,
            eraseService,
            brushService,
            paintBucketService,
            selectionRectangleService,
            selectionEllipseService,
        ];
        this.currentTool = this.tools[0];
        const subsTools = this.toolsSelectorService.tool$.subscribe((tool) => {
            this.currentTool = tool;
            this.hasEraser = this.currentTool === this.tools[ERASE_INDEX];
        });

        const subsDisable = this.shortcutManagerService.shortcutObs$.subscribe((disable) => {
            this.shortcutDisable = disable;
        });
        this.subscriptions.push(subsTools);
        this.subscriptions.push(subsDisable);
    }
    get width(): number {
        return this.canvasSize.x;
    }

    get height(): number {
        return this.canvasSize.y;
    }

    @ViewChild('baseCanvas', { static: false }) baseCanvas: ElementRef<HTMLCanvasElement>;
    @ViewChild('previewCanvas', { static: false }) previewCanvas: ElementRef<HTMLCanvasElement>;
    @ViewChild('borderCanvas', { static: false }) borderCanvas: ElementRef<HTMLDivElement>;
    @ViewChild('both', { static: true }) both: ElementRef<HTMLDivElement>;
    @ViewChild('bottom', { static: true }) bottom: ElementRef<HTMLDivElement>;
    @ViewChild('right', { static: true }) right: ElementRef<HTMLDivElement>;
    @ViewChild('background', { static: true }) background: ElementRef<HTMLDivElement>;

    private baseCtx: CanvasRenderingContext2D;
    private previewCtx: CanvasRenderingContext2D;
    private canvasSize: Vec2 = { x: DEFAULT_WIDTH, y: DEFAULT_HEIGHT };
    originalHeight: number = 0;
    minimumSize: number = 250;
    originalWidth: number = 0;
    originalMouseX: number = 0;
    originalMouseY: number = 0;
    isNotResing: boolean = true;
    maxSizeWidth: number = 280;
    maxSizeHeight: number = 25;
    galleryIsOpen: boolean = false;
    private subscriptions: Subscription[] = [];
    private tools: Tool[];
    currentTool: Tool;
    hasEraser: boolean = false;

    private unlistenMouseDown: () => void;
    private unlistenMouseMove: () => void;
    private unlistenMouseUp: () => void;

    ngAfterViewInit(): void {
        this.baseCtx = this.baseCanvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        this.previewCtx = this.previewCanvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        this.drawingService.baseCtx = this.baseCtx;
        this.drawingService.previewCtx = this.previewCtx;
        this.drawingService.canvas = this.baseCanvas.nativeElement;
        this.drawingService.previewCanvas = this.previewCanvas.nativeElement;
        this.drawingService.borderCanvas = this.borderCanvas.nativeElement;
        this.drawingService.background = this.background.nativeElement;
        this.background.nativeElement.style.width = this.borderCanvas.nativeElement.style.width = this.canvasSize.x + 'px';
        this.background.nativeElement.style.height = this.borderCanvas.nativeElement.style.height = this.canvasSize.y + 'px';
        // this.drawingService.startImage = new BehaviorSubject<string>('');
        this.drawingService.setBackground(this.drawingService.baseCtx);
    }

    ngOnInit(): void {
        const bothDiv = this.both.nativeElement;
        const rightDiv = this.right.nativeElement;
        const bottom = this.bottom.nativeElement;
        this.unlistenMouseDown = this.renderer2.listen(bothDiv, 'mousedown', () => {
            this.isNotResing = false;
            this.unlistenMouseMove = this.renderer2.listen('window', 'mousemove', (event: MouseEvent) => {
                const width = this.originalWidth + (event.pageX - this.originalMouseX);
                const height = this.originalHeight + (event.pageY - this.originalMouseY);
                if (width > this.minimumSize && width < window.innerWidth - this.maxSizeWidth)
                    this.borderCanvas.nativeElement.style.width = width + 'px';
                if (height > this.minimumSize && height < window.innerHeight - this.maxSizeHeight)
                    this.borderCanvas.nativeElement.style.height = height + 'px';
                this.undoRedoService.setToolInUse(true);
            });

            this.unlistenMouseUp = this.renderer2.listen('window', 'mouseup', () => {
                this.unlistenMouseMove();
                this.unlistenMouseUp();
                this.undoRedoService.setToolInUse(false);
                const oldCanvas = this.baseCanvas.nativeElement.toDataURL('image/png');
                const image = new Image();

                image.onload = () => {
                    this.drawingService.setBackground(this.baseCtx);
                    this.baseCtx.drawImage(image, 0, 0);
                };

                const dh = parseInt(this.borderCanvas.nativeElement.style.height, 10) - this.baseCanvas.nativeElement.height;
                const dw = parseInt(this.borderCanvas.nativeElement.style.width, 10) - this.canvasSize.x;

                const resize = new Resize(
                    this.drawingService,
                    image,
                    this.baseCanvas.nativeElement.width,
                    this.baseCanvas.nativeElement.height,
                    dw,
                    dh,
                );
                this.undoRedoService.setToolInUse(false);
                this.undoRedoService.addToStack(resize);
                image.src = oldCanvas;
                this.canvasSize.x = parseInt(this.borderCanvas.nativeElement.style.width, 10);
                this.canvasSize.y = parseInt(this.borderCanvas.nativeElement.style.height, 10);
                this.isNotResing = true;
            });
        });

        this.unlistenMouseDown = this.renderer2.listen(rightDiv, 'mousedown', () => {
            this.isNotResing = false;
            this.unlistenMouseMove = this.renderer2.listen('document', 'mousemove', (event: MouseEvent) => {
                const width = this.originalWidth + (event.pageX - this.originalMouseX);
                const height = this.originalHeight;
                if (width > this.minimumSize && width < window.innerWidth - this.maxSizeWidth)
                    this.borderCanvas.nativeElement.style.width = width + 'px';
                if (height > this.minimumSize && height < window.innerHeight) this.borderCanvas.nativeElement.style.height = height + 'px';
                this.undoRedoService.setToolInUse(true);
            });

            this.unlistenMouseUp = this.renderer2.listen('document', 'mouseup', () => {
                this.unlistenMouseMove();
                this.unlistenMouseUp();
                this.undoRedoService.setToolInUse(false);
                const oldCanvas = this.baseCanvas.nativeElement.toDataURL('image/png');
                const image = new Image();
                image.src = oldCanvas;
                const dw = parseInt(this.borderCanvas.nativeElement.style.width, 10) - this.canvasSize.x;

                const resize = new Resize(
                    this.drawingService,
                    image,
                    this.baseCanvas.nativeElement.width,
                    this.baseCanvas.nativeElement.height,
                    dw,
                    0,
                );
                this.undoRedoService.addToStack(resize);
                this.canvasSize.x = parseInt(this.borderCanvas.nativeElement.style.width, 10);
                this.isNotResing = true;
                image.onload = () => {
                    this.drawingService.setBackground(this.baseCtx);
                    this.baseCtx.drawImage(image, 0, 0);
                };
            });
        });

        this.unlistenMouseDown = this.renderer2.listen(bottom, 'mousedown', () => {
            this.isNotResing = false;

            this.unlistenMouseMove = this.renderer2.listen('document', 'mousemove', (event: MouseEvent) => {
                const width = this.originalWidth;
                const height = this.originalHeight + (event.pageY - this.originalMouseY);
                if (width > this.minimumSize && width < window.innerWidth) this.borderCanvas.nativeElement.style.width = width + 'px';
                if (height > this.minimumSize && height < window.innerHeight - this.maxSizeHeight)
                    this.borderCanvas.nativeElement.style.height = height + 'px';
                this.undoRedoService.setToolInUse(true);
            });

            this.unlistenMouseUp = this.renderer2.listen('document', 'mouseup', () => {
                this.unlistenMouseMove();
                this.unlistenMouseUp();
                this.undoRedoService.setToolInUse(false);
                const oldCanvas = this.baseCanvas.nativeElement.toDataURL('image/png');
                const image = new Image();

                image.onload = () => {
                    this.drawingService.setBackground(this.baseCtx);
                    this.baseCtx.drawImage(image, 0, 0);
                };

                const dh = parseInt(this.borderCanvas.nativeElement.style.height, 10) - this.baseCanvas.nativeElement.height;

                const resize = new Resize(
                    this.drawingService,
                    image,
                    this.baseCanvas.nativeElement.width,
                    this.baseCanvas.nativeElement.height,
                    0,
                    dh,
                );
                this.undoRedoService.addToStack(resize);
                image.src = oldCanvas;
                this.canvasSize.x = parseInt(this.borderCanvas.nativeElement.style.width, 10);
                this.canvasSize.y = parseInt(this.borderCanvas.nativeElement.style.height, 10);
                this.isNotResing = true;
            });
        });
    }

    ngOnDestroy(): void {
        this.unlistenMouseDown();
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }

    @HostListener('document: mousemove', ['$event'])
    onMouseMove(event: MouseEvent): void {
        if (this.isNotResing) this.currentTool.onMouseMove(event);
    }

    @HostListener('mousedown', ['$event'])
    onMouseDown(event: MouseEvent): void {
        if (this.isNotResing) this.currentTool.onMouseDown(event);
    }

    @HostListener('document: mouseup', ['$event'])
    onMouseUp(event: MouseEvent): void {
        if (this.isNotResing) this.currentTool.onMouseUp(event);
    }

    @HostListener('mouseleave', ['$event'])
    onMouseLeave(event: MouseEvent): void {
        if (this.isNotResing) this.currentTool.onMouseLeave(event);
    }

    @HostListener('mouseenter', ['$event'])
    onMouseEnter(event: MouseEvent): void {
        if (this.isNotResing) this.currentTool.onMouseEnter(event);
    }

    @HostListener('window:keydown', ['$event'])
    onkeydown(event: KeyboardEvent): void {
        if (this.shortcutDisable) {
            return;
        }
        this.hasEraser = this.currentTool === this.tools[ERASE_INDEX];
        this.currentTool.onKeyDown(event);
        this.undoRedoService.onKeyDown(event);
    }

    @HostListener('window:keyup', ['$event'])
    onKeyUp(event: KeyboardEvent): void {
        if (this.isNotResing) this.currentTool.onKeyUp(event);
    }

    @HostListener('click', ['$event'])
    onClick(event: MouseEvent): void {
        if (this.isNotResing) this.currentTool.onClick(event);
    }

    @HostListener('dblclick', ['$event'])
    onDoubleClick(event: MouseEvent): void {
        if (this.isNotResing) this.currentTool.onDoubleClick(event);
    }

    @HostListener('window:keydown.control.o', ['$event'])
    createNewDrawing(event: KeyboardEvent): void {
        if (!this.undoRedoService.canUndo() && !this.drawingService.imageLoadedFromGallery()) {
            return;
        }
        console.log('can undo');
        event.preventDefault();
        const confirm = window.confirm('Voulez-vous abandonner vos changement ?');
        if (confirm) {
            this.drawingService.setBackground(this.drawingService.baseCtx);
            this.undoRedoService.clearStacks();
            this.drawingService.imageIsLoadedFromGallery.next(false);
        }
    }

    @HostListener('contextmenu', ['$event'])
    disableContextMenu(event: MouseEvent): void {
        event.preventDefault();
    }
}
