import { AfterViewInit, Component, ElementRef, EventEmitter, HostListener, Output, ViewChild } from '@angular/core';
import { Vec2 } from '@app/classes/vec2';
import { COLOR_PICKER_WIDTH, COLOR_SLIDER_HEIGHT, CURSOR_SIZE } from '@app/constantes/constants';
import { MouseButton } from '@app/enums/mouse-button';

@Component({
    selector: 'app-color-slider',
    templateUrl: './color-slider.component.html',
    styleUrls: ['./color-slider.component.scss'],
})
export class ColorSliderComponent implements AfterViewInit {
    @Output() colorEmitter: EventEmitter<string> = new EventEmitter();

    @ViewChild('canvas', { static: false }) canvas: ElementRef<HTMLCanvasElement>;

    private context: CanvasRenderingContext2D;
    private currentPoint: Vec2;
    private canvasSize: Vec2 = { x: COLOR_PICKER_WIDTH, y: COLOR_SLIDER_HEIGHT };
    private mouseDown: boolean = false;

    ngAfterViewInit(): void {
        this.context = this.canvas.nativeElement.getContext('2d') as CanvasRenderingContext2D;
        this.displaySlider();
    }

    @HostListener('mousemove', ['$event'])
    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown) {
            this.clear();
            this.currentPoint = this.getCurrentPoint(event);
            this.displaySlider();
        }
    }

    @HostListener('mousedown', ['$event'])
    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        this.currentPoint = this.getCurrentPoint(event);
        this.colorEmitter.emit(this.getColorAtPosition(event));
        this.clear();
        this.displaySlider();
    }

    @HostListener('mouseup', ['$event'])
    onMouseUp(event: MouseEvent): void {
        this.colorEmitter.emit(this.getColorAtPosition(event));
        this.mouseDown = false;
    }

    get width(): number {
        return this.canvasSize.x;
    }

    get height(): number {
        return this.canvasSize.y;
    }

    //  tslint:disable:no-magic-numbers
    private displaySlider(): void {
        const cursorSize = CURSOR_SIZE;
        const gradient = this.context.createLinearGradient(0, 0, 0, this.height);
        gradient.addColorStop(0, 'rgba(255, 0, 0, 1)');

        gradient.addColorStop(0.17, 'rgba(255, 255, 0, 1)');
        gradient.addColorStop(0.34, 'rgba(0, 255, 0, 1)');
        gradient.addColorStop(0.51, 'rgba(0, 255, 255, 1)');
        gradient.addColorStop(0.68, 'rgba(0, 0, 255, 1)');
        gradient.addColorStop(0.85, 'rgba(255, 0, 255, 1)');
        gradient.addColorStop(1, 'rgba(255, 0, 0, 1)');

        this.context.beginPath();
        this.context.rect(cursorSize, 0, this.width, this.height);

        this.context.fillStyle = gradient;
        this.context.fill();
        this.context.closePath();

        // pour dessiner le petit triange qui represente le curseur
        if (this.currentPoint) {
            this.context.beginPath();
            this.context.fillStyle = 'black';
            this.context.moveTo(0, this.currentPoint.y - cursorSize / 2);
            this.context.lineTo(cursorSize, this.currentPoint.y);
            this.context.lineTo(0, this.currentPoint.y + cursorSize / 2);
            this.context.fill();
            this.context.closePath();
        }
    }

    getColorAtPosition(event: MouseEvent): string {
        const x = CURSOR_SIZE + COLOR_PICKER_WIDTH / 2; // to make sure to give right color even if we move juste the left side cursor
        const imageData = this.context.getImageData(x, event.offsetY, 1, 1).data;
        const redHex = imageData[0].toString(16).length > 1 ? imageData[0].toString(16) : '0' + imageData[0].toString(16);
        const greenHex = imageData[1].toString(16).length > 1 ? imageData[1].toString(16) : '0' + imageData[1].toString(16);
        const blueHex = imageData[2].toString(16).length > 1 ? imageData[2].toString(16) : '0' + imageData[2].toString(16);
        const hexadecimalColor = '#' + (redHex + greenHex + blueHex).toUpperCase();

        return hexadecimalColor;
    }

    private getCurrentPoint(event: MouseEvent): Vec2 {
        return { x: event.offsetX, y: event.offsetY };
    }
    private clear(): void {
        this.context.clearRect(0, 0, this.width, this.height);
    }
}
