import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { MatSliderChange } from '@angular/material/slider';
import { Keyboard } from '@app/enums/key-board';
import { LineService } from '@app/services/tools/line/line.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { SidebarComponent } from './sidebar.component';

// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable:no-magic-numbers
// tslint:disable: max-file-line-count
describe('SidebarComponent', () => {
    let component: SidebarComponent;
    let fixture: ComponentFixture<SidebarComponent>;
    let matDialogStub: jasmine.SpyObj<MatDialog>;
    let lineStub: LineService;
    let sideBareStub: SidebarService;

    beforeEach(async(() => {
        matDialogStub = jasmine.createSpyObj('MatDialog', ['open', 'afterClosed']);
        lineStub = { radius: 0 } as LineService;

        sideBareStub = new SidebarService();
        TestBed.configureTestingModule({
            declarations: [SidebarComponent],
            imports: [],
            providers: [
                { provide: MatDialog, useValue: matDialogStub },
                { provide: LineService, useValue: lineStub },
                { provide: SidebarService, useValue: sideBareStub },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SidebarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should set radius of line tool ', () => {
        const radiusStub = 10;
        component.getRadius(radiusStub);
        expect(component.radius).toEqual(lineStub.radius);
    });

    it('should correctly format parametre', () => {
        const valueStub = 10;
        component.formatLabel(valueStub);
        expect(component.formatLabel(valueStub)).toEqual('10px');
    });

    it('should hide all menu bars', () => {
        component.hideAllBarAtt();
        const result: boolean =
            component.isShownBarAttShapes || component.isShownBarAttLine || component.isShownBarAttShapes || component.isShownBarAttTools;
        expect(result).toBeFalsy();
    });

    it('should show tool bar', () => {
        component.showBarAttributesTools();
        expect(component['isShownBarAttTools']).toBeTruthy();
    });

    it('openExport should do nothing if shortcuts is disbale', () => {
        component['shortcutDisabled'] = true;

        component.openExportWindow();
        expect(matDialogStub.open).not.toHaveBeenCalled();
    });

    it('openExport should open dialogue ', () => {
        component['shortcutDisabled'] = false;
        component.openExportWindow();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('openSauvegard should do nothing if shortcuts is disbale', () => {
        component['shortcutDisabled'] = true;

        component.openDialogSauvegarde();
        expect(matDialogStub.open).not.toHaveBeenCalled();
    });

    it('openSauvegard shoulds open dialogue ', () => {
        component['shortcutDisabled'] = false;
        component.openDialogSauvegarde();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('openGallery shoulds do nothing if shortcuts is disbale', () => {
        component['shortcutDisabled'] = true;
        spyOn(component['drawingService'], 'isBlank').and.returnValue(false);
        spyOn(window, 'confirm').and.returnValue(false);
        component.galleryManager();
        expect(matDialogStub.open).not.toHaveBeenCalled();
    });

    it('openGallery should open dialogue ', () => {
        component['shortcutDisabled'] = false;
        spyOn(component['drawingService'], 'isBlank').and.returnValue(false);
        spyOn(window, 'confirm').and.returnValue(false);
        component.galleryManager();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('open should open dialogue ', () => {
        component['shortcutDisabled'] = false;
        component.openDialog();
        expect(matDialogStub.open).toHaveBeenCalled();
    });
    it('should show shapes attribute bar ', () => {
        component.showBarAttributesShapes();
        expect(component.isShownBarAttShapes).toBeTruthy();
    });

    it('should show lines attribute bar', () => {
        component.showBarAttributesLine();
        expect(component.isShownBarAttLine).toBeTruthy();
    });

    it('should show junction type bar ', () => {
        component.showJonctionType();
        expect(component.isShownJonctionType).toBeTruthy();
    });

    it('should show default junction type', () => {
        component.showDefaultJonctionAtt();
        expect(component.jonctionType).toEqual(component.jonctionTypes[0]);
    });

    it('should show dottet junction type', () => {
        component.showWithDotsJonctionAtt();
        expect(component.jonctionType).toEqual(component.jonctionTypes[1]);
    });

    it('should show Eraser attributes ', () => {
        component.showBarAttributesEraser();
        expect(component['isShownBarAttEraser']).toBeTruthy();
    });

    it('should call undo of undo redo service', () => {
        const spy = spyOn<any>(component['undoRedoService'], 'undo').and.callThrough();
        component.undo();
        expect(spy).toHaveBeenCalled();
    });

    it('should call undo of undo redo service', () => {
        const spy = spyOn<any>(component['undoRedoService'], 'redo').and.callThrough();
        component.redo();
        expect(spy).toHaveBeenCalled();
    });

    it('should call change size ', () => {
        const spy = spyOn<any>(component['sidebarService'], 'changeWidth').and.callThrough();

        const event = {} as MatSliderChange;
        component.changeWidth(event);
        expect(spy).toHaveBeenCalled();
    });

    it('should call change size ', () => {
        const spy = spyOn<any>(component['sidebarService'], 'changeEraserSize').and.callThrough();

        const event = {} as MatSliderChange;
        component.changeEraserSize(event);
        expect(spy).toHaveBeenCalled();
    });

    it('should call change size ', () => {
        const spy = spyOn<any>(component['toolsSelectorService'], 'changeTool').and.callThrough();
        component.showPippetteAttribute();
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should do nothing if shortcuts is disabled', () => {
        component['shortcutDisabled'] = true;

        const spy = spyOn(component, 'showBarAttributesShapes').and.callThrough();
        const event = {} as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).not.toHaveBeenCalled();
    });

    it('onkeydown should call showBarAttributesShapes', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesShapes').and.callThrough();
        const event = { code: Keyboard.one } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call showBarAttributesShapes', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesShapes').and.callThrough();
        const event = { code: Keyboard.two } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call showBarAttributesShapes', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesShapes').and.callThrough();
        const event = { code: Keyboard.three } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should do nothing if shortcuts is disabled', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesLine').and.callThrough();
        const event = { code: Keyboard.l } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should line on c', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesTools').and.callThrough();
        const event = { code: Keyboard.c } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should line on c', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesTools').and.callThrough();
        const event = { code: Keyboard.w } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should line on c', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showPippetteAttribute').and.callThrough();
        const event = { code: Keyboard.i } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should line on c', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesEraser').and.callThrough();
        const event = { code: Keyboard.e } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should line on c', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showBarAttributesPaintBucket').and.callThrough();
        const event = { code: Keyboard.b } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should line on c', () => {
        component['shortcutDisabled'] = false;

        const spy = spyOn(component, 'showRectangSelectionleAtt').and.callThrough();
        const event = { code: Keyboard.r } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('showBarAttributesSelection should call hideAllBarAtt and change isShownBarAttSelection', () => {
        const spyClose = spyOn(component, 'closeBar3').and.callThrough();
        const spy = spyOn(component, 'hideAllBarAtt').and.callThrough();
        component.isShownBarAttSelection = false;
        component.showBarAttributesSelection();
        expect(spy).toHaveBeenCalled();
        expect(spyClose).toHaveBeenCalled();
        expect(component.isShownBarAttSelection).toBe(true);
    });

    it('showSelections should change isShownSelections', () => {
        component.isShownSelections = false;
        component.showSelections();
        expect(component.isShownSelections).toBe(true);
    });

    it('showMagicWandAtt should call closebar3', () => {
        const spy = spyOn(component, 'closeBar3').and.callThrough();
        component.showMagicWandAtt();
        expect(spy).toHaveBeenCalled();
    });
    it('showEllipseSelectionAtt should call closebar3', () => {
        const spy = spyOn(component, 'closeBar3').and.callThrough();
        component.showEllipseSelectionAtt();
        expect(spy).toHaveBeenCalled();
    });

    it('showRectangSelectionleAtt should call closebar3', () => {
        const spy = spyOn(component, 'closeBar3').and.callThrough();
        component.showRectangSelectionleAtt();
        expect(spy).toHaveBeenCalled();
    });

    it('showBarAttributesPixelPicker should call hideAllBarAtt and change isShownBarAttSelection', () => {
        const spyClose = spyOn(component, 'closeBar3').and.callThrough();
        const spy = spyOn(component, 'hideAllBarAtt').and.callThrough();
        component.isShownAttPixelPicker = false;
        component.showBarAttributesPixelPicker();
        expect(spy).toHaveBeenCalled();
        expect(spyClose).toHaveBeenCalled();
        expect(component.isShownAttPixelPicker).toBe(true);
    });

    it(' should change lineWidth in slidebarservice ', () => {
        const spy = spyOn(sideBareStub, 'changeWidthLine').and.callThrough();
        const event = { value: 30 } as MatSliderChange;
        component.changeWidthLine(event);
        expect(spy).toHaveBeenCalledWith(event.value as number);
    });

    it('should get line width from sideBar', () => {
        const expected = sideBareStub.widthLine;
        expect(component.returnLineWidth()).toEqual(expected);
    });

    it('should get  width from sideBar', () => {
        const expected = sideBareStub.width;
        expect(component.returnWidth()).toEqual(expected);
    });

    it('should get line width from sideBar', () => {
        const expected = sideBareStub.eraserSize;
        expect(component.returnEraserSize()).toEqual(expected);
    });

    it('galleryManager should do nothing if shortcuts is disabled', () => {
        component['shortcutDisabled'] = true;
        spyOn(component['drawingService'], 'isBlank').and.returnValue(false);
        spyOn(window, 'confirm').and.returnValue(false);
        component.galleryManager();
        expect(matDialogStub.open).not.toHaveBeenCalled();
    });

    it('isClicked should clear canvas on confirm', () => {
        spyOn(component['drawingService'], 'isBlank').and.returnValue(false);
        spyOn(component['drawingService'], 'imageLoadedFromGallery').and.returnValue(true);
        spyOn(window, 'confirm').and.returnValue(true);
        const spy = spyOn(component['drawingService'], 'clearCanvas');
        const spy2 = spyOn(component['drawingService'], 'setBackground').and.callFake(() => {
            return;
        });
        component.isCliked();
        expect(spy).toHaveBeenCalledTimes(2);
        expect(spy2).toHaveBeenCalled();
    });

    it('isClicked should do nothing if the canvas is blank', () => {
        spyOn(component['drawingService'], 'isBlank').and.returnValue(true);
        spyOn(window, 'confirm').and.returnValue(true);
        const spy = spyOn(component['drawingService'], 'clearCanvas');
        const spy2 = spyOn(component['drawingService'], 'setBackground').and.callFake(() => {
            return;
        });
        component.isCliked();
        expect(spy).not.toHaveBeenCalledTimes(2);
        expect(spy2).not.toHaveBeenCalled();
    });

    it('should call prevetDefault', () => {
        const event = new KeyboardEvent('e');
        const spy = spyOn(event, 'preventDefault');
        component.openDialogSauvegarde(event);
        expect(spy).toHaveBeenCalled();
    });

    it('should call prevetDefault', () => {
        const event = new KeyboardEvent('e');
        const spy = spyOn(event, 'preventDefault');
        component.openExportWindow(event);
        expect(spy).toHaveBeenCalled();
    });

    it('should call prevetDefault', () => {
        const event = new KeyboardEvent('e');
        const spy = spyOn(event, 'preventDefault');
        component['galleryWindow'] = matDialogStub;
        spyOn(component['drawingService'], 'isBlank').and.returnValue(true);
        component.galleryManager(event);
        expect(spy).toHaveBeenCalled();
    });

    it('#changeTolerance should call changeTolerance of the service', () => {
        const e = { value: 10 } as MatSliderChange;
        const spy = spyOn(component['sidebarService'], 'changeTolerance');
        component.changeTolerance(e);
        expect(spy).toHaveBeenCalled();
    });

    it('#hideAllToolAttrebutes should change showPipetteAttribute', () => {
        component.hideAllToolAttrebutes();
        expect(component.showPipetteAttribute).toBe(false);
    });
});
