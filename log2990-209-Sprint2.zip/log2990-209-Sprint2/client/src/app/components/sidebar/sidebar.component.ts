import { Component, HostListener } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSliderChange } from '@angular/material/slider';
import { LoadedImage } from '@app/classes/loaded-image';
import { ExportComponent } from '@app/components/export/export.component';
import { GalleryComponent } from '@app/components/gallery/gallery.component';
import { GuideUtilsateurComponent } from '@app/components/guide-utilsateur/guide-utilsateur.component';
import { SaveDrawingComponent } from '@app/components/save-drawing//save-drawing.component';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';
import { LineService } from '@app/services/tools/line/line.service';
import { SelectionRectangleService } from '@app/services/tools/selection-rectangle/selection-rectangle.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent {
    private shortcutDisabled: boolean;
    constructor(
        private dialog: MatDialog,
        private galleryWindow: MatDialog,
        private sidebarService: SidebarService,
        private toolsSelectorService: ToolsSelectorService,
        private lineService: LineService,
        private drawingService: DrawingService,
        private undoRedoService: UndoRedoService,
        private shortcutManagerService: ShortcutManagerService,
        private selectionRectangleService: SelectionRectangleService,
    ) {
        this.shortcutManagerService.shortcutObs$.subscribe((disable) => {
            this.shortcutDisabled = disable;
        });
    }
    radius: number = 5;
    isShownBarAttTools: boolean = true;
    isShownBarAttShapes: boolean = false;
    isShownJonctionType: boolean = false;
    isShownSelections: boolean = false;
    isShownShapes: boolean = false;
    isShownBarAttLine: boolean = false;
    isShownLineAtt: boolean = false;
    isShownBarAttPaintBucket: boolean = false;
    isShownBarAttEraser: boolean = false;
    isShownAttPixelPicker: boolean = false;
    isShownBarAttSelection: boolean = false;
    showPipetteAttribute: boolean = false;
    jonctionTypes: string[] = ['Sans point', 'Avec points'];
    selctions: string[] = ['Rectangle de sélection', 'Ellipse de sélection', 'Baguette magique'];
    selection: string = 'Outils de sélection';
    jonctionType: string = 'Sans point';
    brush: string = 'Outils de tracage';
    shape: string = 'Formes';

    @HostListener('document:keydown.control.e', ['$event'])
    openExportWindow(event?: KeyboardEvent): void {
        if (event) {
            event.preventDefault();
        }

        if (this.shortcutDisabled) {
            return;
        }
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(ExportComponent, {
            disableClose: true,
            height: '400px',
            width: '600px',
        });
    }
    @HostListener('document:keydown.control.a', ['$event'])
    selectAll(event?: KeyboardEvent): void {
        if (event) {
            event.preventDefault();
        }
        this.showBarAttributesSelection();
        this.showRectangSelectionleAtt();
        this.selectionRectangleService.isSelected = true;
        this.selectionRectangleService.imageData = this.drawingService.getImageData();
        this.selectionRectangleService.topLeftPointSelectionX = this.selectionRectangleService.movedXPoint = 0;
        this.selectionRectangleService.topLeftPointSelectionY = this.selectionRectangleService.movedYPoint = 0;
        this.selectionRectangleService.widthSelection = this.selectionRectangleService.width = this.drawingService.canvas.width;
        this.selectionRectangleService.heightSelection = this.selectionRectangleService.height = this.drawingService.canvas.height;
    }

    @HostListener('window:keydown.control.s', ['$event'])
    openDialogSauvegarde(event?: KeyboardEvent): void {
        if (event) {
            event.preventDefault();
        }
        if (this.shortcutDisabled) {
            return;
        }
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(SaveDrawingComponent, {
            disableClose: true,
            height: '400px',
            width: '600px',
        });
    }

    @HostListener('window:keydown.control.g', ['$event'])
    galleryManager(event?: KeyboardEvent): void {
        if (event) {
            event.preventDefault();
        }
        if (this.shortcutDisabled) {
            return;
        }
        this.shortcutManagerService.disableShortcut();
        this.galleryWindow.open(GalleryComponent, { disableClose: true, data: this.drawingService.canvas });
    }

    openDialog(): void {
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(GuideUtilsateurComponent, { disableClose: true });
    }

    undo(): void {
        this.undoRedoService.undo();
        this.undoRedoService.undo();
        this.selectionRectangleService.isSelected = false;
        this.selectionRectangleService.isMoving = false;
    }
    redo(): void {
        this.undoRedoService.redo();
    }

    canUndo(): boolean {
        return this.undoRedoService.canUndo();
    }

    canRedo(): boolean {
        return this.undoRedoService.canRedo();
    }

    getRadius(radius: number): void {
        this.radius = radius;
        this.lineService.radius = radius;
    }

    formatLabel(value: number): string {
        return (value + 'px') as string;
    }

    changeWidth(event: MatSliderChange): void {
        this.sidebarService.changeWidth(event.value as number);
    }

    changeEraserSize(event: MatSliderChange): void {
        this.sidebarService.changeEraserSize(event.value as number);
    }

    changeTolerance(event: MatSliderChange): void {
        this.sidebarService.changeTolerance(event.value as number);
    }

    showPippetteAttribute(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.showPipetteAttribute = !this.showPipetteAttribute;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.i);
        this.toolsSelectorService.changeTool(tool);
    }

    hideAllBarAtt(): void {
        this.isShownBarAttTools = false;
        this.isShownBarAttShapes = false;
        this.isShownBarAttLine = false;
        this.isShownBarAttPaintBucket = false;
        this.isShownBarAttEraser = false;
        this.isShownBarAttSelection = false;
        this.showPipetteAttribute = false;
        this.isShownAttPixelPicker = false;
    }
    closeBar3(): void {
        this.isShownJonctionType = false;
        this.isShownSelections = false;
    }
    // BarAttributesTools
    hideAllToolAttrebutes(): void {
        this.showPipetteAttribute = false;
    }

    showBarAttributesTools(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttTools = !this.isShownBarAttTools;
    }
    showBarAttributesShapes(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttShapes = !this.isShownBarAttShapes;
    }
    // BarAttributesLine
    showBarAttributesLine(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttLine = !this.isShownBarAttLine;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.l);
        this.toolsSelectorService.changeTool(tool);
    }

    showJonctionType(): void {
        this.isShownJonctionType = !this.isShownJonctionType;
    }

    showDefaultJonctionAtt(): void {
        this.isShownLineAtt = false;
        this.showJonctionType();
        this.jonctionType = this.jonctionTypes[0];
        this.lineService.pointJoin = false;
    }

    showWithDotsJonctionAtt(): void {
        this.isShownLineAtt = true;
        this.showJonctionType();
        this.jonctionType = this.jonctionTypes[1];
        this.lineService.pointJoin = true;
    }

    // paint bucket attrebutes
    showBarAttributesPaintBucket(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttPaintBucket = !this.isShownBarAttPaintBucket;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.b);
        this.toolsSelectorService.changeTool(tool);
    }
    showBarAttributesEraser(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.e);
        this.toolsSelectorService.changeTool(tool);
        this.isShownBarAttEraser = !this.isShownBarAttEraser;
    }
    showBarAttributesSelection(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownBarAttSelection = !this.isShownBarAttSelection;
    }
    showSelections(): void {
        this.isShownSelections = !this.isShownSelections;
    }
    showRectangSelectionleAtt(): void {
        this.closeBar3();
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.r);
        this.toolsSelectorService.changeTool(tool);
    }
    showEllipseSelectionAtt(): void {
        this.closeBar3();
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.f);
        this.toolsSelectorService.changeTool(tool);
    }
    showMagicWandAtt(): void {
        this.closeBar3();
    }
    showBarAttributesPixelPicker(): void {
        this.closeBar3();
        this.hideAllBarAtt();
        this.isShownAttPixelPicker = !this.isShownAttPixelPicker;
    }
    changeWidthLine(event: MatSliderChange): void {
        this.sidebarService.changeWidthLine(event.value as number);
    }
    returnWidth(): number {
        return this.sidebarService.width;
    }
    returnLineWidth(): number {
        return this.sidebarService.widthLine;
    }

    returnEraserSize(): number {
        return this.sidebarService.eraserSize;
    }
    isCliked(): void {
        if (!this.undoRedoService.canUndo() && !this.drawingService.imageLoadedFromGallery()) {
            return;
        }
        if (window.confirm('Voulez-vous abandonner vos changement ?')) {
            this.drawingService.clearCanvas(this.drawingService.baseCtx);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.undoRedoService.clearStacks();
            this.undoRedoService.loadedImage.next(new LoadedImage());
            this.drawingService.imageIsLoadedFromGallery.next(false);
            this.drawingService.setBackground(this.drawingService.baseCtx);
        }
    }
    @HostListener('window:keydown', ['$event'])
    onkeydown(event: KeyboardEvent): void {
        if (this.shortcutDisabled) {
            return;
        }

        if (event.ctrlKey && event.code === Keyboard.z) {
            this.selectionRectangleService.isSelected = false;
            this.selectionRectangleService.isMoving = false;
        }

        switch (event.code) {
            case Keyboard.three:
                this.showBarAttributesShapes();
                this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolBykey(Keyboard.three));
                break;
            case Keyboard.one:
                this.showBarAttributesShapes();
                this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolBykey(Keyboard.one));
                break;
            case Keyboard.two:
                this.showBarAttributesShapes();
                this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolBykey(Keyboard.two));
                break;
            case Keyboard.l:
                this.showBarAttributesLine();
                break;
            case Keyboard.i:
                this.showPippetteAttribute();
                break;
            case Keyboard.e:
                this.showBarAttributesEraser();
                break;
            case Keyboard.c:
                this.showBarAttributesTools();
                this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolBykey(Keyboard.c));
                break;
            case Keyboard.w:
                this.showBarAttributesTools();
                this.toolsSelectorService.changeTool(this.toolsSelectorService.getToolBykey(Keyboard.w));
                break;
            case Keyboard.b:
                this.showBarAttributesPaintBucket();
                break;
            case Keyboard.r:
                this.showBarAttributesSelection();
                this.showRectangSelectionleAtt();
                break;
            case Keyboard.f:
                this.showBarAttributesSelection();
                this.showEllipseSelectionAtt();
        }
    }
}
