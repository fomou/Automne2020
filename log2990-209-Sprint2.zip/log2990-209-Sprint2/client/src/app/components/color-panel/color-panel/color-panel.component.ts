import { Component, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ColorPickerComponent } from '@app/components/color-picker/color-picker/color-picker.component';
import { ColorType } from '@app/enums/color-type';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-color-panel',
    templateUrl: './color-panel.component.html',
    styleUrls: ['./color-panel.component.scss'],
})
export class ColorPanelComponent implements OnDestroy {
    colors: string[];
    primaryColor: string;
    secondaryColor: string;

    private subscriptions: Subscription[];

    constructor(
        private dialog: MatDialog,
        private colorSelectorService: ColorSelectorService,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.subscriptions = [];
        const subsPrimaryColor = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.primaryColor = color;
        });
        const subssecondaryColor = this.colorSelectorService.secondaryColor$.subscribe((color) => {
            this.secondaryColor = color;
        });
        const subsRecentColor = this.colorSelectorService.recentColor$.subscribe((colors) => {
            this.colors = colors;
        });

        this.subscriptions.push(subsPrimaryColor);
        this.subscriptions.push(subsRecentColor);
        this.subscriptions.push(subssecondaryColor);
    }

    ngOnDestroy(): void {
        for (const sub of this.subscriptions) {
            sub.unsubscribe();
        }
    }

    rigthClick(color: string): void {
        this.colorSelectorService.colorType = ColorType.secondary;
        this.colorSelectorService.annonceColor(color);
    }

    leftClick(color: string): void {
        this.colorSelectorService.colorType = ColorType.primary;
        this.colorSelectorService.annonceColor(color);
    }

    changePrimaryColor(): void {
        this.colorSelectorService.colorType = ColorType.primary;
        this.shortcutManagerService.disableShortcut();
        this.dialog.open(ColorPickerComponent, { disableClose: true });
    }

    changeSecondaryColor(): void {
        this.colorSelectorService.colorType = ColorType.secondary;
        this.dialog.open(ColorPickerComponent, { disableClose: true });
    }

    swapColors(): void {
        this.colorSelectorService.swapColor(this.primaryColor, this.secondaryColor);
    }
}
