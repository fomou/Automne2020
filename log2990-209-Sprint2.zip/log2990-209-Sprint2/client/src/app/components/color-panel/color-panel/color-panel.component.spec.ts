import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { ColorPanelComponent } from './color-panel.component';

// tslint:disable: no-any
// tslint:disable: no-magic-numbers
// tslint:disable: no-string-literal
describe('ColorPanelComponent', () => {
    let component: ColorPanelComponent;
    let fixture: ComponentFixture<ColorPanelComponent>;
    let colorSelectorServiceStub: ColorSelectorService;

    let matDialogStub: jasmine.SpyObj<MatDialog>;

    beforeEach(async(() => {
        colorSelectorServiceStub = new ColorSelectorService();

        matDialogStub = jasmine.createSpyObj('MatDialog', ['open']);

        TestBed.configureTestingModule({
            declarations: [ColorPanelComponent],

            providers: [
                { provide: MatDialog, useValue: matDialogStub },
                { provide: ColorSelectorService, useValue: colorSelectorServiceStub },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ColorPanelComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should set secondaryColor on right click', () => {
        const annonceSPy = spyOn<any>(component['colorSelectorService'], 'annonceColor').and.callThrough();
        component.rigthClick('red');
        expect(annonceSPy).toHaveBeenCalled();
    });

    it('changeSecondaryColor should call open of matDialog', () => {
        component.changePrimaryColor();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('changeSecondaryColor() should call open of matDialog', () => {
        component.changeSecondaryColor();
        expect(matDialogStub.open).toHaveBeenCalled();
    });

    it('swapColors should call swapcolor of colorSelectorService', () => {
        const spy = spyOn<any>(component['colorSelectorService'], 'swapColor').and.callThrough();
        component.swapColors();
        expect(spy).toHaveBeenCalled();
    });

    it('leftClick should call annoceColor of colorSelectorService', () => {
        const annonceSPy = spyOn(component['colorSelectorService'], 'annonceColor').and.callThrough();
        component.leftClick('red');
        expect(annonceSPy).toHaveBeenCalled();
    });
});
