import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatChipInputEvent, MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { Tag } from '@common/communication/tag';
import { SaveDrawingComponent } from './save-drawing.component';
// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers

describe('SaveDrawingComponent', () => {
    let component: SaveDrawingComponent;
    let fixture: ComponentFixture<SaveDrawingComponent>;
    let saveDrawingStub: jasmine.SpyObj<SaveDrawingService>;
    let dialogrefstub: jasmine.SpyObj<MatDialog>;
    let tagStub: Tag;
    beforeEach(async(() => {
        saveDrawingStub = jasmine.createSpyObj('SaveDrawingService', ['addData']);
        dialogrefstub = jasmine.createSpyObj('MatDialog', ['open', 'closeAll']);

        TestBed.configureTestingModule({
            declarations: [SaveDrawingComponent],
            imports: [MatDialogModule, MatFormFieldModule, MatChipsModule, FormsModule, MatInputModule, BrowserAnimationsModule],
            providers: [
                { provide: SaveDrawingService, useValue: saveDrawingStub },
                { provide: MatDialog, useValue: dialogrefstub },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SaveDrawingComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        tagStub = { name: 'something' };
        component.tags.push(tagStub);
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('add() should call push()', () => {
        const spy = spyOn(component.tags, 'push');
        const htmlinput = document.createElement('input');
        const event = { value: '123', input: htmlinput } as MatChipInputEvent;
        component.add(event);
        expect(spy).toHaveBeenCalled();
        expect(event.input.value).toBe('');
    });
    it('event shoud have value lenght < than 3', () => {
        const event = { value: '12' } as MatChipInputEvent;
        component.add(event);
        expect(event.value.length).toBeLessThan(component.minLenghtTag);
    });
    it('getDataName() should call getDataTag()', () => {
        const drawingName = 'drawing';
        const spy = spyOn(component, 'getDataTag');
        component.getDataName(drawingName);
        expect(spy).toHaveBeenCalled();
    });
    it('getDataTag() should call confirm() then alert()', () => {
        const spyConfirm = spyOn(window, 'confirm').and.returnValue(false);
        const spyAlert = spyOn(window, 'alert');
        component.getDataTag();
        expect(spyConfirm).toHaveBeenCalledWith('Voulez-vous sauvegarder le dessin ? ');
        expect(spyAlert).toHaveBeenCalledWith('Votre dessin n a pas ete enregistre');
    });
    it('getDataTag() should call open() and addData() and closeAll()', () => {
        spyOn(window, 'confirm').and.returnValue(true);
        jasmine.clock().install();
        component.getDataTag();
        jasmine.clock().tick(component.loadingTime);
        expect(saveDrawingStub.addData).toHaveBeenCalled();
        expect(dialogrefstub.open).toHaveBeenCalled();
        expect(dialogrefstub.closeAll).toHaveBeenCalled();
        jasmine.clock().uninstall();
    });

    it('remove() should call indexOf() and splice()', () => {
        const spyIndexOf = spyOn(component.tags, 'indexOf').and.returnValue(2);
        const spySplice = spyOn(component.tags, 'splice');
        component.remove(tagStub);
        expect(spyIndexOf).toHaveBeenCalled();
        expect(spySplice).toHaveBeenCalled();
    });
    it('should have array tags empty', () => {
        spyOn(component.tags, 'indexOf').and.returnValue(-1);
        component.remove(tagStub);
        expect(component.tags.length).toEqual(1);
    });
});
