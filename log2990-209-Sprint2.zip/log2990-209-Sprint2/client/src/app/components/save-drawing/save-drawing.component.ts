import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component } from '@angular/core';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { ModalSpinComponent } from '@app/components/modal-spin/modal-spin.component';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';
import { Tag } from '@common/communication/tag';
@Component({
    selector: 'app-save-drawing',
    templateUrl: './save-drawing.component.html',
    styleUrls: ['./save-drawing.component.scss'],
})
export class SaveDrawingComponent {
    constructor(private saveDessin: SaveDrawingService, private dialog: MatDialog, private shortcutManagerService: ShortcutManagerService) {}
    visible: boolean = false;
    selectable: boolean = true;
    removable: boolean = true;
    addOnBlur: boolean = true;
    minLenghtTag: number = 3;
    loadingTime: number = 1000;
    maxTags: number = 6;
    readonly separatorKeysCodes: number[] = [ENTER, COMMA];
    tags: Tag[] = [];
    name: string = '';
    imageData: string[];

    add(event: MatChipInputEvent): void {
        this.visible = false;
        const input = event.input;
        const value = event.value;

        if (value.length >= this.minLenghtTag) {
            // if (value.trim()) {
            this.tags.push({ name: value.trim() });
            // }
        }
        // Reinitialiser la valeur d'entrée
        if (input) {
            input.value = '';
        }
    }

    remove(tags: Tag): void {
        const index = this.tags.indexOf(tags);

        if (index >= 0) {
            this.tags.splice(index, 1);
        }
    }

    // Envoyer les infos du dessin à la database
    getDataName(name: string): void {
        this.name = name;
        this.getDataTag();
        this.enableShortcuts();
    }
    getDataTag(): void {
        const TAGS_: string[] = [];
        for (let i = 0; i < this.tags.length; ++i) TAGS_[i] = this.tags[i].name;
        const confirm = window.confirm('Voulez-vous sauvegarder le dessin ? ');
        if (confirm) {
            this.dialog.open(ModalSpinComponent, { disableClose: true });
            this.saveDessin.addData({ name: this.name, tags: TAGS_ });
            setTimeout(() => {
                this.dialog.closeAll();
            }, this.loadingTime);
        } else {
            window.alert('Votre dessin n a pas ete enregistre');
        }
    }
    enableShortcuts(): void {
        this.shortcutManagerService.enableShortcut();
    }
}
