import { Component, HostListener } from '@angular/core';
import { MatSliderChange } from '@angular/material/slider';
import { Keyboard } from '@app/enums/key-board';
import { ToolNames } from '@app/enums/tool-names';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';
import { DrawingTypeSelectorService } from '@app/services/tools/drawing-type/drawing-type-selector.service';
import { PolygoneService } from '@app/services/tools/polygone/polygone.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';
@Component({
    selector: 'app-shapes',
    templateUrl: './shapes.component.html',
    styleUrls: ['./shapes.component.scss'],
})
export class ShapesComponent {
    private shortCutDisabled: boolean;
    showPolygoneAttribute: boolean;
    showTraceType: boolean;
    showShapes: boolean;
    shape: string;
    sides: number = 3;

    constructor(
        private drawingType: DrawingTypeSelectorService,
        private toolsSelectorService: ToolsSelectorService,
        private polygone: PolygoneService,
        private sidebarService: SidebarService,
        private shortcutManagerService: ShortcutManagerService,
    ) {
        this.shape = 'Formes';
        this.showPolygoneAttribute = false;
        this.showTraceType = false;
        this.showShapes = false;
        this.shortcutManagerService.shortcutObs$.subscribe((disabler) => {
            this.shortCutDisabled = disabler;
        });
    }

    changeWidthShape(event: MatSliderChange): void {
        this.sidebarService.changeWidthShape(event.value as number);
    }

    ShowShapes(): void {
        this.showTraceType = false;
        this.showShapes = !this.showShapes;
    }

    changeDrawingType(type: string): void {
        this.drawingType.changeDrawingType(type);
        this.showTraceType = false;
    }

    formatLabel(value: number): string {
        return (value + 'px') as string;
    }

    ShowTraceType(): void {
        this.showShapes = false;
        this.showTraceType = !this.showTraceType;
    }

    showRectangleAttibut(): void {
        this.showPolygoneAttribute = false;
        this.shape = ToolNames.Rectangle;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.one);
        this.toolsSelectorService.changeTool(tool);
        this.showShapes = false;
    }

    showEllipseAttribut(): void {
        this.showPolygoneAttribute = false;
        this.shape = ToolNames.Ellipse;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.two);
        this.toolsSelectorService.changeTool(tool);
        this.showShapes = false;
    }

    ShowPolygoneAtt(): void {
        this.showPolygoneAttribute = true;
        this.shape = ToolNames.Polygone;
        const tool = this.toolsSelectorService.getToolBykey(Keyboard.three);
        this.toolsSelectorService.changeTool(tool);
        this.showShapes = false;
    }

    getSides(sides: number): void {
        this.sides = sides;
        this.polygone.sides = this.sides;
    }

    returnShapeBrush(): number {
        return this.sidebarService.widthShape;
    }

    @HostListener('window:keydown', ['$event'])
    onkeydown(event: KeyboardEvent): void {
        if (this.shortCutDisabled) {
            return;
        }
        switch (event.code) {
            case Keyboard.three: {
                this.ShowPolygoneAtt();
                break;
            }
            case Keyboard.one:
                this.showRectangleAttibut();
                break;
            case Keyboard.two:
                this.showEllipseAttribut();
                break;
        }
    }
}
