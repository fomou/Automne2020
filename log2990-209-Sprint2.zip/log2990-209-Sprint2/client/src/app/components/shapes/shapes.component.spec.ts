import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatSliderChange } from '@angular/material/slider';
import { Tool } from '@app/classes/tool';
import { Keyboard } from '@app/enums/key-board';
import { BrushService } from '@app/services/tools/brush/brush.service';
import { DrawingTypeSelectorService } from '@app/services/tools/drawing-type/drawing-type-selector.service';
import { EllipseService } from '@app/services/tools/ellipse/ellipse.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { PencilService } from '@app/services/tools/pencil/pencil-service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { PolygoneService } from '@app/services/tools/polygone/polygone.service';
import { RectangleService } from '@app/services/tools/rectangle/rectangle.service';
import { SelectionEllipseService } from '@app/services/tools/selection-ellipse/selection-ellipse.service';
import { SelectionRectangleService } from '@app/services/tools/selection-rectangle/selection-rectangle.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { ToolsSelectorService } from '@app/services/tools/tools-selectors/tools-selector.service';
import { ShapesComponent } from './shapes.component';

class ToolSelector extends ToolsSelectorService {
    getToolBykey(s: string): Tool {
        return {} as Tool;
    }
    // tslint:disable-next-line:no-empty
    changeTool(t: Tool): void {}
}

// tslint:disable: no-magic-numbers
describe('ShapesComponent', () => {
    let component: ShapesComponent;
    let fixture: ComponentFixture<ShapesComponent>;
    let sideBareStub: SidebarService;
    let toolSelect: ToolsSelectorService;
    let drawType: DrawingTypeSelectorService;
    let poly: PolygoneService;

    beforeEach(async(() => {
        sideBareStub = new SidebarService();
        drawType = new DrawingTypeSelectorService();
        const rect = {} as RectangleService;
        const ellipse = {} as EllipseService;
        poly = { sides: 10 } as PolygoneService;
        const pen = {} as PencilService;
        const brus = {} as BrushService;
        const era = {} as EraseService;
        const line = {} as LineService;
        const seau = {} as PaintBucketService;
        const pipette = {} as PickerService;
        const selRect = {} as SelectionRectangleService;
        const selEll = {} as SelectionEllipseService;
        toolSelect = new ToolSelector(pen, rect, ellipse, line, era, brus, poly, pipette, seau, selRect, selEll);

        TestBed.configureTestingModule({
            declarations: [ShapesComponent],
            providers: [
                { provide: SidebarService, useValue: sideBareStub },
                { provide: ToolsSelectorService, useValue: toolSelect },
                { provide: DrawingTypeSelectorService, useValue: drawType },
                { provide: PolygoneService, useValue: poly },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ShapesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(' should change shape size in slidebarservice ', () => {
        const spy = spyOn(sideBareStub, 'changeWidthShape').and.callThrough();
        const event = { value: 30 } as MatSliderChange;
        component.changeWidthShape(event);
        expect(spy).toHaveBeenCalledWith(event.value as number);
    });

    it('showShape should set v to false and change  showShapes', () => {
        component.showShapes = true;
        component.ShowShapes();
        expect(component.showShapes).toBe(false);
        expect(component.showTraceType).toBe(false);
    });

    it('changeDrawingType should call changeDrawingType of the service ', () => {
        const spy = spyOn(drawType, 'changeDrawingType').and.callThrough();
        component.changeDrawingType('fill');
        expect(spy).toHaveBeenCalledWith('fill');
        expect(component.showTraceType).toBe(false);
    });

    it('formatLab should give a string', () => {
        const expected = '10px';
        expect(component.formatLabel(10)).toBe(expected);
    });

    it('showShape should set v to false and change  showShapes', () => {
        component.showTraceType = true;
        component.ShowTraceType();
        expect(component.showShapes).toBe(false);
        expect(component.showTraceType).toBe(false);
    });

    it('showRectangleAttibut should change tool', () => {
        const changeSpy = spyOn(toolSelect, 'changeTool').and.callThrough();
        const getSpys = spyOn(toolSelect, 'getToolBykey').and.callThrough();
        component.showRectangleAttibut();
        expect(getSpys).toHaveBeenCalled();
        expect(component.shape).toBe('Rectangle');
        expect(component.showPolygoneAttribute).toEqual(false);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('showRectangleAttibut should change tool', () => {
        const changeSpy = spyOn(toolSelect, 'changeTool').and.callThrough();
        const getSpys = spyOn(toolSelect, 'getToolBykey').and.callThrough();
        component.showEllipseAttribut();
        expect(getSpys).toHaveBeenCalled();
        expect(component.shape).toBe('Ellipse');
        expect(component.showPolygoneAttribute).toEqual(false);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('showRectangleAttibut should change tool', () => {
        const changeSpy = spyOn(toolSelect, 'changeTool').and.callThrough();
        const getSpys = spyOn(toolSelect, 'getToolBykey').and.callThrough();
        component.ShowPolygoneAtt();
        expect(getSpys).toHaveBeenCalled();
        expect(component.shape).toBe('Polygone');
        expect(component.showPolygoneAttribute).toEqual(true);
        expect(changeSpy).toHaveBeenCalled();
    });

    it('should change polygone sides', () => {
        component.getSides(20);
        expect(poly.sides).toEqual(20);
    });

    it('should return width from sidebar service', () => {
        const expected = sideBareStub.widthShape;
        expect(component.returnShapeBrush()).toEqual(expected);
    });

    it('onkeydown should call ShowPolygoneAtt when 3 is hit on keyboard', () => {
        const spy = spyOn(component, 'ShowPolygoneAtt').and.callThrough();
        const event = { code: Keyboard.three } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call ShowPolygoneAtt when 1 is hit on keyboard', () => {
        const spy = spyOn(component, 'showRectangleAttibut').and.callThrough();
        const event = { code: Keyboard.one } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call showEllipseAttribut when 2 is hit on keyboard', () => {
        const spy = spyOn(component, 'showEllipseAttribut').and.callThrough();
        const event = { code: Keyboard.two } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).toHaveBeenCalled();
    });

    it('onkeydown should call showEllipseAttribut when 2 is hit on keyboard', () => {
        // tslint:disable-next-line: no-string-literal
        component['shortCutDisabled'] = true;
        const spy = spyOn(component, 'showEllipseAttribut').and.callThrough();
        const event = { code: Keyboard.two } as KeyboardEvent;
        component.onkeydown(event);
        expect(spy).not.toHaveBeenCalled();
    });

    it('susbscribe should give the valeur from the service', () => {
        // tslint:disable: no-string-literal
        component['shortcutManagerService'].disableShortcut();
        component['shortcutManagerService'].shortcutObs$.subscribe((disable) => {
            expect(disable).toEqual(true);
        });
    });
});
