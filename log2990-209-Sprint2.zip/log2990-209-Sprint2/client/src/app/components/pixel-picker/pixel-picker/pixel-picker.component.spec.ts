import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { PixelData } from '@app/classes/pixel-data';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { of, Subject } from 'rxjs';
import { PixelPickerComponent } from './pixel-picker.component';

// tslint:disable: no-string-literal
// tslint:disable: no-any
describe('PixelPickerComponent', () => {
    let pixelPickerSpy: PickerService;
    let component: PixelPickerComponent;
    let fixture: ComponentFixture<PixelPickerComponent>;
    let displaySubject: Subject<boolean>;

    beforeEach(async(() => {
        displaySubject = new Subject<boolean>();
        pixelPickerSpy = new PickerService({} as ColorSelectorService, {} as DrawingService);

        pixelPickerSpy['display'] = displaySubject;
        pixelPickerSpy.displayObs$ = of(false);
        TestBed.configureTestingModule({
            declarations: [PixelPickerComponent],
            providers: [{ provide: PickerService, useValeur: pixelPickerSpy }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PixelPickerComponent);
        component = fixture.componentInstance;
        component.canvas = { nativeElement: canvasTestHelper.canvas };
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should not draw if display is false', () => {
        const spy = spyOn<any>(component['context'], 'clearRect').and.callThrough();
        component.ngAfterViewInit();
        expect(spy).not.toHaveBeenCalled();
        component['pickerService']['display'].next(false);
    });

    it('#draw should draw element in the canvas if imageData element change', () => {
        const drawImage = spyOn<any>(component, 'drawImage').and.callFake(() => {
            return;
        });
        component.draw();
        const imgData = new ImageData(2, 2);
        const point: Vec2 = { x: 2, y: 2 };
        component['pickerService']['imageDataSource'].next({ centerPoint: point, imageData: imgData } as PixelData);
        expect(drawImage).toHaveBeenCalled();
    });

    it('should change strokeStyle to white', () => {
        component['pickerService']['color'].next('#000000');
        const result = component['getStrokeStyle']();
        const expectedResultat = 'white';

        expect(result).toBe(expectedResultat);
    });

    it('should change strokeStyle to black', () => {
        component['pickerService']['color'].next('#FFFFFF');
        const result = component['getStrokeStyle']();
        const expectedResultat = 'black';

        expect(result).toBe(expectedResultat);
    });

    it('#drawImage should ', async () => {
        const imgData = new ImageData(2, 2);
        const spy = spyOn<any>(component['context'], 'setLineDash').and.callThrough();
        await component['drawImage'](imgData);
        expect(spy).toHaveBeenCalled();
    });

    it('displayClearRect should call clearRect the context', () => {
        const spy = spyOn<any>(component['context'], 'clearRect').and.callThrough();
        component['displayClear'](false);
        expect(spy).toHaveBeenCalled();
    });

    it('displayClearRect should call clearRect the context', () => {
        const spy = spyOn<any>(component['context'], 'clearRect').and.callThrough();
        component['displayClear'](true);
        expect(spy).not.toHaveBeenCalled();
    });
});
