import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatChipInputEvent, MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { ModalSpinComponent } from '@app/components/modal-spin/modal-spin.component';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { Drawing } from '@common/communication/drawing';
import { Tag } from '@common/communication/tag';
import { of } from 'rxjs';
import { GalleryComponent } from './gallery.component';
// tslint:disable: no-any
// tslint:disable: no-string-literal
// tslint:disable: no-magic-numbers

describe('GalleryComponent', () => {
    let component: GalleryComponent;
    let fixture: ComponentFixture<GalleryComponent>;
    let matrefSpy: jasmine.SpyObj<MatDialog>;
    let spinnerDialogRef: jasmine.SpyObj<MatDialogRef<ModalSpinComponent>>;
    let saveDrawingServiceStub: jasmine.SpyObj<SaveDrawingService>;
    let drawingServiceStub: DrawingService;
    beforeEach(async(() => {
        matrefSpy = jasmine.createSpyObj('MatDialog', ['open']);
        spinnerDialogRef = jasmine.createSpyObj('MatDialogRef', ['close']);
        saveDrawingServiceStub = jasmine.createSpyObj('saveDrawingService', ['getAllImages', 'deleteData']);
        drawingServiceStub = new DrawingService();
        const canvasStub: HTMLCanvasElement = document.createElement('canvas');
        const ctxStub = canvasStub.getContext('2d') as CanvasRenderingContext2D;
        canvasStub.width = 40;
        canvasStub.height = 40;
        drawingServiceStub.canvas = canvasStub;
        drawingServiceStub.baseCtx = ctxStub;

        TestBed.configureTestingModule({
            declarations: [GalleryComponent],
            imports: [MatIconModule, MatChipsModule, MatDialogModule, MatFormFieldModule, BrowserAnimationsModule],
            providers: [
                { provide: SaveDrawingService, useValue: saveDrawingServiceStub },
                { provide: MatDialog, useValue: matrefSpy },
                { provide: DrawingService, useValue: drawingServiceStub },
                { provide: MatDialogRef, useValue: spinnerDialogRef },
                { provide: Router, useValue: {} },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GalleryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should call add() and expect event value to be added to tags array', () => {
        const spy = spyOn(component.tags, 'push');
        const htmlinput = document.createElement('input');
        const event = { value: '123', input: htmlinput } as MatChipInputEvent;
        component.add(event);
        expect(spy).toHaveBeenCalled();
        expect(event.input.value).toBe('');
    });
    it('event shoud call add() and expect event value lenght to be < than 3', () => {
        const event = { value: '12' } as MatChipInputEvent;
        component.add(event);
        expect(event.value.length).toBeLessThan(component.minLenghtTag);
    });
    it(' should call remove(tag) and  splice tag from the tags array', () => {
        let tagStub: Tag;
        tagStub = { name: 'something' };
        component.tags.push(tagStub);
        const spyIndexOf = spyOn(component.tags, 'indexOf').and.returnValue(2);
        const spySplice = spyOn(component.tags, 'splice');
        component.remove(tagStub);
        expect(spyIndexOf).toHaveBeenCalled();
        expect(spySplice).toHaveBeenCalled();
    });
    it(' should call remove() and expect the tags array length to be equal 1', () => {
        let tagStub: Tag;
        tagStub = { name: 'something' };
        component.tags.push(tagStub);
        spyOn(component.tags, 'indexOf').and.returnValue(-1);
        component.remove(tagStub);
        expect(component.tags.length).toEqual(1);
    });
    it(' should call search() and expect  andresetIterators() to have been called ', () => {
        let drawingDataStub: Drawing[];
        drawingDataStub = [{ name: 'drawingName', tags: [''] }];
        spyOn(component, 'filter').and.returnValue(drawingDataStub);
        const spyResetIterators = spyOn(component, 'resetIterators');
        component.search();
        expect(spyResetIterators).toHaveBeenCalled();
    });
    it(' should call filter() and expect updateIterators() to have been called', () => {
        const index = 0;
        let drawingDataStub: Drawing[];
        let tagStub: Tag[];
        drawingDataStub = [{ name: 'drawingName', tags: [''] }];
        tagStub = [{ name: 'someName' }];
        component.imageData = drawingDataStub;
        component.tags = tagStub;
        spyOn(component.imageData[index].tags, 'indexOf').and.returnValue(0);
        const spyUpdateIterators = spyOn(component, 'updateIterators');
        component.filter();
        expect(spyUpdateIterators).toHaveBeenCalled();
    });
    it(' should call refresh() and expect getAllImage() to have been called ', () => {
        const spyRefresh = spyOn(component, 'getAllImage');
        component.refresh();
        expect(spyRefresh).toHaveBeenCalled();
    });
    it(' should call scrollRight()and make nextImage increment', () => {
        component.nextImage = -2;
        component.scrollRight();
        expect(component.nextImage).toEqual(-1);
    });
    it('should call  scrollRight() and and have nextImage equal 0', () => {
        component.nextImage = -1;
        component.scrollRight();
        expect(component.nextImage).toEqual(0);
    });
    it(' should call scrollLeft() and make perImage decrement ', () => {
        component.prevImage = 1;
        component.scrollLeft();
        expect(component.prevImage).toEqual(0);
    });
    it(' should call scrollLeft() and make perImage equal to -1 ', () => {
        component.prevImage = 0;
        component.scrollLeft();
        expect(component.prevImage).toEqual(-1);
    });
    it(' should call updateIterators() and make nextImage=1 and prevImage=0 ', () => {
        component.nextImage = 0;
        component.prevImage = 0;
        component.updateIterators();
        expect(component.nextImage).toEqual(1);
        expect(component.prevImage).toEqual(0);
    });
    it(' should call getAllImage() and return data of all images and unpdate iterators ', (done) => {
        const spyResetIterators = spyOn(component, 'resetIterators');
        saveDrawingServiceStub.getAllImages.and.returnValue(of([]));
        component.getAllImage();
        expect(spyResetIterators).toHaveBeenCalled();
        done();
    });
    it(' should call resetIterators() and make nextImage=1 imageCenter=0 and prevImage=someNumber-1 ', () => {
        const someNumber = 1;
        component.resetIterators(someNumber);
        expect(component.prevImage).toEqual(0);
        expect(component.nextImage).toEqual(1);
        expect(component.imageCenter).toEqual(0);
    });

    it(' keyboardNavigation() should call scrollLeft() when pressing on left arrow ', () => {
        const spyKeyboardNavigation = spyOn(component, 'scrollLeft');
        const event = { code: Keyboard.leftArrow } as KeyboardEvent;
        component.keyboardNavigation(event);
        expect(spyKeyboardNavigation).toHaveBeenCalled();
    });
    it(' keyboardNavigation() should call scrollRight() when pressing on right arrow ', () => {
        const spyKeyboardNavigation = spyOn(component, 'scrollRight');
        const event = { code: Keyboard.rightArrow } as KeyboardEvent;
        component.keyboardNavigation(event);
        expect(spyKeyboardNavigation).toHaveBeenCalled();
    });
    it(' enableShortcuts() should call enableShortcut()', () => {
        const spyEnableShortcut = spyOn(component['shortcutManagerService'], 'enableShortcut');
        component.enableShortcuts();
        expect(spyEnableShortcut).toHaveBeenCalled();
    });
});
