import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, HostListener } from '@angular/core';
import { MatChipInputEvent } from '@angular/material/chips/chip-input';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { LoadedImage } from '@app/classes/loaded-image';
import { ModalSpinComponent } from '@app/components/modal-spin/modal-spin.component';
import { GALLERY_LOADING_TIME } from '@app/constantes/constants';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { SaveDrawingService } from '@app/services/save-drawing/save-drawing.service';
import { ShortcutManagerService } from '@app/services/shortcut-manager.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Drawing } from '@common/communication/drawing';
import { Tag } from '@common/communication/tag';
@Component({
    selector: 'app-gallery',
    templateUrl: './gallery.component.html',
    styleUrls: ['./gallery.component.scss'],
})
export class GalleryComponent {
    imageCenter: number = 0;
    prevImage: number = 0;
    nextImage: number = 0;
    imageData: Drawing[] = [];
    selectable: boolean = true;
    removable: boolean = true;
    addOnBlur: boolean = true;
    minLenghtTag: number = 3;
    notFound: number = -1;
    readonly separatorKeysCodes: number[] = [ENTER, COMMA];
    tags: Tag[] = [];

    constructor(
        private saveDraw: SaveDrawingService,
        private spinnerDialogRef: MatDialogRef<ModalSpinComponent>,
        private spinnerDialog: MatDialog,
        private shortcutManagerService: ShortcutManagerService,
        private drawingService: DrawingService,
        private router: Router,
        private undoRedoService: UndoRedoService,
    ) {
        this.spinnerDialogRef = this.spinnerDialog.open(ModalSpinComponent, { disableClose: true });
        setTimeout(() => {
            this.spinnerDialogRef.close();
            this.getAllImage();
        }, GALLERY_LOADING_TIME);
    }

    add(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;

        if (value.length >= this.minLenghtTag) {
            this.tags.push({ name: value.trim() });
        }
        // Reset the input value
        if (input) {
            input.value = '';
        }
    }

    remove(tags: Tag): void {
        const index = this.tags.indexOf(tags);
        if (index >= 0) {
            this.tags.splice(index, 1);
        }
    }

    search(): void {
        this.imageData = this.filter();
        this.resetIterators(this.imageData.length);
    }

    filter(): Drawing[] {
        const temp: Drawing[] = [];
        for (const draw of this.imageData) {
            for (const tag of this.tags) {
                if (draw.tags.indexOf(tag.name) > this.notFound) {
                    if (temp.indexOf(draw) === this.notFound) {
                        temp.push(draw);
                        this.updateIterators();
                        break;
                    }
                }
            }
        }
        return temp;
    }

    refresh(): void {
        this.getAllImage();
    }

    scrollRight(): void {
        this.prevImage = this.imageCenter;
        this.imageCenter = this.nextImage;
        if (this.nextImage >= this.imageData.length - 1) {
            this.nextImage = 0;
        } else {
            this.nextImage++;
        }
    }

    scrollLeft(): void {
        this.nextImage = this.imageCenter;
        this.imageCenter = this.prevImage;
        if (this.prevImage === 0) {
            this.prevImage = this.imageData.length - 1;
        } else {
            this.prevImage--;
        }
    }

    updateIterators(): void {
        if (this.nextImage >= this.imageData.length - 1) {
            this.nextImage = 0;
        }
        if (this.prevImage >= this.imageData.length - 1) {
            this.prevImage--;
        }
        if (this.imageCenter >= this.imageData.length - 1) {
            this.imageCenter = this.nextImage;
            this.nextImage++;
            this.prevImage++;
        }
    }

    getAllImage(): void {
        this.saveDraw.getAllImages().subscribe((data) => {
            this.imageData = data;
            this.resetIterators(this.imageData.length);
        });
    }

    resetIterators(size: number): void {
        this.prevImage = size - 1;
        this.nextImage = 1;
        this.imageCenter = 0;
    }

    deleteImage(): void {
        this.saveDraw.deleteData(this.imageData[this.imageCenter].id as string).subscribe(() => {
            this.imageData.splice(this.imageCenter, 1);
            this.updateIterators();
        });
    }

    selectImg(): void {
        if (this.router.url === '/home') {
            this.router.navigate(['/editor']);
            this.loadImage();
            return;
        }

        if (!this.undoRedoService.canUndo()) {
            this.loadImage();
            return;
        }
        if (window.confirm('Voulez-vous abandonner vos changements ? ')) {
            this.drawingService.clearCanvas(this.drawingService.baseCtx);
            this.drawingService.setBackground(this.drawingService.baseCtx);
            this.loadImage();
            this.undoRedoService.clearStacks();
        }
    }

    loadImage(): void {
        const image = new Image();
        image.src = this.imageData[this.imageCenter].dataUrl as string;
        this.drawingService.imageIsLoadedFromGallery.next(true);
        image.onload = () => {
            this.drawingService.baseCtx.drawImage(image, 0, 0);
            const img = this.drawingService.getImageData();
            this.undoRedoService.loadedImage.next(new LoadedImage(img));
            this.enableShortcuts();
        };
    }

    @HostListener('window:keydown', ['$event'])
    keyboardNavigation(event: KeyboardEvent): void {
        if (event.code === Keyboard.leftArrow) {
            this.scrollLeft();
        } else if (event.code === Keyboard.rightArrow) {
            this.scrollRight();
        }
    }

    enableShortcuts(): void {
        this.shortcutManagerService.enableShortcut();
    }
}
