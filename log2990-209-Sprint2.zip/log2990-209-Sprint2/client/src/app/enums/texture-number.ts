export enum Texture {
    texture1 = 1,
    texture2 = 2,
    texture3 = 3,
    texture4 = 4,
    texture5 = 5,
}
