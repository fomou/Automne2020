export enum ColorType {
    primary = 'primary',
    secondary = 'secondary',
}
