export enum DrawingType {
    fill = 'fill',
    stroke = 'stroke',
    outline = 'outline',
}
