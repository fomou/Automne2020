import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderModule } from '@angular/material/slider';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './components/app/app.component';
import { ColorPaletteComponent } from './components/color-palette/color-palette/color-palette.component';
import { ColorPanelComponent } from './components/color-panel/color-panel/color-panel.component';
import { ColorPickerComponent } from './components/color-picker/color-picker/color-picker.component';
import { ColorSliderComponent } from './components/color-slider/color-slider/color-slider.component';
import { DrawingToolsComponent } from './components/drawing-tools/drawing-tools.component';
import { DrawingComponent } from './components/drawing/drawing.component';
import { EditorComponent } from './components/editor/editor.component';
import { ExportComponent } from './components/export/export.component';
import { GalleryComponent } from './components/gallery/gallery.component';
import { GuideUtilsateurComponent } from './components/guide-utilsateur/guide-utilsateur.component';
import { MainPageComponent } from './components/main-page/main-page.component';
import { ModalSpinComponent } from './components/modal-spin/modal-spin.component';
import { PixelPickerComponent } from './components/pixel-picker/pixel-picker/pixel-picker.component';
import { SaveDrawingComponent } from './components/save-drawing/save-drawing.component';
import { ShapesComponent } from './components/shapes/shapes.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';

@NgModule({
    declarations: [
        AppComponent,
        EditorComponent,
        SidebarComponent,
        DrawingComponent,
        MainPageComponent,
        ColorPickerComponent,
        ColorSliderComponent,
        ColorPaletteComponent,
        ColorPanelComponent,
        GuideUtilsateurComponent,
        GuideUtilsateurComponent,
        PixelPickerComponent,
        GalleryComponent,
        ExportComponent,
        SaveDrawingComponent,
        ShapesComponent,
        DrawingToolsComponent,
        ModalSpinComponent,
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        MatSliderModule,
        MatDialogModule,
        FormsModule,
        ReactiveFormsModule,
        MatSlideToggleModule,
        MatTooltipModule,
        MatDialogModule,
        MatButtonModule,
        MatIconModule,
        MatFormFieldModule,
        MatButtonModule,
        MatSelectModule,
        MatRadioModule,
        MatInputModule,
        MatChipsModule,
        MatCardModule,
        MatTabsModule,
    ],

    bootstrap: [AppComponent],
    providers: [],
})
export class AppModule {}
