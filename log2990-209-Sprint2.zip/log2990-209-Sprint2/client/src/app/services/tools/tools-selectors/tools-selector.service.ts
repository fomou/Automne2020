import { Injectable } from '@angular/core';
import { Tool } from '@app/classes/tool';
import { Keyboard } from '@app/enums/key-board';
import { BrushService } from '@app/services/tools/brush/brush.service';
import { EllipseService } from '@app/services/tools/ellipse/ellipse.service';
import { EraseService } from '@app/services/tools/erase/eraser.service';
import { LineService } from '@app/services/tools/line/line.service';
import { PaintBucketService } from '@app/services/tools/paint-bucket/paint-bucket.service';
import { PencilService } from '@app/services/tools/pencil/pencil-service';
import { PickerService } from '@app/services/tools/picker/picker.service';
import { PolygoneService } from '@app/services/tools/polygone/polygone.service';
import { RectangleService } from '@app/services/tools/rectangle/rectangle.service';
import { SelectionEllipseService } from '@app/services/tools/selection-ellipse/selection-ellipse.service';
import { SelectionRectangleService } from '@app/services/tools/selection-rectangle/selection-rectangle.service';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ToolsSelectorService {
    toolSource: BehaviorSubject<Tool>;
    toolsMap: Map<string, Tool> = new Map<string, Tool>();
    tool$: Observable<Tool>;

    constructor(
        pencilService: PencilService,
        rectangleService: RectangleService,
        ellipseService: EllipseService,
        lineService: LineService,
        eraseService: EraseService,
        brushervice: BrushService,
        polygoneService: PolygoneService,
        picker: PickerService,
        paintBucket: PaintBucketService,
        selectionRectangleService: SelectionRectangleService,
        selectionEllipseService: SelectionEllipseService,
    ) {
        this.toolsMap.set(Keyboard.one, rectangleService);
        this.toolsMap.set(Keyboard.two, ellipseService);
        this.toolsMap.set(Keyboard.three, polygoneService);
        this.toolsMap.set(Keyboard.l, lineService);
        this.toolsMap.set(Keyboard.c, pencilService);
        this.toolsMap.set(Keyboard.e, eraseService);
        this.toolsMap.set(Keyboard.w, brushervice);
        this.toolsMap.set(Keyboard.i, picker);
        this.toolsMap.set(Keyboard.b, paintBucket);
        this.toolsMap.set(Keyboard.r, selectionRectangleService);
        this.toolsMap.set(Keyboard.f, selectionEllipseService);

        this.toolSource = new BehaviorSubject<Tool>(pencilService);
        this.tool$ = this.toolSource.asObservable();
    }
    changeTool(tool: Tool): void {
        this.toolSource.next(tool);
    }

    getToolBykey(key: string): Tool {
        return this.toolsMap.get(key) as Tool;
    }
}
