import { TestBed } from '@angular/core/testing';
import { Tool } from '@app/classes/tool';
import { NB_TOOLS } from '@app/constantes/constants';
import { Keyboard } from '@app/enums/key-board';
import { ToolsSelectorService } from './tools-selector.service';

describe('ToolsSelectorService', () => {
    let service: ToolsSelectorService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(ToolsSelectorService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should fill the map', () => {
        expect(service.toolsMap.size).toEqual(NB_TOOLS);
    });

    it('should change tool', () => {
        const tool = {} as Tool;

        service.changeTool(tool);

        expect(service.toolSource.getValue()).toEqual(tool);
    });

    it('should give tool associated to a key ', () => {
        const event = { code: Keyboard.c } as KeyboardEvent;
        const tool = service.getToolBykey(event.code);

        expect(tool).toBeDefined();
    });
});
