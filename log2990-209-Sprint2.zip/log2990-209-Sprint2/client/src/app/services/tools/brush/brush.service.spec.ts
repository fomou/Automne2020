import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { BrushService } from '@app/services/tools/brush/brush.service';

// tslint:disable: no-any
// tslint:disable:no-string-literal
// tslint:disable:no-magic-numbers
describe('BrushService', () => {
    let service: BrushService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;
    let drawImageSpy: jasmine.Spy<any>;
    let changeTextureSpy: jasmine.Spy<any>;
    let clearPathSpy: jasmine.Spy<any>;
    let drawServiceSpy: jasmine.SpyObj<DrawingService>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({ providers: [{ provide: DrawingService, useValue: drawServiceSpy }] });
        service = TestBed.inject(BrushService);

        drawImageSpy = spyOn<any>(service, 'drawImage').and.callThrough();
        changeTextureSpy = spyOn<any>(service, 'changeTexture').and.callThrough();
        clearPathSpy = spyOn<any>(service, 'clearPath').and.callThrough();

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('onMouseDown with right click should do nothing ', () => {
        const vecPathData1: Vec2 = { x: 10, y: 10 };
        const vecPathData2: Vec2 = { x: 15, y: 15 };
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            button: 1, // click droit
        } as MouseEvent;
        service['pathData'] = [vecPathData1, vecPathData2];
        service.onMouseDown(mouseEvent);
        expect(drawImageSpy).not.toHaveBeenCalled();
    });

    // Test onMouseUp
    it('onMouseUp should set mouseDown to false', () => {
        service['mouseDown'] = true;
        service.onMouseUp(mouseEvent);
        expect(service['mouseDown']).toEqual(false);
    });
    it('onMouseUp should set mouseDown to false', () => {
        service.onMouseUp(mouseEvent);
        service['mouseDown'] = false;
        expect(service['mouseDown']).toEqual(false);
    });

    // // Test onMouseMove
    // it('onMouseMove should draw the texture', () => {
    //     const vecPathData1: Vec2 = { x: 10, y: 10 };
    //     const vecPathData2: Vec2 = { x: 15, y: 15 };
    //     service['pathData'] = [vecPathData1, vecPathData2];
    //     service['mouseDown'] = true;
    //     service.onMouseMove(mouseEvent);
    //     expect(changeTextureSpy).toHaveBeenCalled();
    // });

    it('onMouseMove should not draw the texture if mouseDown is false', () => {
        service['mouseDown'] = false;
        service.onMouseMove(mouseEvent);
        expect(changeTextureSpy).not.toHaveBeenCalled();
    });

    // Test onMouseLeave
    it('onMouseLeave should set mouseDown to false', () => {
        const vecPathData1: Vec2 = { x: 10, y: 10 };
        const vecPathData2: Vec2 = { x: 15, y: 15 };
        service['pathData'] = [vecPathData1, vecPathData2];
        service['mouseDown'] = true;
        service.onMouseLeave(mouseEvent);
        expect(clearPathSpy).toHaveBeenCalled();
        expect(service['mouseDown']).toEqual(false);
    });

    // Test onMouseEnter
    it(' onMouseEnter should put mouseDown to true if event event.buttons==1', () => {
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            buttons: 1,
        } as MouseEvent;
        service.mouseDown = false;
        service.onMouseEnter(mouseEvent);
        expect(service.mouseDown).toEqual(true);
    });
    it(' onMouseEnter should not put mouseDown to true if event event.buttons!=1', () => {
        mouseEvent = {
            offsetX: 25,
            offsetY: 25,
            buttons: 0,
        } as MouseEvent;
        service.mouseDown = false;
        service.onMouseEnter(mouseEvent);
        expect(service.mouseDown).toEqual(false);
    });

    // Tests Textures
    it('initialiserTexture with texture 1', () => {
        service['sidebarService'].textureNum = 1;
        service['initialiserTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/snow.svg');
    });
    it('initialiserTexture with texture 2', () => {
        service['sidebarService'].textureNum = 2;
        service['initialiserTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/star.svg');
    });
    it('initialiserTexture with texture 3', () => {
        service['sidebarService'].textureNum = 3;
        service['initialiserTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/boxes.svg');
    });
    it('initialiserTexture with texture 4', () => {
        service['sidebarService'].textureNum = 4;
        service['initialiserTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/arrow-left.svg');
    });
    it('initialiserTexture with texture 5', () => {
        service['sidebarService'].textureNum = 5;
        service['initialiserTexture'](previewCtxStub);
        expect(service['img'].src).toEqual('http://localhost:9876/assets/circle.svg');
    });
});
