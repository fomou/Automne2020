import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { PickerService } from './picker.service';

// tslint:disable: no-any
// tslint:disable: no-string-literal
describe('PickerService', () => {
    let service: PickerService;

    let baseCtxStub: CanvasRenderingContext2D;
    let getPositionSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        TestBed.configureTestingModule({});
        service = TestBed.inject(PickerService);
        getPositionSpy = spyOn<any>(service, 'getPositionFromMouse').and.callThrough();
        service.drawingService.canvas = canvasTestHelper.canvas;
        service.drawingService.baseCtx = baseCtxStub;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('onMouseMove should call getPositionFromMouse, getImageData and next', () => {
        const nextSpy = spyOn<any>(service['imageDataSource'], 'next').and.callThrough();
        const getImgDataSpy = spyOn<any>(service, 'getImageDatatAtPosition').and.callThrough();
        const event = { pageX: 500, offsetX: 0, offsetY: 0, pageY: 25 } as MouseEvent;

        service.onMouseMove(event);
        expect(getPositionSpy).toHaveBeenCalled();
        expect(getImgDataSpy).toHaveBeenCalled();
        expect(nextSpy).toHaveBeenCalled();
    });

    it('onMouseMove should do nothing if the mouse is out of bound', () => {
        const nextSpy = spyOn<any>(service['imageDataSource'], 'next').and.callThrough();
        const getImgDataSpy = spyOn<any>(service, 'getImageDatatAtPosition').and.callThrough();
        const event = { pageX: 250, offsetY: 25 } as MouseEvent;

        service.onMouseMove(event);
        expect(getPositionSpy).not.toHaveBeenCalled();
        expect(getImgDataSpy).not.toHaveBeenCalled();
        expect(nextSpy).not.toHaveBeenCalled();
    });

    it('should set primary color on left click', () => {
        const event = { offsetX: 20, offsetY: 25, button: 0 } as MouseEvent;
        const changeColorSpy = spyOn<any>(service['colorSelectorService'], 'annonceColor').and.callThrough();
        const getColorSpy = spyOn<any>(service, 'getColorAtPosition').and.callThrough();
        service.onMouseDown(event);
        expect(getColorSpy).toHaveBeenCalled();
        expect(changeColorSpy).toHaveBeenCalled();
        expect(service.colorSelectorService.colorType).toBe('primary');
    });
    it('should set secondary color on right click', () => {
        const event = { offsetX: 20, offsetY: 25, button: 2 } as MouseEvent;
        const changeColorSpy = spyOn<any>(service['colorSelectorService'], 'annonceColor').and.callThrough();
        const getColorSpy = spyOn<any>(service, 'getColorAtPosition').and.callThrough();
        service.onMouseDown(event);
        expect(getColorSpy).toHaveBeenCalled();
        expect(changeColorSpy).toHaveBeenCalled();
        expect(service.colorSelectorService.colorType).toBe('secondary');
    });

    it('fiilString sould complete a string with 0', () => {
        const str = 'F';
        const strFilled = service['fillString'](str);
        expect(strFilled).toEqual('0F');
    });

    it('fiilString sould not complete if the lenght is greater than 2', () => {
        const str = 'FF';
        const strFilled = service['fillString'](str);
        expect(strFilled).toEqual('FF');
    });

    it('onMouseLeave should change the display valeur to false', () => {
        const spy = spyOn<any>(service['display'], 'next').and.callThrough();
        service.onMouseLeave();
        expect(spy).toHaveBeenCalledWith(false);
    });

    it('onMouseEnter should change the display value to true', () => {
        const spy = spyOn<any>(service['display'], 'next').and.callThrough();
        service.onMouseEnter();
        expect(spy).toHaveBeenCalledWith(true);
    });

    it('should do nothing on another mouse click', () => {
        const event = { offsetX: 20, offsetY: 25, button: 3 } as MouseEvent;
        const changeColorSpy = spyOn<any>(service['colorSelectorService'], 'annonceColor').and.callThrough();
        const getColorSpy = spyOn<any>(service, 'getColorAtPosition').and.callThrough();
        service.onMouseDown(event);
        expect(getColorSpy).toHaveBeenCalled();
        expect(changeColorSpy).not.toHaveBeenCalled();
    });
});
