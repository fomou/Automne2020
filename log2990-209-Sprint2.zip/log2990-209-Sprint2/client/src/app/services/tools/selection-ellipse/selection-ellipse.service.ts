import { Injectable } from '@angular/core';
import { ShapeTool } from '@app/classes/shape-tool';
import { Vec2 } from '@app/classes/vec2';
import { BLUE_COLOR_INDEX, COLORS_PER_POSITION, GREEN_COLOR_INDEX, LINE_DASH, OFFSET_ARROW, OPACITY_INDEX } from '@app/constantes/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';

@Injectable({
    providedIn: 'root',
})
export class SelectionEllipseService extends ShapeTool {
    private circleCenter: Vec2;
    private radiusX: number;
    private radiusY: number;
    imageData: ImageData;
    circleCenterSelection: Vec2;
    topLeftPointSelection: Vec2;
    radiusXSelection: number;
    radiusYSelection: number;
    widthSelection: number;
    heightSelection: number;
    isSelected: boolean = false;
    isMoving: boolean = false;

    constructor(drawingService: DrawingService) {
        super(drawingService);
        this.primaryColor = '000000';
        this.secondaryColor = 'FFFFFF';
        this.drawingType = 'stroke';
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            if (!this.isSelected) {
                this.firstPoint = this.getPositionFromMouse(event);
                this.width = 0;
                this.height = 0;
            } else {
                if (!this.isInsideEllipse(event)) {
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.isSelected = false;
                    this.isMoving = false;
                    this.drawingService.baseCtx.putImageData(
                        this.getEllipseImageData(this.circleCenterSelection.x, this.circleCenterSelection.y),
                        this.circleCenterSelection.x,
                        this.circleCenterSelection.y,
                    );
                    this.resetSelectionVariables();
                    this.firstPoint = this.getPositionFromMouse(event);
                    this.width = 0;
                    this.height = 0;
                } else {
                    this.isMoving = true;
                }
            }
        }
    }

    resetSelectionVariables(): void {
        this.circleCenterSelection.x = 0;
        this.circleCenterSelection.y = 0;
        this.topLeftPointSelection.x = 0;
        this.topLeftPointSelection.y = 0;
        this.radiusXSelection = 0;
        this.radiusYSelection = 0;
        this.widthSelection = 0;
        this.heightSelection = 0;
    }
    isInsideEllipse(event: MouseEvent): boolean {
        return (
            Math.pow(this.getPositionFromMouse(event).x - this.circleCenterSelection.x, 2) / Math.pow(this.radiusX, 2) +
                Math.pow(this.getPositionFromMouse(event).y - this.circleCenterSelection.y, 2) / Math.pow(this.radiusY, 2) <=
            1
        );
    }

    isInsideEllipseData(line: number, column: number, circleCenterX: number, circleCenterY: number, radiusX: number, radiusY: number): boolean {
        return Math.pow(line - circleCenterX, 2) / Math.pow(radiusX, 2) + Math.pow(column - circleCenterY, 2) / Math.pow(radiusY, 2) <= 1;
    }
    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown && !this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.topLeftPointSelection = this.findTopLeftPoint(this.firstPoint, this.lastPoint);
            this.circleCenterSelection = this.getCenter(this.firstPoint, this.lastPoint);
            this.radiusXSelection = Math.abs(this.firstPoint.x - this.lastPoint.x) / 2;
            this.radiusYSelection = Math.abs(this.firstPoint.y - this.lastPoint.y) / 2;
            this.widthSelection = Math.abs(this.firstPoint.x - this.lastPoint.x);
            this.heightSelection = Math.abs(this.firstPoint.y - this.lastPoint.y);
            if (this.widthSelection === 0) this.widthSelection = this.widthSelection + 1;
            if (this.heightSelection === 0) this.heightSelection = this.heightSelection + 1;
            if (this.widthSelection > 0 && this.heightSelection > 0) {
                this.imageData = this.drawingService.baseCtx.getImageData(
                    this.topLeftPointSelection.x,
                    this.topLeftPointSelection.y,
                    this.widthSelection,
                    this.heightSelection,
                );
            }
            this.drawSelection(this.drawingService.previewCtx);
            this.isSelected = true;
            this.mouseDown = false;
        } else if (this.mouseDown && this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.mouseDown = false;
            this.circleCenterSelection.x = this.getPositionFromMouse(event).x - this.widthSelection / 2;
            this.circleCenterSelection.y = this.getPositionFromMouse(event).y - this.heightSelection / 2;
            this.drawingService.previewCtx.putImageData(
                this.getEllipseImageData(this.circleCenterSelection.x, this.circleCenterSelection.y),
                this.circleCenterSelection.x,
                this.circleCenterSelection.y,
            );
        }
    }

    drawWhiteEllipse(): void {
        this.drawingService.baseCtx.beginPath();
        this.drawingService.baseCtx.fillStyle = 'white';
        this.drawingService.baseCtx.ellipse(
            this.circleCenter.x,
            this.circleCenter.y,
            this.radiusXSelection,
            this.radiusYSelection,
            0,
            0,
            Math.PI * 2,
        );
        this.drawingService.baseCtx.fill();
        this.drawingService.baseCtx.closePath();
    }
    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown && !this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawSelection(this.drawingService.previewCtx);
        } else if (this.mouseDown && this.isMoving) {
            this.drawWhiteEllipse();
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            const mousePosX: number = this.getPositionFromMouse(event).x - this.widthSelection / 2;
            const mousePosY: number = this.getPositionFromMouse(event).y - this.heightSelection / 2;
            this.drawingService.previewCtx.putImageData(this.getEllipseImageData(mousePosX, mousePosY), mousePosX, mousePosY);
        }
    }

    getEllipseImageData(mousePosx: number, mousePosy: number): ImageData {
        let row: number;
        let column: number;
        const baseImageData: ImageData = this.drawingService.baseCtx.getImageData(mousePosx, mousePosy, this.widthSelection, this.heightSelection);
        for (row = 0; row < this.widthSelection; row++) {
            for (column = 0; column < this.heightSelection; column++) {
                if (
                    !this.isInsideEllipseData(
                        row,
                        column,
                        this.widthSelection / 2,
                        this.heightSelection / 2,
                        this.widthSelection / 2,
                        this.heightSelection / 2,
                    )
                ) {
                    const index: number = (column * this.widthSelection + row) * COLORS_PER_POSITION;
                    this.imageData.data[index] = baseImageData.data[index];
                    this.imageData.data[index + GREEN_COLOR_INDEX] = baseImageData.data[index + GREEN_COLOR_INDEX];
                    this.imageData.data[index + BLUE_COLOR_INDEX] = baseImageData.data[index + BLUE_COLOR_INDEX];
                    this.imageData.data[index + OPACITY_INDEX] = baseImageData.data[index + OPACITY_INDEX];
                }
            }
        }
        return this.imageData;
    }

    onKeyDown(event: KeyboardEvent): void {
        if (event.key === 'Shift') {
            this.shiftPressed = true;
        }
        if (event.key === 'Escape' && this.isSelected) {
            this.isSelected = false;
            this.isMoving = false;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawingService.baseCtx.putImageData(
                this.getEllipseImageData(this.circleCenterSelection.x, this.circleCenterSelection.y),
                this.circleCenterSelection.x,
                this.circleCenterSelection.y,
            );
            this.resetSelectionVariables();
        }
        if (this.isSelected) {
            switch (event.key) {
                case 'ArrowLeft': {
                    this.drawWhiteEllipse();
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.circleCenterSelection.x = this.circleCenterSelection.x - OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(
                        this.getEllipseImageData(this.circleCenterSelection.x, this.circleCenterSelection.y),
                        this.circleCenterSelection.x,
                        this.circleCenterSelection.y,
                    );
                    break;
                }
                case 'ArrowRight': {
                    this.drawWhiteEllipse();
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.circleCenterSelection.x = this.circleCenterSelection.x + OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(
                        this.getEllipseImageData(this.circleCenterSelection.x, this.circleCenterSelection.y),
                        this.circleCenterSelection.x,
                        this.circleCenterSelection.y,
                    );
                    break;
                }
                case 'ArrowUp': {
                    this.drawWhiteEllipse();
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.circleCenterSelection.y = this.circleCenterSelection.y - OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(
                        this.getEllipseImageData(this.circleCenterSelection.x, this.circleCenterSelection.y),
                        this.circleCenterSelection.x,
                        this.circleCenterSelection.y,
                    );
                    break;
                }
                case 'ArrowDown': {
                    this.drawWhiteEllipse();
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.circleCenterSelection.y = this.circleCenterSelection.y + OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(
                        this.getEllipseImageData(this.circleCenterSelection.x, this.circleCenterSelection.y),
                        this.circleCenterSelection.x,
                        this.circleCenterSelection.y,
                    );
                    break;
                }
            }
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        if (event.key === 'Shift') {
            this.shiftPressed = false;
        }
    }

    drawSelection(ctx: CanvasRenderingContext2D): void {
        this.circleCenter = this.getCenter(this.firstPoint, this.lastPoint);
        this.radiusX = Math.abs(this.firstPoint.x - this.lastPoint.x) / 2;
        this.radiusY = Math.abs(this.firstPoint.y - this.lastPoint.y) / 2;

        if (this.shiftPressed) {
            const shiftLastPoint = this.findShiftPoint(this.firstPoint, this.lastPoint);
            this.circleCenter = this.getCenter(this.firstPoint, shiftLastPoint);
            this.radiusX = Math.abs(this.firstPoint.x - shiftLastPoint.x) / 2;
            this.radiusY = Math.abs(this.firstPoint.y - shiftLastPoint.y) / 2;
        }

        ctx.beginPath();
        ctx.setLineDash([LINE_DASH, LINE_DASH]);
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'blue';
        ctx.ellipse(this.circleCenter.x, this.circleCenter.y, this.radiusX, this.radiusY, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.closePath();
    }
}
