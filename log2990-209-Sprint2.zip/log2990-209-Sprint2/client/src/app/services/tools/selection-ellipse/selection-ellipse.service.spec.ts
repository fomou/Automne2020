import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { DrawingService } from '@app/services/drawing/drawing.service';

import { SelectionEllipseService } from './selection-ellipse.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('SelectionEllipseService', () => {
    let service: SelectionEllipseService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let drawSelectionSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(SelectionEllipseService);

        drawSelectionSpy = spyOn<any>(service, 'drawSelection').and.callThrough();
        service.drawingService.baseCtx = baseCtxStub;
        service.drawingService.previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('onMouseDown should set mouseDown true', () => {
        service.isSelected = false;
        service.height = 30;

        spyOn(service, 'getPositionFromMouse').and.returnValue({ x: 25, y: 25 });
        service.onMouseDown(mouseEvent);

        expect(service.height).toEqual(0);
        expect(service.mouseDown).toEqual(true);
    });

    it('onMouseDown in the selection', () => {
        service.mouseDown = true;
        service.isSelected = true;
        service.height = 30;
        service.widthSelection = 30;
        service.heightSelection = 30;

        service.circleCenterSelection = { x: 25, y: 25 };
        service.topLeftPointSelection = { x: 25, y: 25 };
        service.imageData = new ImageData(100, 100);

        spyOn(service, 'getEllipseImageData').and.returnValue(new ImageData(100, 100));
        spyOn(service, 'isInsideEllipse').and.returnValue(false);
        spyOn(service.drawingService.baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));
        service.onMouseDown(mouseEvent);

        expect(service.height).toEqual(0);
    });

    it('onMouseDown outside the selection should put isMoving true ', () => {
        service.mouseDown = false;
        service.isSelected = true;
        service.isMoving = false;

        spyOn(service, 'isInsideEllipse').and.returnValue(true);

        service.onMouseDown(mouseEvent);

        expect(service.isMoving).toEqual(true);
    });

    it('resetSelectionVariables should set to 0 all value ', () => {
        service.circleCenterSelection = { x: 25, y: 25 };
        service.topLeftPointSelection = { x: 25, y: 25 };
        service.radiusXSelection = 25;
        service.widthSelection = 25;

        service.resetSelectionVariables();

        expect(service.radiusXSelection).toEqual(0);
        expect(service.widthSelection).toEqual(0);
    });

    it('isInsideEllipse true ', () => {
        service.circleCenterSelection = { x: 25, y: 25 };
        service['radiusX'] = 50;
        service['radiusY'] = 50;

        spyOn(service, 'getPositionFromMouse').and.returnValue({ x: 25, y: 25 });

        const expectBool = service.isInsideEllipse(mouseEvent);
        expect(expectBool).toEqual(true);
    });

    it('onMouseUp with no selection', () => {
        service.mouseDown = true;
        service.isMoving = false;
        service.firstPoint = { x: 25, y: 25 };
        service.circleCenterSelection = { x: 25, y: 25 };
        service.topLeftPointSelection = { x: 25, y: 25 };

        service.width = 30;
        service.height = 30;

        spyOn(service, 'getPositionFromMouse').and.returnValue({ x: 25, y: 25 });

        service.onMouseUp(mouseEvent);

        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseUp with a selection', () => {
        service.mouseDown = true;
        service.isMoving = true;
        service.firstPoint = { x: 25, y: 25 };
        service.circleCenterSelection = { x: 25, y: 25 };
        service.topLeftPointSelection = { x: 25, y: 25 };
        service.imageData = new ImageData(100, 100);

        service.widthSelection = 30;
        service.heightSelection = 30;

        service.onMouseUp(mouseEvent);

        expect(service.mouseDown).toEqual(false);
    });

    it('drawWhiteEllipse should put the color to white', () => {
        service['circleCenter'] = { x: 25, y: 25 };
        service['radiusXSelection'] = 25;
        service['radiusYSelection'] = 25;
        service['drawingService'].baseCtx.fillStyle = 'blue';
        service.widthSelection = 30;
        service.heightSelection = 30;

        service.drawWhiteEllipse();

        expect(service['drawingService'].baseCtx.fillStyle).toEqual('#ffffff');
    });

    it('onMouseMove with no selection', () => {
        service.mouseDown = true;
        service.isMoving = false;
        service.shiftPressed = true;
        service.firstPoint = { x: 25, y: 25 };

        service.onMouseMove(mouseEvent);

        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseMove with a selection', () => {
        service.mouseDown = true;
        service.isMoving = true;
        service.firstPoint = { x: 25, y: 25 };
        service.imageData = new ImageData(100, 100);
        service['circleCenter'] = { x: 25, y: 25 };
        service['radiusXSelection'] = 25;
        service['radiusYSelection'] = 25;
        service.widthSelection = 30;
        service.heightSelection = 30;

        service.onMouseMove(mouseEvent);

        expect(drawSelectionSpy).not.toHaveBeenCalled();
    });

    it('onKeyDown with shift should put shiftPressed true', () => {
        const keyboardEvent = { key: 'Shift' } as KeyboardEvent;
        service.shiftPressed = false;

        service.onKeyDown(keyboardEvent);

        expect(service.shiftPressed).toEqual(true);
    });

    it('onKeyDown should not set shiftPressed if shift was not the event key', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service.shiftPressed = false;

        service.onKeyUp(keyboardEvent);

        expect(service.shiftPressed).toEqual(false);
    });

    it('onKeyDown with Escape should call resestSeletionVariables', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service.shiftPressed = false;
        service.isSelected = true;
        service.isMoving = true;
        service.imageData = new ImageData(100, 100);
        service.circleCenterSelection = { x: 25, y: 25 };
        service.topLeftPointSelection = { x: 25, y: 25 };
        spyOn(service.drawingService.baseCtx, 'getImageData').and.returnValue(new ImageData(100, 100));

        service.onKeyDown(keyboardEvent);

        expect(service.isSelected).toEqual(false);
        expect(service.isMoving).toEqual(false);
    });

    it('onKeyDown with ArrowLeft', () => {
        const keyboardEvent = { key: 'ArrowLeft' } as KeyboardEvent;
        service.isSelected = true;
        service['circleCenter'] = { x: 25, y: 25 };
        service['radiusXSelection'] = 25;
        service['radiusYSelection'] = 25;
        service['drawingService'].baseCtx.fillStyle = 'blue';
        service.widthSelection = 30;
        service.heightSelection = 30;
        service.circleCenterSelection = { x: 30, y: 30 };
        service.imageData = new ImageData(100, 100);

        service.onKeyDown(keyboardEvent);

        expect(service.circleCenterSelection.x).toEqual(27);
    });

    it('onKeyDown with ArrowRight', () => {
        const keyboardEvent = { key: 'ArrowRight' } as KeyboardEvent;
        service.isSelected = true;
        service['circleCenter'] = { x: 25, y: 25 };
        service['radiusXSelection'] = 25;
        service['radiusYSelection'] = 25;
        service['drawingService'].baseCtx.fillStyle = 'blue';
        service.widthSelection = 30;
        service.heightSelection = 30;
        service.circleCenterSelection = { x: 30, y: 30 };
        service.imageData = new ImageData(100, 100);

        service.onKeyDown(keyboardEvent);

        expect(service.circleCenterSelection.x).toEqual(33);
    });

    it('onKeyDown with ArrowUp', () => {
        const keyboardEvent = { key: 'ArrowUp' } as KeyboardEvent;
        service.isSelected = true;
        service['circleCenter'] = { x: 25, y: 25 };
        service['radiusXSelection'] = 25;
        service['radiusYSelection'] = 25;
        service['drawingService'].baseCtx.fillStyle = 'blue';
        service.widthSelection = 30;
        service.heightSelection = 30;
        service.circleCenterSelection = { x: 30, y: 30 };
        service.imageData = new ImageData(100, 100);

        service.onKeyDown(keyboardEvent);

        expect(service.circleCenterSelection.y).toEqual(27);
    });

    it('onKeyDown with ArrowDown', () => {
        const keyboardEvent = { key: 'ArrowDown' } as KeyboardEvent;
        service.isSelected = true;
        service['circleCenter'] = { x: 25, y: 25 };
        service['radiusXSelection'] = 25;
        service['radiusYSelection'] = 25;
        service['drawingService'].baseCtx.fillStyle = 'blue';
        service.widthSelection = 30;
        service.heightSelection = 30;
        service.circleCenterSelection = { x: 30, y: 30 };
        service.imageData = new ImageData(100, 100);

        service.onKeyDown(keyboardEvent);

        expect(service.circleCenterSelection.y).toEqual(33);
    });
});
