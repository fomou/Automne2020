import { Injectable, OnDestroy } from '@angular/core';
import { Ellipse } from '@app/classes/ellipse';
import { ShapeTool } from '@app/classes/shape-tool';
import { Vec2 } from '@app/classes/vec2';
import { DrawingType } from '@app/enums/draw-type';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { DrawingTypeSelectorService } from '@app/services/tools/drawing-type/drawing-type-selector.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { Subscription } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class EllipseService extends ShapeTool implements OnDestroy {
    subscription: Subscription;
    private circleCenter: Vec2;
    private radiusX: number;
    private radiusY: number;

    constructor(
        drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private sidebarService: SidebarService,
        private undoRedoService: UndoRedoService,
        drawingTypeService: DrawingTypeSelectorService,
    ) {
        super(drawingService);

        this.subscription = this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.primaryColor = color;
        });

        this.colorSelectorService.secondaryColor$.subscribe((color) => {
            this.secondaryColor = color;
        });

        drawingTypeService.drawingType$.subscribe((type) => {
            this.drawingType = type;
        });
    }

    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawShape(this.drawingService.baseCtx);

            const ellipse = new Ellipse(
                this.circleCenter,
                this.radiusX,
                this.radiusY,
                this.drawingType,
                this.sidebarService.widthShape,
                this.primaryColor,
                this.secondaryColor,
            );

            this.undoRedoService.addToStack(ellipse);
            this.undoRedoService.setToolInUse(false);
            this.mouseDown = false;
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown) {
            this.undoRedoService.setToolInUse(true);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawPreviewPerimeter(this.drawingService.previewCtx);
            this.drawShape(this.drawingService.previewCtx);
        }
    }

    onKeyDown(event: KeyboardEvent): void {
        if (event.key === 'Shift') {
            this.shiftPressed = true;
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        if (event.key === 'Shift') {
            this.shiftPressed = false;
        }
    }

    drawPreviewPerimeter(ctx: CanvasRenderingContext2D): void {
        this.width = Math.abs(this.firstPoint.x - this.lastPoint.x);
        this.height = Math.abs(this.firstPoint.y - this.lastPoint.y);

        ctx.beginPath();
        ctx.setLineDash([1, 2]); // ligne pointillée

        ctx.lineWidth = 1;
        ctx.strokeStyle = 'blue';
        const point = this.findTopLeftPoint(this.firstPoint, this.lastPoint);
        ctx.strokeRect(point.x, point.y, this.width, this.height);

        ctx.stroke();
        ctx.setLineDash([]); // remettre la ligne normale
        ctx.closePath();
    }

    drawShape(ctx: CanvasRenderingContext2D): void {
        this.circleCenter = this.getCenter(this.firstPoint, this.lastPoint);
        this.radiusX = Math.abs(this.firstPoint.x - this.lastPoint.x) / 2;
        this.radiusY = Math.abs(this.firstPoint.y - this.lastPoint.y) / 2;

        if (this.shiftPressed) {
            const shiftLastPoint = this.findShiftPoint(this.firstPoint, this.lastPoint);
            this.circleCenter = this.getCenter(this.firstPoint, shiftLastPoint);
            this.radiusX = Math.abs(this.firstPoint.x - shiftLastPoint.x) / 2;
            this.radiusY = Math.abs(this.firstPoint.y - shiftLastPoint.y) / 2;
        }

        this.radiusX = Math.abs(this.radiusX - this.sidebarService.widthShape / 2);
        this.radiusY = Math.abs(this.radiusY - this.sidebarService.widthShape / 2);

        ctx.beginPath();
        ctx.lineWidth = this.sidebarService.widthShape;
        ctx.strokeStyle = this.secondaryColor;
        ctx.fillStyle = this.primaryColor;
        ctx.ellipse(this.circleCenter.x, this.circleCenter.y, this.radiusX, this.radiusY, 0, 0, Math.PI * 2);

        switch (this.drawingType) {
            case DrawingType.stroke:
                ctx.stroke();
                break;

            case DrawingType.fill:
                ctx.fill();
                break;

            case DrawingType.outline:
                ctx.fill();
                ctx.stroke();
                break;
        }
        ctx.closePath();
    }
}
