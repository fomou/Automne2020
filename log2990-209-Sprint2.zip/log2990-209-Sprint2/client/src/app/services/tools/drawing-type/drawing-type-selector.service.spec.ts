import { TestBed } from '@angular/core/testing';

import { DrawingTypeSelectorService } from './drawing-type-selector.service';

describe('DrawingTypeSelectorService', () => {
    let service: DrawingTypeSelectorService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(DrawingTypeSelectorService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should change the drawing type ', () => {
        service.changeDrawingType('fill');
        expect(service.drawingTypeSource.getValue()).toEqual('fill');
    });
});
