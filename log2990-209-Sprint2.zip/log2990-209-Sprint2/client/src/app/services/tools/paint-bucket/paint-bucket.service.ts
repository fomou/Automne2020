import { Injectable } from '@angular/core';
import { Color } from '@app/classes/color';
import { PaintBucket } from '@app/classes/paint-bucket';
import { Tool } from '@app/classes/tool';
import * as CONSTANT from '@app/constantes/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';

@Injectable({
    providedIn: 'root',
})
export class PaintBucketService extends Tool {
    private color: string;
    private imageDataNoContigous: ImageData;
    private imageDataContigous: ImageData;
    constructor(
        drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private sidebarService: SidebarService,
        private undoRedoService: UndoRedoService,
    ) {
        super(drawingService);
        this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });
    }

    getPixelPos(x: number, y: number): number {
        return (y * this.drawingService.baseCtx.canvas.clientWidth + x) * CONSTANT.COLORS_PER_POSITION; // y = la lignes dans la variable image data
    }

    matchPixel(data: Uint8ClampedArray, position: number, colorAtStart: Color): boolean {
        if (this.sidebarService.tolerance === 0) {
            return (
                data[position] === colorAtStart.r &&
                data[position + CONSTANT.GREEN_COLOR_INDEX] === colorAtStart.g &&
                data[position + CONSTANT.BLUE_COLOR_INDEX] === colorAtStart.b &&
                data[position + CONSTANT.OPACITY_INDEX] === colorAtStart.a
            );
        } else {
            return (
                data[position] <= colorAtStart.r + (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE &&
                data[position] >= colorAtStart.r - (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE &&
                // rouge - %tolerance*255 < Pixel < rouge + %tolerance*255
                data[position + CONSTANT.GREEN_COLOR_INDEX] <=
                    colorAtStart.g + (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE &&
                data[position + CONSTANT.GREEN_COLOR_INDEX] >=
                    colorAtStart.g - (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE &&
                // vert - %tolerance*255 < Pixel < vert + %tolerance*255
                data[position + CONSTANT.BLUE_COLOR_INDEX] <=
                    colorAtStart.b + (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE &&
                data[position + CONSTANT.BLUE_COLOR_INDEX] >=
                    colorAtStart.b - (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE &&
                // bleu - %tolerance*255 < Pixel < bleu + %tolerance*255
                data[position + CONSTANT.OPACITY_INDEX] <=
                    colorAtStart.a + (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE &&
                data[position + CONSTANT.OPACITY_INDEX] >=
                    colorAtStart.a - (CONSTANT.MAX_BIT_NUM * this.sidebarService.tolerance) / CONSTANT.MAX_TOLERANCE
                // opacite - %tolerance*255 < Pixel < opacite + %tolerance*255
            );
        }
    }

    colorPixel(data: Uint8ClampedArray, position: number, color: string): void {
        data[position] = this.hexadecimalToDecimal(color.substring(CONSTANT.RED_INDEX_START, CONSTANT.RED_INDEX_END));
        data[position + CONSTANT.GREEN_COLOR_INDEX] = this.hexadecimalToDecimal(color.substring(CONSTANT.RED_INDEX_END, CONSTANT.GREEN_INDEX_END));
        data[position + CONSTANT.BLUE_COLOR_INDEX] = this.hexadecimalToDecimal(color.substring(CONSTANT.GREEN_INDEX_END, CONSTANT.BLUE_INDEX_END));
        if (color.length === CONSTANT.OPACITY_INDEX_END) {
            data[position + CONSTANT.OPACITY_INDEX] = this.hexadecimalToDecimal(color.substring(CONSTANT.BLUE_INDEX_END, CONSTANT.OPACITY_INDEX_END));
        } else {
            data[position + CONSTANT.OPACITY_INDEX] = CONSTANT.MAX_BIT_NUM;
        }
    }

    floodFill(startX: number, startY: number, fillColor: string): void {
        const dstImg: ImageData = this.drawingService.baseCtx.getImageData(
            0,
            0,
            this.drawingService.baseCtx.canvas.clientWidth,
            this.drawingService.baseCtx.canvas.clientHeight,
        );
        const dstData: Uint8ClampedArray = dstImg.data;

        const startPos: number = this.getPixelPos(startX, startY);
        const colorAtStart = {
            r: dstData[startPos],
            g: dstData[startPos + CONSTANT.GREEN_COLOR_INDEX],
            b: dstData[startPos + CONSTANT.BLUE_COLOR_INDEX],
            a: dstData[startPos + CONSTANT.OPACITY_INDEX],
        };
        const positionToBeEdited: number[][] = [[startX, startY]];
        const editedPositions = new Set();

        while (positionToBeEdited.length) {
            const pos: number[] = positionToBeEdited.pop() as number[];
            const x: number = pos[0];
            let y: number = pos[1];
            let currentPos: number = this.getPixelPos(x, y);
            if (editedPositions.has(currentPos)) continue;
            editedPositions.add(currentPos);

            while (y-- >= 0 && this.matchPixel(dstData, currentPos, colorAtStart)) {
                // aller au pixel le plus en haut qui a la meme couleure
                currentPos -= this.drawingService.baseCtx.canvas.clientWidth * CONSTANT.COLORS_PER_POSITION;
            }

            currentPos += this.drawingService.baseCtx.canvas.clientWidth * CONSTANT.COLORS_PER_POSITION; // descendre d une ligne
            ++y; // descendre d un ligne
            let reachLeft = false;
            let reachRight = false;

            while (y++ < this.drawingService.baseCtx.canvas.clientHeight - 1 && this.matchPixel(dstData, currentPos, colorAtStart)) {
                this.colorPixel(dstData, currentPos, fillColor);

                if (x > 0) {
                    if (this.matchPixel(dstData, currentPos - CONSTANT.COLORS_PER_POSITION, colorAtStart)) {
                        // aller une colone a gauche
                        if (!reachLeft) {
                            positionToBeEdited.push([x - 1, y]);
                            reachLeft = true;
                        }
                    } else if (reachLeft) {
                        reachLeft = false;
                    }
                }

                if (x < this.drawingService.baseCtx.canvas.clientWidth - 1) {
                    if (this.matchPixel(dstData, currentPos + CONSTANT.COLORS_PER_POSITION, colorAtStart)) {
                        // aller une colone a droite
                        if (!reachRight) {
                            positionToBeEdited.push([x + 1, y]);
                            reachRight = true;
                        }
                    } else if (reachRight) {
                        reachRight = false;
                    }
                }

                currentPos += this.drawingService.baseCtx.canvas.clientWidth * CONSTANT.COLORS_PER_POSITION;
            }
        }

        this.imageDataNoContigous = dstImg;
        this.drawingService.baseCtx.putImageData(dstImg, 0, 0);
        editedPositions.clear();
    }

    contigiousFloodFill(startX: number, startY: number, fillColor: string): void {
        const dstImg: ImageData = this.drawingService.baseCtx.getImageData(
            0,
            0,
            this.drawingService.baseCtx.canvas.clientWidth,
            this.drawingService.baseCtx.canvas.clientHeight,
        );
        const dstData: Uint8ClampedArray = dstImg.data;

        const startPos: number = this.getPixelPos(startX, startY);
        const colorAtStart: Color = {
            r: dstData[startPos],
            g: dstData[startPos + CONSTANT.GREEN_COLOR_INDEX],
            b: dstData[startPos + CONSTANT.BLUE_COLOR_INDEX],
            a: dstData[startPos + CONSTANT.OPACITY_INDEX],
        };
        for (let row = 0; row < this.drawingService.baseCtx.canvas.clientWidth - 1; row++) {
            for (let column = 0; column < this.drawingService.baseCtx.canvas.clientHeight - 1; column++) {
                const currentPos: number = this.getPixelPos(row, column);
                if (this.matchPixel(dstData, currentPos, colorAtStart)) {
                    this.colorPixel(dstData, currentPos, fillColor);
                }
            }
        }
        this.imageDataContigous = dstImg;
        this.drawingService.baseCtx.putImageData(dstImg, 0, 0);
    }

    hexadecimalToDecimal(hex: string): number {
        let decimalNum = 0;
        for (let i = 0; i < hex.length; i++) {
            let convertion: number;
            switch (hex[i]) {
                case 'A': {
                    convertion = CONSTANT.A;
                    break;
                }
                case 'B': {
                    convertion = CONSTANT.B;
                    break;
                }
                case 'C': {
                    convertion = CONSTANT.C;
                    break;
                }
                case 'D': {
                    convertion = CONSTANT.D;
                    break;
                }
                case 'E': {
                    convertion = CONSTANT.E;
                    break;
                }
                case 'F': {
                    convertion = CONSTANT.F;
                    break;
                }
                default: {
                    convertion = +hex[i];
                }
            }
            if (i === 0) {
                decimalNum = convertion * CONSTANT.HEXADECIMAL;
            } else if (i === 1) {
                decimalNum += convertion;
            }
        }
        return decimalNum;
    }

    onMouseDown(event: MouseEvent): void {
        const startX = event.pageX - CONSTANT.SIDE_BAR_X_POSITION;
        const startY = event.pageY;
        if (event.button === 0) {
            this.floodFill(startX, startY, this.color);
            const paintBucket = new PaintBucket(false, this.imageDataNoContigous, this.imageDataContigous);
            this.undoRedoService.addToStack(paintBucket);
        } else if (event.button === 2) {
            this.contigiousFloodFill(startX, startY, this.color);
            const paintBucket = new PaintBucket(true, this.imageDataNoContigous, this.imageDataContigous);
            this.undoRedoService.addToStack(paintBucket);
        }
    }
}
