import { Injectable } from '@angular/core';
import { Tool } from '@app/classes/tool';

@Injectable({
    providedIn: 'root',
})
export class SidebarService {
    width: number = 1;
    textureNum: number = 1;
    eraserSize: number = 5;
    brushWidth: number = 10;
    widthShape: number = 1;
    widthLine: number = 1;
    tolerance: number = 0;
    tool: Tool;
    changeWidth(lineWidth: number): void {
        this.width = lineWidth;
    }
    changeBrushWidth(brushWidth: number): void {
        this.brushWidth = brushWidth;
    }
    selectTexture(textureNumber: number): void {
        this.textureNum = textureNumber;
    }
    changeEraserSize(eraserSize: number): void {
        this.eraserSize = eraserSize;
    }
    changeWidthShape(widthShape: number): void {
        this.widthShape = widthShape;
    }

    changeWidthLine(widthLine: number): void {
        this.widthLine = widthLine;
    }

    changeTolerance(tolerance: number): void {
        this.tolerance = tolerance;
    }

    returnCurrentTool(tool: Tool): void {
        this.tool = tool;
    }
}
