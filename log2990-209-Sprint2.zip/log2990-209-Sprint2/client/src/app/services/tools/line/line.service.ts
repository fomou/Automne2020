import { Injectable } from '@angular/core';
import { Line } from '@app/classes/line';
import { Tool } from '@app/classes/tool';
import { Vec2 } from '@app/classes/vec2';
import * as CONSTANT from '@app/constantes/constants';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { ColorSelectorService } from '@app/services/tools/color-selector/color-selector.service';
import { SidebarService } from '@app/services/tools/sidebar/sidebar.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
@Injectable({
    providedIn: 'root',
})
export class LineService extends Tool {
    private mousePosition: Vec2;
    private firstPoint: Vec2; // premier point de la ligne
    private endShiftPoint: Vec2; // point pour la fin du segment avec le bon angle (avec shift)
    private pathData: Vec2[];
    private tracing: boolean = false;
    private shiftPresse: boolean = false;
    private color: string;
    pointJoin: boolean = false;
    joinRadius: number = CONSTANT.JOIN_MIN_RADIUS;
    private dFirstPointX: number; // distance sur x entre le curseur et le premier point de la ligne
    private dFirstPointY: number; // distance sur y entre le curseur et le premier point de la ligne

    constructor(
        drawingService: DrawingService,
        private colorSelectorService: ColorSelectorService,
        private sidebarService: SidebarService,
        private undoRedoService: UndoRedoService,
    ) {
        super(drawingService);
        this.colorSelectorService.primaryColor$.subscribe((color) => {
            this.color = color;
        });
        this.clearPath();
    }

    set radius(radius: number) {
        this.joinRadius = radius;
    }

    onClick(event: MouseEvent): void {
        this.mousePosition = this.getPositionFromMouse(event);
        this.undoRedoService.setToolInUse(true);
        if (!this.tracing) {
            // si c'est le premier point de la ligne composée
            this.pathData.push(this.mousePosition);
            this.tracing = true;
            this.firstPoint = this.mousePosition;
        } else if (this.shiftPresse) {
            console.log(this.endShiftPoint.x === this.endShiftPoint.y);
            this.pathData.push(this.endShiftPoint);
        } else {
            this.pathData.push(this.mousePosition);
        }
    }

    onDoubleClick(event: MouseEvent): void {
        if (this.tracing) {
            this.mousePosition = this.getPositionFromMouse(event);
            if (this.dFirstPointX < CONSTANT.CLOSED_LINE && this.dFirstPointY < CONSTANT.CLOSED_LINE) {
                // Si le curseur est proche du départ de la ligne
                this.pathData.pop(); // enlever le point du premier click compris dans le doubleClick
                this.pathData.pop(); // enlever le point du deuxième click compris dans le doubleClick
                this.pathData.push(this.firstPoint);
            } else if (this.shiftPresse) {
                this.pathData.pop();
            } else {
                this.pathData.push(this.mousePosition);
            }
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            const line = new Line(this.pathData, this.firstPoint, this.color, this.sidebarService.widthLine, this.joinRadius, this.pointJoin);
            line.draw(this.drawingService.baseCtx);
            this.clearPath();
            this.undoRedoService.addToStack(line);
            this.undoRedoService.setToolInUse(false);
            this.tracing = false;
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.tracing) {
            this.mousePosition = this.getPositionFromMouse(event);
            // On dessine sur le canvas de prévisualisation et on l'efface à chaque déplacement de la souris
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawLine(this.drawingService.previewCtx, this.pathData);
            this.dFirstPointX = Math.abs(this.mousePosition.x - this.firstPoint.x);
            this.dFirstPointY = Math.abs(this.mousePosition.y - this.firstPoint.y);

            if (this.shiftPresse) {
                this.endShiftPoint = this.findShiftPoint();
                this.drawPreviewSegment(this.drawingService.previewCtx, this.endShiftPoint);
            } else if (this.dFirstPointX < CONSTANT.CLOSED_LINE && this.dFirstPointY < CONSTANT.CLOSED_LINE) {
                // Si le curseur est proche du point de départ de la ligne, on trace un segment jusqu'à ce dernier
                this.drawPreviewSegment(this.drawingService.previewCtx, this.firstPoint);
            } else {
                this.drawPreviewSegment(this.drawingService.previewCtx, this.mousePosition);
            }
        }
    }

    onKeyDown(event: KeyboardEvent): void {
        if (this.tracing) {
            switch (event.key) {
                case 'Shift': // segment avec angle multiple de 45° par rapport à l'axe des X
                    this.shiftPresse = true;
                    this.endShiftPoint = this.findShiftPoint(); // on calcul la position du point avec le bon angle
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.drawLine(this.drawingService.previewCtx, this.pathData);
                    this.drawPreviewSegment(this.drawingService.previewCtx, this.endShiftPoint);
                    break;
                case 'Escape': // annulation de la ligne
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.clearPath();
                    this.tracing = false;
                    break;
                case 'Backspace': // annulation du dernier segment
                    this.pathData.pop();
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.drawLine(this.drawingService.previewCtx, this.pathData);
                    if (this.pathData.length === 0) {
                        this.tracing = false;
                    } else {
                        this.drawPreviewSegment(this.drawingService.previewCtx, this.mousePosition);
                    }
                    break;
            }
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        // désactiver le mode segment avec angle multiple de 45° par rapport à l'axe des X
        if (event.key === 'Shift') {
            this.shiftPresse = false;
        }
    }

    drawPreviewSegment(ctx: CanvasRenderingContext2D, endVec2: Vec2): void {
        const beginVec2 = this.pathData[this.pathData.length - 1];
        ctx.beginPath();
        ctx.strokeStyle = this.color;
        ctx.lineWidth = this.sidebarService.widthLine;
        ctx.moveTo(beginVec2.x, beginVec2.y);
        ctx.lineTo(endVec2.x, endVec2.y);
        ctx.stroke();
    }

    drawLine(ctx: CanvasRenderingContext2D, path: Vec2[]): void {
        if (this.pathData.length > 1) {
            ctx.beginPath();
            ctx.strokeStyle = this.color;
            ctx.lineWidth = this.sidebarService.widthLine;
            ctx.moveTo(this.firstPoint.x, this.firstPoint.y);
            for (const point of path) {
                if (this.pointJoin) {
                    ctx.lineTo(point.x, point.y);
                    ctx.fillStyle = this.color;
                    ctx.moveTo(point.x + this.joinRadius, point.y);
                    ctx.arc(point.x, point.y, this.joinRadius, 0, Math.PI * 2, true); // point pour la jonction
                    ctx.moveTo(point.x, point.y);
                } else {
                    ctx.lineJoin = 'miter';
                    ctx.lineTo(point.x, point.y);
                }
            }
            ctx.stroke();
            if (this.pointJoin) {
                ctx.fill();
            }
        }
    }

    // Trouve l'angle du point par rapport à l'axe des x
    findAngle(mouseVec2: Vec2): number {
        const refPoint = this.pathData[this.pathData.length - 1];
        const a = mouseVec2.x - refPoint.x;
        const b = mouseVec2.y - refPoint.y;
        let mouseAngle = Math.atan2(b, a);
        mouseAngle *= CONSTANT._180_DEGREE / Math.PI;
        if (mouseAngle < 0) {
            mouseAngle += CONSTANT._360_DEGREE;
        }
        return mouseAngle;
    }

    // convertit l'angle au plus proche multiple de 45°
    findShiftAngle(mouseVec2: Vec2): number {
        const mouseAngle = this.findAngle(mouseVec2);
        if (CONSTANT.MIN_45_DEGREE < mouseAngle && mouseAngle < CONSTANT.MIN_90_DEGREE) {
            return CONSTANT._45_DEGREE;
        } else if (CONSTANT.MIN_90_DEGREE < mouseAngle && mouseAngle < CONSTANT.MIN_135_DEGREE) {
            return CONSTANT._90_DEGREE;
        } else if (CONSTANT.MIN_135_DEGREE < mouseAngle && mouseAngle < CONSTANT.MIN_180_DEGREE) {
            return CONSTANT._135_DEGREE;
        } else if (CONSTANT.MIN_180_DEGREE < mouseAngle && mouseAngle < CONSTANT.MIN_225_DEGREE) {
            return CONSTANT._180_DEGREE;
        } else if (CONSTANT.MIN_225_DEGREE < mouseAngle && mouseAngle < CONSTANT.MIN_270_DEGREE) {
            return CONSTANT._225_DEGREE;
        } else if (CONSTANT.MIN_270_DEGREE < mouseAngle && mouseAngle < CONSTANT.MIN_315_DEGREE) {
            return CONSTANT._270_DEGREE;
        } else if (CONSTANT.MIN_315_DEGREE < mouseAngle && mouseAngle < CONSTANT.MIN_0_DEGREE) {
            return CONSTANT._315_DEGREE;
        } else {
            return CONSTANT._0_DEGREE;
        }
    }

    // Retourne le point correspondant au plus proche multiple de 45°
    findShiftPoint(): Vec2 {
        const refPoint = this.pathData[this.pathData.length - 1]; // point autour duquel on tourne
        const endShiftPoint = this.mousePosition;
        const dShiftX = Math.abs(this.mousePosition.x - refPoint.x);
        const angle = this.findShiftAngle(this.mousePosition);
        console.log(angle);
        // console.log(this.angle);
        switch (angle) {
            case CONSTANT._0_DEGREE:
                endShiftPoint.x = this.mousePosition.x;
                endShiftPoint.y = refPoint.y;
                break;
            case CONSTANT._45_DEGREE:
                endShiftPoint.x = this.mousePosition.x;
                endShiftPoint.y = refPoint.y + dShiftX;
                break;
            case CONSTANT._90_DEGREE:
                endShiftPoint.x = refPoint.x;
                endShiftPoint.y = this.mousePosition.y;
                break;
            case CONSTANT._135_DEGREE:
                endShiftPoint.x = this.mousePosition.x;
                endShiftPoint.y = refPoint.y + dShiftX;
                break;
            case CONSTANT._180_DEGREE:
                endShiftPoint.x = this.mousePosition.x;
                endShiftPoint.y = refPoint.y;
                break;
            case CONSTANT._225_DEGREE:
                endShiftPoint.x = this.mousePosition.x;
                endShiftPoint.y = refPoint.y - dShiftX;
                break;
            case CONSTANT._270_DEGREE:
                endShiftPoint.x = refPoint.x;
                endShiftPoint.y = this.mousePosition.y;
                break;
            case CONSTANT._315_DEGREE:
                endShiftPoint.x = this.mousePosition.x;
                endShiftPoint.y = refPoint.y - dShiftX;
                break;
        }
        return endShiftPoint;
    }

    private clearPath(): void {
        this.pathData = [];
    }
}
