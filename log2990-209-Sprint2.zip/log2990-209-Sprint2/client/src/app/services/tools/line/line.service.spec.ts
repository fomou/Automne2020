import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { Vec2 } from '@app/classes/vec2';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { LineService } from './line.service';

// tslint:disable: no-any
// tslint:disable:no-string-literal

describe('LineService', () => {
    let service: LineService;
    let mouseEvent: MouseEvent;
    let keyboardEvent: KeyboardEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;
    let drawLineSpy: jasmine.Spy<any>;
    let clearPathSpy: jasmine.Spy<any>;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let drawSegmentSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(LineService);
        drawLineSpy = spyOn<any>(service, 'drawLine').and.callThrough();
        drawSegmentSpy = spyOn<any>(service, 'drawPreviewSegment').and.callThrough();

        service['drawingService'].baseCtx = baseCtxStub;
        service['drawingService'].previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 296,
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    // Tests setters
    it('set radius should set joinRadius property to a new value', () => {
        service.radius = 1;
        expect(service.joinRadius).toEqual(1);
    });
    it('set pointJoint should set pointJoin property to a new value', () => {
        service.pointJoin = false;
        expect(service.pointJoin).toEqual(false);
    });

    // Tests onClick
    it('onClick should set mousePosition to correct position', () => {
        const expectedResult: Vec2 = { x: 25, y: 25 };
        service.onClick(mouseEvent);
        expect(service['mousePosition']).toEqual(expectedResult);
    });
    it('onClick should put tracing true if it was false', () => {
        service['tracing'] = false;
        service.onClick(mouseEvent);
        expect(service['tracing']).toEqual(true);
    });
    it('onClick should push endShiftPoint in pathData if tracing and shiftPresse true', () => {
        const expectedResult: Vec2 = { x: 10, y: 10 };
        service['tracing'] = true;
        service['shiftPresse'] = true;
        service['endShiftPoint'] = expectedResult;
        service.onClick(mouseEvent);
        expect(service['pathData'][service['pathData'].length - 1]).toEqual(expectedResult);
    });
    it('onClick should push mousePosition in pathData if tracing true', () => {
        const expectedResult: Vec2 = { x: 25, y: 25 };
        service['tracing'] = true;
        service.onClick(mouseEvent);
        expect(service['pathData'][service['pathData'].length - 1]).toEqual(expectedResult);
    });

    // Tests onDoubleClick
    it('onDoubleClick should set mousePosition to correct position', () => {
        const expectedResult: Vec2 = { x: 25, y: 25 };
        service['tracing'] = true;
        service.onDoubleClick(mouseEvent);
        expect(service['mousePosition']).toEqual(expectedResult);
    });
    it('onDoubleClick should put tracing false if it was true', () => {
        service['tracing'] = true;
        service.onDoubleClick(mouseEvent);
        expect(service['tracing']).toEqual(false);
    });

    it('onDoubleClick near the firstPoint should call clearPath', () => {
        clearPathSpy = spyOn<any>(service, 'clearPath').and.callThrough();
        service['dFirstPointX'] = 1;
        service['dFirstPointY'] = 1;
        service['tracing'] = true;
        service.onDoubleClick(mouseEvent);
        expect(clearPathSpy).toHaveBeenCalled();
    });
    it('onDoubleClick with Shift should call clearPath', () => {
        clearPathSpy = spyOn<any>(service, 'clearPath').and.callThrough();
        service['tracing'] = true;
        service['shiftPresse'] = true;
        service.onDoubleClick(mouseEvent);
        expect(clearPathSpy).toHaveBeenCalled();
    });

    // Tests OnMouseMove
    it('onMouseMove with shift should call drawPreviewSegment if tracing true', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 25, y: 25 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['firstPoint'] = vecMouse;
        service['tracing'] = true;
        service['shiftPresse'] = true;
        service.onMouseMove(mouseEvent);
        expect(drawSegmentSpy).toHaveBeenCalled(); // valide drawPreviewSegment()
    });
    it('onMouseMove near the firstPoint should call drawPreviewSegment if tracing true', () => {
        const vecPathData1: Vec2 = { x: 10, y: 10 };
        const vecPathData2: Vec2 = { x: 15, y: 15 };
        const vecMouse: Vec2 = { x: 25, y: 25 };
        service['pathData'] = [vecPathData1, vecPathData2]; // Valide drawline()
        service['mousePosition'] = vecMouse;
        service['firstPoint'] = vecMouse;
        service['tracing'] = true;
        service['shiftPresse'] = false;
        service.onMouseMove(mouseEvent);
        expect(drawSegmentSpy).toHaveBeenCalled();
    });
    it('onMouseMove should call drawPreviewSegment if tracing true', () => {
        const vecPathData1: Vec2 = { x: 80, y: 80 };
        const vecPathData2: Vec2 = { x: 90, y: 80 };
        const vecMouse: Vec2 = { x: 25, y: 25 };
        service['pathData'] = [vecPathData1, vecPathData2];
        service['mousePosition'] = vecMouse;
        service['firstPoint'] = vecPathData1;
        service['tracing'] = true;
        service['shiftPresse'] = false;
        service['pointJoin'] = false; // valide drawLine() avec pointJoin false
        service.onMouseMove(mouseEvent);
        expect(drawSegmentSpy).toHaveBeenCalled();
    });
    it('onMouseMove should not call drawLine if there was no click before', () => {
        service['tracing'] = false;
        service.onMouseMove(mouseEvent);
        expect(drawLineSpy).not.toHaveBeenCalled();
    });

    // Tests onKeyDown
    it('onKeyDown with escape should put tracing false if it was true', () => {
        service['tracing'] = true;
        keyboardEvent = new KeyboardEvent('keydown', { key: 'Escape' });
        service.onKeyDown(keyboardEvent);
        expect(service['tracing']).toEqual(false);
    });
    it('onKeyDown with backspace should put tracing false if it was true and pathData is empty', () => {
        service['tracing'] = true;
        keyboardEvent = new KeyboardEvent('keydown', { key: 'Backspace' });
        service.onKeyDown(keyboardEvent);
        expect(service['tracing']).toEqual(false);
    });
    it('onKeyDown with backspace should not put tracing false if pathData is not empty', () => {
        service['tracing'] = true;
        service['color'] = 'red';
        service['sidebarService'].widthLine = 2;
        service['mousePosition'] = { x: 100, y: 100 };
        const vecPathData1: Vec2 = { x: 80, y: 80 };
        const vecPathData2: Vec2 = { x: 90, y: 80 };
        service['pathData'] = [vecPathData1, vecPathData2];
        keyboardEvent = new KeyboardEvent('keydown', { key: 'Backspace' });
        service.onKeyDown(keyboardEvent);
        expect(service['tracing']).toEqual(true);
    });
    it('onKeyDown with Shift should put shiftPress to true if there was a click before', () => {
        service['tracing'] = true;
        const vecPathData: Vec2 = { x: 25, y: 25 };
        const vecMouse: Vec2 = { x: 10, y: 10 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        keyboardEvent = new KeyboardEvent('keydown', { key: 'Shift' });
        service.onKeyDown(keyboardEvent);
        expect(service['shiftPresse']).toEqual(true);
    });
    it('onKeyDown with backspace should call drawLine if there was a click before', () => {
        service['tracing'] = true;
        keyboardEvent = new KeyboardEvent('keydown', { key: 'Backspace' });
        service.onKeyDown(keyboardEvent);
        expect(drawLineSpy).toHaveBeenCalled();
    });
    it('onKeyDown with escape should not call drawLine if there was a click before', () => {
        service['tracing'] = true;
        keyboardEvent = new KeyboardEvent('keydown', { key: 'Escape' });
        service.onKeyDown(keyboardEvent);
        expect(drawLineSpy).not.toHaveBeenCalled();
    });
    it('onKeyDown should do nothing if there was no click before', () => {
        service['tracing'] = false;
        keyboardEvent = new KeyboardEvent('keydown', { key: 'Escape' });
        service.onKeyDown(keyboardEvent);
        expect(drawLineSpy).not.toHaveBeenCalled();
    });

    // Test onKeyUp
    it('onKeyUp with Shift should put shiftPress to false', () => {
        service['shiftPresse'] = true;
        keyboardEvent = new KeyboardEvent('keyup', { key: 'Shift' });
        service.onKeyUp(keyboardEvent);
        expect(service['shiftPresse']).toEqual(false);
    });
    it('onKeyUp should do nothing another key than Shift is pressed', () => {
        service['shiftPresse'] = true;
        keyboardEvent = new KeyboardEvent('keyup', { key: 'Escape' });
        service.onKeyUp(keyboardEvent);
        expect(service['shiftPresse']).toEqual(true);
    });

    // shiftAngle
    it('shiftVec2 with 0° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 20, y: 9 };
        const expectedResult: Vec2 = { x: 20, y: 10 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
    it('shiftVec2 with 45° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 20, y: 19 };
        const expectedResult: Vec2 = { x: 20, y: 20 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
    it('shiftVec2 with 90° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 9, y: 19 };
        const expectedResult: Vec2 = { x: 10, y: 19 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
    it('shiftVec2 with 135° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 1, y: 20 };
        const expectedResult: Vec2 = { x: 1, y: 19 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
    it('shiftVec2 with 180° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 1, y: 11 };
        const expectedResult: Vec2 = { x: 1, y: 10 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
    it('shiftVec2 with 225° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 1, y: 0 };
        const expectedResult: Vec2 = { x: 1, y: 1 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
    it('shiftVec2 with 270° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 9, y: 1 };
        const expectedResult: Vec2 = { x: 10, y: 1 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
    it('shiftVec2 with 315° angle', () => {
        const vecPathData: Vec2 = { x: 10, y: 10 };
        const vecMouse: Vec2 = { x: 19, y: 0 };
        const expectedResult: Vec2 = { x: 19, y: 1 };
        service['pathData'] = [vecPathData];
        service['mousePosition'] = vecMouse;
        service['shiftPresse'] = true;
        const vecResult = service.findShiftPoint();
        expect(vecResult).toEqual(expectedResult);
    });
});
