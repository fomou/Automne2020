import { Injectable } from '@angular/core';
import { MAXIMUM_COLOR } from '@app/constantes/constants';
import { ColorType } from '@app/enums/color-type';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ColorSelectorService {
    primaryColorSource: BehaviorSubject<string> = new BehaviorSubject<string>('#000000');
    secondaryColorSource: BehaviorSubject<string> = new BehaviorSubject<string>('#FF0000');
    rencentsColorsHandler: BehaviorSubject<string[]> = new BehaviorSubject<string[]>([]);
    hueKeeper: BehaviorSubject<string> = new BehaviorSubject<string>('#000000');
    colorType: string;

    primaryColor$: Observable<string> = this.primaryColorSource.asObservable();
    secondaryColor$: Observable<string> = this.secondaryColorSource.asObservable();
    recentColor$: Observable<string[]> = this.rencentsColorsHandler.asObservable();

    annonceColor(color: string): void {
        switch (this.colorType) {
            case ColorType.primary:
                this.primaryColorSource.next(color);
                break;
            case ColorType.secondary:
                this.secondaryColorSource.next(color);
                break;
            default:
                break;
        }
    }

    swapColor(primaryColor: string, secondarySecondary: string): void {
        this.primaryColorSource.next(secondarySecondary);
        this.secondaryColorSource.next(primaryColor);
    }

    getCurentColor(): string {
        let currentColor = '';

        switch (this.colorType) {
            case ColorType.primary:
                currentColor = this.primaryColorSource.getValue();
                break;

            case ColorType.secondary:
                currentColor = this.secondaryColorSource.getValue();
                break;
        }

        return currentColor;
    }

    addColorsToArray(color: string): void {
        const colors = this.rencentsColorsHandler.getValue();
        if (colors.length === MAXIMUM_COLOR) {
            colors.shift();
        }
        if (colors.includes(color)) {
            return;
        }
        colors.push(color);
        this.rencentsColorsHandler.next(colors);
    }

    keepHue(color: string): void {
        this.hueKeeper.next(color);
    }

    getHue(): string {
        return this.hueKeeper.getValue();
    }
}
