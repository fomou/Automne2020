import { Injectable } from '@angular/core';
import { RectangleSelection } from '@app/classes/rectangle-selection';
import { ShapeTool } from '@app/classes/shape-tool';
import { LINE_DASH, OFFSET_ARROW } from '@app/constantes/constants';
import { MouseButton } from '@app/enums/mouse-button';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';

@Injectable({
    providedIn: 'root',
})
export class SelectionRectangleService extends ShapeTool {
    imageData: ImageData;
    topLeftPointSelectionX: number;
    topLeftPointSelectionY: number;
    widthSelection: number;
    heightSelection: number;
    movedXPoint: number;
    movedYPoint: number;
    isSelected: boolean = false;
    isMoving: boolean = false;

    constructor(drawingService: DrawingService, private undoRedoService: UndoRedoService) {
        super(drawingService);
        this.primaryColor = '000000';
        this.secondaryColor = 'FFFFFF';
        this.drawingType = 'stroke';
    }

    onMouseDown(event: MouseEvent): void {
        this.mouseDown = event.button === MouseButton.Left;
        if (this.mouseDown) {
            if (!this.isSelected) {
                this.firstPoint = this.getPositionFromMouse(event);
                this.width = 0;
                this.height = 0;
            } else {
                if (!this.isInsideRectangle(event)) {
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.isSelected = false;
                    this.isMoving = false;
                    this.drawingService.baseCtx.putImageData(this.imageData, this.movedXPoint, this.movedYPoint);
                    const rectangle = new RectangleSelection(
                        this.imageData,
                        { x: this.topLeftPointSelectionX, y: this.topLeftPointSelectionY },
                        this.widthSelection,
                        this.heightSelection,
                        this.movedXPoint,
                        this.movedYPoint,
                    );
                    this.undoRedoService.undoStack.pop();
                    this.undoRedoService.addToStack(rectangle);

                    this.resetSelectionVariables();
                    this.firstPoint = this.getPositionFromMouse(event);
                    this.width = 0;
                    this.height = 0;
                } else {
                    this.isMoving = true;
                }
            }
        }
    }

    resetSelectionVariables(): void {
        this.topLeftPointSelectionX = 0;
        this.topLeftPointSelectionY = 0;
        this.widthSelection = 0;
        this.heightSelection = 0;
        this.movedXPoint = 0;
        this.movedYPoint = 0;
    }

    isInsideRectangle(event: MouseEvent): boolean {
        let isInside: boolean = this.getPositionFromMouse(event).x <= this.movedXPoint + this.width;
        isInside = isInside && this.getPositionFromMouse(event).x >= this.movedXPoint;
        isInside = isInside && this.getPositionFromMouse(event).y <= this.movedYPoint + this.height;
        isInside = isInside && this.getPositionFromMouse(event).y >= this.movedYPoint;
        return isInside;
    }

    onMouseUp(event: MouseEvent): void {
        if (this.mouseDown && !this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);

            const topLeftPoint = this.findTopLeftPoint(this.firstPoint, this.lastPoint);
            if (this.width >= 0 && this.height >= 0) {
                this.imageData = this.drawingService.baseCtx.getImageData(topLeftPoint.x, topLeftPoint.y, this.width + 1, this.height + 1);
            }

            this.drawSelection(this.drawingService.previewCtx);

            this.topLeftPointSelectionX = this.movedXPoint = topLeftPoint.x;
            this.topLeftPointSelectionY = this.movedYPoint = topLeftPoint.y;
            this.widthSelection = this.width;
            this.heightSelection = this.height;
            this.isSelected = true;
            this.mouseDown = false;
        } else if (this.mouseDown && this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.mouseDown = false;
            this.movedXPoint = this.getPositionFromMouse(event).x - this.widthSelection / 2;
            this.movedYPoint = this.getPositionFromMouse(event).y - this.heightSelection / 2;
            this.drawingService.previewCtx.putImageData(this.imageData, this.movedXPoint, this.movedYPoint);
            const rectangle = new RectangleSelection(
                this.imageData,
                { x: this.topLeftPointSelectionX, y: this.topLeftPointSelectionY },
                this.widthSelection,
                this.heightSelection,
                this.movedXPoint,
                this.movedYPoint,
            );
            this.undoRedoService.addToStack(rectangle);
        }
    }

    onMouseMove(event: MouseEvent): void {
        if (this.mouseDown && !this.isMoving) {
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.lastPoint = this.getPositionFromMouse(event);
            this.drawSelection(this.drawingService.previewCtx);
        } else if (this.mouseDown && this.isMoving) {
            this.drawingService.baseCtx.fillStyle = 'white';
            this.drawingService.baseCtx.fillRect(this.topLeftPointSelectionX, this.topLeftPointSelectionY, this.widthSelection, this.heightSelection);
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawingService.previewCtx.putImageData(
                this.imageData,
                this.getPositionFromMouse(event).x - this.widthSelection / 2,
                this.getPositionFromMouse(event).y - this.heightSelection / 2,
            );
        }
    }

    onKeyDown(event: KeyboardEvent): void {
        if (event.key === 'Shift') {
            this.shiftPressed = true;
        }
        if (event.key === 'Escape' && this.isSelected) {
            this.isSelected = false;
            this.isMoving = false;
            this.drawingService.clearCanvas(this.drawingService.previewCtx);
            this.drawingService.baseCtx.putImageData(this.imageData, this.movedXPoint, this.movedYPoint);
            this.resetSelectionVariables();
        }
        if (this.isSelected) {
            switch (event.key) {
                case 'ArrowLeft': {
                    this.drawingService.baseCtx.fillStyle = 'white';
                    this.drawingService.baseCtx.fillRect(
                        this.topLeftPointSelectionX,
                        this.topLeftPointSelectionY,
                        this.widthSelection,
                        this.heightSelection,
                    );
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.movedXPoint = this.movedXPoint - OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(this.imageData, this.movedXPoint, this.movedYPoint);
                    break;
                }
                case 'ArrowRight': {
                    this.drawingService.baseCtx.fillStyle = 'white';
                    this.drawingService.baseCtx.fillRect(
                        this.topLeftPointSelectionX,
                        this.topLeftPointSelectionY,
                        this.widthSelection,
                        this.heightSelection,
                    );
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.movedXPoint = this.movedXPoint + OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(this.imageData, this.movedXPoint, this.movedYPoint);
                    break;
                }
                case 'ArrowUp': {
                    this.drawingService.baseCtx.fillStyle = 'white';
                    this.drawingService.baseCtx.fillRect(
                        this.topLeftPointSelectionX,
                        this.topLeftPointSelectionY,
                        this.widthSelection,
                        this.heightSelection,
                    );
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.movedYPoint = this.movedYPoint - OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(this.imageData, this.movedXPoint, this.movedYPoint);
                    break;
                }
                case 'ArrowDown': {
                    this.drawingService.baseCtx.fillStyle = 'white';
                    this.drawingService.baseCtx.fillRect(
                        this.topLeftPointSelectionX,
                        this.topLeftPointSelectionY,
                        this.widthSelection,
                        this.heightSelection,
                    );
                    this.drawingService.clearCanvas(this.drawingService.previewCtx);
                    this.movedYPoint = this.movedYPoint + OFFSET_ARROW;
                    this.drawingService.previewCtx.putImageData(this.imageData, this.movedXPoint, this.movedYPoint);
                    break;
                }
            }
        }
    }

    onKeyUp(event: KeyboardEvent): void {
        if (event.key === 'Shift') {
            this.shiftPressed = false;
        }
    }

    drawSelection(ctx: CanvasRenderingContext2D): void {
        const startPoint = this.firstPoint;
        let endPoint = this.lastPoint;

        if (this.shiftPressed) {
            endPoint = this.findShiftPoint(this.firstPoint, this.lastPoint);
        }

        this.width = Math.abs(startPoint.x - endPoint.x);
        this.height = Math.abs(startPoint.y - endPoint.y);
        const topLeftPoint = this.findTopLeftPoint(startPoint, endPoint);

        ctx.beginPath();
        ctx.setLineDash([LINE_DASH, LINE_DASH]); // ligne pointillée
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'blue';
        ctx.strokeRect(topLeftPoint.x, topLeftPoint.y, this.width, this.height);
        ctx.setLineDash([]); // remettre la ligne normale
        ctx.closePath();
    }
}
