import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { DrawingService } from '@app/services//drawing/drawing.service';
import { SelectionRectangleService } from './selection-rectangle.service';

// tslint:disable: no-string-literal
// tslint:disable: no-any
// tslint:disable: no-magic-numbers
describe('SelectionRectangleService', () => {
    let service: SelectionRectangleService;
    let mouseEvent: MouseEvent;

    let baseCtxStub: CanvasRenderingContext2D;
    let previewCtxStub: CanvasRenderingContext2D;

    let drawServiceSpy: jasmine.SpyObj<DrawingService>;
    let drawSelectionSpy: jasmine.Spy<any>;

    beforeEach(() => {
        baseCtxStub = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        previewCtxStub = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        drawServiceSpy = jasmine.createSpyObj('DrawingService', ['clearCanvas']);

        TestBed.configureTestingModule({
            providers: [{ provide: DrawingService, useValue: drawServiceSpy }],
        });
        service = TestBed.inject(SelectionRectangleService);

        drawSelectionSpy = spyOn<any>(service, 'drawSelection').and.callThrough();
        service.drawingService.baseCtx = baseCtxStub;
        service.drawingService.previewCtx = previewCtxStub;

        mouseEvent = {
            pageX: 25,
            pageY: 25,
            button: 0,
        } as MouseEvent;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('onMouseDown should set mouseDown true', () => {
        service.mouseDown = false;
        service.height = 30;

        service.onMouseDown(mouseEvent);

        expect(service.height).toEqual(0);
        expect(service.mouseDown).toEqual(true);
    });

    it('onMouseDown in the selection should call resetSelectionVariables', () => {
        service.mouseDown = false;
        service.height = 30;
        service.isSelected = true;
        service.imageData = new ImageData(100, 100);
        service.movedXPoint = 30;
        service.movedYPoint = 30;

        spyOn(service.drawingService.baseCtx, 'putImageData').and.callFake(() => {
            return;
        });
        spyOn(service, 'isInsideRectangle').and.returnValue(false);
        const spy = spyOn(service, 'resetSelectionVariables').and.callThrough();
        service.onMouseDown(mouseEvent);

        expect(service.height).toEqual(0);
        expect(spy).toHaveBeenCalled();
    });

    it('onMouseDown outside the selection should put isMoving true ', () => {
        service.mouseDown = false;
        service.isSelected = true;
        service.isMoving = false;

        spyOn(service, 'isInsideRectangle').and.returnValue(true);

        service.onMouseDown(mouseEvent);

        expect(service.isMoving).toEqual(true);
    });

    it('onMouseDown with rightClic should not set mouseDown true', () => {
        mouseEvent = {
            pageX: 30,
            pageY: 30,
            button: 2,
        } as MouseEvent;

        service.mouseDown = false;

        service.onMouseDown(mouseEvent);
        expect(service.mouseDown).toEqual(false);
    });

    it('isInsideRectangle true ', () => {
        service.movedXPoint = 10;
        service.movedYPoint = 10;
        service.width = 30;
        service.height = 30;

        spyOn(service, 'getPositionFromMouse').and.returnValue({ x: 25, y: 25 });

        const expectBool = service.isInsideRectangle(mouseEvent);
        expect(expectBool).toEqual(true);
    });

    it('onMouseUp with no selection', () => {
        service.mouseDown = true;
        service.isMoving = false;
        service.firstPoint = { x: 25, y: 25 };

        service.width = 30;
        service.height = 30;

        spyOn(service, 'getPositionFromMouse').and.returnValue({ x: 25, y: 25 });

        service.onMouseUp(mouseEvent);

        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseUp with no selection with width < 0', () => {
        service.mouseDown = true;
        service.isMoving = false;
        service.firstPoint = { x: 25, y: 25 };

        service.width = -10;
        service.height = 30;

        spyOn(service, 'getPositionFromMouse').and.returnValue({ x: 25, y: 25 });

        service.onMouseUp(mouseEvent);

        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseUp with a selection', () => {
        service.mouseDown = true;
        service.isMoving = true;
        service.firstPoint = { x: 25, y: 25 };
        service.imageData = new ImageData(100, 100);
        service.movedXPoint = 30;
        service.movedYPoint = 30;
        service.widthSelection = 30;
        service.heightSelection = 30;

        service.onMouseUp(mouseEvent);

        expect(service.mouseDown).toEqual(false);
    });

    it('onMouseUp with mouseDown false should do nothing', () => {
        service.mouseDown = false;

        service.onMouseUp(mouseEvent);

        expect(service.mouseDown).toEqual(false);
    });

    it('onMouseMove with no selection', () => {
        service.mouseDown = true;
        service.isMoving = false;
        service.shiftPressed = true;
        service.firstPoint = { x: 25, y: 25 };

        service.onMouseMove(mouseEvent);

        expect(drawSelectionSpy).toHaveBeenCalled();
    });

    it('onMouseMove with a selection', () => {
        service.mouseDown = true;
        service.isMoving = true;
        service.firstPoint = { x: 25, y: 25 };
        service.imageData = new ImageData(100, 100);
        service.topLeftPointSelectionX = 30;
        service.topLeftPointSelectionY = 30;
        service.widthSelection = 30;
        service.heightSelection = 30;

        service.onMouseMove(mouseEvent);

        expect(drawSelectionSpy).not.toHaveBeenCalled();
    });

    it('onMouseMove with mouseDown false should do nothing', () => {
        service.mouseDown = false;
        service.isMoving = true;

        service.onMouseMove(mouseEvent);

        expect(service.mouseDown).toEqual(false);
    });

    it('onKeyDown with shift should put shiftPressed true', () => {
        const keyboardEvent = { key: 'Shift' } as KeyboardEvent;
        service.shiftPressed = false;

        service.onKeyDown(keyboardEvent);

        expect(service.shiftPressed).toEqual(true);
    });

    it('onKeyDown should not set shiftPressed if shift was not the event key', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service.shiftPressed = false;

        service.onKeyUp(keyboardEvent);

        expect(service.shiftPressed).toEqual(false);
    });

    it('onKeyDown with Escape should call resestSeletionVariables', () => {
        const keyboardEvent = { key: 'Escape' } as KeyboardEvent;
        service.shiftPressed = false;
        service.isSelected = true;
        service.isMoving = true;
        service.imageData = new ImageData(100, 100);
        service.movedXPoint = 30;
        service.movedYPoint = 30;

        service.onKeyDown(keyboardEvent);

        expect(service.isSelected).toEqual(false);
        expect(service.isMoving).toEqual(false);
    });

    it('onKeyDown with ArrowLeft', () => {
        const keyboardEvent = { key: 'ArrowLeft' } as KeyboardEvent;
        service.isSelected = true;
        service.imageData = new ImageData(100, 100);
        service.movedXPoint = 30;
        service.movedYPoint = 30;

        service.onKeyDown(keyboardEvent);

        expect(service.movedXPoint).toEqual(27);
    });

    it('onKeyDown with ArrowRight', () => {
        const keyboardEvent = { key: 'ArrowRight' } as KeyboardEvent;
        service.isSelected = true;
        service.imageData = new ImageData(100, 100);
        service.movedXPoint = 30;
        service.movedYPoint = 30;

        service.onKeyDown(keyboardEvent);

        expect(service.movedXPoint).toEqual(33);
    });

    it('onKeyDown with ArrowUp', () => {
        const keyboardEvent = { key: 'ArrowUp' } as KeyboardEvent;
        service.isSelected = true;
        service.imageData = new ImageData(100, 100);
        service.movedXPoint = 30;
        service.movedYPoint = 30;

        service.onKeyDown(keyboardEvent);

        expect(service.movedYPoint).toEqual(27);
    });

    it('onKeyDown with ArrowDown', () => {
        const keyboardEvent = { key: 'ArrowDown' } as KeyboardEvent;
        service.isSelected = true;
        service.imageData = new ImageData(100, 100);
        service.movedXPoint = 30;
        service.movedYPoint = 30;

        service.onKeyDown(keyboardEvent);

        expect(service.movedYPoint).toEqual(33);
    });

    it('onKeyUp should set shiftpressed to false', () => {
        const keyboardEvent = { key: 'Shift' } as KeyboardEvent;
        service.shiftPressed = true;

        service.onKeyUp(keyboardEvent);

        expect(service.shiftPressed).toEqual(false);
    });
});
