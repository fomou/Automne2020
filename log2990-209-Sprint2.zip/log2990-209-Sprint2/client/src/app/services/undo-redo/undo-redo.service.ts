import { Injectable } from '@angular/core';
import { Drawable } from '@app/classes/drawable';
import { LoadedImage } from '@app/classes/loaded-image';
import { Resize } from '@app/classes/resize';
import { Stack } from '@app/classes/stack';
import { Keyboard } from '@app/enums/key-board';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class UndoRedoService {
    undoStack: Stack<Drawable>;
    private redoStack: Stack<Drawable>;
    private toolsInUse: BehaviorSubject<boolean>;
    loadedImage: BehaviorSubject<Drawable>;
    constructor(private drawingService: DrawingService) {
        this.undoStack = new Stack<Drawable>();
        this.redoStack = new Stack<Drawable>();
        this.toolsInUse = new BehaviorSubject<boolean>(false);
        this.loadedImage = new BehaviorSubject<Drawable>(new LoadedImage());
    }

    setToolInUse(inUse: boolean): void {
        this.toolsInUse.next(inUse);
    }

    undo(): void {
        if (this.undoStack.isEmpty() || this.toolsInUse.getValue()) {
            return;
        }

        const lastElement = this.undoStack.pop();
        const array = this.undoStack.getAll();
        this.redoStack.add(lastElement);
        lastElement.undraw();
        this.drawingService.clearCanvas(this.drawingService.baseCtx);
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        this.drawingService.setBackground(this.drawingService.baseCtx);
        const startImg = this.loadedImage.getValue() as LoadedImage;
        if (startImg.src !== undefined) {
            // si une image est chargée depuis le serveur
            this.loadedImage.getValue().draw(this.drawingService.baseCtx);
        }
        for (const element of array) {
            if (element instanceof Resize) {
                // on efface et redessine dans le cas où il ya redimensionnement pour contre-balancer
                element.undraw();
                element.draw(this.drawingService.baseCtx);
            } else {
                element.draw(this.drawingService.baseCtx);
            }
        }
    }

    addToStack(drawable: Drawable): void {
        this.redoStack.clear();
        this.undoStack.add(drawable);
    }

    redo(): void {
        if (this.redoStack.isEmpty() || this.toolsInUse.getValue()) {
            return;
        }

        const lastElement = this.redoStack.pop();
        this.undoStack.add(lastElement);
        this.drawingService.clearCanvas(this.drawingService.previewCtx);
        lastElement.draw(this.drawingService.baseCtx);
    }

    onKeyDown(event: KeyboardEvent): void {
        if (event.ctrlKey && event.shiftKey && event.code === Keyboard.z) {
            this.redo();
        } else if (event.ctrlKey && event.code === Keyboard.z) {
            this.undo();
        }
    }

    canUndo(): boolean {
        return !this.undoStack.isEmpty();
    }

    canRedo(): boolean {
        return !this.redoStack.isEmpty();
    }
    clearStacks(): void {
        this.undoStack.clear();
        this.redoStack.clear();
    }
}
