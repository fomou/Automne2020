import { TestBed } from '@angular/core/testing';
import { canvasTestHelper } from '@app/classes/canvas-test-helper';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { DrawingService } from './drawing.service';

describe('DrawingService', () => {
    let service: DrawingService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(DrawingService);
        service.canvas = canvasTestHelper.canvas;
        service.baseCtx = canvasTestHelper.canvas.getContext('2d') as CanvasRenderingContext2D;
        service.previewCtx = canvasTestHelper.drawCanvas.getContext('2d') as CanvasRenderingContext2D;
        service.undoRedoService = new UndoRedoService({} as DrawingService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should clear the whole canvas', () => {
        service.clearCanvas(service.baseCtx);
        const pixelBuffer = new Uint32Array(service.baseCtx.getImageData(0, 0, service.canvas.width, service.canvas.height).data.buffer);
        const hasColoredPixels = pixelBuffer.some((color) => color !== 0);
        expect(hasColoredPixels).toEqual(false);
    });

    it('isBlanck should return false if the canvas is blanck', () => {
        const spy = spyOn(document, 'createElement').and.returnValue(canvasTestHelper.canvas);
        service.isBlank();
        expect(service.isBlank()).toBe(true);
        expect(spy).toHaveBeenCalled();
    });

    it(' getImage should return the url of Image on the canvas ', () => {
        const spy = spyOn(service.canvas, 'toDataURL').and.returnValue('image.png');
        service.getImage();
        expect(spy).toHaveBeenCalled();
    });

    it('setBackground should set the backgrounnd of the canvas to white', () => {
        const spy = spyOn(service.baseCtx, 'fillRect');
        service.setBackground(service.baseCtx);
        expect(spy).toHaveBeenCalled();
    });

    it('getImageData should call getImage on baseCtx', () => {
        const spy = spyOn(service.baseCtx, 'getImageData');
        service.getImageData();
        expect(spy).toHaveBeenCalled();
    });

    it('isCliked should return false if the canvas was not blank', () => {
        spyOn(service, 'isBlank').and.returnValue(true);
        expect(service.isCliked()).toBe(false);
    });

    it('isCliked should return true if confirmed on window', () => {
        spyOn(service, 'isBlank').and.returnValue(false);
        spyOn(window, 'confirm').and.returnValue(true);
        const spy = spyOn(service.undoRedoService, 'clearStacks').and.callFake(() => {
            return;
        });
        expect(service.isCliked()).toBe(true);
        expect(spy).toHaveBeenCalled();
    });
    it('isCliked should return false if not confirmed on window', () => {
        spyOn(service, 'isBlank').and.returnValue(false);
        spyOn(window, 'confirm').and.returnValue(false);
        expect(service.isCliked()).toBe(false);
    });
    it('imageLoadedFromGallery should give right value ', () => {
        service.imageIsLoadedFromGallery.next(false);
        expect(service.imageLoadedFromGallery()).toBe(false);
    });
});
