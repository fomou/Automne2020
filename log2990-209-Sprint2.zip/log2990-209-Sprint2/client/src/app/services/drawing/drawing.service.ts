import { Injectable } from '@angular/core';
import { UndoRedoService } from '@app/services/undo-redo/undo-redo.service';
import { BehaviorSubject } from 'rxjs';
@Injectable({
    providedIn: 'root',
})
export class DrawingService {
    baseCtx: CanvasRenderingContext2D;
    previewCtx: CanvasRenderingContext2D;
    canvas: HTMLCanvasElement;
    previewCanvas: HTMLCanvasElement;
    borderCanvas: HTMLDivElement;
    background: HTMLDivElement;
    undoRedoService: UndoRedoService;
    drawingService: DrawingService;
    imageIsLoadedFromGallery: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    clearCanvas(context: CanvasRenderingContext2D): void {
        context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }

    isBlank(): boolean {
        const blankCanvas: HTMLCanvasElement = document.createElement('canvas');
        console.log(blankCanvas);
        blankCanvas.width = this.canvas.width;
        blankCanvas.height = this.canvas.height;
        return this.canvas.toDataURL() === blankCanvas.toDataURL();
    }

    setBackground(context: CanvasRenderingContext2D): void {
        context.fillStyle = 'white';
        context.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }

    getImage(): string {
        const oldcanvas = this.canvas.toDataURL('image/png');
        const image = new Image();
        image.onload = () => {
            this.baseCtx.drawImage(image, 0, 0);
        };
        image.src = oldcanvas;
        return image.src;
    }

    getImageData(): ImageData {
        return this.baseCtx.getImageData(0, 0, this.canvas.width, this.canvas.height);
    }

    isCliked(): boolean {
        let confirm = false;
        if (!this.isBlank()) {
            confirm = window.confirm('Voulez-vous abandonner vos changement ?');
            if (confirm) {
                this.clearCanvas(this.baseCtx);
                this.clearCanvas(this.previewCtx);
                this.undoRedoService.clearStacks();
                this.imageIsLoadedFromGallery.next(false);
                this.setBackground(this.baseCtx);
            }
        }
        return confirm;
    }

    imageLoadedFromGallery(): boolean {
        return this.imageIsLoadedFromGallery.getValue();
    }
}
