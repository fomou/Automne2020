import { HttpClient, HttpClientModule, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { DrawingService } from '@app/services/drawing/drawing.service';
// tslint:disable-next-line:no-relative-imports
import { Drawing } from '../../../../../common/communication/drawing';
import { SaveDrawingService } from './save-drawing.service';

// tslint:disable:no-any
// tslint:disable: no-string-literal
describe('SaveDrawingService', () => {
    let service: SaveDrawingService;
    let client: HttpClient;

    let drawService: DrawingService;

    beforeEach(() => {
        client = new HttpClient({} as HttpHandler);
        drawService = new DrawingService();
        TestBed.configureTestingModule({
            providers: [
                { provide: DrawingService, useValue: drawService },
                { provide: HttpClient, useValue: client },
            ],
            imports: [HttpClientModule],
        });
        service = TestBed.inject(SaveDrawingService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should call post request on addData', async () => {
        const drawing: Drawing = { name: 'Test', tags: [''], dataUrl: '' };

        spyOn<any>(service['drawingService'], 'getImage').and.callFake(() => {
            return 'test';
        });

        spyOn<any>(client.post('', drawing), 'subscribe').and.callFake(() => {
            return 'test';
        });
        service.addData(drawing);
        expect(service['urladd']).toEqual('http://localhost:3000/api/drawing/add');
    });

    it('should call delete request on deleteData ', async () => {
        const spy = spyOn<any>(client, 'delete').and.callFake(() => {
            return;
        });
        const stringStub = 'test';
        service.deleteData(stringStub);
        expect(service['urldelete']).toEqual('http://localhost:3000/api/drawing/delete/test');
        expect(spy).toHaveBeenCalled();
    });
});
