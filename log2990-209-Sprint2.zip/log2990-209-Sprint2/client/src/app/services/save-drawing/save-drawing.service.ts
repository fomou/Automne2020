import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DrawingService } from '@app/services/drawing/drawing.service';
import { Drawing } from '@common/communication/drawing';
import { Observable, Subject, Subscription } from 'rxjs';

const DEFAULT_SERVER_ADD = 'http://localhost:3000/api/drawing/add';
const DEFAULT_SERVER_DELETE = 'http://localhost:3000/api/drawing/delete/';
@Injectable({
    providedIn: 'root',
})
export class SaveDrawingService {
    private urladd: string = DEFAULT_SERVER_ADD;
    private urldelete: string = DEFAULT_SERVER_DELETE;
    constructor(private http: HttpClient, private drawingService: DrawingService) {}
    tabImage: Drawing[] = [];

    addData(dessin: Drawing): Subscription {
        dessin.dataUrl = this.drawingService.getImage();
        return this.http.post<string>(this.urladd, dessin).subscribe(
            // tslint:disable-next-line: no-empty
            () => {},
            // tslint:disable-next-line: no-empty
            (error) => {},
        );
    }

    deleteData(idImage: string): Observable<string> {
        console.log('test1');
        this.urldelete = 'http://localhost:3000/api/drawing/delete/' + idImage;
        return this.http.delete<string>(this.urldelete);
    }

    getAllImages(): Observable<Drawing[]> {
        const subject = new Subject<Drawing[]>();
        this.http.get<Drawing[]>('http://localhost:3000/api/drawing/').subscribe((data) => {
            this.tabImage = data;
            subject.next(data);
        });
        return subject.asObservable();
    }
}
