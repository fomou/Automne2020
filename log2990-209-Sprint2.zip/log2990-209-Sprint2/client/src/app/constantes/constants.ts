const WIDTH_SIDEBAR = 220;
export const DEFAULT_WIDTH = (window.innerWidth - WIDTH_SIDEBAR) / 2;
export const DEFAULT_HEIGHT = window.innerHeight / 2;

export const COLOR_PICKER_WIDTH = 50;
export const COLOR_SLIDER_HEIGHT = 250;
export const CURSOR_SIZE = 10;
export const MAXIMUM_COLOR = 10;

export const _0_DEGREE = 0;
export const _45_DEGREE = 45;
export const _90_DEGREE = 90;
export const _135_DEGREE = 135;
export const _180_DEGREE = 180;
export const _225_DEGREE = 225;
export const _270_DEGREE = 270;
export const _315_DEGREE = 315;
export const _360_DEGREE = 360;

export const MIN_0_DEGREE = 337.5;
export const MIN_45_DEGREE = 22.5;
export const MIN_90_DEGREE = 67.5;
export const MIN_135_DEGREE = 112.5;
export const MIN_180_DEGREE = 157.5;
export const MIN_225_DEGREE = 202.5;
export const MIN_270_DEGREE = 247.5;
export const MIN_315_DEGREE = 292.5;

export const CLOSED_LINE = 20;
export const JOIN_MIN_RADIUS = 5;
export const NB_TOOLS = 11;

export const ANGLE_BRUSH = 25;
export const IMAGES_BY_POINT = 5;
export const ERASE_INDEX = 4;
export const WIDTH_RATE = 4;

export const PREVIEW_CIRCLE_RADIUS = 10;
export const CENTER_CIRCLE_RADIUS = 5;
export const MAX_WIDTH = 1;
export const CENTER_RADIUS = 5;

export const NEXT_COLOR = 4;
export const NUMBER_OF_COLORS = 3;
export const CENTER_WIDTH = 20;
export const SIDE_BAR_X_POSITION = 271;

export const COLORS_PER_POSITION = 4;
export const MAX_BIT_NUM = 255;
export const MAX_TOLERANCE = 100;
export const GREEN_COLOR_INDEX = 1;
export const BLUE_COLOR_INDEX = 2;
export const OPACITY_INDEX = 3;
export const RED_INDEX_START = 1;
export const RED_INDEX_END = 3;
export const GREEN_INDEX_END = 5;
export const BLUE_INDEX_END = 7;
export const OPACITY_INDEX_END = 9;
export const A = 10;
export const B = 11;
export const C = 12;
export const D = 13;
export const E = 14;
export const F = 15;
export const HEXADECIMAL = 16;

export const GALLERY_LOADING_TIME = 4000;

export const DARKEN_COLOR_FACTOR = 0.5;

export const LINE_DASH = 10;

export const OFFSET_ARROW = 3;
