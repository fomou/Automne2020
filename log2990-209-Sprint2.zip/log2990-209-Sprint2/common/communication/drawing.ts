export interface Drawing {
    name: string;
    tags: string[];
    dataUrl?: string;
    id?: string;
}
