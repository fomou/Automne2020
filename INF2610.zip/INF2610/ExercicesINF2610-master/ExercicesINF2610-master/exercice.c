#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include<sys/wait.h>
#include<string.h>
int main(){

  int fd[2];
  pipe(fd);

  if(fork()==0){
    const char * mess="je suis le fils";
    close(fd[0]);
    write(fd[1],mess,strlen(mess)+1);
    close(fd[1]);
    _exit(0);
  }

  else
  {
    close(fd[1]);
    char *buf;
    while(read(fd[0],buf,1)>0){
      write(1,buf,1);
    }
    close(fd[1]);
    wait(NULL);
  }
  

  return 0;
}