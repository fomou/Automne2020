/*
 * INF2610 - dummy.c
 * 
 * Ecole polytechnique de Montreal, 2019
 */

#include <stdio.h>

int main() {
    printf("Hello world\n");
    return 0;
}