// programme deuxfils.c
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
const int n=3, m=2;
int main(){
int i,j=0;
for(i=0; i<n&& j<m; i++)
{ if(fork()==0)
 { i=0;
 j=j+1;
 }
}
printf(" j=%d\n",j);
 while(wait(NULL)>0);
    _exit (0);
}

