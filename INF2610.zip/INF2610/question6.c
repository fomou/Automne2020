
#include<semaphore.h>

