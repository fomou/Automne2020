/*
Vous devez créer 10 threads niveau noyau. Chaque thread devra exécuter la fonction suivante :

void* action(char* nom, char* prenom)

·       -Supposez que vous avez accès aux noms des threads avec un tableau nommé NOMS qui possède 10 entrées.

·       Supposez que vous avez accès aux prénoms des threads avec un tableau nommé PRENOMS qui possède 10 entrées.

 

Note : sentez-vous libre de créer des fonctions et/ou structures.

 

Votre code devra être découpé en trois parties (que vous allez identifier avec un commentaire,

exemple //Partie 1 //Partie 2 et //Partie 3)

Il n’est pas obligatoire de donner un code compilable. On vous demande seulement de lister les appels nécessaires, les boucles, conditions, etc. sous la forme de code C.

Partie 1 : (2 pts)

·       Vous devez initialiser le sémaphore à 1. Vous n’avez pas besoin de faire l’allocation de la mémoire avec calloc, seulement l’appel d’initialisation. Supposez que vous avez accès à la variable sem_t* semaphore que vous utiliserez comme sémaphore binaire.

Partie 2 : (2 pts)

·       Vous devez détruire le sémaphore nommé semaphore. Vous n’avez pas besoin de faire l’appel free, on vous demande seulement d’appeler la fonction pour le détruire.

Partie 3 : (6 pts)

·       Vous devez créer les 10 threads et faire en sorte que chaque thread appelle la fonction demandée.
*/

struct Identifiant{
    char* nom;
    char * premon;
};

void* action(char* nom, char* prenom){

}

void * actionWrapper( void * param){
   struct Identifiant* id= (struct Identifiant*)(param);

    return action(id->nom, id->prenom);
}

int main(){

//partie 1

const int nbAcces=10;

sem_t* semaphore;

sem_init(semaphore,0,nbAcces);


//partie 3

for(int i=0;i<nbAcces; ++i){
    sem_wait(semaphore[i]);
    
    struct Identifiant* id = calloc(1, sizeof(struct Identifiant));
    id->nom = NOM[i];
    id->prenom = PRENOM[i];

    pthread_t tid;
    pthread_create(&tid, NULL, actionWrapper, (void*)id);
    pthread_join(tid, NULL);
    sem_post(semaphore[i])
}





//partie 2

sem_destroy(semaphore);
    return 0;
}