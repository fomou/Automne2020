#include<sys/wait.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
int main() {

    mkfifo(" /tmp/pipe_a",0660);
    mkfifo(" /tmp/pipe_b",0660);
     
    if(fork()==0){
        //fils1

        char ppid[10];
       
        sprintf(ppid,"%d",getppid());
        execl("./executables/Question1/marioKart","marioKart", ppid,NULL);
        _exit(0);
    } if(fork()==0){

        //fils2
        
        char ppid[10];
        sprintf(ppid,"%d",getppid());
        execl("./executables/Question1/bacAsable","bacAsable", ppid,NULL);
        _exit(0);
        
    } if(fork()==0)
    {
        /* fils3 */
        int fdTubeA=open("/tmp/pipe_a",O_WRONLY);
        write(fdTubeA,"33bd56a1ae9a63b5", strlen("33bd56a1ae9a63b5"));
        close(fdTubeA);
        _exit(0);
    } if (fork()==0)
    {
        /* fils 4 */
        int fdTubeB=open("/tmp/pipe_b",O_WRONLY);   
        write(fdTubeB,"24d6b65d99e25e93", strlen("24d6b65d99e25e93"));
        close(fdTubeB);
        _exit(0);
    }
    
   
        while(wait(NULL)>0);
    
       
}