#include<sys/wait.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>

int main() {

    int fd[2];

    pipe(fd);

    if (fork() == 0)
    {

      close(fd[1]);
      dup2(fd[0], 0);
      execl("./executables/Question2/prog2", "prog2", NULL);

      close(fd[0]);
       _exit(0);

      
    } 
    if(fork()==0){

        int tempfile= open("./executables/Question2/tmpfile",O_RDONLY);
        close(fd[0]);
        dup2(tempfile,1);
        dup2(fd[1],2);

        execl("./executables/Question2/prog1", "prog1", NULL);

        close(tempfile);
        close(fd[1]);
         _exit(0);

    }
        if(fork()==0){

        int tempfile= open("./executables/Question2/tmpfile",O_WRONLY);
        dup2(tempfile,1);
        execl("./executables/Question2/prog3", "prog3", NULL);
        _exit(0);
    }
    
}