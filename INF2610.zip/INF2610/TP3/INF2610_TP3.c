#include <semaphore.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
// ajouter d’autres imports au besoin…
struct Access
{
    int id_boucle;
    int tid;
    sem_t* semRedarcteur;
    sem_t* semLecteur;
};


void* acces_bd_ecriture(int id_boucle, int tid ) {

    printf("accès en ecriture numero %d à la %deme iteration\n",tid,id_boucle);
return NULL ;
}

void* acces_bd_lecture(int id_boucle, int tid ) {
    printf("accès en lecture numero %d à la %deme iteration\n",tid,id_boucle);
return NULL ;
}

void* acces_bd_ecriture_Wrapper(void* param){
    struct Access* access=(struct Access*) param ;
    sem_wait(access->semRedarcteur);
    acces_bd_ecriture(access->id_boucle,access->tid);
    sem_post(access->semRedarcteur);
    return NULL;
}

void* acces_bd_lecture_Wrapper(void* param){
    struct Access* access=(struct Access*) param ;

    sem_wait(access->semLecteur);
    sem_wait(access->semRedarcteur);
    acces_bd_lecture(access->id_boucle,access->tid);
    sem_post(access->semRedarcteur);
    sem_post(access->semLecteur);
    return NULL;
}
sem_t* init_sem(){
    sem_t* semaphore= calloc(1,sizeof(sem_t));
    sem_init(semaphore,0,1);
    return semaphore;
}


void detruire_sem(sem_t* sem){
    sem_destroy(sem);
    free(sem);
}
/*
Question A-1:

Les accès en ecriture dans la base données modifie sont état donc pour assurer la cohérence des données il faut un seul accès en ecriture.
*/
int main() {

    // Question 2,questions 3

    pthread_t tids[20];
    const int NB_PTHREADS=10;

     sem_t* semRedarcteur=init_sem();
     sem_t* semLecteur=init_sem();

// la boucle pour l'ecriture
    for(int i=0;i<NB_PTHREADS; ++i){
        struct Access access;
        access.tid=tids[i];
        access.id_boucle=i;
        access.semRedarcteur=semRedarcteur;
         access.semLecteur=semLecteur;
        pthread_create(&tids[i],NULL,acces_bd_ecriture_Wrapper,(void*)&access );
    }

// la boucle de lecture  
    for(int i=NB_PTHREADS;i<2*NB_PTHREADS; ++i){
        struct Access access;
        access.tid=tids[i];
        access.id_boucle=i;
        access.semRedarcteur=semRedarcteur;
         access.semLecteur=semLecteur;
        pthread_create(&tids[i],NULL,acces_bd_lecture_Wrapper,(void*)&access );
    }
    

    // les etats de terminaison des fils d'execution
    for(int i=0;i<2*NB_PTHREADS; ++i){
        pthread_join(tids[i],NULL);
    }

  detruire_sem(semRedarcteur);
  detruire_sem(semLecteur);

   exit(0) ;
}