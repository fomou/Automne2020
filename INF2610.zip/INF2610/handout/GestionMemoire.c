#include "./libs/lib.h"
#define TAILLE_PAGE 1024
unsigned int calculerNumeroDePage(unsigned long adresse) {
	// TODO
	return adresse/TAILLE_PAGE;
}

unsigned long calculerDeplacementDansLaPage(unsigned long adresse) {
	// TODO
	return adresse%TAILLE_PAGE;
}

unsigned long calculerAdresseComplete(unsigned int numeroDePage, unsigned long deplacementDansLaPage) {
	// TODO
	return numeroDePage*TAILLE_PAGE+deplacementDansLaPage;
}

void rechercherTLB(struct RequeteMemoire* req, struct SystemeMemoire* mem) {
	
	const int NUM_CHERCHE= calculerNumeroDePage(req->adresseVirtuelle);

	for(int i=0;i<TAILLE_TLB;++i){
		if(NUM_CHERCHE==mem->tlb->numeroPage[i]&&mem->tlb->entreeValide[i]){
			req->adressePhysique=calculerAdresseComplete(mem->tlb->numeroCadre[i],calculerDeplacementDansLaPage(req->adresseVirtuelle));
			req->estDansTLB=1;
			mem->tlb->dernierAcces[i]=req->date;
			return;
			}
		}

	req->adressePhysique=0;
	req->estDansTLB=0;
}

void rechercherTableDesPages(struct RequeteMemoire* req, struct SystemeMemoire* mem) {
	// TODO
	const int NUM_CHERCHE= calculerNumeroDePage(req->adresseVirtuelle);
	
		if(mem->tp->entreeValide[NUM_CHERCHE]){
			req->adressePhysique=calculerAdresseComplete(mem->tp->numeroCadre[NUM_CHERCHE],calculerDeplacementDansLaPage(req->adresseVirtuelle));
			req->estDansTablePages=1;
			return;
		}
	req->adressePhysique=0;
	req->estDansTablePages=0;
}

void ajouterDansMemoire(struct RequeteMemoire* req, struct SystemeMemoire* mem) {
	//TODO
	for(int i=0;i<TAILLE_MEMOIRE;++i){
		if(!mem->memoire->utilisee[i]){
			mem->memoire->utilisee[i]=1;
			mem->memoire->dernierAcces[i]=req->date;
			mem->memoire->dateCreation[i]=req->date;
			req->adressePhysique=calculerAdresseComplete(i,calculerDeplacementDansLaPage(req->adresseVirtuelle));
			
			return;
		}
	}
}

void mettreAJourTLB(struct RequeteMemoire* req, struct SystemeMemoire* mem) {
	// TODO
	
	//ne rien faire si déjà present dans TLB

	if(req->estDansTLB){
		return;
	}

// le tlb n'est pas remplit, on utilise la première case vide et arrêter la fonction 
	for(int i=0;i<TAILLE_TLB;++i){
		if(!mem->tlb->entreeValide[i]){
			mem->tlb->entreeValide[i]=1;
			mem->tlb->numeroPage[i]=calculerNumeroDePage(req->adresseVirtuelle);
			mem->tlb->numeroCadre[i]=calculerNumeroDePage(req->adressePhysique);
			mem->tlb->dateCreation[i]=req->date;
			mem->tlb->dernierAcces[i]=req->date;
			return;
		}
	}

	// trouvons l'index du premier entrée
	int date = mem->tlb->dateCreation[0];
	int index=0;

	for(int i=0;i<TAILLE_TLB;++i){
		if(mem->tlb->dateCreation[i]<date) {
			date=mem->tlb->dateCreation[i]; 
			index=i;
			}
	}

	mem->tlb->entreeValide[index]=1;
	mem->tlb->numeroPage[index]=calculerNumeroDePage(req->adresseVirtuelle);
	mem->tlb->numeroCadre[index]=calculerNumeroDePage(req->adressePhysique);
	mem->tlb->dateCreation[index]=req->date;
	mem->tlb->dernierAcces[index]=req->date;
}

// NE PAS MODIFIER
int main() {
    evaluate(
		&calculerNumeroDePage, 
		&calculerDeplacementDansLaPage, 
		&calculerAdresseComplete, 
        &rechercherTLB, 
		&rechercherTableDesPages,
		&mettreAJourTLB,
		&ajouterDansMemoire
    );
    return 0;
}
