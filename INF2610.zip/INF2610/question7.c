#include<stdio.h>

/*
Écrivez le code nécessaire pour réaliser les actions suivantes :

·       Ouvrir un fichier en mode écriture.

·       Dupliquer le descripteur du fichier ouvert à l’étape précédente

·       Rediriger la sortie standard vers le descripteur dupliqué à l’étape précédente

·       Écrire un message (n’importe quel message) dans le fichier.

·       Transformer le code du processus en exécutant le programme allo prenant en paramètre le PID du processus.

·       Le programme allo se trouve dans le répertoire courant.

·       Le répertoire courant n’est pas enregistré dans le PATH.
*/

int main(){
   int file= open('monfichier',O_WRONLY);

    dup(file);

    char pid[100];
    sprintf(pid,getpid());

    dup2(file,1);

    const char* message="un message de la question 7 de l'intra";

    write(file, message, strlen(message));
    excelp("./allo","allo",pid);
}